
import java.util.Random;

// BlockIce
public final class ZBI extends ng {

    public ZBI() {
        super(79, 67);
        c(0.5F).f(3).a(j).a("ice"); // "ice" * drop the last function.
    }
    
    public int a(Random random) { // only function with random
        return 1;
    }

    public void a(fb fb1, gq gq1, int i1, int j1, int k1, int l1) { // \], 1\); * function in base class
        if(fb1.a(i1, j1 - 1, k1) != 9) // mapGetId
            fb1.c(i1, j1, k1, 0); // search: < 4 \|\| random\.nextInt\(2\) != 0\) && [a-z0-9]+\.[a-z]+\(    * remove the spawned water as we harvested it
        super.a(fb1, gq1, i1, j1, k1, l1); // forward to original
    }
    
}
