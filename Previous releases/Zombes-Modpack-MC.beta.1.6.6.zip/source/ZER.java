
import net.minecraft.client.Minecraft;

// search:  = 32D;
public final class ZER extends pt {

    public ZER(Minecraft minecraft, pt inst) { super(minecraft); c = inst.c; }

    public void b(float f1) {
        super.b(f1);
        ZMod.pingDrawGUIHandle();
    }
    
    // search: environment/snow.png
    protected void c(float f1) {
        if(ZMod.drawRainHandle()) super.c(f1);
    }

}
