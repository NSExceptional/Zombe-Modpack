
// BlockTorch
public final class ZBT extends ve {

    public ZBT() {
        super(50, 80);
        c(0.0F).a(0.9375F).a(e).a("torch"); // "torch" * drop the last function.
    }
    
    public boolean a(fb fb1, int i, int j, int k) {
        if(fb1.a(i, j - 1, k) == 85) return true; // mapGetId
        return super.a(fb1, i, j, k);
    }

}
