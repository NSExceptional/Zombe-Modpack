
// search: [a-z]+ = new [a-z]+\[4\]; * new Objects!
public class ZI extends iu {

    public ZI(gq player) { super(player); } // update
    
    // function with two for loops over inventory and armor
    public void g() {
        if(ZMod.dropAllHandle()) super.g();
    }

}
