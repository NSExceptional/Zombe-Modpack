
public final class ZBFL extends ahh {

    public ZBFL() {
        super(60);
        c(0.6F).a(f).a("farmland"); // "farmland" * drop the last function.
    }

    // EntityWalkingOn: function with  nextFloat  in it
    public void a(World map, int x, int y, int z, Entity ent, float f) {
        return;
    }

}
