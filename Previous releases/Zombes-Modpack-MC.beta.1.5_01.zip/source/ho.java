// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.util.List;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

// search: = -999;
public abstract class ho extends cs {

    protected static final boolean zmodmarker = true;

    public ho(zz do1) {
        a = 176;
        i = 166;
        j = do1;
    }

    public void a() {
        super.a();
        // b.g.h = j; ... can not be arsed to do that properly
        try { b.g.getClass().getField("h").set(b.g, j); } catch(Exception whatever) {}
    }

    public void a(int i1, int j1, float f) {
        i();
        int k1 = (c - a) / 2;
        int l1 = (d - i) / 2;
        a(f);
        GL11.glPushMatrix();
        GL11.glRotatef(180F, 1.0F, 0.0F, 0.0F);
        t.b();
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(k1, l1, 0.0F);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glEnable(32826);
        ge ge1 = null;
        for(int i2 = 0; i2 < j.e.size(); i2++) {
            ge ge2 = (ge)j.e.get(i2);
            a(ge2);
            if(a(ge2, i1, j1)) {
                ge1 = ge2;
                GL11.glDisable(2896);
                GL11.glDisable(2929);
                int j2 = ge2.b;
                int l2 = ge2.c;
                a(j2, l2, j2 + 16, l2 + 16, 0x80ffffff, 0x80ffffff);
                GL11.glEnable(2896);
                GL11.glEnable(2929);
            }
        }

        ih ih1 = b.g.f;
        if(ih1.i() != null) {
            GL11.glTranslatef(0.0F, 0.0F, 32F);
            l.a(g, b.o, ih1.i(), i1 - k1 - 8, j1 - l1 - 8);
            l.b(g, b.o, ih1.i(), i1 - k1 - 8, j1 - l1 - 8);
        }
        GL11.glDisable(32826);
        t.a();
        GL11.glDisable(2896);
        GL11.glDisable(2929);
        k();
        if(ih1.i() == null && ge1 != null && ge1.b()) {
            String s = (new StringBuilder()).append("").append(ml.a().b(ge1.a().l())).toString().trim();
            if(s.length() > 0) {
                int k2 = (i1 - k1) + 12;
                int i3 = j1 - l1 - 12;
                int j3 = g.a(s);
                a(k2 - 3, i3 - 3, k2 + j3 + 3, i3 + 8 + 3, 0xc0000000, 0xc0000000);
                g.a(s, k2, i3, -1);
            }
        }
        GL11.glPopMatrix();
        super.a(i1, j1, f);
        GL11.glEnable(2896);
        GL11.glEnable(2929);
    }

    protected void k() {
    }

    protected abstract void a(float f);

    private void a(ge ge1) {
        int i1 = ge1.b;
        int j1 = ge1.c;
        ii ii1 = ge1.a();
        if(ii1 == null) {
            int k1 = ge1.e();
            if(k1 >= 0) {
                GL11.glDisable(2896);
                b.o.b(b.o.a("/gui/items.png"));
                b(i1, j1, (k1 % 16) * 16, (k1 / 16) * 16, 16, 16);
                GL11.glEnable(2896);
                return;
            }
        }
        l.a(g, b.o, ii1, i1, j1);
        l.b(g, b.o, ii1, i1, j1);
    }

    private ge a(int i1, int j1) {
        for(int k1 = 0; k1 < j.e.size(); k1++) {
            ge ge1 = (ge)j.e.get(k1);
            if(a(ge1, i1, j1))
                return ge1;
        }

        return null;
    }

    private boolean a(ge ge1, int i1, int j1) {
        int k1 = (c - a) / 2;
        int l1 = (d - i) / 2;
        i1 -= k1;
        j1 -= l1;
        return i1 >= ge1.b - 1 && i1 < ge1.b + 16 + 1 && j1 >= ge1.c - 1 && j1 < ge1.c + 16 + 1;
    }

    protected void a(int i1, int j1, int k1) {
        super.a(i1, j1, k1);
        if(k1 == 0 || k1 == 1) {
            ge ge1 = a(i1, j1);
            int l1 = (c - a) / 2;
            int i2 = (d - i) / 2;
            boolean flag = i1 < l1 || j1 < i2 || i1 >= l1 + a || j1 >= i2 + i;
            int j2 = -1;
            if(ge1 != null)
                j2 = ge1.a;
            if(flag)
                j2 = -999;
            if(j2 != -1) {
                boolean flag1 = j2 != -999 && (Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54));
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                int infinite = 1; // yes ... this is horrible hack - sue me
                if(j2==0 && ge1!=null && ge1.getClass()!=ge.class) infinite = ZMod.craftingHandle();
                while(   b.b.a(j.f, j2, k1, flag1 && (infinite == 1), b.g)   != null && --infinite > 0); // FIXME: should be "infinite--"
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            }
        }
    }

    protected void b(int i1, int j1, int k1) {
        if(k1 != 0);
    }

    protected void a(char c, int i1) {
        if(i1 == 1 || i1 == b.y.r.b)
            b.g.r();
    }

    public void h() {
        if(b.g == null) {
            return;
        } else {
            b.b.a(j.f, b.g);
            return;
        }
    }

    public boolean b() {
        return false;
    }

    private static av l = new av();
    protected int a, i;
    public zz j;

}
