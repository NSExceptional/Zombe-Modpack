
public class ZI extends ih {

   public ZI(gh player) { super(player); }
    
    public void g() {
        if(ZMod.dropAllHandle()) super.g();
    }

}
