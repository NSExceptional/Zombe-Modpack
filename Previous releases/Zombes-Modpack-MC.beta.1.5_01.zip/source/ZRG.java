
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.*;
import java.nio.*;

// search: cloud
public class ZRG extends m {

    public ZRG(Minecraft minecraft, ip renderengine) {
        super(minecraft, renderengine);
    }

    public void callSuper(float f) {
        super.b(f);
    }

    // the found cloud is inside this function - it draws the plane clouds and calls fancy clouds also
    public void b(float f) {
        ZMod.pingDrawHandle(f);
    }

    // this is called after matrix setup and before drawing geometry [you find it called in fuction that calls the function setting up matrixes - search: glu]
    public int a(kw par1, int par2, double par3) {
        ZMod.pingStartHandle();
        return super.a(par1, par2, par3);
    }
    
    // called after : glColorMask in the draw-all function
    public void a(bm par1, xd par2, float par3) {
        ZMod.pingItemsHandle();
        super.a(par1, par2, par3);
    }
    
    // called after : glColorMask in the draw-all function
    public void a(int par1, double par2) {
        ZMod.pingGeomHandle();
        super.a(par1, par2);
    }

    // function that does only: ?++;
    public void d() {
        ZMod.pingPreEntHandle();
        super.d();
    }

}
