// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.util.*;
import java.lang.reflect.*;

// EntityPlayer ? search: "humanoid"
public abstract class gh extends kw {

    // ---------------------------------------------------------------------------------------------------------------------------
    protected static boolean zmodmarker = true;
    private static Method flyHandle;
    // moveEntity   : b   ? search: double d9 = 0\.050000000000000003D; - it is in the function
    public final void callSuper(double mx, double my, double mz) { super.b(mx,my,mz); }
    public void b(double mx, double my, double mz) { // ZMod.flyHandle(this,mx,my,mz);
      if(zmodmarker && flyHandle==null) {
          try { flyHandle = Class.forName("ZMod").getDeclaredMethod("flyHandle", new Class[]{Object.class, Double.TYPE, Double.TYPE, Double.TYPE}); }
          catch(Exception whatever) { zmodmarker=false; flyHandle = null; }
      }
      if(flyHandle!=null) try { flyHandle.invoke(null, new Object[]{this, mx, my, mz}); } catch(Exception whatever) { flyHandle = null; callSuper(mx,my,mz); }
      else callSuper(mx,my,mz);
    }
    // ---------------------------------------------------------------------------------------------------------------------------


    public gh(et et1) {
        super(et1);
        f = new ih(this);
        i = 0;
        j = 0;
        m = false;
        n = 0;
        e = 0;
        B = null;
        g = new y(f, !et1.v);
        h = g;
        bd = 1.62F;
        bk bk1 = et1.u();
        c((double)bk1.a + 0.5D, bk1.b + 1, (double)bk1.c + 0.5D, 0.0F, 0.0F);
        W = 20;
        P = "humanoid";
        O = 180F;
        bs = 20;
        M = "/mob/char.png";
    }

    protected void b() {
        super.b();
        bB.a(16, Byte.valueOf((byte)0));
    }

    public void w_() {
        if(O()) {
            b++;
            if(b > 100)
                b = 100;
            if(!am())
                a(true, true, false);
            else
            if(!aG.v && aG.f())
                a(false, true, true);
        } else
        if(b > 0) {
            b++;
            if(b >= 110)
                b = 0;
        }
        super.w_();
        if(!aG.v && h != null && !h.b(this)) {
            r();
            h = g;
        }
        r = u;
        s = v;
        t = w;
        double d1 = aK - u;
        double d2 = aL - v;
        double d3 = aM - w;
        double d4 = 10D;
        if(d1 > d4)
            r = u = aK;
        if(d3 > d4)
            t = w = aM;
        if(d2 > d4)
            s = v = aL;
        if(d1 < -d4)
            r = u = aK;
        if(d3 < -d4)
            t = w = aM;
        if(d2 < -d4)
            s = v = aL;
        u += d1 * 0.25D;
        w += d3 * 0.25D;
        v += d2 * 0.25D;
        a(is.k, 1);
        if(aF == null)
            d = null;
    }

    protected boolean z() {
        return W <= 0 || O();
    }

    protected void r() {
        h = g;
    }

    public void u_() {
        q = (new StringBuilder()).append("http://s3.amazonaws.com/MinecraftCloaks/").append(o).append(".png").toString();
        bz = q;
    }

    public void s_() {
        double d1 = aK;
        double d2 = aL;
        double d3 = aM;
        super.s_();
        k = l;
        l = 0.0F;
        i(aK - d1, aL - d2, aM - d3);
    }

    public void t_() {
        bd = 1.62F;
        b(0.6F, 1.8F);
        super.t_();
        W = 20;
        ab = 0;
    }

    protected void e_() {
        if(m) {
            n++;
            if(n == 8) {
                n = 0;
                m = false;
            }
        } else {
            n = 0;
        }
        V = (float)n / 8F;
    }

    public void o() {
        if(aG.l == 0 && W < 20 && (br % 20) * 12 == 0)
            c(1);
        f.e();
        k = l;
        super.o();
        float f1 = hy.a(aN * aN + aP * aP);
        float f2 = (float)Math.atan(-aO * 0.20000000298023224D) * 15F;
        if(f1 > 0.1F)
            f1 = 0.1F;
        if(!aV || W <= 0)
            f1 = 0.0F;
        if(aV || W <= 0)
            f2 = 0.0F;
        l += (f1 - l) * 0.4F;
        ae += (f2 - ae) * 0.8F;
        if(W > 0) {
            List list = aG.b(this, aU.b(1.0D, 0.0D, 1.0D));
            if(list != null) {
                for(int i1 = 0; i1 < list.size(); i1++) {
                    rj rj1 = (rj)list.get(i1);
                    if(!rj1.bc)
                        j(rj1);
                }

            }
        }
    }

    private void j(rj rj1) {
        rj1.b(this);
    }

    public int D() {
        return j;
    }

    public void b(rj rj1) {
        super.b(rj1);
        b(0.2F, 0.2F);
        c(aK, aL, aM);
        aO = 0.10000000149011612D;
        if(o.equals("Notch"))
            a(new ii(gb.h, 1), true);
        f.g();
        if(rj1 != null) {
            aN = -hy.b(((aa + aQ) * 3.141593F) / 180F) * 0.1F;
            aP = -hy.a(((aa + aQ) * 3.141593F) / 180F) * 0.1F;
        } else {
            aN = aP = 0.0D;
        }
        bd = 0.1F;
        a(is.y, 1);
    }

    public void c(rj rj1, int i1) {
        j += i1;
        if(rj1 instanceof gh)
            a(is.A, 1);
        else
            a(is.z, 1);
    }

    public void E() {
        a(f.a(f.c, 1), false);
    }

    public void a(ii ii1) {
        a(ii1, false);
    }

    public void a(ii ii1, boolean flag) {
        if(ii1 == null)
            return;
        gz gz1 = new gz(aG, aK, (aL - 0.30000001192092896D) + (double)x(), aM, ii1);
        gz1.c = 40;
        float f1 = 0.1F;
        if(flag) {
            float f3 = bq.nextFloat() * 0.5F;
            float f5 = bq.nextFloat() * 3.141593F * 2.0F;
            gz1.aN = -hy.a(f5) * f3;
            gz1.aP = hy.b(f5) * f3;
            gz1.aO = 0.20000000298023224D;
        } else {
            float f2 = 0.3F;
            gz1.aN = -hy.a((aQ / 180F) * 3.141593F) * hy.b((aR / 180F) * 3.141593F) * f2;
            gz1.aP = hy.b((aQ / 180F) * 3.141593F) * hy.b((aR / 180F) * 3.141593F) * f2;
            gz1.aO = -hy.a((aR / 180F) * 3.141593F) * f2 + 0.1F;
            f2 = 0.02F;
            float f4 = bq.nextFloat() * 3.141593F * 2.0F;
            f2 *= bq.nextFloat();
            gz1.aN += Math.cos(f4) * (double)f2;
            gz1.aO += (bq.nextFloat() - bq.nextFloat()) * 0.1F;
            gz1.aP += Math.sin(f4) * (double)f2;
        }
        a(gz1);
        a(is.v, 1);
    }

    protected void a(gz gz1) {
        aG.b(gz1);
    }

    public float a(to to1) {
        float f1 = f.a(to1);
        if(a(kr.f))
            f1 /= 5F;
        if(!aV)
            f1 /= 5F;
        return f1;
    }

    public boolean b(to to1) {
        return f.b(to1);
    }

    public void a(my my1) {
        super.a(my1);
        rl rl1 = my1.l("Inventory");
        f.b(rl1);
        p = my1.e("Dimension");
        x = my1.m("Sleeping");
        b = my1.d("SleepTimer");
        if(x) {
            a = new bk(hy.b(aK), hy.b(aL), hy.b(aM));
            a(true, true, false);
        }
        if(my1.b("SpawnX") && my1.b("SpawnY") && my1.b("SpawnZ"))
            c = new bk(my1.e("SpawnX"), my1.e("SpawnY"), my1.e("SpawnZ"));
    }

    public void b(my my1) {
        super.b(my1);
        my1.a("Inventory", f.a(new rl()));
        my1.a("Dimension", p);
        my1.a("Sleeping", x);
        my1.a("SleepTimer", (short)b);
        if(c != null) {
            my1.a("SpawnX", c.a);
            my1.a("SpawnY", c.b);
            my1.a("SpawnZ", c.c);
        }
    }

    public void a(la la) {
    }

    public void a(int i1, int j1, int k1) {
    }

    public void b(rj rj1, int i1) {
    }

    public float x() {
        return 0.12F;
    }

    protected void F() {
        bd = 1.62F;
    }

    public boolean a(rj rj1, int i1) {
        at = 0;
        if(W <= 0)
            return false;
        if(O())
            a(true, true, false);
        if((rj1 instanceof go) || (rj1 instanceof rh)) {
            if(aG.l == 0)
                i1 = 0;
            if(aG.l == 1)
                i1 = i1 / 3 + 1;
            if(aG.l == 3)
                i1 = (i1 * 3) / 2;
        }
        if(i1 == 0)
            return false;
        Object obj = rj1;
        if((obj instanceof rh) && ((rh)obj).b != null)
            obj = ((rh)obj).b;
        if(obj instanceof kw)
            a((kw)obj, false);
        a(is.x, i1);
        return super.a(rj1, i1);
    }

    protected boolean G() {
        return false;
    }

    protected void a(kw kw1, boolean flag) {
        if((kw1 instanceof fq) || (kw1 instanceof bi))
            return;
        if(kw1 instanceof fx) {
            fx fx1 = (fx)kw1;
            if(fx1.E() && o.equals(fx1.B()))
                return;
        }
        if((kw1 instanceof gh) && !G())
            return;
        List list = aG.a(fx.class, eg.b(aK, aL, aM, aK + 1.0D, aL + 1.0D, aM + 1.0D).b(16D, 4D, 16D));
        Iterator iterator = list.iterator();
        do {
            if(!iterator.hasNext())
                break;
            rj rj1 = (rj)iterator.next();
            fx fx2 = (fx)rj1;
            if(fx2.E() && fx2.G() == null && o.equals(fx2.B()) && (!flag || !fx2.C())) {
                fx2.b(false);
                fx2.c(kw1);
            }
        } while(true);
    }

    protected void b(int i1) {
        int j1 = 25 - f.f();
        int k1 = i1 * j1 + e;
        f.e(i1);
        i1 = k1 / 25;
        e = k1 % 25;
        super.b(i1);
    }

    public void a(rg rg) {
    }

    public void a(at at) {
    }

    public void a(xa xa) {
    }

    public void c(rj rj1) {
        if(rj1.a(this))
            return;
        ii ii1 = H();
        if(ii1 != null && (rj1 instanceof kw)) {
            ii1.a((kw)rj1);
            if(ii1.a <= 0) {
                ii1.a(this);
                I();
            }
        }
    }

    public ii H() {
        return f.b();
    }

    public void I() {
        f.a(f.c, null);
    }

    public double J() {
        return (double)(bd - 0.5F);
    }

    public void K() {
        n = -1;
        m = true;
    }

    public void d(rj rj1) {
        int i1 = f.a(rj1);
        if(i1 > 0) {
            if(aO < 0.0D)
                i1++;
            rj1.a(this, i1);
            ii ii1 = H();
            if(ii1 != null && (rj1 instanceof kw)) {
                ii1.a((kw)rj1, this);
                if(ii1.a <= 0) {
                    ii1.a(this);
                    I();
                }
            }
            if(rj1 instanceof kw) {
                if(rj1.W())
                    a((kw)rj1, true);
                a(is.w, i1);
            }
        }
    }

    public void o_() {
    }

    public abstract void w();

    public void b(ii ii1) {
    }

    public void L() {
        super.L();
        g.a(this);
        if(h != null)
            h.a(this);
    }

    public boolean M() {
        return !x && super.M();
    }

    public co b(int i1, int j1, int k1) {
        if(O() || !W())
            return co.e;
        if(aG.o.c)
            return co.b;
        if(aG.f())
            return co.c;
        if(Math.abs(aK - (double)i1) > 3D || Math.abs(aL - (double)j1) > 2D || Math.abs(aM - (double)k1) > 3D)
            return co.d;
        b(0.2F, 0.2F);
        bd = 0.2F;
        if(aG.h(i1, j1, k1)) {
            int l1 = aG.e(i1, j1, k1);
            int i2 = tx.c(l1);
            float f1 = 0.5F;
            float f2 = 0.5F;
            switch(i2) {
            case 0: // '\0'
                f2 = 0.9F;
                break;

            case 2: // '\002'
                f2 = 0.1F;
                break;

            case 1: // '\001'
                f1 = 0.1F;
                break;

            case 3: // '\003'
                f1 = 0.9F;
                break;
            }
            e(i2);
            c((float)i1 + f1, (float)j1 + 0.9375F, (float)k1 + f2);
        } else {
            c((float)i1 + 0.5F, (float)j1 + 0.9375F, (float)k1 + 0.5F);
        }
        x = true;
        b = 0;
        a = new bk(i1, j1, k1);
        aN = aP = aO = 0.0D;
        if(!aG.v)
            aG.y();
        return co.a;
    }

    private void e(int i1) {
        y = 0.0F;
        A = 0.0F;
        switch(i1) {
        case 0: // '\0'
            A = -1.8F;
            break;

        case 2: // '\002'
            A = 1.8F;
            break;

        case 1: // '\001'
            y = 1.8F;
            break;

        case 3: // '\003'
            y = -1.8F;
            break;
        }
    }

    public void a(boolean flag, boolean flag1, boolean flag2) {
        b(0.6F, 1.8F);
        F();
        bk bk1 = a;
        bk bk2 = a;
        if(bk1 != null && aG.a(bk1.a, bk1.b, bk1.c) == to.S.bl) {
            tx.a(aG, bk1.a, bk1.b, bk1.c, false);
            bk bk3 = tx.f(aG, bk1.a, bk1.b, bk1.c, 0);
            if(bk3 == null)
                bk3 = new bk(bk1.a, bk1.b + 1, bk1.c);
            c((float)bk3.a + 0.5F, (float)bk3.b + bd + 0.1F, (float)bk3.c + 0.5F);
        }
        x = false;
        if(!aG.v && flag1)
            aG.y();
        if(flag)
            b = 0;
        else
            b = 100;
        if(flag2)
            a(a);
    }

    private boolean am() {
        return aG.a(a.a, a.b, a.c) == to.S.bl;
    }

    public static bk a(et et1, bk bk1) {
        cf cf1 = et1.w();
        cf1.c(bk1.a - 3 >> 4, bk1.c - 3 >> 4);
        cf1.c(bk1.a + 3 >> 4, bk1.c - 3 >> 4);
        cf1.c(bk1.a - 3 >> 4, bk1.c + 3 >> 4);
        cf1.c(bk1.a + 3 >> 4, bk1.c + 3 >> 4);
        if(et1.a(bk1.a, bk1.b, bk1.c) != to.S.bl) {
            return null;
        } else {
            bk bk2 = tx.f(et1, bk1.a, bk1.b, bk1.c, 0);
            return bk2;
        }
    }

    public float N() {
        if(a != null) {
            int i1 = aG.e(a.a, a.b, a.c);
            int j1 = tx.c(i1);
            switch(j1) {
            case 0: // '\0'
                return 90F;

            case 1: // '\001'
                return 0.0F;

            case 2: // '\002'
                return 270F;

            case 3: // '\003'
                return 180F;
            }
        }
        return 0.0F;
    }

    public boolean O() {
        return x;
    }

    public boolean P() {
        return x && b >= 100;
    }

    public int Q() {
        return b;
    }

    public void b(String s1) {
    }

    public bk R() {
        return c;
    }

    public void a(bk bk1) {
        if(bk1 != null)
            c = new bk(bk1);
        else
            c = null;
    }

    public void a(uk uk) {
        a(uk, 1);
    }

    public void a(uk uk, int i1) {
    }

    protected void S() {
        super.S();
        a(is.u, 1);
    }

    public void a_(float f1, float f2) {
        double d1 = aK;
        double d2 = aL;
        double d3 = aM;
        super.a_(f1, f2);
        h(aK - d1, aL - d2, aM - d3);
    }

    private void h(double d1, double d2, double d3) {
        if(aF != null)
            return;
        if(a(kr.f)) {
            int i1 = Math.round(hy.a(d1 * d1 + d2 * d2 + d3 * d3) * 100F);
            if(i1 > 0)
                a(is.q, i1);
        } else
        if(ag()) {
            int j1 = Math.round(hy.a(d1 * d1 + d3 * d3) * 100F);
            if(j1 > 0)
                a(is.m, j1);
        } else
        if(p()) {
            if(d2 > 0.0D)
                a(is.o, (int)Math.round(d2 * 100D));
        } else
        if(aV) {
            int k1 = Math.round(hy.a(d1 * d1 + d3 * d3) * 100F);
            if(k1 > 0)
                a(is.l, k1);
        } else {
            int l1 = Math.round(hy.a(d1 * d1 + d3 * d3) * 100F);
            if(l1 > 25)
                a(is.p, l1);
        }
    }

    private void i(double d1, double d2, double d3) {
        if(aF != null) {
            int i1 = Math.round(hy.a(d1 * d1 + d2 * d2 + d3 * d3) * 100F);
            if(i1 > 0)
                if(aF instanceof xb) {
                    a(is.r, i1);
                    if(d == null)
                        d = new bk(hy.b(aK), hy.b(aL), hy.b(aM));
                    else
                    if(d.a(hy.b(aK), hy.b(aL), hy.b(aM)) >= 1000D)
                        a(ef.q, 1);
                } else
                if(aF instanceof fo)
                    a(is.s, i1);
                else
                if(aF instanceof va)
                    a(is.t, i1);
        }
    }

    protected void b(float f1) {
        if(f1 >= 2.0F)
            a(is.n, (int)Math.round((double)f1 * 100D));
        super.b(f1);
    }

    public void a(kw kw1) {
        if(kw1 instanceof go)
            a(((uk) (ef.s)));
    }

    public ih f;
    public zz g, h;
    public byte i;
    public int j, n, p;
    public float k, l, y, z, A;
    public boolean m;
    public String o, q;
    public double r, s, t, u, v;
    public double w;
    protected boolean x;
    private bk a, c, d;
    private int b, e;
    public lb B;
}
