// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nolvt nonlb safe
// Source File Name:   SourceFile

import net.minecraft.client.Minecraft;

// NEED TO DECOMPILE SEPARATELY WITH SAFE MODE ON
public class abn extends jf {

    protected static final boolean zmodmarker = true;

    public abn(Minecraft minecraft) {
        super(minecraft);
        c = -1;
        d = -1;
        e = -1;
        f = 0.0F;
        g = 0.0F;
        h = 0.0F;
        i = 0;
    }

    public void a(wd wd1) {
        wd1.u = -180F;
    }

    public boolean d() {
        return true;
    }

    public boolean b(int k, int l, int i1, int j1) {
        int k1 = a.f.a(k, l, i1);
        int l1 = a.f.e(k, l, i1);
        boolean flag = super.b(k, l, i1, j1);
        xs xs1 = a.h.as();
        boolean flag1 = a.h.b(no.m[k1]);
        // -----------------------------------------------------------------------------------------------------------------------
        flag = ZMod.harvestableHandle(flag);
        // -----------------------------------------------------------------------------------------------------------------------
        if(xs1 != null) {
            xs1.a(k1, k, l, i1, ((wd) (a.h)));
            if(xs1.a == 0) {
                xs1.a(((wd) (a.h)));
                a.h.at();
            }
        }
        if(flag && flag1)
            no.m[k1].a(a.f, ((wd) (a.h)), k, l, i1, l1);
        return flag;
    }

    public void a(int k, int l, int i1, int j1) {
        if(!a.h.e(k, l, i1))
            return;
        a.f.a(((wd) (a.h)), k, l, i1, j1);
        int k1 = a.f.a(k, l, i1);
        if(k1 > 0 && f == 0.0F)
            no.m[k1].a(a.f, k, l, i1, ((wd) (a.h)));
        if(k1 > 0 && no.m[k1].a(((wd) (a.h))) >= 1.0F)
            b(k, l, i1, j1);
    }

    public void a() {
        f = 0.0F;
        i = 0;
    }

    public void c(int k, int l, int i1, int j1) {
        if(i > 0) {
            i--;
            return;
        }
        if(k == c && l == d && i1 == e) {
            int k1 = a.f.a(k, l, i1);
            if(!a.h.e(k, l, i1))
                return;
            if(k1 == 0)
                return;
            no no1 = no.m[k1];
            // -------------------------------------------------------------------------------------------------------------------
            float add;
            f += add = ZMod.digProgressHandle(  no1.a(((wd) (a.h)))  , k1 );
            int skip = add > 1.0f ? (int)(6f / add - 0.99999f) : 5;
            // -------------------------------------------------------------------------------------------------------------------
            if(h % 4F == 0.0F && no1 != null)
                a.C.b(no1.bY.d(), (float)k + 0.5F, (float)l + 0.5F, (float)i1 + 0.5F, (no1.bY.b() + 1.0F) / 8F, no1.bY.c() * 0.5F);
            h++;
            if(f >= 1.0F) {
                b(k, l, i1, j1);
                f = 0.0F;
                g = 0.0F;
                h = 0.0F;
                i = skip; // ****** UPDATE ******
            }
        } else {
            f = 0.0F;
            g = 0.0F;
            h = 0.0F;
            c = k;
            d = l;
            e = i1;
        }
    }

    public void a(float f1) {
        if(f <= 0.0F) {
            a.w.b = 0.0F;
            a.g.g = 0.0F;
        } else {
            float f2 = g + (f - g) * f1;
            a.w.b = f2;
            a.g.g = f2;
        }
    }

    public float b() {
        // -----------------------------------------------------------------------------------------------------------------------
        return ZMod.digReachHandle();
        // -----------------------------------------------------------------------------------------------------------------------
    }

    public void a(uu uu1) {
        super.a(uu1);
    }

    public wd b(uu uu1) {
        wd wd1 = super.b(uu1);
        return wd1;
    }

    public void c() {
        g = f;
        a.C.c();
    }

    public boolean a(wd wd1, uu uu1, xs xs1, int k, int l, int i1, int j1) {
        int k1 = uu1.a(k, l, i1);
        if(k1 > 0 && no.m[k1].b(uu1, k, l, i1, wd1))
            return true;
        if(xs1 == null)
            return false;
        else
            return xs1.a(wd1, uu1, k, l, i1, j1);
    }

    public boolean f() {
        return true;
    }

    private int c, d, e, i;
    private float f, g, h;
}
