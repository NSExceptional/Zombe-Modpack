// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb
// Source File Name:   SourceFile

import java.util.*;
import java.lang.reflect.*;

public abstract class wd extends zs {

    public static Method getClassMethod(String c, String m, Class param[]) { try { return Class.forName(c).getMethod(m, param); } catch(Exception e) { e.printStackTrace(); return null; } }
    public static Field getClassField(String c, String m) { try { return Class.forName(c).getField(m); } catch(Exception e) { e.printStackTrace(); return null; } }
    public static Object getResult(Method m, Object obj, Object param[]) { try { return m.invoke(obj, param); } catch(Exception whatever) { } return null; }
    public static Object getValue(Field field, Object obj) { try { return field.get(obj); } catch(Exception whatever) { } return null; }

    // ---------------------------------------------------------------------------------------------------------------------------
    protected static boolean zmodmarker = true;
    private static Method flyHandle, flyCancel, flyJump;
    public final void callSuper(double mx, double my, double mz) { super.entMove(mx,my,mz); }
    private static void flyInitialize() {
        try {
            Class mod = Class.forName("ZMod");
            flyHandle = mod.getDeclaredMethod("flyHandle", new Class[]{Object.class, Double.TYPE, Double.TYPE, Double.TYPE});
            flyCancel = mod.getDeclaredMethod("flyDickmoveCancel", new Class[]{});
            flyJump = mod.getDeclaredMethod("flyJumpHandle", new Class[]{});
        } catch(Exception whatever) { zmodmarker=false; flyHandle = flyCancel = null; }
    }
    public void entMove(double mx, double my, double mz) { // ZMod.flyHandle(this,mx,my,mz);
        if(zmodmarker && flyHandle==null) flyInitialize();
        if(flyHandle!=null) try { flyHandle.invoke(null, new Object[]{this, mx, my, mz}); } catch(Exception whatever) { flyHandle = null; callSuper(mx,my,mz); }
        else callSuper(mx,my,mz);
    }

    // this thing is in this class: add first variable (noclip)
    public boolean M() {
        return !entNoClip && !aM && super.M();
    }

    // ... as is this: first chance to undo the dickmove
    public void d() {
        if(zmodmarker && flyCancel==null) flyInitialize(); if(flyCancel!=null) try { flyCancel.invoke(null, new Object[]{}); } catch(Exception whatever) {} // undo.
        if(av > 0)
            av--;
        if(k.v == 0 && aH() < c() && (V % 20) * 12 == 0)
            j(1);
        ar.g();
        ay = az;
        super.d();
        bu = aZ;
        bv = ba;
        if(V()) {
            bu += (double)aZ * 0.29999999999999999D;
            bv += (double)ba * 0.29999999999999999D;
        }
        float f1 = fp.a(r * r + t * t);
        float f2 = (float)Math.atan(-s * 0.20000000298023224D) * 15F;
        if(f1 > 0.1F)
            f1 = 0.1F;
        if(!z || aH() <= 0)
            f1 = 0.0F;
        if(z || aH() <= 0)
            f2 = 0.0F;
        az += (f1 - az) * 0.4F;
        bH += (f2 - bH) * 0.8F;
        if(aH() > 0) {
            List list = k.b(this, y.b(1.0D, 0.0D, 1.0D));
            if(list != null) {
                for(int j = 0; j < list.size(); j++) {
                    md md1 = (md)list.get(j);
                    if(!md1.G)
                        k(md1);
                }

            }
        }
    }

    // ... as is this. search: 0.8F
    protected void aA() {
        super.aA();
        // -----------------------------------------------------------------------------------------------------------------------
        double jump = 1.0D;
        if(flyJump != null) try {
            jump = (Double)flyJump.invoke(null, new Object[]{});
        } catch(Exception whatever) {
            flyJump = null;
            jump = 1.0D;
        }
        entMotionY *= jump;
        // -----------------------------------------------------------------------------------------------------------------------
        a(ga.u, 1);
        if(V())
            d(0.8F);
        else
            d(0.2F);
    }
    // ---------------------------------------------------------------------------------------------------------------------------

    public wd(uu uu1) {
        super(uu1);
        ar = new xp(this);
        au = new lw();
        av = 0;
        aw = 0;
        ax = 0;
        aA = false;
        aB = 0;
        aF = 0;
        aR = 20;
        aS = false;
        aV = new pf();
        aZ = 0.1F;
        ba = 0.02F;
        bb = null;
        as = new t(ar, !uu1.I);
        at = as;
        H = 1.62F;
        sj sj1 = uu1.v();
        c((double)sj1.a + 0.5D, sj1.b + 1, (double)sj1.c + 0.5D, 0.0F, 0.0F);
        bp = "humanoid";
        bo = 180F;
        W = 20;
        bm = "/mob/char.png";
    }

    public int c() {
        return 20;
    }

    protected void b() {
        super.b();
        ae.a(16, Byte.valueOf((byte)0));
        ae.a(17, Byte.valueOf((byte)0));
    }

    public xs af() {
        return d;
    }

    public int ag() {
        return e;
    }

    public boolean ah() {
        return d != null;
    }

    public int ai() {
        if(ah())
            return d.l() - e;
        else
            return 0;
    }

    public void aj() {
        if(d != null)
            d.a(k, this, e);
        ak();
    }

    public void ak() {
        d = null;
        e = 0;
        if(!k.I)
            c(false);
    }

    public boolean al() {
        return ah() && vy.e[d.c].c(d) == xv.d;
    }

    public void B_() {
        if(d != null) {
            xs xs1 = ar.b();
            if(xs1 != d) {
                ak();
            } else {
                if(e <= 25 && e % 4 == 0)
                    a(xs1, 5);
                if(--e == 0 && !k.I)
                    am();
            }
        }
        if(aF > 0)
            aF--;
        if(aw()) {
            a++;
            if(a > 100)
                a = 100;
            if(!k.I)
                if(!aR())
                    a(true, true, false);
                else
                if(k.l())
                    a(false, true, true);
        } else
        if(a > 0) {
            a++;
            if(a >= 110)
                a = 0;
        }
        super.B_();
        if(!k.I && at != null && !at.b(this)) {
            ac();
            at = as;
        }
        if(aV.b) {
            for(int j = 0; j < 8; j++);
        }
        if(S() && aV.a)
            B();
        aG = aJ;
        aH = aK;
        aI = aL;
        double d1 = o - aJ;
        double d2 = p - aK;
        double d3 = q - aL;
        double d4 = 10D;
        if(d1 > d4)
            aG = aJ = o;
        if(d3 > d4)
            aI = aL = q;
        if(d2 > d4)
            aH = aK = p;
        if(d1 < -d4)
            aG = aJ = o;
        if(d3 < -d4)
            aI = aL = q;
        if(d2 < -d4)
            aH = aK = p;
        aJ += d1 * 0.25D;
        aL += d3 * 0.25D;
        aK += d2 * 0.25D;
        a(ga.k, 1);
        if(this.j == null)
            c = null;
        if(!k.I)
            au.a(this);
    }

    // WORKAROUND
    Method be_b = getClassMethod("be", "b", new Class[]{Double.TYPE, Double.TYPE, Double.TYPE});
    protected void a(xs xs1, int j) {
        if(xs1.m() == xv.b) {
            for(int l = 0; l < j; l++) {
                be be1 = (be)getResult(be_b, null, new Object[]{((double)U.nextFloat() - 0.5D) * 0.10000000000000001D, Math.random() * 0.10000000000000001D + 0.10000000000000001D, 0.0D});
                //be be1 = be.b(((double)U.nextFloat() - 0.5D) * 0.10000000000000001D, Math.random() * 0.10000000000000001D + 0.10000000000000001D, 0.0D);
                be1.a((-v * 3.141593F) / 180F);
                be1.b((-u * 3.141593F) / 180F);
                be be2 = (be)getResult(be_b, null, new Object[]{((double)U.nextFloat() - 0.5D) * 0.29999999999999999D, (double)(-U.nextFloat()) * 0.59999999999999998D - 0.29999999999999999D, 0.59999999999999998D});
                //be be2 = be.b(((double)U.nextFloat() - 0.5D) * 0.29999999999999999D, (double)(-U.nextFloat()) * 0.59999999999999998D - 0.29999999999999999D, 0.59999999999999998D);
                be2.a((-v * 3.141593F) / 180F);
                be2.b((-u * 3.141593F) / 180F);
                be2 = be2.c(o, p + (double)G(), q);
                k.a((new StringBuilder()).append("iconcrack_").append(xs1.a().bN).toString(), be2.a, be2.b, be2.c, be1.a, be1.b + 0.050000000000000003D, be1.c);
            }

            k.a(this, "mob.eat", 0.5F + 0.5F * (float)U.nextInt(2), (U.nextFloat() - U.nextFloat()) * 0.2F + 1.0F);
        }
    }

    protected void am() {
        if(d != null) {
            a(d, 16);
            int j = d.a;
            xs xs1 = d.b(k, this);
            if(xs1 != d || xs1 != null && xs1.a != j) {
                ar.a[ar.c] = xs1;
                if(xs1.a == 0)
                    ar.a[ar.c] = null;
            }
            ak();
        }
    }

    public void a(byte byte0) {
        if(byte0 == 9)
            am();
        else
            super.a(byte0);
    }

    protected boolean an() {
        return aH() <= 0 || aw();
    }

    protected void ac() {
        at = as;
    }

    public void R() {
        aE = (new StringBuilder()).append("http://s3.amazonaws.com/MinecraftCloaks/").append(aC).append(".png").toString();
        ac = aE;
    }

    public void N() {
        double d1 = o;
        double d2 = p;
        double d3 = q;
        super.N();
        ay = az;
        az = 0.0F;
        k(o - d1, p - d2, q - d3);
    }

    public void x() {
        H = 1.62F;
        a(0.6F, 1.8F);
        super.x();
        k(c());
        bE = 0;
    }

    private int aQ() {
        if(a(xi.e))
            return 6 - (1 + b(xi.e).c()) * 1;
        if(a(xi.f))
            return 6 + (1 + b(xi.f).c()) * 2;
        else
            return 6;
    }

    protected void t_() {
        int j = aQ();
        if(aA) {
            aB++;
            if(aB >= j) {
                aB = 0;
                aA = false;
            }
        } else {
            aB = 0;
        }
        bx = (float)aB / (float)j;
    }

    private void k(md md1) {
        md1.a(this);
    }

    public int ao() {
        return ax;
    }

    public void a(ky ky1) {
        super.a(ky1);
        a(0.2F, 0.2F);
        d(o, p, q);
        s = 0.10000000149011612D;
        if(aC.equals("Notch"))
            a(new xs(vy.j, 1), true);
        ar.i();
        if(ky1 != null) {
            r = -fp.b(((bD + u) * 3.141593F) / 180F) * 0.1F;
            t = -fp.a(((bD + u) * 3.141593F) / 180F) * 0.1F;
        } else {
            r = t = 0.0D;
        }
        H = 0.1F;
        a(ga.y, 1);
    }

    public void a(md md1, int j) {
        ax += j;
        if(md1 instanceof wd)
            a(ga.A, 1);
        else
            a(ga.z, 1);
    }

    protected int f(int j) {
        int l = afi.a(ar);
        if(l > 0 && U.nextInt(l + 1) > 0)
            return j;
        else
            return super.f(j);
    }

    public void ap() {
        a(ar.a(ar.c, 1), false);
    }

    public void a(xs xs1) {
        a(xs1, false);
    }

    public void a(xs xs1, boolean flag) {
        if(xs1 == null)
            return;
        ey ey1 = new ey(k, o, (p - 0.30000001192092896D) + (double)G(), q, xs1);
        ey1.c = 40;
        float f1 = 0.1F;
        if(flag) {
            float f3 = U.nextFloat() * 0.5F;
            float f5 = U.nextFloat() * 3.141593F * 2.0F;
            ey1.r = -fp.a(f5) * f3;
            ey1.t = fp.b(f5) * f3;
            ey1.s = 0.20000000298023224D;
        } else {
            float f2 = 0.3F;
            ey1.r = -fp.a((u / 180F) * 3.141593F) * fp.b((v / 180F) * 3.141593F) * f2;
            ey1.t = fp.b((u / 180F) * 3.141593F) * fp.b((v / 180F) * 3.141593F) * f2;
            ey1.s = -fp.a((v / 180F) * 3.141593F) * f2 + 0.1F;
            f2 = 0.02F;
            float f4 = U.nextFloat() * 3.141593F * 2.0F;
            f2 *= U.nextFloat();
            ey1.r += Math.cos(f4) * (double)f2;
            ey1.s += (U.nextFloat() - U.nextFloat()) * 0.1F;
            ey1.t += Math.sin(f4) * (double)f2;
        }
        a(ey1);
        a(ga.v, 1);
    }

    protected void a(ey ey1) {
        k.a(ey1);
    }

    public float a(no no1) {
        float f1 = ar.a(no1);
        float f2 = f1;
        int j = afi.b(ar);
        if(j > 0 && f1 > 1.0F)
            f2 += j * j + 1;
        if(a(xi.e))
            f2 *= 1.0F + (float)(b(xi.e).c() + 1) * 0.2F;
        if(a(xi.f))
            f2 *= 1.0F - (float)(b(xi.f).c() + 1) * 0.2F;
        if(a(zo.g) && !afi.g(ar))
            f2 /= 5F;
        if(!z)
            f2 /= 5F;
        return f2;
    }

    public boolean b(no no1) {
        return ar.b(no1);
    }

    public void a(aav aav1) {
        super.a(aav1);
        mf mf1 = aav1.m("Inventory");
        ar.b(mf1);
        aD = aav1.f("Dimension");
        aM = aav1.n("Sleeping");
        a = aav1.e("SleepTimer");
        aY = aav1.h("XpP");
        aW = aav1.f("XpLevel");
        aX = aav1.f("XpTotal");
        if(aM) {
            aN = new sj(fp.c(o), fp.c(p), fp.c(q));
            a(true, true, false);
        }
        if(aav1.c("SpawnX") && aav1.c("SpawnY") && aav1.c("SpawnZ"))
            b = new sj(aav1.f("SpawnX"), aav1.f("SpawnY"), aav1.f("SpawnZ"));
        au.a(aav1);
        aV.b(aav1);
    }

    public void b(aav aav1) {
        super.b(aav1);
        aav1.a("Inventory", ar.a(new mf()));
        aav1.a("Dimension", aD);
        aav1.a("Sleeping", aM);
        aav1.a("SleepTimer", (short)a);
        aav1.a("XpP", aY);
        aav1.a("XpLevel", aW);
        aav1.a("XpTotal", aX);
        if(b != null) {
            aav1.a("SpawnX", b.a);
            aav1.a("SpawnY", b.b);
            aav1.a("SpawnZ", b.c);
        }
        au.b(aav1);
        aV.a(aav1);
    }

    public void a(hq hq) {
    }

    public void c(int j, int l, int i1) {
    }

    public void a(int j, int l, int i1) {
    }

    public void b(md md1, int j) {
    }

    public float G() {
        return 0.12F;
    }

    protected void Y() {
        H = 1.62F;
    }

    public boolean a(ky ky1, int j) {
        if(aV.a && !ky1.f())
            return false;
        cc = 0;
        if(aH() <= 0)
            return false;
        if(aw() && !k.I)
            a(true, true, false);
        md md1 = ky1.a();
        if((md1 instanceof wf) || (md1 instanceof mc)) {
            if(k.v == 0)
                j = 0;
            if(k.v == 1)
                j = j / 2 + 1;
            if(k.v == 3)
                j = (j * 3) / 2;
        }
        if(j == 0)
            return false;
        md md2 = md1;
        if((md2 instanceof mc) && ((mc)md2).c != null)
            md2 = ((mc)md2).c;
        if(md2 instanceof zs)
            a((zs)md2, false);
        a(ga.x, j);
        return super.a(ky1, j);
    }

    protected int b(ky ky1, int j) {
        int l = super.b(ky1, j);
        if(l <= 0)
            return 0;
        int i1 = afi.a(ar, ky1);
        if(i1 > 20)
            i1 = 20;
        if(i1 > 0 && i1 <= 20) {
            int j1 = 25 - i1;
            int k1 = l * j1 + bA;
            l = k1 / 25;
            bA = k1 % 25;
        }
        return l;
    }

    protected boolean aq() {
        return false;
    }

    protected void a(zs zs1, boolean flag) {
        if((zs1 instanceof vo) || (zs1 instanceof sk))
            return;
        if(zs1 instanceof vv) {
            vv vv1 = (vv)zs1;
            if(vv1.aj() && aC.equals(vv1.ag()))
                return;
        }
        if((zs1 instanceof wd) && !aq())
            return;
        List list = k.a(vv.class, um.b(o, p, q, o + 1.0D, p + 1.0D, q + 1.0D).b(16D, 4D, 16D));
        Iterator iterator = list.iterator();
        do {
            if(!iterator.hasNext())
                break;
            md md1 = (md)iterator.next();
            vv vv2 = (vv)md1;
            if(vv2.aj() && vv2.ao() == null && aC.equals(vv2.ag()) && (!flag || !vv2.ah())) {
                vv2.d(false);
                vv2.h(zs1);
            }
        } while(true);
    }

    protected void g(int j) {
        ar.f(j);
    }

    protected int ar() {
        return ar.h();
    }

    protected void c(ky ky1, int j) {
        if(!ky1.d() && al())
            j = 1 + j >> 1;
        j = d(ky1, j);
        j = b(ky1, j);
        d(ky1.e());
        super.c(ky1, j);
    }

    public void a(ady ady) {
    }

    public void a(as as1) {
    }

    public void a(ql ql) {
    }

    public void a(aig aig) {
    }

    public void h(md md1) {
        if(md1.c(this))
            return;
        xs xs1 = as();
        if(xs1 != null && (md1 instanceof zs)) {
            xs1.a((zs)md1);
            if(xs1.a <= 0) {
                xs1.a(this);
                at();
            }
        }
    }

    public xs as() {
        return ar.b();
    }

    public void at() {
        ar.a(ar.c, null);
    }

    public double O() {
        return (double)(H - 0.5F);
    }

    public void au() {
        if(!aA || aB >= aQ() / 2 || aB < 0) {
            aB = -1;
            aA = true;
        }
    }

    public void i(md md1) {
        int j = ar.a(md1);
        if(a(xi.g))
            j += 3 << b(xi.g).c();
        if(a(xi.t))
            j -= 2 << b(xi.t).c();
        int l = 0;
        int i1 = 0;
        if(md1 instanceof zs) {
            i1 = afi.a(ar, (zs)md1);
            l += afi.b(ar, (zs)md1);
        }
        if(V())
            l++;
        if(j > 0 || i1 > 0) {
            boolean flag = s < 0.0D && !z && !q() && !F() && !a(xi.q);
            if(flag)
                j += U.nextInt(j / 2 + 2);
            j += i1;
            boolean flag1 = md1.a(ky.a(this), j);
            if(flag1) {
                if(l > 0) {
                    md1.c(-fp.a((u * 3.141593F) / 180F) * (float)l * 0.5F, 0.10000000000000001D, fp.b((u * 3.141593F) / 180F) * (float)l * 0.5F);
                    r *= 0.59999999999999998D;
                    t *= 0.59999999999999998D;
                    b(false);
                }
                if(flag)
                    b(md1);
                if(i1 > 0)
                    c(md1);
                if(j >= 18)
                    a(dd.E);
            }
            xs xs1 = as();
            if(xs1 != null && (md1 instanceof zs)) {
                xs1.a((zs)md1, this);
                if(xs1.a <= 0) {
                    xs1.a(this);
                    at();
                }
            }
            if(md1 instanceof zs) {
                if(md1.L())
                    a((zs)md1, true);
                a(ga.w, j);
                int j1 = afi.c(ar, (zs)md1);
                if(j1 > 0)
                    md1.d(j1 * 4);
            }
            d(0.3F);
        }
    }

    public void b(md md1) {
    }

    public void c(md md1) {
    }

    public void ae() {
    }

    public abstract void Z();

    public void b(xs xs1) {
    }

    public void y() {
        super.y();
        as.a(this);
        if(at != null)
            at.a(this);
    }

    // WORKAROUND
    Field bw_e = getClassField("bw", "e");
    Field bw_a = getClassField("bw", "a");
    Field bw_b = getClassField("bw", "b");
    Field bw_c = getClassField("bw", "c");
    Field bw_d = getClassField("bw", "d");
    public bw d(int j, int l, int i1) {
        if(!k.I) {
            if(aw() || !L())
                return (bw)getValue(bw_e, null);
            if(k.y.c)
                return (bw)getValue(bw_b, null);
            if(k.l())
                return (bw)getValue(bw_c, null);
            if(Math.abs(o - (double)j) > 3D || Math.abs(p - (double)l) > 2D || Math.abs(q - (double)i1) > 3D)
                return (bw)getValue(bw_d, null);
        }
        a(0.2F, 0.2F);
        H = 0.2F;
        if(k.d(j, l, i1)) {
            int j1 = k.e(j, l, i1);
            int k1 = ny.d(j1);
            float f1 = 0.5F;
            float f2 = 0.5F;
            switch(k1) {
            case 0: // '\0'
                f2 = 0.9F;
                break;

            case 2: // '\002'
                f2 = 0.1F;
                break;

            case 1: // '\001'
                f1 = 0.1F;
                break;

            case 3: // '\003'
                f1 = 0.9F;
                break;
            }
            c(k1);
            d((float)j + f1, (float)l + 0.9375F, (float)i1 + f2);
        } else {
            d((float)j + 0.5F, (float)l + 0.9375F, (float)i1 + 0.5F);
        }
        aM = true;
        a = 0;
        aN = new sj(j, l, i1);
        r = t = s = 0.0D;
        if(!k.I)
            k.A();
        return (bw)getValue(bw_a, null);
    }

    private void c(int j) {
        aO = 0.0F;
        aQ = 0.0F;
        switch(j) {
        case 0: // '\0'
            aQ = -1.8F;
            break;

        case 2: // '\002'
            aQ = 1.8F;
            break;

        case 1: // '\001'
            aO = 1.8F;
            break;

        case 3: // '\003'
            aO = -1.8F;
            break;
        }
    }

    public void a(boolean flag, boolean flag1, boolean flag2) {
        a(0.6F, 1.8F);
        Y();
        sj sj1 = aN;
        sj sj2 = aN;
        if(sj1 != null && k.a(sj1.a, sj1.b, sj1.c) == no.T.bN) {
            ny.a(k, sj1.a, sj1.b, sj1.c, false);
            sj sj3 = ny.f(k, sj1.a, sj1.b, sj1.c, 0);
            if(sj3 == null)
                sj3 = new sj(sj1.a, sj1.b + 1, sj1.c);
            d((float)sj3.a + 0.5F, (float)sj3.b + H + 0.1F, (float)sj3.c + 0.5F);
        }
        aM = false;
        if(!k.I && flag1)
            k.A();
        if(flag)
            a = 0;
        else
            a = 100;
        if(flag2)
            a(aN);
    }

    private boolean aR() {
        return k.a(aN.a, aN.b, aN.c) == no.T.bN;
    }

    public static sj a(uu uu1, sj sj1) {
        bm bm1 = uu1.x();
        bm1.c(sj1.a - 3 >> 4, sj1.c - 3 >> 4);
        bm1.c(sj1.a + 3 >> 4, sj1.c - 3 >> 4);
        bm1.c(sj1.a - 3 >> 4, sj1.c + 3 >> 4);
        bm1.c(sj1.a + 3 >> 4, sj1.c + 3 >> 4);
        if(uu1.a(sj1.a, sj1.b, sj1.c) != no.T.bN) {
            return null;
        } else {
            sj sj2 = ny.f(uu1, sj1.a, sj1.b, sj1.c, 0);
            return sj2;
        }
    }

    public float av() {
        if(aN != null) {
            int j = k.e(aN.a, aN.b, aN.c);
            int l = ny.d(j);
            switch(l) {
            case 0: // '\0'
                return 90F;

            case 1: // '\001'
                return 0.0F;

            case 2: // '\002'
                return 270F;

            case 3: // '\003'
                return 180F;
            }
        }
        return 0.0F;
    }

    public boolean aw() {
        return aM;
    }

    public boolean ax() {
        return aM && a >= 100;
    }

    public int ay() {
        return a;
    }

    public void b(String s) {
    }

    public sj az() {
        return b;
    }

    public void a(sj sj1) {
        if(sj1 != null)
            b = new sj(sj1);
        else
            b = null;
    }

    public void a(agf agf) {
        a(agf, 1);
    }

    public void a(agf agf, int j) {
    }

    public void a_(float f1, float f2) {
        double d1 = o;
        double d2 = p;
        double d3 = q;
        if(aV.b) {
            double d4 = s;
            float f3 = bv;
            bv = 0.05F;
            super.a_(f1, f2);
            s = d4 * 0.59999999999999998D;
            bv = f3;
        } else {
            super.a_(f1, f2);
        }
        i(o - d1, p - d2, q - d3);
    }

    public void i(double d1, double d2, double d3) {
        if(this.j != null)
            return;
        if(a(zo.g)) {
            int j = Math.round(fp.a(d1 * d1 + d2 * d2 + d3 * d3) * 100F);
            if(j > 0) {
                a(ga.q, j);
                d(0.015F * (float)j * 0.01F);
            }
        } else
        if(F()) {
            int l = Math.round(fp.a(d1 * d1 + d3 * d3) * 100F);
            if(l > 0) {
                a(ga.m, l);
                d(0.015F * (float)l * 0.01F);
            }
        } else
        if(q()) {
            if(d2 > 0.0D)
                a(ga.o, (int)Math.round(d2 * 100D));
        } else
        if(z) {
            int i1 = Math.round(fp.a(d1 * d1 + d3 * d3) * 100F);
            if(i1 > 0) {
                a(ga.l, i1);
                if(V())
                    d(0.09999999F * (float)i1 * 0.01F);
                else
                    d(0.01F * (float)i1 * 0.01F);
            }
        } else {
            int j1 = Math.round(fp.a(d1 * d1 + d3 * d3) * 100F);
            if(j1 > 25)
                a(ga.p, j1);
        }
    }

    private void k(double d1, double d2, double d3) {
        if(this.j != null) {
            int j = Math.round(fp.a(d1 * d1 + d2 * d2 + d3 * d3) * 100F);
            if(j > 0)
                if(this.j instanceof aie) {
                    a(ga.r, j);
                    if(c == null)
                        c = new sj(fp.c(o), fp.c(p), fp.c(q));
                    else
                    if(c.a(fp.c(o), fp.c(p), fp.c(q)) >= 1000D)
                        a(dd.q, 1);
                } else
                if(this.j instanceof dz)
                    a(ga.s, j);
                else
                if(this.j instanceof pb)
                    a(ga.t, j);
        }
    }

    protected void c(float f1) {
        if(aV.c)
            return;
        if(f1 >= 2.0F)
            a(ga.n, (int)Math.round((double)f1 * 100D));
        super.c(f1);
    }

    public void a(zs zs1) {
        if(zs1 instanceof wf)
            a(((agf) (dd.s)));
    }

    public int b(xs xs1, int j) {
        int l = super.b(xs1, j);
        if(xs1.c == vy.aR.bN && bb != null) {
            l = xs1.b() + 16;
        } else {
            if(xs1.c == vy.bs.bN)
                if(j == 1)
                    return xs1.b();
                else
                    return 141;
            if(d != null && xs1.c == vy.k.bN) {
                int i1 = xs1.l() - e;
                if(i1 >= 18)
                    return 133;
                if(i1 > 13)
                    return 117;
                if(i1 > 0)
                    return 101;
            }
        }
        return l;
    }

    public void Q() {
        if(aR > 0) {
            aR = 10;
            return;
        } else {
            aS = true;
            return;
        }
    }

    public void h(int j) {
        ax += j;
        aY += (float)j / (float)aB();
        aX += j;
        while(aY >= 1.0F)  {
            aY--;
            aS();
        }
    }

    public void i(int j) {
        aW -= j;
        if(aW < 0)
            aW = 0;
    }

    public int aB() {
        return (aW + 1) * 7;
    }

    private void aS() {
        aW++;
    }

    public void d(float f1) {
        if(aV.a)
            return;
        if(!k.I)
            au.a(f1);
    }

    public lw aC() {
        return au;
    }

    public boolean a(boolean flag) {
        return (flag || au.c()) && !aV.a;
    }

    public boolean aD() {
        return aH() > 0 && aH() < c();
    }

    public void c(xs xs1, int j) {
        if(xs1 == d)
            return;
        d = xs1;
        e = j;
        if(!k.I)
            c(true);
    }

    public boolean e(int j, int l, int i1) {
        return true;
    }

    protected int b(wd wd1) {
        int j = aW * 7;
        if(j > 100)
            return 100;
        else
            return j;
    }

    protected boolean aE() {
        return true;
    }

    public void b(int j) {
    }

    public xp ar;
    public cr as, at;
    protected lw au;
    protected int av;
    public byte aw;
    public int ax, aB, aD, aF, aR;
    public float ay, az, aO, aP, aQ;
    public boolean aA;
    public String aC, aE;
    public double aG, aH, aI, aJ, aK;
    public double aL;
    protected boolean aM, aS;
    public sj aN;
    private int a, e;
    private sj b, c;
    public float aT, aU, aY;
    public pf aV;
    public int aW, aX;
    private xs d;
    protected float aZ, ba;
    public zv bb;
}
