
import java.util.Random;

public final class ZBT extends mh {

    private final int id;

    public ZBT(int blockId) {
        // search: "stair
        super(blockId,
               blockId == 53 ? y
            : (blockId == 67 ? x
            : (blockId == 108 ? am
            : (blockId == 109 ? bn
            : (blockId == 114 ? bB
            : null)))));
        id = blockId;
        switch(blockId) {
            case 53 : a("stairsWood"); break;
            case 67 : a("stairsStone"); break;
            case 108: a("stairsBrick"); break;
            case 109: a("stairsStoneBrickSmooth"); break;
            case 114: a("stairsNetherBrick"); break;
        }
        k();
    }

    public int blockGetDropCount(int zero, Random random) {
        return 1;
    }

    public int blockGetDropId(int meta, Random random, int zero) {
        return id;
    }

    // replacement for the one in parent class - found in base class - copy-pasta. search: continue
    public void a(uu uu1, int i1, int j1, int k1, int l1, float f1, int i2) {
        if(uu1.I)
            return;
        int j2 = a(i2, uu1.w);
        for(int k2 = 0; k2 < j2; k2++) {
            if(uu1.w.nextFloat() > f1)
                continue;
            int l2 = a(l1, uu1.w, i2);
            if(l2 > 0)
                a(uu1, i1, j1, k1, new xs(l2, 1, b(l1)));
        }

    }

}
