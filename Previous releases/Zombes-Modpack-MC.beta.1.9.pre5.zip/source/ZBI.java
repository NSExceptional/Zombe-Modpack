
import java.util.Random;

public final class ZBI extends iy {

    public ZBI() {
        super(79, 67);
        c(0.5F).e(3).a(j).a("ice"); // "ice" * drop the last function.
    }
    
    public int blockGetDropCount(int zero, Random random) {
        return 1;
    }

    public int blockGetDropId(int meta, Random random, int zero) {
        return 79;
    }

    public void a(World map, EntityPlayer player, int x, int y, int z, int meta) { // \], 1\); * function in base class
        // found in base class (Block) ... stright copy
        player.a(ga.C[79], 1); // public static agh C[] = a("stat.mineBlock", 0x1000000);
        player.d(0.025F);      // food ?
        if(b() && !p[79] && afi.d(player.entInventory)) {
            a(map, x, y, z, new ItemStack(this));
        } else {
            int kst = afi.e(player.entInventory);
            a(map, x, y, z, meta, kst);
        }
        // original fn ... just without the "isSolid ||" part
        Material mat = map.f(x, y - 1, z);
        if(mat.matGetIsLiquid()) map.g(x, y, z, 8);
    }

}
