
import java.util.Random;

public final class ZBW extends jo {

    public ZBW(boolean water) {
        super(water ? 8 : 10, water ? Material.g : Material.h);
        if(water) c(100F).e(3).a("water").r(); // "water" * drop the last function.
        else c(0.0F).a(1.0F).e(255).a("lava").r(); // "lava" * drop the last function.
    }
    
    private void j(uu uu1, int i, int i1, int j1) {
        int k1 = uu1.e(i, i1, j1);
        if(h(uu1, i - 1, i1, j1) == 0 && h(uu1, i + 1, i1, j1) == 0 && h(uu1, i, i1, j1 - 1) == 0 && h(uu1, i, i1, j1 + 1) == 0)
            k1 = 0;
        uu1.b(i, i1, j1, bN + 1, k1);
        uu1.c(i, i1, j1, i, i1, j1);
        uu1.j(i, i1, j1);
        if(k1 != 0 && ca == zo.g)
            uu1.a(i, i1, j1, bN + 1, f());
    }

    public void a(uu uu1, int i, int i1, int j1, Random random) {
        int k1 = h(uu1, i, i1, j1);
        byte byte0 = 1;
        if(ca == zo.h && !uu1.y.d)
            byte0 = 2;
        boolean flag = true;
        if(k1 > 0) {
            int l1 = -100;
            a = 0;
            l1 = f(uu1, i - 1, i1, j1, l1);
            l1 = f(uu1, i + 1, i1, j1, l1);
            l1 = f(uu1, i, i1, j1 - 1, l1);
            l1 = f(uu1, i, i1, j1 + 1, l1);
            int i2 = l1 + byte0;
            if(i2 >= 8 || l1 < 0)
                i2 = -1;
            if(h(uu1, i, i1 + 1, j1) >= 0) {
                int k2 = h(uu1, i, i1 + 1, j1);
                if(k2 >= 8)
                    i2 = k2;
                else
                    i2 = k2 + 8;
            }
            if(a >= 2) i2 = 0;// UPDATE
            if(ca == zo.h && k1 < 8 && i2 < 8 && i2 > k1 && random.nextInt(4) != 0) {
                i2 = k1;
                flag = false;
            }
            if(i2 != k1) {
                k1 = i2;
                if(k1 < 0) {
                    uu1.g(i, i1, j1, 0);
                } else {
                    uu1.f(i, i1, j1, k1);
                    uu1.a(i, i1, j1, bN, f());
                    uu1.j(i, i1, j1, bN);
                }
            } else
            if(flag)
                j(uu1, i, i1, j1);
        } else {
            j(uu1, i, i1, j1);
        }
        if(m(uu1, i, i1 - 1, j1)) {
            if(ca == zo.h && uu1.f(i, i1 - 1, j1) == zo.g) {
                uu1.g(i, i1 - 1, j1, no.u.bN);
                i(uu1, i, i1 - 1, j1);
                return;
            }
            if(k1 >= 8)
                uu1.d(i, i1 - 1, j1, bN, k1);
            else
                uu1.d(i, i1 - 1, j1, bN, k1 + 8);
        } else
        if(k1 >= 0 && (k1 == 0 || l(uu1, i, i1 - 1, j1))) {
            boolean aflag[] = k(uu1, i, i1, j1);
            int j2 = k1 + byte0;
            if(k1 >= 8)
                j2 = 1;
            if(j2 >= 8)
                return;
            if(aflag[0])
                g(uu1, i - 1, i1, j1, j2);
            if(aflag[1])
                g(uu1, i + 1, i1, j1, j2);
            if(aflag[2])
                g(uu1, i, i1, j1 - 1, j2);
            if(aflag[3])
                g(uu1, i, i1, j1 + 1, j2);
        }
    }

    private void g(uu uu1, int i, int i1, int j1, int k1) {
        if(m(uu1, i, i1, j1)) {
            int l1 = uu1.a(i, i1, j1);
            if(l1 > 0)
                if(ca == zo.h)
                    i(uu1, i, i1, j1);
                else
                    no.m[l1].a(uu1, i, i1, j1, uu1.e(i, i1, j1), 0);
            uu1.d(i, i1, j1, bN, k1);
        }
    }

    private int c(uu uu1, int i, int i1, int j1, int k1, int l1) {
        int i2 = 1000;
        for(int j2 = 0; j2 < 4; j2++) {
            if(j2 == 0 && l1 == 1 || j2 == 1 && l1 == 0 || j2 == 2 && l1 == 3 || j2 == 3 && l1 == 2)
                continue;
            int k2 = i;
            int l2 = i1;
            int i3 = j1;
            if(j2 == 0)
                k2--;
            if(j2 == 1)
                k2++;
            if(j2 == 2)
                i3--;
            if(j2 == 3)
                i3++;
            if(l(uu1, k2, l2, i3) || uu1.f(k2, l2, i3) == ca && uu1.e(k2, l2, i3) == 0)
                continue;
            if(!l(uu1, k2, l2 - 1, i3))
                return k1;
            if(k1 >= 4)
                continue;
            int j3 = c(uu1, k2, l2, i3, k1 + 1, j2);
            if(j3 < i2)
                i2 = j3;
        }

        return i2;
    }

    private boolean[] k(uu uu1, int i, int i1, int j1) {
        for(int k1 = 0; k1 < 4; k1++) {
            c[k1] = 1000;
            int i2 = i;
            int l2 = i1;
            int i3 = j1;
            if(k1 == 0)
                i2--;
            if(k1 == 1)
                i2++;
            if(k1 == 2)
                i3--;
            if(k1 == 3)
                i3++;
            if(l(uu1, i2, l2, i3) || uu1.f(i2, l2, i3) == ca && uu1.e(i2, l2, i3) == 0)
                continue;
            if(!l(uu1, i2, l2 - 1, i3))
                c[k1] = 0;
            else
                c[k1] = c(uu1, i2, l2, i3, 1, k1);
        }

        int l1 = c[0];
        for(int j2 = 1; j2 < 4; j2++)
            if(c[j2] < l1)
                l1 = c[j2];

        for(int k2 = 0; k2 < 4; k2++)
            b[k2] = c[k2] == l1;

        return b;
    }

    private boolean l(uu uu1, int i, int i1, int j1) {
        int k1 = uu1.a(i, i1, j1);
        if(k1 == no.aF.bN || k1 == no.aM.bN || k1 == no.aE.bN || k1 == no.aG.bN || k1 == no.aY.bN)
            return true;
        if(k1 == 0)
            return false;
        zo zo1 = no.m[k1].ca;
        if(zo1 == zo.z)
            return false;
        return zo1.c();
    }

    private boolean m(uu uu1, int i, int i1, int j1) {
        zo zo1 = uu1.f(i, i1, j1);
        if(zo1 == ca)
            return false;
        if(zo1 == zo.h)
            return false;
        else
            return !l(uu1, i, i1, j1);
    }

}

