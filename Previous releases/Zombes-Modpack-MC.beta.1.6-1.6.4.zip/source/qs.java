// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.util.*;

// search: "random.explode"
public class qs {

    protected static final boolean zmodmarker = true;
    private boolean creeper;
    private int eX, eY, eZ;

    public qs(fb fb1, si si1, double d1, double d2, double d3, float f1) {
        // -----------------------------------------------------------------------------------------------------------------------
        eX = (int)d1; eY = (int)d2; eZ = (int)d3; // update
        creeper = si1 instanceof fz; // update : creeper
        f = ZMod.boomScaleHandle(f1, creeper); // update AND DO NOT FORGET TO REMOVE THE ORIGINAL!
        // -----------------------------------------------------------------------------------------------------------------------
        a = false;
        h = new Random();
        g = new HashSet();
        i = fb1;
        e = si1;
        b = d1;
        c = d2;
        d = d3;
    }

    public void a() {
        float f1 = f;
        int j = 16;
        for(int k = 0; k < j; k++) {
            for(int i1 = 0; i1 < j; i1++) {
label0:
                for(int k1 = 0; k1 < j; k1++) {
                    if(k != 0 && k != j - 1 && i1 != 0 && i1 != j - 1 && k1 != 0 && k1 != j - 1)
                        continue;
                    double d1 = ((float)k / ((float)j - 1.0F)) * 2.0F - 1.0F;
                    double d2 = ((float)i1 / ((float)j - 1.0F)) * 2.0F - 1.0F;
                    double d3 = ((float)k1 / ((float)j - 1.0F)) * 2.0F - 1.0F;
                    double d4 = Math.sqrt(d1 * d1 + d2 * d2 + d3 * d3);
                    d1 /= d4;
                    d2 /= d4;
                    d3 /= d4;
                    float f2 = f * (0.7F + i.r.nextFloat() * 0.6F);
                    double d6 = b;
                    double d8 = c;
                    double d10 = d;
                    float f3 = 0.3F;
                    do {
                        if(f2 <= 0.0F)
                            continue label0;
                        int k4 = ik.b(d6);
                        int l4 = ik.b(d8);
                        int i5 = ik.b(d10);
                        int j5 = i.a(k4, l4, i5);
                        if(j5 > 0)
                            f2 -= (un.m[j5].a(e) + 0.3F) * f3;
                        if(f2 > 0.0F)
                            g.add(new vx(k4, l4, i5));
                        d6 += d1 * (double)f3;
                        d8 += d2 * (double)f3;
                        d10 += d3 * (double)f3;
                        f2 -= f3 * 0.75F;
                    } while(true);
                }

            }

        }

        f *= 2.0F;
        int l = ik.b(b - (double)f - 1.0D);
        int j1 = ik.b(b + (double)f + 1.0D);
        int l1 = ik.b(c - (double)f - 1.0D);
        int i2 = ik.b(c + (double)f + 1.0D);
        int j2 = ik.b(d - (double)f - 1.0D);
        int k2 = ik.b(d + (double)f + 1.0D);
        List list = i.b(e, eo.b(l, l1, j2, j1, i2, k2));
        br br1 = br.b(b, c, d);
        for(int l2 = 0; l2 < list.size(); l2++) {
            si si1 = (si)list.get(l2);
            double d5 = si1.g(b, c, d) / (double)f;
            if(d5 <= 1.0D) {
                double d7 = si1.aL - b;
                double d9 = si1.aM - c;
                double d11 = si1.aN - d;
                double d12 = ik.a(d7 * d7 + d9 * d9 + d11 * d11);
                d7 /= d12;
                d9 /= d12;
                d11 /= d12;
                double d13 = i.a(br1, si1.aV);
                double d14 = (1.0D - d5) * d13;
                si1.a(e, (int)(((d14 * d14 + d14) / 2D) * 8D * (double)f + 1.0D));
                double d15 = d14;
                si1.aO += d7 * d15;
                si1.aP += d9 * d15;
                si1.aQ += d11 * d15;
            }
        }

        f = f1;
        ArrayList arraylist = new ArrayList();
        arraylist.addAll(g);
        if(a) {
            for(int i3 = arraylist.size() - 1; i3 >= 0; i3--) {
                vx vx1 = (vx)arraylist.get(i3);
                int j3 = vx1.a;
                int k3 = vx1.b;
                int l3 = vx1.c;
                int i4 = i.a(j3, k3, l3);
                int j4 = i.a(j3, k3 - 1, l3);
                if(i4 == 0 && un.o[j4] && h.nextInt(3) == 0)
                    i.f(j3, k3, l3, un.as.bn);
            }

        }
    }

    public void a(boolean flag) {
        // -----------------------------------------------------------------------------------------------------------------------
        boolean damage = ZMod.boomDamageHandle(eX, eY, eZ, creeper);
        // -----------------------------------------------------------------------------------------------------------------------

        i.a(b, c, d, "random.explode", 4F, (1.0F + (i.r.nextFloat() - i.r.nextFloat()) * 0.2F) * 0.7F);
        ArrayList arraylist = new ArrayList();
        arraylist.addAll(g);
        for(int j = arraylist.size() - 1; j >= 0; j--) {
            vx vx1 = (vx)arraylist.get(j);
            int k = vx1.a;
            int l = vx1.b;
            int i1 = vx1.c;
            int j1 = i.a(k, l, i1);
            if(flag) {
                double d1 = (float)k + i.r.nextFloat();
                double d2 = (float)l + i.r.nextFloat();
                double d3 = (float)i1 + i.r.nextFloat();
                double d4 = d1 - b;
                double d5 = d2 - c;
                double d6 = d3 - d;
                double d7 = ik.a(d4 * d4 + d5 * d5 + d6 * d6);
                d4 /= d7;
                d5 /= d7;
                d6 /= d7;
                double d8 = 0.5D / (d7 / (double)f + 0.10000000000000001D);
                d8 *= i.r.nextFloat() * i.r.nextFloat() + 0.3F;
                d4 *= d8;
                d5 *= d8;
                d6 *= d8;
                i.a("explode", (d1 + b * 1.0D) / 2D, (d2 + c * 1.0D) / 2D, (d3 + d * 1.0D) / 2D, d4, d5, d6);
                i.a("smoke", d1, d2, d3, d4, d5, d6);
            }

            // -------------------------------------------------------------------------------------------------------------------
            if(!damage) continue;
            float chance = ZMod.boomDropHandle( j1 ); // update : id
            // -------------------------------------------------------------------------------------------------------------------

            if(j1 > 0) {
                un.m[j1].a(i, k, l, i1, i.e(k, l, i1), chance); // UPDATE THIS TOO YOU MORON !
                i.f(k, l, i1, 0);
                un.m[j1].c(i, k, l, i1);
            }
        }

    }

    public boolean a;
    private Random h;
    private fb i;
    public double b, c, d;
    public si e;
    public float f;
    public Set g;
}
