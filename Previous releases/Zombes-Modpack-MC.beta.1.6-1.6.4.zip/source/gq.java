// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.util.*;
import java.lang.reflect.*;

// EntityPlayer ? search: "humanoid"
public abstract class gq extends lo {

    // ---------------------------------------------------------------------------------------------------------------------------
    protected static boolean zmodmarker = true;
    private static Method flyHandle;
    // moveEntity   : b   ? search: double d9 = 0\.050000000000000003D; - it is in the function
    public final void callSuper(double mx, double my, double mz) { super.b(mx,my,mz); }
    public void b(double mx, double my, double mz) { // ZMod.flyHandle(this,mx,my,mz);
      if(zmodmarker && flyHandle==null) {
          try { flyHandle = Class.forName("ZMod").getDeclaredMethod("flyHandle", new Class[]{Object.class, Double.TYPE, Double.TYPE, Double.TYPE}); }
          catch(Exception whatever) { zmodmarker=false; flyHandle = null; }
      }
      if(flyHandle!=null) try { flyHandle.invoke(null, new Object[]{this, mx, my, mz}); } catch(Exception whatever) { flyHandle = null; callSuper(mx,my,mz); }
      else callSuper(mx,my,mz);
    }
    // ---------------------------------------------------------------------------------------------------------------------------


    public gq(fb fb1) {
        super(fb1);
        c = new iu(this);
        f = 0;
        g = 0;
        j = false;
        k = 0;
        y = 20;
        z = false;
        bN = 0;
        C = null;
        d = new z(c, !fb1.B);
        e = d;
        be = 1.62F;
        bp bp1 = fb1.u();
        c((double)bp1.a + 0.5D, bp1.b + 1, (double)bp1.c + 0.5D, 0.0F, 0.0F);
        X = 20;
        Q = "humanoid";
        P = 180F;
        bt = 20;
        N = "/mob/char.png";
    }

    protected void b() {
        super.b();
        bC.a(16, Byte.valueOf((byte)0));
    }

    public void w_() {
        if(N()) {
            b++;
            if(b > 100)
                b = 100;
            if(!am())
                a(true, true, false);
            else
            if(!aH.B && aH.f())
                a(false, true, true);
        } else
        if(b > 0) {
            b++;
            if(b >= 110)
                b = 0;
        }
        super.w_();
        if(!aH.B && e != null && !e.b(this)) {
            r();
            e = d;
        }
        o = r;
        p = s;
        q = t;
        double d1 = aL - r;
        double d2 = aM - s;
        double d3 = aN - t;
        double d4 = 10D;
        if(d1 > d4)
            o = r = aL;
        if(d3 > d4)
            q = t = aN;
        if(d2 > d4)
            p = s = aM;
        if(d1 < -d4)
            o = r = aL;
        if(d3 < -d4)
            q = t = aN;
        if(d2 < -d4)
            p = s = aM;
        r += d1 * 0.25D;
        t += d3 * 0.25D;
        s += d2 * 0.25D;
        a(ji.k, 1);
        if(aG == null)
            bM = null;
    }

    protected boolean y() {
        return X <= 0 || N();
    }

    protected void r() {
        e = d;
    }

    public void u_() {
        n = (new StringBuilder()).append("http://s3.amazonaws.com/MinecraftCloaks/").append(l).append(".png").toString();
        bA = n;
    }

    public void s_() {
        double d1 = aL;
        double d2 = aM;
        double d3 = aN;
        super.s_();
        h = i;
        i = 0.0F;
        j(aL - d1, aM - d2, aN - d3);
    }

    public void t_() {
        be = 1.62F;
        b(0.6F, 1.8F);
        super.t_();
        X = 20;
        ac = 0;
    }

    protected void e_() {
        if(j) {
            k++;
            if(k >= 8) {
                k = 0;
                j = false;
            }
        } else {
            k = 0;
        }
        W = (float)k / 8F;
    }

    public void o() {
        if(aH.q == 0 && X < 20 && (bs % 20) * 12 == 0)
            c(1);
        c.e();
        h = i;
        super.o();
        float f1 = ik.a(aO * aO + aQ * aQ);
        float f2 = (float)Math.atan(-aP * 0.20000000298023224D) * 15F;
        if(f1 > 0.1F)
            f1 = 0.1F;
        if(!aW || X <= 0)
            f1 = 0.0F;
        if(aW || X <= 0)
            f2 = 0.0F;
        i += (f1 - i) * 0.4F;
        af += (f2 - af) * 0.8F;
        if(X > 0) {
            List list = aH.b(this, aV.b(1.0D, 0.0D, 1.0D));
            if(list != null) {
                for(int i1 = 0; i1 < list.size(); i1++) {
                    si si1 = (si)list.get(i1);
                    if(!si1.bd)
                        j(si1);
                }

            }
        }
    }

    private void j(si si1) {
        si1.b(this);
    }

    public int C() {
        return g;
    }

    public void b(si si1) {
        super.b(si1);
        b(0.2F, 0.2F);
        d(aL, aM, aN);
        aP = 0.10000000149011612D;
        if(l.equals("Notch"))
            a(new iw(gk.h, 1), true);
        c.g();
        if(si1 != null) {
            aO = -ik.b(((ab + aR) * 3.141593F) / 180F) * 0.1F;
            aQ = -ik.a(((ab + aR) * 3.141593F) / 180F) * 0.1F;
        } else {
            aO = aQ = 0.0D;
        }
        be = 0.1F;
        a(ji.y, 1);
    }

    public void c(si si1, int i1) {
        g += i1;
        if(si1 instanceof gq)
            a(ji.A, 1);
        else
            a(ji.z, 1);
    }

    public void D() {
        a(c.a(c.c, 1), false);
    }

    public void a(iw iw1) {
        a(iw1, false);
    }

    public void a(iw iw1, boolean flag) {
        if(iw1 == null)
            return;
        hj hj1 = new hj(aH, aL, (aM - 0.30000001192092896D) + (double)w(), aN, iw1);
        hj1.c = 40;
        float f1 = 0.1F;
        if(flag) {
            float f3 = br.nextFloat() * 0.5F;
            float f5 = br.nextFloat() * 3.141593F * 2.0F;
            hj1.aO = -ik.a(f5) * f3;
            hj1.aQ = ik.b(f5) * f3;
            hj1.aP = 0.20000000298023224D;
        } else {
            float f2 = 0.3F;
            hj1.aO = -ik.a((aR / 180F) * 3.141593F) * ik.b((aS / 180F) * 3.141593F) * f2;
            hj1.aQ = ik.b((aR / 180F) * 3.141593F) * ik.b((aS / 180F) * 3.141593F) * f2;
            hj1.aP = -ik.a((aS / 180F) * 3.141593F) * f2 + 0.1F;
            f2 = 0.02F;
            float f4 = br.nextFloat() * 3.141593F * 2.0F;
            f2 *= br.nextFloat();
            hj1.aO += Math.cos(f4) * (double)f2;
            hj1.aP += (br.nextFloat() - br.nextFloat()) * 0.1F;
            hj1.aQ += Math.sin(f4) * (double)f2;
        }
        a(hj1);
        a(ji.v, 1);
    }

    protected void a(hj hj1) {
        aH.b(hj1);
    }

    public float a(un un1) {
        float f1 = c.a(un1);
        if(a(lj.g))
            f1 /= 5F;
        if(!aW)
            f1 /= 5F;
        return f1;
    }

    public boolean b(un un1) {
        return c.b(un1);
    }

    public void a(nq nq1) {
        super.a(nq1);
        sk sk1 = nq1.l("Inventory");
        c.b(sk1);
        m = nq1.e("Dimension");
        u = nq1.m("Sleeping");
        b = nq1.d("SleepTimer");
        if(u) {
            a = new bp(ik.b(aL), ik.b(aM), ik.b(aN));
            a(true, true, false);
        }
        if(nq1.b("SpawnX") && nq1.b("SpawnY") && nq1.b("SpawnZ"))
            bL = new bp(nq1.e("SpawnX"), nq1.e("SpawnY"), nq1.e("SpawnZ"));
    }

    public void b(nq nq1) {
        super.b(nq1);
        nq1.a("Inventory", c.a(new sk()));
        nq1.a("Dimension", m);
        nq1.a("Sleeping", u);
        nq1.a("SleepTimer", (short)b);
        if(bL != null) {
            nq1.a("SpawnX", bL.a);
            nq1.a("SpawnY", bL.b);
            nq1.a("SpawnZ", bL.c);
        }
    }

    public void a(ls ls) {
    }

    public void a(int i1, int j1, int k1) {
    }

    public void b(si si1, int i1) {
    }

    public float w() {
        return 0.12F;
    }

    protected void E() {
        be = 1.62F;
    }

    public boolean a(si si1, int i1) {
        au = 0;
        if(X <= 0)
            return false;
        if(N())
            a(true, true, false);
        if((si1 instanceof gx) || (si1 instanceof sg)) {
            if(aH.q == 0)
                i1 = 0;
            if(aH.q == 1)
                i1 = i1 / 3 + 1;
            if(aH.q == 3)
                i1 = (i1 * 3) / 2;
        }
        if(i1 == 0)
            return false;
        Object obj = si1;
        if((obj instanceof sg) && ((sg)obj).c != null)
            obj = ((sg)obj).c;
        if(obj instanceof lo)
            a((lo)obj, false);
        a(ji.x, i1);
        return super.a(si1, i1);
    }

    protected boolean F() {
        return false;
    }

    protected void a(lo lo1, boolean flag) {
        if((lo1 instanceof fz) || (lo1 instanceof bn))
            return;
        if(lo1 instanceof gg) {
            gg gg1 = (gg)lo1;
            if(gg1.D() && l.equals(gg1.A()))
                return;
        }
        if((lo1 instanceof gq) && !F())
            return;
        List list = aH.a(gg.class, eo.b(aL, aM, aN, aL + 1.0D, aM + 1.0D, aN + 1.0D).b(16D, 4D, 16D));
        Iterator iterator = list.iterator();
        do {
            if(!iterator.hasNext())
                break;
            si si1 = (si)iterator.next();
            gg gg2 = (gg)si1;
            if(gg2.D() && gg2.F() == null && l.equals(gg2.A()) && (!flag || !gg2.B())) {
                gg2.b(false);
                gg2.c(lo1);
            }
        } while(true);
    }

    protected void b(int i1) {
        int j1 = 25 - c.f();
        int k1 = i1 * j1 + bN;
        c.e(i1);
        i1 = k1 / 25;
        bN = k1 % 25;
        super.b(i1);
    }

    public void a(sf sf) {
    }

    public void a(ay ay) {
    }

    public void a(yb yb) {
    }

    public void c(si si1) {
        if(si1.a(this))
            return;
        iw iw1 = G();
        if(iw1 != null && (si1 instanceof lo)) {
            iw1.a((lo)si1);
            if(iw1.a <= 0) {
                iw1.a(this);
                H();
            }
        }
    }

    public iw G() {
        return c.b();
    }

    public void H() {
        c.a(c.c, null);
    }

    public double I() {
        return (double)(be - 0.5F);
    }

    public void J() {
        k = -1;
        j = true;
    }

    public void d(si si1) {
        int i1 = c.a(si1);
        if(i1 > 0) {
            if(aP < 0.0D)
                i1++;
            si1.a(this, i1);
            iw iw1 = G();
            if(iw1 != null && (si1 instanceof lo)) {
                iw1.a((lo)si1, this);
                if(iw1.a <= 0) {
                    iw1.a(this);
                    H();
                }
            }
            if(si1 instanceof lo) {
                if(si1.W())
                    a((lo)si1, true);
                a(ji.w, i1);
            }
        }
    }

    public void o_() {
    }

    public abstract void v();

    public void b(iw iw1) {
    }

    public void K() {
        super.K();
        d.a(this);
        if(e != null)
            e.a(this);
    }

    public boolean L() {
        return !u && super.L();
    }

    public cu b(int i1, int j1, int k1) {
        if(N() || !W())
            return cu.e;
        if(aH.t.c)
            return cu.b;
        if(aH.f())
            return cu.c;
        if(Math.abs(aL - (double)i1) > 3D || Math.abs(aM - (double)j1) > 2D || Math.abs(aN - (double)k1) > 3D)
            return cu.d;
        b(0.2F, 0.2F);
        be = 0.2F;
        if(aH.i(i1, j1, k1)) {
            int l1 = aH.e(i1, j1, k1);
            int i2 = uw.c(l1);
            float f1 = 0.5F;
            float f2 = 0.5F;
            switch(i2) {
            case 0: // '\0'
                f2 = 0.9F;
                break;

            case 2: // '\002'
                f2 = 0.1F;
                break;

            case 1: // '\001'
                f1 = 0.1F;
                break;

            case 3: // '\003'
                f1 = 0.9F;
                break;
            }
            e(i2);
            d((float)i1 + f1, (float)j1 + 0.9375F, (float)k1 + f2);
        } else {
            d((float)i1 + 0.5F, (float)j1 + 0.9375F, (float)k1 + 0.5F);
        }
        u = true;
        b = 0;
        a = new bp(i1, j1, k1);
        aO = aQ = aP = 0.0D;
        if(!aH.B)
            aH.y();
        return cu.a;
    }

    private void e(int i1) {
        v = 0.0F;
        x = 0.0F;
        switch(i1) {
        case 0: // '\0'
            x = -1.8F;
            break;

        case 2: // '\002'
            x = 1.8F;
            break;

        case 1: // '\001'
            v = 1.8F;
            break;

        case 3: // '\003'
            v = -1.8F;
            break;
        }
    }

    public void a(boolean flag, boolean flag1, boolean flag2) {
        b(0.6F, 1.8F);
        E();
        bp bp1 = a;
        bp bp2 = a;
        if(bp1 != null && aH.a(bp1.a, bp1.b, bp1.c) == un.T.bn) {
            uw.a(aH, bp1.a, bp1.b, bp1.c, false);
            bp bp3 = uw.g(aH, bp1.a, bp1.b, bp1.c, 0);
            if(bp3 == null)
                bp3 = new bp(bp1.a, bp1.b + 1, bp1.c);
            d((float)bp3.a + 0.5F, (float)bp3.b + be + 0.1F, (float)bp3.c + 0.5F);
        }
        u = false;
        if(!aH.B && flag1)
            aH.y();
        if(flag)
            b = 0;
        else
            b = 100;
        if(flag2)
            a(a);
    }

    private boolean am() {
        return aH.a(a.a, a.b, a.c) == un.T.bn;
    }

    public static bp a(fb fb1, bp bp1) {
        cj cj1 = fb1.w();
        cj1.c(bp1.a - 3 >> 4, bp1.c - 3 >> 4);
        cj1.c(bp1.a + 3 >> 4, bp1.c - 3 >> 4);
        cj1.c(bp1.a - 3 >> 4, bp1.c + 3 >> 4);
        cj1.c(bp1.a + 3 >> 4, bp1.c + 3 >> 4);
        if(fb1.a(bp1.a, bp1.b, bp1.c) != un.T.bn) {
            return null;
        } else {
            bp bp2 = uw.g(fb1, bp1.a, bp1.b, bp1.c, 0);
            return bp2;
        }
    }

    public float M() {
        if(a != null) {
            int i1 = aH.e(a.a, a.b, a.c);
            int j1 = uw.c(i1);
            switch(j1) {
            case 0: // '\0'
                return 90F;

            case 1: // '\001'
                return 0.0F;

            case 2: // '\002'
                return 270F;

            case 3: // '\003'
                return 180F;
            }
        }
        return 0.0F;
    }

    public boolean N() {
        return u;
    }

    public boolean O() {
        return u && b >= 100;
    }

    public int P() {
        return b;
    }

    public void b(String s1) {
    }

    public bp Q() {
        return bL;
    }

    public void a(bp bp1) {
        if(bp1 != null)
            bL = new bp(bp1);
        else
            bL = null;
    }

    public void a(vj vj) {
        a(vj, 1);
    }

    public void a(vj vj, int i1) {
    }

    protected void R() {
        super.R();
        a(ji.u, 1);
    }

    public void a_(float f1, float f2) {
        double d1 = aL;
        double d2 = aM;
        double d3 = aN;
        super.a_(f1, f2);
        i(aL - d1, aM - d2, aN - d3);
    }

    private void i(double d1, double d2, double d3) {
        if(aG != null)
            return;
        if(a(lj.g)) {
            int i1 = Math.round(ik.a(d1 * d1 + d2 * d2 + d3 * d3) * 100F);
            if(i1 > 0)
                a(ji.q, i1);
        } else
        if(ag()) {
            int j1 = Math.round(ik.a(d1 * d1 + d3 * d3) * 100F);
            if(j1 > 0)
                a(ji.m, j1);
        } else
        if(p()) {
            if(d2 > 0.0D)
                a(ji.o, (int)Math.round(d2 * 100D));
        } else
        if(aW) {
            int k1 = Math.round(ik.a(d1 * d1 + d3 * d3) * 100F);
            if(k1 > 0)
                a(ji.l, k1);
        } else {
            int l1 = Math.round(ik.a(d1 * d1 + d3 * d3) * 100F);
            if(l1 > 25)
                a(ji.p, l1);
        }
    }

    private void j(double d1, double d2, double d3) {
        if(aG != null) {
            int i1 = Math.round(ik.a(d1 * d1 + d2 * d2 + d3 * d3) * 100F);
            if(i1 > 0)
                if(aG instanceof yc) {
                    a(ji.r, i1);
                    if(bM == null)
                        bM = new bp(ik.b(aL), ik.b(aM), ik.b(aN));
                    else
                    if(bM.a(ik.b(aL), ik.b(aM), ik.b(aN)) >= 1000D)
                        a(en.q, 1);
                } else
                if(aG instanceof fx)
                    a(ji.s, i1);
                else
                if(aG instanceof vz)
                    a(ji.t, i1);
        }
    }

    protected void b(float f1) {
        if(f1 >= 2.0F)
            a(ji.n, (int)Math.round((double)f1 * 100D));
        super.b(f1);
    }

    public void a(lo lo1) {
        if(lo1 instanceof gx)
            a(((vj) (en.s)));
    }

    public int c(iw iw1) {
        int i1 = super.c(iw1);
        if(iw1.c == gk.aP.be && C != null)
            i1 = iw1.b() + 16;
        return i1;
    }

    public void S() {
        if(y > 0) {
            y = 10;
            return;
        } else {
            z = true;
            return;
        }
    }

    public iu c;
    public du d, e;
    public byte f;
    public int g, k, m, y;
    public float h, i, v, w, x;
    public boolean j;
    public String l, n;
    public double o, p, q, r, s;
    public double t;
    protected boolean u, z;
    private bp a, bL, bM;
    private int b, bN;
    public float A, B;
    public lt C;
}
