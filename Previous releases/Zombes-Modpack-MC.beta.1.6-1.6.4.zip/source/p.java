// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.awt.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MinecraftApplet;

// search: "Center"
public class p extends Minecraft {

    public p(MinecraftApplet minecraftapplet, Component component, Canvas canvas, MinecraftApplet minecraftapplet1, int i, int j, boolean flag) {
        super(component, canvas, minecraftapplet1, i, j, flag);
        a = minecraftapplet;
        ZMod.initialize(this); // initialization
    }

    public void a(mc mc) {
        a.removeAll();
        a.setLayout(new BorderLayout());
        a.add(new bz(mc), "Center");
        a.validate();
    }

    // search: "/font/default.png" * function contains it
    public void a() {
        super.a();
        ZMod.initOverrides();
    }

    // called before "Pre render" just before continue command
    public void k() {
        ZMod.pingUpdateHandle();
        super.k();
    }

    // search: "tile.bed.notValid"\) * it is in the function
    public void a(boolean flag, int kst) {
        super.a(flag, kst);
        ZMod.pingRespawnHandle(flag);
    }

    final MinecraftApplet a;
}
