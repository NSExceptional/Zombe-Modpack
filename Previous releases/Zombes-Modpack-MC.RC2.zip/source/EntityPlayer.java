// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb
// Source File Name:   SourceFile

import java.util.*;
import java.lang.reflect.*;

public abstract class wh extends zx {

    public static Method getClassMethod(String c, String m, Class param[]) { try { return Class.forName(c).getMethod(m, param); } catch(Exception e) { e.printStackTrace(); return null; } }
    public static Field getClassField(String c, String m) { try { return Class.forName(c).getField(m); } catch(Exception e) { e.printStackTrace(); return null; } }
    public static Object getResult(Method m, Object obj, Object param[]) { try { return m.invoke(obj, param); } catch(Exception whatever) { } return null; }
    public static Object getValue(Field field, Object obj) { try { return field.get(obj); } catch(Exception whatever) { } return null; }

    // ---------------------------------------------------------------------------------------------------------------------------
    protected static boolean zmodmarker = true;
    private static Method flyHandle, flyCancel, flyJump;
    public final void callSuper(double mx, double my, double mz) { super.entMove(mx,my,mz); }
    private static void flyInitialize() {
        try {
            Class mod = Class.forName("ZMod");
            flyHandle = mod.getDeclaredMethod("flyHandle", new Class[]{Object.class, Double.TYPE, Double.TYPE, Double.TYPE});
            flyCancel = mod.getDeclaredMethod("flyDickmoveCancel", new Class[]{});
            flyJump = mod.getDeclaredMethod("flyJumpHandle", new Class[]{});
        } catch(Exception whatever) { zmodmarker=false; flyHandle = flyCancel = null; }
    }
    public void entMove(double mx, double my, double mz) { // ZMod.flyHandle(this,mx,my,mz);
        if(zmodmarker && flyHandle==null) flyInitialize();
        if(flyHandle!=null) try { flyHandle.invoke(null, new Object[]{this, mx, my, mz}); } catch(Exception whatever) { flyHandle = null; callSuper(mx,my,mz); }
        else callSuper(mx,my,mz);
    }

    // this thing is in this class: add first variable (noclip)
    public boolean M() {
        return !entNoClip && !aK && super.M();
    }

    // ... as is this: first chance to undo the dickmove
    public void d() {
        if(zmodmarker && flyCancel==null) flyInitialize(); if(flyCancel!=null) try { flyCancel.invoke(null, new Object[]{}); } catch(Exception whatever) {} // undo.
        if(at > 0)
            at--;
        if(k.v == 0 && aI() < c() && (V % 20) * 12 == 0)
            k(1);
        ap.g();
        aw = ax;
        super.d();
        bs = aX;
        bt = aY;
        if(V()) {
            bs += (double)aX * 0.29999999999999999D;
            bt += (double)aY * 0.29999999999999999D;
        }
        float f = fs.a(r * r + t * t);
        float f1 = (float)Math.atan(-s * 0.20000000298023224D) * 15F;
        if(f > 0.1F)
            f = 0.1F;
        if(!z || aI() <= 0)
            f = 0.0F;
        if(z || aI() <= 0)
            f1 = 0.0F;
        ax += (f - ax) * 0.4F;
        bF += (f1 - bF) * 0.8F;
        if(aI() > 0) {
            List list = k.b(this, y.b(1.0D, 0.0D, 1.0D));
            if(list != null) {
                for(int i1 = 0; i1 < list.size(); i1++) {
                    mh mh1 = (mh)list.get(i1);
                    if(!mh1.G)
                        l(mh1);
                }

            }
        }
    }

    // ... as is this. search: 0.8F
    protected void aB() {
        super.aB();
        // -----------------------------------------------------------------------------------------------------------------------
        double jump = 1.0D;
        if(flyJump != null) try {
            jump = (Double)flyJump.invoke(null, new Object[]{});
        } catch(Exception whatever) {
            flyJump = null;
            jump = 1.0D;
        }
        entMotionY *= jump;
        // -----------------------------------------------------------------------------------------------------------------------
        a(gd.u, 1);
        if(V())
            d(0.8F);
        else
            d(0.2F);
    }
    // ---------------------------------------------------------------------------------------------------------------------------

    public wh(uy uy1) {
        super(uy1);
        ap = new xt(this);
        as = new ma();
        at = 0;
        au = 0;
        av = 0;
        ay = false;
        az = 0;
        aD = 0;
        aP = 20;
        aQ = false;
        aT = new pj();
        aX = 0.1F;
        aY = 0.02F;
        aZ = null;
        aq = new u(ap, !uy1.I);
        ar = aq;
        H = 1.62F;
        sn sn1 = uy1.v();
        c((double)sn1.a + 0.5D, sn1.b + 1, (double)sn1.c + 0.5D, 0.0F, 0.0F);
        bn = "humanoid";
        bm = 180F;
        W = 20;
        bk = "/mob/char.png";
    }

    public int c() {
        return 20;
    }

    protected void b() {
        super.b();
        ac.a(16, Byte.valueOf((byte)0));
        ac.a(17, Byte.valueOf((byte)0));
    }

    public xw ag() {
        return d;
    }

    public int ah() {
        return e;
    }

    public boolean ai() {
        return d != null;
    }

    public int aj() {
        if(ai())
            return d.l() - e;
        else
            return 0;
    }

    public void ak() {
        if(d != null)
            d.a(k, this, e);
        al();
    }

    public void al() {
        d = null;
        e = 0;
        if(!k.I)
            c(false);
    }

    public boolean am() {
        return ai() && wc.e[d.c].c(d) == xz.d;
    }

    public void A_() {
        if(d != null) {
            xw xw1 = ap.b();
            if(xw1 != d) {
                al();
            } else {
                if(e <= 25 && e % 4 == 0)
                    a(xw1, 5);
                if(--e == 0 && !k.I)
                    an();
            }
        }
        if(aD > 0)
            aD--;
        if(ax()) {
            a++;
            if(a > 100)
                a = 100;
            if(!k.I)
                if(!aS())
                    a(true, true, false);
                else
                if(k.l())
                    a(false, true, true);
        } else
        if(a > 0) {
            a++;
            if(a >= 110)
                a = 0;
        }
        super.A_();
        if(!k.I && ar != null && !ar.b(this)) {
            ad();
            ar = aq;
        }
        if(aT.b) {
            for(int i1 = 0; i1 < 8; i1++);
        }
        if(S() && aT.a)
            B();
        aE = aH;
        aF = aI;
        aG = aJ;
        double d1 = o - aH;
        double d2 = p - aI;
        double d3 = q - aJ;
        double d4 = 10D;
        if(d1 > d4)
            aE = aH = o;
        if(d3 > d4)
            aG = aJ = q;
        if(d2 > d4)
            aF = aI = p;
        if(d1 < -d4)
            aE = aH = o;
        if(d3 < -d4)
            aG = aJ = q;
        if(d2 < -d4)
            aF = aI = p;
        aH += d1 * 0.25D;
        aJ += d3 * 0.25D;
        aI += d2 * 0.25D;
        a(gd.k, 1);
        if(j == null)
            c = null;
        if(!k.I)
            as.a(this);
    }

    // WORKAROUND
    Method bf_b = getClassMethod("bf", "b", new Class[]{Double.TYPE, Double.TYPE, Double.TYPE});
    protected void a(xw xw1, int i1) {
        if(xw1.m() == xz.c)
            k.a(this, "random.drink", 0.5F, k.w.nextFloat() * 0.1F + 0.9F);
        if(xw1.m() == xz.b) {
            for(int j1 = 0; j1 < i1; j1++) {
                bf bf1 = (bf)getResult(bf_b, null, new Object[]{((double)U.nextFloat() - 0.5D) * 0.10000000000000001D, Math.random() * 0.10000000000000001D + 0.10000000000000001D, 0.0D});
                //bf bf1 = bf.b(((double)U.nextFloat() - 0.5D) * 0.10000000000000001D, Math.random() * 0.10000000000000001D + 0.10000000000000001D, 0.0D);
                bf1.a((-v * 3.141593F) / 180F);
                bf1.b((-u * 3.141593F) / 180F);
                bf bf2 = (bf)getResult(bf_b, null, new Object[]{((double)U.nextFloat() - 0.5D) * 0.29999999999999999D, (double)(-U.nextFloat()) * 0.59999999999999998D - 0.29999999999999999D, 0.59999999999999998D});
                //bf bf2 = bf.b(((double)U.nextFloat() - 0.5D) * 0.29999999999999999D, (double)(-U.nextFloat()) * 0.59999999999999998D - 0.29999999999999999D, 0.59999999999999998D);
                bf2.a((-v * 3.141593F) / 180F);
                bf2.b((-u * 3.141593F) / 180F);
                bf2 = bf2.c(o, p + (double)G(), q);
                k.a((new StringBuilder()).append("iconcrack_").append(xw1.a().bN).toString(), bf2.a, bf2.b, bf2.c, bf1.a, bf1.b + 0.050000000000000003D, bf1.c);
            }

            k.a(this, "random.eat", 0.5F + 0.5F * (float)U.nextInt(2), (U.nextFloat() - U.nextFloat()) * 0.2F + 1.0F);
        }
    }

    protected void an() {
        if(d != null) {
            a(d, 16);
            int i1 = d.a;
            xw xw1 = d.b(k, this);
            if(xw1 != d || xw1 != null && xw1.a != i1) {
                ap.a[ap.c] = xw1;
                if(xw1.a == 0)
                    ap.a[ap.c] = null;
            }
            al();
        }
    }

    public void a(byte byte0) {
        if(byte0 == 9)
            an();
        else
            super.a(byte0);
    }

    protected boolean ao() {
        return aI() <= 0 || ax();
    }

    protected void ad() {
        ar = aq;
    }

    public void R() {
        aC = (new StringBuilder()).append("http://s3.amazonaws.com/MinecraftCloaks/").append(aA).append(".png").toString();
        aa = aC;
    }

    public void N() {
        double d1 = o;
        double d2 = p;
        double d3 = q;
        super.N();
        aw = ax;
        ax = 0.0F;
        k(o - d1, p - d2, q - d3);
    }

    public void x() {
        H = 1.62F;
        a(0.6F, 1.8F);
        super.x();
        l(c());
        bC = 0;
    }

    private int aR() {
        if(a(xm.e))
            return 6 - (1 + b(xm.e).c()) * 1;
        if(a(xm.f))
            return 6 + (1 + b(xm.f).c()) * 2;
        else
            return 6;
    }

    protected void s_() {
        int i1 = aR();
        if(ay) {
            az++;
            if(az >= i1) {
                az = 0;
                ay = false;
            }
        } else {
            az = 0;
        }
        bv = (float)az / (float)i1;
    }

    private void l(mh mh1) {
        mh1.a(this);
    }

    public int ap() {
        return av;
    }

    public void a(lc lc1) {
        super.a(lc1);
        a(0.2F, 0.2F);
        d(o, p, q);
        s = 0.10000000149011612D;
        if(aA.equals("Notch"))
            a(new xw(wc.j, 1), true);
        ap.i();
        if(lc1 != null) {
            r = -fs.b(((bB + u) * 3.141593F) / 180F) * 0.1F;
            t = -fs.a(((bB + u) * 3.141593F) / 180F) * 0.1F;
        } else {
            r = t = 0.0D;
        }
        H = 0.1F;
        a(gd.y, 1);
    }

    public void a(mh mh1, int i1) {
        av += i1;
        if(mh1 instanceof wh)
            a(gd.A, 1);
        else
            a(gd.z, 1);
    }

    protected int d(int i1) {
        int j1 = afo.a(ap);
        if(j1 > 0 && U.nextInt(j1 + 1) > 0)
            return i1;
        else
            return super.d(i1);
    }

    public void aq() {
        a(ap.a(ap.c, 1), false);
    }

    public void a(xw xw1) {
        a(xw1, false);
    }

    public void a(xw xw1, boolean flag) {
        if(xw1 == null)
            return;
        fb fb1 = new fb(k, o, (p - 0.30000001192092896D) + (double)G(), q, xw1);
        fb1.c = 40;
        float f = 0.1F;
        if(flag) {
            float f2 = U.nextFloat() * 0.5F;
            float f4 = U.nextFloat() * 3.141593F * 2.0F;
            fb1.r = -fs.a(f4) * f2;
            fb1.t = fs.b(f4) * f2;
            fb1.s = 0.20000000298023224D;
        } else {
            float f1 = 0.3F;
            fb1.r = -fs.a((u / 180F) * 3.141593F) * fs.b((v / 180F) * 3.141593F) * f1;
            fb1.t = fs.b((u / 180F) * 3.141593F) * fs.b((v / 180F) * 3.141593F) * f1;
            fb1.s = -fs.a((v / 180F) * 3.141593F) * f1 + 0.1F;
            f1 = 0.02F;
            float f3 = U.nextFloat() * 3.141593F * 2.0F;
            f1 *= U.nextFloat();
            fb1.r += Math.cos(f3) * (double)f1;
            fb1.s += (U.nextFloat() - U.nextFloat()) * 0.1F;
            fb1.t += Math.sin(f3) * (double)f1;
        }
        a(fb1);
        a(gd.v, 1);
    }

    protected void a(fb fb1) {
        k.a(fb1);
    }

    public float a(ns ns1) {
        float f = ap.a(ns1);
        float f1 = f;
        int i1 = afo.b(ap);
        if(i1 > 0 && ap.b(ns1))
            f1 += i1 * i1 + 1;
        if(a(xm.e))
            f1 *= 1.0F + (float)(b(xm.e).c() + 1) * 0.2F;
        if(a(xm.f))
            f1 *= 1.0F - (float)(b(xm.f).c() + 1) * 0.2F;
        if(a(zt.g) && !afo.g(ap))
            f1 /= 5F;
        if(!z)
            f1 /= 5F;
        return f1;
    }

    public boolean b(ns ns1) {
        return ap.b(ns1);
    }

    public void a(aba aba1) {
        super.a(aba1);
        mj mj1 = aba1.m("Inventory");
        ap.b(mj1);
        aB = aba1.f("Dimension");
        aK = aba1.n("Sleeping");
        a = aba1.e("SleepTimer");
        aW = aba1.h("XpP");
        aU = aba1.f("XpLevel");
        aV = aba1.f("XpTotal");
        if(aK) {
            aL = new sn(fs.c(o), fs.c(p), fs.c(q));
            a(true, true, false);
        }
        if(aba1.c("SpawnX") && aba1.c("SpawnY") && aba1.c("SpawnZ"))
            b = new sn(aba1.f("SpawnX"), aba1.f("SpawnY"), aba1.f("SpawnZ"));
        as.a(aba1);
        aT.b(aba1);
    }

    public void b(aba aba1) {
        super.b(aba1);
        aba1.a("Inventory", ap.a(new mj()));
        aba1.a("Dimension", aB);
        aba1.a("Sleeping", aK);
        aba1.a("SleepTimer", (short)a);
        aba1.a("XpP", aW);
        aba1.a("XpLevel", aU);
        aba1.a("XpTotal", aV);
        if(b != null) {
            aba1.a("SpawnX", b.a);
            aba1.a("SpawnY", b.b);
            aba1.a("SpawnZ", b.c);
        }
        as.b(aba1);
        aT.a(aba1);
    }

    public void a(hu hu) {
    }

    public void c(int i1, int j1, int k1) {
    }

    public void a(int i1, int j1, int k1) {
    }

    public void b(mh mh1, int i1) {
    }

    public float G() {
        return 0.12F;
    }

    protected void Z() {
        H = 1.62F;
    }

    public boolean a(lc lc1, int i1) {
        if(aT.a && !lc1.f())
            return false;
        ca = 0;
        if(aI() <= 0)
            return false;
        if(ax() && !k.I)
            a(true, true, false);
        mh mh1 = lc1.a();
        if((mh1 instanceof wj) || (mh1 instanceof mg)) {
            if(k.v == 0)
                i1 = 0;
            if(k.v == 1)
                i1 = i1 / 2 + 1;
            if(k.v == 3)
                i1 = (i1 * 3) / 2;
        }
        if(i1 == 0)
            return false;
        mh mh2 = mh1;
        if((mh2 instanceof mg) && ((mg)mh2).c != null)
            mh2 = ((mg)mh2).c;
        if(mh2 instanceof zx)
            a((zx)mh2, false);
        a(gd.x, i1);
        return super.a(lc1, i1);
    }

    protected int b(lc lc1, int i1) {
        int j1 = super.b(lc1, i1);
        if(j1 <= 0)
            return 0;
        int k1 = afo.a(ap, lc1);
        if(k1 > 20)
            k1 = 20;
        if(k1 > 0 && k1 <= 20) {
            int l1 = 25 - k1;
            int i2 = j1 * l1 + by;
            j1 = i2 / 25;
            by = i2 % 25;
        }
        return j1;
    }

    protected boolean ar() {
        return false;
    }

    protected void a(zx zx1, boolean flag) {
        if((zx1 instanceof vs) || (zx1 instanceof so))
            return;
        if(zx1 instanceof vz) {
            vz vz1 = (vz)zx1;
            if(vz1.ak() && aA.equals(vz1.ah()))
                return;
        }
        if((zx1 instanceof wh) && !ar())
            return;
        List list = k.a(vz.class, uq.b(o, p, q, o + 1.0D, p + 1.0D, q + 1.0D).b(16D, 4D, 16D));
        Iterator iterator = list.iterator();
        do {
            if(!iterator.hasNext())
                break;
            mh mh1 = (mh)iterator.next();
            vz vz2 = (vz)mh1;
            if(vz2.ak() && vz2.ap() == null && aA.equals(vz2.ah()) && (!flag || !vz2.ai())) {
                vz2.d(false);
                vz2.i(zx1);
            }
        } while(true);
    }

    protected void h(int i1) {
        ap.f(i1);
    }

    protected int as() {
        return ap.h();
    }

    protected void c(lc lc1, int i1) {
        if(!lc1.d() && am())
            i1 = 1 + i1 >> 1;
        i1 = d(lc1, i1);
        i1 = b(lc1, i1);
        d(lc1.e());
        super.c(lc1, i1);
    }

    public void a(aee aee) {
    }

    public void a(at at1) {
    }

    public void a(qp qp) {
    }

    public void a(aim aim) {
    }

    public void i(mh mh1) {
        if(mh1.c(this))
            return;
        xw xw1 = at();
        if(xw1 != null && (mh1 instanceof zx)) {
            xw1.a((zx)mh1);
            if(xw1.a <= 0) {
                xw1.a(this);
                au();
            }
        }
    }

    public xw at() {
        return ap.b();
    }

    public void au() {
        ap.a(ap.c, null);
    }

    public double O() {
        return (double)(H - 0.5F);
    }

    public void av() {
        if(!ay || az >= aR() / 2 || az < 0) {
            az = -1;
            ay = true;
        }
    }

    public void j(mh mh1) {
        int i1 = ap.a(mh1);
        if(a(xm.g))
            i1 += 3 << b(xm.g).c();
        if(a(xm.t))
            i1 -= 2 << b(xm.t).c();
        int j1 = 0;
        int k1 = 0;
        if(mh1 instanceof zx) {
            k1 = afo.a(ap, (zx)mh1);
            j1 += afo.b(ap, (zx)mh1);
        }
        if(V())
            j1++;
        if(i1 > 0 || k1 > 0) {
            boolean flag = M > 0.0F && !z && !q() && !F() && !a(xm.q) && j == null && (mh1 instanceof zx);
            if(flag)
                i1 += U.nextInt(i1 / 2 + 2);
            i1 += k1;
            boolean flag1 = mh1.a(lc.a(this), i1);
            if(flag1) {
                if(j1 > 0) {
                    mh1.c(-fs.a((u * 3.141593F) / 180F) * (float)j1 * 0.5F, 0.10000000000000001D, fs.b((u * 3.141593F) / 180F) * (float)j1 * 0.5F);
                    r *= 0.59999999999999998D;
                    t *= 0.59999999999999998D;
                    b(false);
                }
                if(flag)
                    c(mh1);
                if(k1 > 0)
                    d(mh1);
                if(i1 >= 18)
                    a(df.E);
            }
            xw xw1 = at();
            if(xw1 != null && (mh1 instanceof zx)) {
                xw1.a((zx)mh1, this);
                if(xw1.a <= 0) {
                    xw1.a(this);
                    au();
                }
            }
            if(mh1 instanceof zx) {
                if(mh1.L())
                    a((zx)mh1, true);
                a(gd.w, i1);
                int l1 = afo.c(ap, (zx)mh1);
                if(l1 > 0)
                    mh1.e(l1 * 4);
            }
            d(0.3F);
        }
    }

    public void c(mh mh1) {
    }

    public void d(mh mh1) {
    }

    public void af() {
    }

    public abstract void aa();

    public void b(xw xw1) {
    }

    public void y() {
        super.y();
        aq.a(this);
        if(ar != null)
            ar.a(this);
    }

    // WORKAROUND
    Field bx_a = getClassField("bx", "a");
    Field bx_b = getClassField("bx", "b");
    Field bx_c = getClassField("bx", "c");
    Field bx_d = getClassField("bx", "d");
    Field bx_e = getClassField("bx", "e");
    Field bx_f = getClassField("bx", "f");
    public bx d(int i1, int j1, int k1) {
        if(!k.I) {
            if(ax() || !L())
                return (bx)getValue(bx_e, null);
            if(k.y.c)
                return (bx)getValue(bx_b, null);
            if(k.l())
                return (bx)getValue(bx_c, null);
            if(Math.abs(o - (double)i1) > 3D || Math.abs(p - (double)j1) > 2D || Math.abs(q - (double)k1) > 3D)
                return (bx)getValue(bx_d, null);
            double d1 = 8D;
            double d2 = 5D;
            List list = k.a(wj.class, uq.b((double)i1 - d1, (double)j1 - d2, (double)k1 - d1, (double)i1 + d1, (double)j1 + d2, (double)k1 + d1));
            if(!list.isEmpty())
                return (bx)getValue(bx_f, null);
        }
        a(0.2F, 0.2F);
        H = 0.2F;
        if(k.d(i1, j1, k1)) {
            int l1 = k.e(i1, j1, k1);
            int i2 = oc.e(l1);
            float f = 0.5F;
            float f1 = 0.5F;
            switch(i2) {
            case 0: // '\0'
                f1 = 0.9F;
                break;

            case 2: // '\002'
                f1 = 0.1F;
                break;

            case 1: // '\001'
                f = 0.1F;
                break;

            case 3: // '\003'
                f = 0.9F;
                break;
            }
            c(i2);
            d((float)i1 + f, (float)j1 + 0.9375F, (float)k1 + f1);
        } else {
            d((float)i1 + 0.5F, (float)j1 + 0.9375F, (float)k1 + 0.5F);
        }
        aK = true;
        a = 0;
        aL = new sn(i1, j1, k1);
        r = t = s = 0.0D;
        if(!k.I)
            k.A();
        return (bx)getValue(bx_a, null);
    }

    private void c(int i1) {
        aM = 0.0F;
        aO = 0.0F;
        switch(i1) {
        case 0: // '\0'
            aO = -1.8F;
            break;

        case 2: // '\002'
            aO = 1.8F;
            break;

        case 1: // '\001'
            aM = 1.8F;
            break;

        case 3: // '\003'
            aM = -1.8F;
            break;
        }
    }

    public void a(boolean flag, boolean flag1, boolean flag2) {
        a(0.6F, 1.8F);
        Z();
        sn sn1 = aL;
        sn sn2 = aL;
        if(sn1 != null && k.a(sn1.a, sn1.b, sn1.c) == ns.U.bO) {
            oc.a(k, sn1.a, sn1.b, sn1.c, false);
            sn sn3 = oc.f(k, sn1.a, sn1.b, sn1.c, 0);
            if(sn3 == null)
                sn3 = new sn(sn1.a, sn1.b + 1, sn1.c);
            d((float)sn3.a + 0.5F, (float)sn3.b + H + 0.1F, (float)sn3.c + 0.5F);
        }
        aK = false;
        if(!k.I && flag1)
            k.A();
        if(flag)
            a = 0;
        else
            a = 100;
        if(flag2)
            a(aL);
    }

    private boolean aS() {
        return k.a(aL.a, aL.b, aL.c) == ns.U.bO;
    }

    public static sn a(uy uy1, sn sn1) {
        bn bn1 = uy1.x();
        bn1.c(sn1.a - 3 >> 4, sn1.c - 3 >> 4);
        bn1.c(sn1.a + 3 >> 4, sn1.c - 3 >> 4);
        bn1.c(sn1.a - 3 >> 4, sn1.c + 3 >> 4);
        bn1.c(sn1.a + 3 >> 4, sn1.c + 3 >> 4);
        if(uy1.a(sn1.a, sn1.b, sn1.c) != ns.U.bO) {
            return null;
        } else {
            sn sn2 = oc.f(uy1, sn1.a, sn1.b, sn1.c, 0);
            return sn2;
        }
    }

    public float aw() {
        if(aL != null) {
            int i1 = k.e(aL.a, aL.b, aL.c);
            int j1 = oc.e(i1);
            switch(j1) {
            case 0: // '\0'
                return 90F;

            case 1: // '\001'
                return 0.0F;

            case 2: // '\002'
                return 270F;

            case 3: // '\003'
                return 180F;
            }
        }
        return 0.0F;
    }

    public boolean ax() {
        return aK;
    }

    public boolean ay() {
        return aK && a >= 100;
    }

    public int az() {
        return a;
    }

    public void b(String s) {
    }

    public sn aA() {
        return b;
    }

    public void a(sn sn1) {
        if(sn1 != null)
            b = new sn(sn1);
        else
            b = null;
    }

    public void a(agl agl) {
        a(agl, 1);
    }

    public void a(agl agl, int i1) {
    }

    public void a_(float f, float f1) {
        double d1 = o;
        double d2 = p;
        double d3 = q;
        if(aT.b) {
            double d4 = s;
            float f2 = bt;
            bt = 0.05F;
            super.a_(f, f1);
            s = d4 * 0.59999999999999998D;
            bt = f2;
        } else {
            super.a_(f, f1);
        }
        i(o - d1, p - d2, q - d3);
    }

    public void i(double d1, double d2, double d3) {
        if(j != null)
            return;
        if(a(zt.g)) {
            int i1 = Math.round(fs.a(d1 * d1 + d2 * d2 + d3 * d3) * 100F);
            if(i1 > 0) {
                a(gd.q, i1);
                d(0.015F * (float)i1 * 0.01F);
            }
        } else
        if(F()) {
            int j1 = Math.round(fs.a(d1 * d1 + d3 * d3) * 100F);
            if(j1 > 0) {
                a(gd.m, j1);
                d(0.015F * (float)j1 * 0.01F);
            }
        } else
        if(q()) {
            if(d2 > 0.0D)
                a(gd.o, (int)Math.round(d2 * 100D));
        } else
        if(z) {
            int k1 = Math.round(fs.a(d1 * d1 + d3 * d3) * 100F);
            if(k1 > 0) {
                a(gd.l, k1);
                if(V())
                    d(0.09999999F * (float)k1 * 0.01F);
                else
                    d(0.01F * (float)k1 * 0.01F);
            }
        } else {
            int l1 = Math.round(fs.a(d1 * d1 + d3 * d3) * 100F);
            if(l1 > 25)
                a(gd.p, l1);
        }
    }

    private void k(double d1, double d2, double d3) {
        if(j != null) {
            int i1 = Math.round(fs.a(d1 * d1 + d2 * d2 + d3 * d3) * 100F);
            if(i1 > 0)
                if(j instanceof aik) {
                    a(gd.r, i1);
                    if(c == null)
                        c = new sn(fs.c(o), fs.c(p), fs.c(q));
                    else
                    if(c.a(fs.c(o), fs.c(p), fs.c(q)) >= 1000D)
                        a(df.q, 1);
                } else
                if(j instanceof ec)
                    a(gd.s, i1);
                else
                if(j instanceof pf)
                    a(gd.t, i1);
        }
    }

    protected void c(float f) {
        if(aT.c)
            return;
        if(f >= 2.0F)
            a(gd.n, (int)Math.round((double)f * 100D));
        super.c(f);
    }

    public void a(zx zx1) {
        if(zx1 instanceof wj)
            a(((agl) (df.s)));
    }

    public int b(xw xw1, int i1) {
        int j1 = super.b(xw1, i1);
        if(xw1.c == wc.aR.bN && aZ != null) {
            j1 = xw1.b() + 16;
        } else {
            if(xw1.c == wc.bs.bN)
                if(i1 == 1)
                    return xw1.b();
                else
                    return 141;
            if(d != null && xw1.c == wc.k.bN) {
                int k1 = xw1.l() - e;
                if(k1 >= 18)
                    return 133;
                if(k1 > 13)
                    return 117;
                if(k1 > 0)
                    return 101;
            }
        }
        return j1;
    }

    public void Q() {
        if(aP > 0) {
            aP = 10;
            return;
        } else {
            aQ = true;
            return;
        }
    }

    public void i(int i1) {
        av += i1;
        aW += (float)i1 / (float)aC();
        aV += i1;
        while(aW >= 1.0F)  {
            aW--;
            aT();
        }
    }

    public void j(int i1) {
        aU -= i1;
        if(aU < 0)
            aU = 0;
    }

    public int aC() {
        return 7 + (aU * 7 >> 1);
    }

    private void aT() {
        aU++;
    }

    public void d(float f) {
        if(aT.a)
            return;
        if(!k.I)
            as.a(f);
    }

    public ma aD() {
        return as;
    }

    public boolean a(boolean flag) {
        return (flag || as.c()) && !aT.a;
    }

    public boolean aE() {
        return aI() > 0 && aI() < c();
    }

    public void c(xw xw1, int i1) {
        if(xw1 == d)
            return;
        d = xw1;
        e = i1;
        if(!k.I)
            c(true);
    }

    public boolean e(int i1, int j1, int k1) {
        return true;
    }

    protected int b(wh wh1) {
        int i1 = aU * 7;
        if(i1 > 100)
            return 100;
        else
            return i1;
    }

    protected boolean aF() {
        return true;
    }

    public void b(int i1) {
    }

    public void d(wh wh1) {
        ap.a(wh1.ap);
        bw = wh1.bw;
        as = wh1.as;
        aU = wh1.aU;
        aV = wh1.aV;
        aW = wh1.aW;
        av = wh1.av;
    }

    public xt ap;
    public cs aq, ar;
    protected ma as;
    protected int at;
    public byte au;
    public int av, az, aB, aD, aP;
    public float aw, ax, aM, aN, aO;
    public boolean ay;
    public String aA, aC;
    public double aE, aF, aG, aH, aI;
    public double aJ;
    protected boolean aK, aQ;
    public sn aL;
    private int a, e;
    private sn b, c;
    public float aR, aS, aW;
    public pj aT;
    public int aU, aV;
    private xw d;
    protected float aX, aY;
    public aaa aZ;
}
