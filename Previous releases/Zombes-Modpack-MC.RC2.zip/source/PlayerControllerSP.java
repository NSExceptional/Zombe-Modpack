// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nolvt nonlb safe
// Source File Name:   SourceFile

import net.minecraft.client.Minecraft;

// NEED TO DECOMPILE SEPARATELY WITH SAFE MODE ON
// search: = -180F  * the smaller file
public class abs extends jj {

    protected static final boolean zmodmarker = true;

    public abs(Minecraft minecraft) {
        super(minecraft);
        c = -1;
        d = -1;
        e = -1;
        f = 0.0F;
        g = 0.0F;
        h = 0.0F;
        i = 0;
    }

    public void a(wh wh1) {
        wh1.u = -180F;
    }

    public boolean d() {
        return true;
    }

    public boolean b(int j, int l, int i1, int j1) {
        int k1 = a.f.a(j, l, i1);
        int l1 = a.f.e(j, l, i1);
        boolean flag = super.b(j, l, i1, j1);
        xw xw1 = a.h.at();
        boolean flag1 = a.h.b(ns.m[k1]);
        // -----------------------------------------------------------------------------------------------------------------------
        flag = ZMod.harvestableHandle(flag);
        // -----------------------------------------------------------------------------------------------------------------------
        if(xw1 != null) {
            xw1.a(k1, j, l, i1, ((wh) (a.h)));
            if(xw1.a == 0) {
                xw1.a(((wh) (a.h)));
                a.h.au();
            }
        }
        if(flag && flag1)
            ns.m[k1].a(a.f, ((wh) (a.h)), j, l, i1, l1);
        return flag;
    }

    public void a(int j, int l, int i1, int j1) {
        if(!a.h.e(j, l, i1))
            return;
        a.f.a(((wh) (a.h)), j, l, i1, j1);
        int k1 = a.f.a(j, l, i1);
        if(k1 > 0 && f == 0.0F)
            ns.m[k1].a(a.f, j, l, i1, ((wh) (a.h)));
        if(k1 > 0 && ns.m[k1].a(((wh) (a.h))) >= 1.0F)
            b(j, l, i1, j1);
    }

    public void a() {
        f = 0.0F;
        i = 0;
    }

    public void c(int j, int l, int i1, int j1) {
        if(i > 0) {
            i--;
            return;
        }
        if(j == c && l == d && i1 == e) {
            int k1 = a.f.a(j, l, i1);
            if(!a.h.e(j, l, i1))
                return;
            if(k1 == 0)
                return;
            ns ns1 = ns.m[k1];
            // -------------------------------------------------------------------------------------------------------------------
            float add;
            f += add = ZMod.digProgressHandle(  ns1.a(((wh) (a.h)))  , k1 );
            int skip = add > 1.0f ? (int)(6f / add - 0.99999f) : 5;
            // -------------------------------------------------------------------------------------------------------------------
            if(h % 4F == 0.0F && ns1 != null)
                a.C.b(ns1.bZ.d(), (float)j + 0.5F, (float)l + 0.5F, (float)i1 + 0.5F, (ns1.bZ.b() + 1.0F) / 8F, ns1.bZ.c() * 0.5F);
            h++;
            if(f >= 1.0F) {
                b(j, l, i1, j1);
                f = 0.0F;
                g = 0.0F;
                h = 0.0F;
                i = skip; // ****** UPDATE ******
            }
        } else {
            f = 0.0F;
            g = 0.0F;
            h = 0.0F;
            c = j;
            d = l;
            e = i1;
        }
    }

    public void a(float f1) {
        if(f <= 0.0F) {
            a.w.b = 0.0F;
            a.g.g = 0.0F;
        } else {
            float f2 = g + (f - g) * f1;
            a.w.b = f2;
            a.g.g = f2;
        }
    }

    public float b() {
        // -----------------------------------------------------------------------------------------------------------------------
        return ZMod.digReachHandle();
        // -----------------------------------------------------------------------------------------------------------------------
    }

    public void a(uy uy1) {
        super.a(uy1);
    }

    public wh b(uy uy1) {
        wh wh1 = super.b(uy1);
        return wh1;
    }

    public void c() {
        g = f;
        a.C.c();
    }

    public boolean a(wh wh1, uy uy1, xw xw1, int j, int l, int i1, int j1) {
        int k1 = uy1.a(j, l, i1);
        if(k1 > 0 && ns.m[k1].b(uy1, j, l, i1, wh1))
            return true;
        if(xw1 == null)
            return false;
        else
            return xw1.a(wh1, uy1, j, l, i1, j1);
    }

    public boolean f() {
        return true;
    }

    private int c, d, e, i;
    private float f, g, h;
}
