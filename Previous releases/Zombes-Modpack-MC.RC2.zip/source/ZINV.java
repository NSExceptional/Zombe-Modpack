
public class ZINV extends InventoryPlayer {

    public ZINV(EntityPlayer player) { super(player); }
    
    public void invDropAll() {
        if(ZMod.dropAllHandle()) super.invDropAll();
    }

}
