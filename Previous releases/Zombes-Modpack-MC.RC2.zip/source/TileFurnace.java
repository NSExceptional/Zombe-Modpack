// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb
// Source File Name:   SourceFile

import java.lang.reflect.*;

// search: "CookTime"
public class aee extends jw
    implements hu {

    protected static final boolean zmodmarker = true;

    public aee() {
        d = new xw[3];
        a = 0;
        b = 0;
        c = 0;
    }

    public int a() {
        return d.length;
    }

    public xw f_(int i) {
        return d[i];
    }

    public xw a(int i, int j) {
        if(d[i] != null) {
            if(d[i].a <= j) {
                xw xw1 = d[i];
                d[i] = null;
                return xw1;
            }
            xw xw2 = d[i].a(j);
            if(d[i].a == 0)
                d[i] = null;
            return xw2;
        } else {
            return null;
        }
    }

    public void a(int i, xw xw1) {
        d[i] = xw1;
        if(xw1 != null && xw1.a > d())
            xw1.a = d();
    }

    public String c() {
        return "Furnace";
    }

    public void a(aba aba1) {
        super.a(aba1);
        mj mj1 = aba1.m("Items");
        d = new xw[a()];
        for(int i = 0; i < mj1.d(); i++) {
            aba aba2 = (aba)mj1.a(i);
            byte byte0 = aba2.d("Slot");
            if(byte0 >= 0 && byte0 < d.length)
                d[byte0] = xw.a(aba2);
        }

        a = aba1.e("BurnTime");
        c = aba1.e("CookTime");
        b = a(d[1]);
    }

    public void b(aba aba1) {
        super.b(aba1);
        aba1.a("BurnTime", (short)a);
        aba1.a("CookTime", (short)c);
        mj mj1 = new mj();
        for(int i = 0; i < d.length; i++)
            if(d[i] != null) {
                aba aba2 = new aba();
                aba2.a("Slot", (byte)i);
                d[i].b(aba2);
                mj1.a(aba2);
            }

        aba1.a("Items", mj1);
    }

    public int d() {
        return 64;
    }

    public int b(int i) {
        // -----------------------------------------------------------------------------------------------------------------------
        return (c * i) / ZMod.furnaceSmeltTimeHandle();
        // -----------------------------------------------------------------------------------------------------------------------
    }

    public int c(int i) {
        // -----------------------------------------------------------------------------------------------------------------------
        if(b == 0) b = ZMod.furnaceSmeltTimeHandle();
        // -----------------------------------------------------------------------------------------------------------------------
        return (a * i) / b;
    }

    public boolean g() {
        return a > 0;
    }

    public void j_() {
        boolean flag = a > 0;
        boolean flag1 = false;
        // -----------------------------------------------------------------------------------------------------------------------
        if(a>0 && ZMod.furnaceUseFuelHandle(  a, o() )) a--;
        // -----------------------------------------------------------------------------------------------------------------------
        if(!i.I) {
            if(a == 0 && o()) {
                b = a = a(d[1]);
                if(a > 0) {
                    flag1 = true;
                    if(d[1] != null) {
                        // -------------------------------------------------------------------------------------------------------
                        d[1] = ZMod.furnaceDecFuelHandle( d[1] ); // update
                        // -------------------------------------------------------------------------------------------------------
                    }
                }
            }
            if(g() && o()) {
                c++;
                // ---------------------------------------------------------------------------------------------------------------
                if(c >= ZMod.furnaceSmeltTimeHandle()) {
                // ---------------------------------------------------------------------------------------------------------------
                    c = 0;
                    n();
                    flag1 = true;
                }
            // -------------------------------------------------------------------------------------------------------------------
            } else if(ZMod.furnaceWasteHandle()) {
            // -------------------------------------------------------------------------------------------------------------------
                c = 0;
            }
            if(flag != (a > 0)) {
                flag1 = true;
                aem.a(a > 0, i, j, k, l);
            }
        }
        if(flag1)
            B_();
    }

    private boolean o() {
        if(d[0] == null)
            return false;
        // -----------------------------------------------------------------------------------------------------------------------
        xw xw1 = ZMod.furnaceSmeltingHandle(  d[0].a().bN  );
        if(xw1 == null) xw1 = dn.a().a(d[0].a().bN);
        // -----------------------------------------------------------------------------------------------------------------------
        if(xw1 == null)
            return false;
        if(d[2] == null)
            return true;
        if(!d[2].a(xw1))
            return false;
        if(d[2].a < d() && d[2].a < d[2].c())
            return true;
        return d[2].a < xw1.c();
    }

    public void n() {
        if(!o())
            return;
        // -----------------------------------------------------------------------------------------------------------------------
        xw xw1 = ZMod.furnaceSmeltingHandle(  d[0].a().bN  );
        if(xw1 == null) xw1 = dn.a().a(d[0].a().bN);
        // -----------------------------------------------------------------------------------------------------------------------
        if(d[2] == null)
            d[2] = xw1.k();
        else
        if(d[2].c == xw1.c)
            d[2].a++;
        d[0].a--;
        if(d[0].a <= 0)
            d[0] = null;
    }

    // ===========================================================================================================================
    private static boolean mlInit = false;
    private static Class mlClass;
    private static Method mlMethod;
    private int a(xw xw1) {
        if(xw1 == null)
            return 0;
        int i = xw1.a().bN;
        // -----------------------------------------------------------------------------------------------------------------------
        int fuel = ZMod.furnaceFuelHandle(  i  ); if(fuel!=0) return fuel; //
        if(i < 256 && Block.blockArr[i].blockMat == Material.d) return ZMod.furnaceWoodFuelHandle(); //
        // -----------------------------------------------------------------------------------------------------------------------
        if(i == wc.D.bN)
            return 100;
        if(i == wc.m.bN)
            return 1600;
        if(i == wc.ay.bN)
            return 20000;
        if(i == ns.A.bO)
            return 100;
        // -----------------------------------------------------------------------------------------------------------------------
        if(i == wc.bo.bN) return 2400; //
        try {
            if(!mlInit) {
                mlInit = true;
                mlClass = Class.forName("ModLoader");
                mlMethod = mlClass.getDeclaredMethod("AddAllFuel", new Class[]{ Integer.TYPE });
            }
            if(mlMethod != null) return (Integer)(mlMethod.invoke(null, new Object[]{ i })); // update: i
        } catch(Exception whatever) { }
        return 0;
        // -----------------------------------------------------------------------------------------------------------------------
    }
    // ===========================================================================================================================

    public boolean a_(wh wh1) {
        if(i.b(j, k, l) != this)
            return false;
        return wh1.f((double)j + 0.5D, (double)k + 0.5D, (double)l + 0.5D) <= 64D;
    }

    public void e() {
    }

    public void C_() {
    }

    private xw d[];
    public int a, b, c;
}
