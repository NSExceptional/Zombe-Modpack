// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.lang.reflect.*;

// search: "BurnTime"
public class sf extends os implements ls {

    protected static final boolean zmodmarker = true;

    public sf() {
        h = new iw[3];
        a = 0;
        b = 0;
        c = 0;
    }

    public int a() {
        return h.length;
    }

    public iw d_(int j) {
        return h[j];
    }

    public iw a(int j, int k) {
        if(h[j] != null) {
            if(h[j].a <= k) {
                iw iw1 = h[j];
                h[j] = null;
                return iw1;
            }
            iw iw2 = h[j].a(k);
            if(h[j].a == 0)
                h[j] = null;
            return iw2;
        } else {
            return null;
        }
    }

    public void a(int j, iw iw1) {
        h[j] = iw1;
        if(iw1 != null && iw1.a > d())
            iw1.a = d();
    }

    public String c() {
        return "Furnace";
    }

    public void a(nq nq1) {
        super.a(nq1);
        sk sk1 = nq1.l("Items");
        h = new iw[a()];
        for(int j = 0; j < sk1.c(); j++) {
            nq nq2 = (nq)sk1.a(j);
            byte byte0 = nq2.c("Slot");
            if(byte0 >= 0 && byte0 < h.length)
                h[byte0] = new iw(nq2);
        }

        a = nq1.d("BurnTime");
        c = nq1.d("CookTime");
        b = a(h[1]);
    }

    public void b(nq nq1) {
        super.b(nq1);
        nq1.a("BurnTime", (short)a);
        nq1.a("CookTime", (short)c);
        sk sk1 = new sk();
        for(int j = 0; j < h.length; j++)
            if(h[j] != null) {
                nq nq2 = new nq();
                nq2.a("Slot", (byte)j);
                h[j].a(nq2);
                sk1.a(nq2);
            }

        nq1.a("Items", sk1);
    }

    public int d() {
        return 64;
    }

    public int b(int j) {
        // -----------------------------------------------------------------------------------------------------------------------
        return (c * j) / ZMod.furnaceSmeltTimeHandle();
        // -----------------------------------------------------------------------------------------------------------------------
    }

    public int c(int j) {
        // -----------------------------------------------------------------------------------------------------------------------
        if(b == 0) b = ZMod.furnaceSmeltTimeHandle();
        // -----------------------------------------------------------------------------------------------------------------------
        return (a * j) / b;
    }

    public boolean b() {
        return a > 0;
    }

    public void m_() {
        boolean flag = a > 0;
        boolean flag1 = false;
        // -----------------------------------------------------------------------------------------------------------------------
        if(a>0 && ZMod.furnaceUseFuelHandle(  a, i()  )) a--;
        // -----------------------------------------------------------------------------------------------------------------------
        if(!d.B) {
            if(a == 0 && i()) {
                b = a = a(h[1]);
                if(a > 0) {
                    flag1 = true;
                    if(h[1] != null) {
                        // -------------------------------------------------------------------------------------------------------
                        h[1] = (iw)ZMod.furnaceDecFuelHandle( h[1] );
                        // -------------------------------------------------------------------------------------------------------
                    }
                }
            }
            if(b() && i()) {
                c++;
                // ---------------------------------------------------------------------------------------------------------------
                if(c >= ZMod.furnaceSmeltTimeHandle()) {
                // ---------------------------------------------------------------------------------------------------------------
                    c = 0;
                    g();
                    flag1 = true;
                }
            // -------------------------------------------------------------------------------------------------------------------
            } else if(ZMod.furnaceWasteHandle()) {
            // -------------------------------------------------------------------------------------------------------------------
                c = 0;
            }
            // -------------------------------------------------------------------------------------------------------------------
            if(flag != (a > 0) || ZMod.furnaceWorldUpdateHandle(a, e, f, g)) {
            // -------------------------------------------------------------------------------------------------------------------
                flag1 = true;
                sx.a(a > 0, d, e, f, g);
            }
        }
        if(flag1)
            y_();
    }

    private boolean i() {
        if(h[0] == null)
            return false;
        // -----------------------------------------------------------------------------------------------------------------------
        iw iw1 = (iw)ZMod.furnaceSmeltingHandle(  h[0].a().be  );
        if(iw1 == null) iw1 = ew.a().a(h[0].a().be);
        // -----------------------------------------------------------------------------------------------------------------------
        if(iw1 == null)
            return false;
        if(h[2] == null)
            return true;
        if(!h[2].a(iw1))
            return false;
        if(h[2].a < d() && h[2].a < h[2].c())
            return true;
        return h[2].a < iw1.c();
    }

    public void g() {
        if(!i())
            return;
        // -----------------------------------------------------------------------------------------------------------------------
        iw iw1 = (iw)ZMod.furnaceSmeltingHandle(  h[0].a().be  );
        if(iw1 == null) iw1 = ew.a().a(h[0].a().be);
        // -----------------------------------------------------------------------------------------------------------------------
        if(h[2] == null)
            h[2] = iw1.k();
        else
        if(h[2].c == iw1.c)
            h[2].a++;
        h[0].a--;
        if(h[0].a <= 0)
            h[0] = null;
    }

    // ===========================================================================================================================
    private static boolean mlInit = false;
    private static Class mlClass;
    private static Method mlMethod;

    private int a(iw iw1) {
        if(iw1 == null)
            return 0;
        int j = iw1.a().be;
        int fuel = ZMod.furnaceFuelHandle(  j  ); if(fuel!=0) return fuel; // update: j
        if(j < 256 && un.m[j].bA == lj.d) return ZMod.furnaceWoodFuelHandle();
        if(j == gk.B.be)
            return 100;
        if(j == gk.k.be)
            return 1600;
        if(j == gk.aw.be)
            return 20000;
        if(j == un.z.bn) return 100;
        try {
            if(!mlInit) {
                mlInit = true;
                mlClass = Class.forName("ModLoader");
                mlMethod = mlClass.getDeclaredMethod("AddAllFuel", new Class[]{ Integer.TYPE });
            }
            if(mlMethod != null) return (Integer)(mlMethod.invoke(null, new Object[]{ j })); // update: j
        } catch(Exception whatever) { }
        return 0;
    }
    // ===========================================================================================================================

    public boolean a_(gq gq1) {
        if(d.b(e, f, g) != this)
            return false;
        return gq1.f((double)e + 0.5D, (double)f + 0.5D, (double)g + 0.5D) <= 64D;
    }

    private iw h[];
    public int a, b, c;
}
