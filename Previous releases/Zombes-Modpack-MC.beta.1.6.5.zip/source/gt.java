// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;

// search: "deadmau5" * the one with simpler IF
public class gt extends bu {

    protected static final boolean zmodmarker = true;

    public gt(kk kk1, float f1) {
        e = kk1;
        c = f1;
    }

    public void a(kk kk1) {
        f = kk1;
    }

    public void a(lo lo1, double d1, double d2, double d3, 
            float f1, float f2) {
        GL11.glPushMatrix();
        GL11.glDisable(2884);
        e.m = d(lo1, f2);
        if(f != null)
            f.m = e.m;
        e.n = lo1.al();
        if(f != null)
            f.n = e.n;
        try {
            float f3 = lo1.I + (lo1.H - lo1.I) * f2;
            float f4 = lo1.aU + (lo1.aS - lo1.aU) * f2;
            float f5 = lo1.aV + (lo1.aT - lo1.aV) * f2;
            b(lo1, d1, d2, d3);
            float f6 = c(lo1, f2);
            a(lo1, f6, f3, f2);
            float f7 = 0.0625F;
            GL11.glEnable(32826);
            GL11.glScalef(-1F, -1F, 1.0F);
            a(lo1, f2);
            GL11.glTranslatef(0.0F, -24F * f7 - 0.0078125F, 0.0F);
            float f8 = lo1.ak + (lo1.al - lo1.ak) * f2;
            float f9 = lo1.am - lo1.al * (1.0F - f2);
            if(f8 > 1.0F)
                f8 = 1.0F;
            a(lo1.bA, lo1.p_());
            GL11.glEnable(3008);
            e.a(lo1, f9, f8, f2);
            e.a(f9, f8, f6, f4 - f3, f5, f7);
            for(int i = 0; i < 4; i++)
                if(a(lo1, i, f2)) {
                    f.a(f9, f8, f6, f4 - f3, f5, f7);
                    GL11.glDisable(3042);
                    GL11.glEnable(3008);
                }

            b(lo1, f2);
            float f10 = lo1.a(f2);
            int j = a(lo1, f10, f2);
            if((j >> 24 & 0xff) > 0 || lo1.aa > 0 || lo1.ad > 0) {
                GL11.glDisable(3553);
                GL11.glDisable(3008);
                GL11.glEnable(3042);
                GL11.glBlendFunc(770, 771);
                GL11.glDepthFunc(514);
                if(lo1.aa > 0 || lo1.ad > 0) {
                    GL11.glColor4f(f10, 0.0F, 0.0F, 0.4F);
                    e.a(f9, f8, f6, f4 - f3, f5, f7);
                    for(int k = 0; k < 4; k++)
                        if(b(lo1, k, f2)) {
                            GL11.glColor4f(f10, 0.0F, 0.0F, 0.4F);
                            f.a(f9, f8, f6, f4 - f3, f5, f7);
                        }

                }
                if((j >> 24 & 0xff) > 0) {
                    float f11 = (float)(j >> 16 & 0xff) / 255F;
                    float f12 = (float)(j >> 8 & 0xff) / 255F;
                    float f13 = (float)(j & 0xff) / 255F;
                    float f14 = (float)(j >> 24 & 0xff) / 255F;
                    GL11.glColor4f(f11, f12, f13, f14);
                    e.a(f9, f8, f6, f4 - f3, f5, f7);
                    for(int l = 0; l < 4; l++)
                        if(b(lo1, l, f2)) {
                            GL11.glColor4f(f11, f12, f13, f14);
                            f.a(f9, f8, f6, f4 - f3, f5, f7);
                        }

                }
                GL11.glDepthFunc(515);
                GL11.glDisable(3042);
                GL11.glEnable(3008);
                GL11.glEnable(3553);
            }
            GL11.glDisable(32826);
        }
        catch(Exception exception) {
            exception.printStackTrace();
        }
        GL11.glEnable(2884);
        GL11.glPopMatrix();
        a(lo1, d1, d2, d3);
    }

    protected void b(lo lo1, double d1, double d2, double d3) {
        GL11.glTranslatef((float)d1, (float)d2, (float)d3);
    }

    protected void a(lo lo1, float f1, float f2, float f3) {
        GL11.glRotatef(180F - f2, 0.0F, 1.0F, 0.0F);
        if(lo1.ad > 0) {
            float f4 = ((((float)lo1.ad + f3) - 1.0F) / 20F) * 1.6F;
            f4 = ik.c(f4);
            if(f4 > 1.0F)
                f4 = 1.0F;
            GL11.glRotatef(f4 * a(lo1), 0.0F, 0.0F, 1.0F);
        }
    }

    protected float d(lo lo1, float f1) {
        return lo1.d(f1);
    }

    protected float c(lo lo1, float f1) {
        return (float)lo1.bt + f1;
    }

    protected void b(lo lo1, float f1) {
    }

    protected boolean b(lo lo1, int i, float f1) {
        return a(lo1, i, f1);
    }

    protected boolean a(lo lo1, int i, float f1) {
        return false;
    }

    protected float a(lo lo1) {
        return 90F;
    }

    protected int a(lo lo1, float f1, float f2) {
        return 0;
    }

    protected void a(lo lo1, float f1) {
        // -----------------------------------------------------------------------------------------------------------------------
        ZMod.resizeHandle(lo1);
        // -----------------------------------------------------------------------------------------------------------------------
    }

    protected void a(lo lo1, double d1, double d2, double d3) {
        if(Minecraft.w())
            a(lo1, Integer.toString(lo1.aD), d1, d2, d3, 64);
    }

    protected void a(lo lo1, String s, double d1, double d2, double d3, int i) {
        float f1 = lo1.f(b.h);
        if(f1 > (float)i)
            return;
        se se1 = a();
        float f2 = 1.6F;
        float f3 = 0.01666667F * f2;
        GL11.glPushMatrix();
        GL11.glTranslatef((float)d1 + 0.0F, (float)d2 + 2.3F, (float)d3);
        GL11.glNormal3f(0.0F, 1.0F, 0.0F);
        GL11.glRotatef(-b.i, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(b.j, 1.0F, 0.0F, 0.0F);
        GL11.glScalef(-f3, -f3, f3);
        GL11.glDisable(2896);
        GL11.glDepthMask(false);
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        ns ns1 = ns.a;
        byte byte0 = 0;
        if(s.equals("deadmau5"))
            byte0 = -10;
        GL11.glDisable(3553);
        ns1.b();
        int j = se1.a(s) / 2;
        ns1.a(0.0F, 0.0F, 0.0F, 0.25F);
        ns1.a(-j - 1, -1 + byte0, 0.0D);
        ns1.a(-j - 1, 8 + byte0, 0.0D);
        ns1.a(j + 1, 8 + byte0, 0.0D);
        ns1.a(j + 1, -1 + byte0, 0.0D);
        ns1.a();
        GL11.glEnable(3553);
        se1.b(s, -se1.a(s) / 2, byte0, 0x20ffffff);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        se1.b(s, -se1.a(s) / 2, byte0, -1);
        GL11.glEnable(2896);
        GL11.glDisable(3042);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glPopMatrix();
    }

    public void a(si si, double d1, double d2, double d3,
            float f1, float f2) {
        a((lo)si, d1, d2, d3, f1, f2);
    }

    protected kk e, f;
}
