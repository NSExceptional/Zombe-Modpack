
public final class ZBFL extends ni {

    public ZBFL() {
        super(60);
        c(0.6F).a(d).a("farmland"); // "farmland" * drop the last function.
    }

    // EntityWalkingOn: function with  nextInt(4) == 0  in it
    public void b(World map, int x, int y, int z, Entity ent) {
        return;
    }

}
