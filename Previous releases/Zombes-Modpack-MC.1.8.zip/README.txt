
 0) Before anything

     The one and only official place where this modpack is distributed is:
         www.minecraftforum.net/topic/91055-/
     Be warned: if you got it from elsewhere, it might not be clean.
     Similarly, people who redistribute it elsewhere sometimes put a Donate
     With Paypal button on their page. We never see this money.

     Have fun using this modpack!


 I) Installation

     0) To install this modpack, you must first locate your local Minecraft 
        folder. It depends on your OS:
          - Windows XP/7: %APPDATA%\.minecraft
          - GNU/Linux:    ~/.minecraft
          - Mac/OSX:      ~/Library/Application Support/minecraft

    You can skip this part entirely if you are using a mod-installation tool
    like MCPatcher, MagicLauncher or else, and if it worked of course.

    Then, starting from this folder, you will have to do the following:

     1) (Optional) Making subfolders for the modpack
         a) In your minecraft folder, create a subfolder named 'mods/zombe'
         b) Go in the 'config' folder of this modpack's archive
              - Copy every .txt file from it into mods/zombe
                so that you have mods/zombe/names.txt
                               " mods/zombe/config.txt
                                           ...etc

     2) Installation of the modpack's core
         a) In your minecraft folder, locate and open subfolder 'versions/1.8'
         b) Make a copy of this subfolder named, for example, '1.8-zombe'
         c) Rename files inside accordingly; for example:
                versions/1.8-zombe/1.8-zombe.jar
                versions/1.8-zombe/1.8-zombe.json
         d) Open the text file "1.8-zombe.json" with your favorite text editor
            Modify the first two lines accordingly; for example:
                {
                    "id": "1.8-zombe",
         e) Locate the file '1.8-zombe.jar' which we will now call "the jar"
         f) Open the jar as a Zip file with a tool like 7-zip
         g) In the jar, delete the subfolder 'META-INF'
            or, at least, the file 'META-INF/MOJANGCS.SF'
            Keep the jar opened
         h) Go in the 'Classes' folder of this modpack's archive
              - Copy files from it into the jar
              - Not all class files are required for the modpack to work:
                a list of mods and features associated with each file can 
                be found in 'zombe class files <version>.txt' in the archive
            You can now close the jar

     3) Installation of mods
        Mods class files are in the 'Mods' folder of this modpack's archive
         alternative a) Copy the mods class files right into the jar

         alternative b) (recommended) Copy the mods class files into zombe's
             version folder; for example:
                 versions/1.8-zombe/zombe/mod/Fly.class

         alternative c) (NOT recommended) Copy the mods class files globally, 
             for all versions, in 'mods/zombe'; for example:
                 mods/zombe/mod/Fly.class

     4) Configuration of the Minecraft Launcher
         a) Click [New Profile]
              - give it a name
              - disable "Automatically ask Mojang for assistance"
              - Use version: select "release 1.8-zombe"
              - Click [Save profile]
         b) Play


 II) Configuration of the modpack

     alternative 1) Using the config file
        Starting from your local Minecraft folder (see I.0):
         a) Open mods/zombe/config.txt with your favorite text editor
             If it doesn't exist, check mods/zombe/default.txt for inspiration
             If it doesn't exist either, launch the game with zombe once
         b) Enable the wanted mods by finding their corresponding line, like:
                 #modFlyEnabled = yes
             or
                 modFlyEnabled = no
             and change them, like:
                 modFlyEnabled = yes
         c) (optional) Configure the enabled mods by setting the values you 
             want to the variables that immediately follow

     alternative 2) (recommended) Using the ingame config menu
         a) Launch the game with zombe installed
         b) While ingame (in any world), press F7* to open the config menu
            * default key, can be set


 III) Compatibility

     1) This mod may or may not be compatible with modloader or Forge, 
        depending on many factors (mods versions, installation order...)

     2) It is usually compatible with:
          - ModLoader
          - Optifine
          - Rei's minimap
          - Inventory Tweaks

        It is usually incompatible with Forge because, since 1.6 or so,
        it's the Forge's way or the highway.

     3) The golden rule is to install Zombe's modpack BEFORE EVERYTHING ELSE,
        including Modloader, Forge, and everything else.
    
    Class files modified by Zombe can conflict with files modified by 
    Modloader, Forge and other mods. These files are often essential for 
    these mods but not for Zombe which was designed to be more robust to 
    missing files, that's the reason behind the previous assertions and 
    more specificaly the third.
    Of course, with missing files you should also expect missing features.


 IV) Troubleshooting

    Original throubleshooting page:
        http://dl.dropbox.com/u/19090066/minecraft/readme.html#trouble
    
    note: This webpage can go from slightly-out-of-date to outright-obsolete. 
          If you need up-to-date information you can not find by yourself 
          or want to report a bug you just found in the modpack, you can go 
          on the official Zombe modpack forum thread at this location:
              www.minecraftforum.net/topic/91055-/


 V) Credits

    All credits go first to Zombe (aka tanzanite) for the modpack's existence
    and updating work up to v.6.2 / MC 1.2.5.
    Then, credits go to the contributors:
        md_5 for 1.3.1
        NolanSyKinsley for 1.3.2 and 1.4.2
        Nilat for 1.4.4 up to 1.8


