// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.util.*;

// search: "random.explode"
public class na {

    protected static final boolean zmodmarker = true;
    private boolean creeper;
    private int eX, eY, eZ;

    public na(dt dt1, om om1, double d1, double d2, double d3, float f1) {
        eX = (int)d1; eY = (int)d2; eZ = (int)d3; // update
        creeper = om1 instanceof ep; // update : creeper
        f = ZMod.modBoomEnabled && !ZMod.isMultiplayer ? f1 * (creeper ? ZMod.optBoomScaleCreeper : ZMod.optBoomScaleTNT) : f1; // update AND DO NOT FORGET TO REMOVE THE ORIGINAL!
        a = false;
        h = new Random();
        g = new HashSet();
        i = dt1;
        e = om1;
        b = d1;
        c = d2;
        d = d3;
    }

    public void a() {
        float f1 = f;
        int j = 16;
        for(int k = 0; k < j; k++) {
            for(int i1 = 0; i1 < j; i1++) {
label0:
                for(int k1 = 0; k1 < j; k1++) {
                    if(k != 0 && k != j - 1 && i1 != 0 && i1 != j - 1 && k1 != 0 && k1 != j - 1)
                        continue;
                    double d1 = ((float)k / ((float)j - 1.0F)) * 2.0F - 1.0F;
                    double d2 = ((float)i1 / ((float)j - 1.0F)) * 2.0F - 1.0F;
                    double d3 = ((float)k1 / ((float)j - 1.0F)) * 2.0F - 1.0F;
                    double d4 = Math.sqrt(d1 * d1 + d2 * d2 + d3 * d3);
                    d1 /= d4;
                    d2 /= d4;
                    d3 /= d4;
                    float f2 = f * (0.7F + i.k.nextFloat() * 0.6F);
                    double d6 = b;
                    double d8 = c;
                    double d10 = d;
                    float f3 = 0.3F;
                    do {
                        if(f2 <= 0.0F)
                            continue label0;
                        int k4 = gq.b(d6);
                        int l4 = gq.b(d8);
                        int i5 = gq.b(d10);
                        int j5 = i.a(k4, l4, i5);
                        if(j5 > 0)
                            f2 -= (qk.m[j5].a(e) + 0.3F) * f3;
                        if(f2 > 0.0F)
                            g.add(new rm(k4, l4, i5));
                        d6 += d1 * (double)f3;
                        d8 += d2 * (double)f3;
                        d10 += d3 * (double)f3;
                        f2 -= f3 * 0.75F;
                    } while(true);
                }

            }

        }

        f *= 2.0F;
        int l = gq.b(b - (double)f - 1.0D);
        int j1 = gq.b(b + (double)f + 1.0D);
        int l1 = gq.b(c - (double)f - 1.0D);
        int i2 = gq.b(c + (double)f + 1.0D);
        int j2 = gq.b(d - (double)f - 1.0D);
        int k2 = gq.b(d + (double)f + 1.0D);
        List list = i.b(e, di.b(l, l1, j2, j1, i2, k2));
        ay ay1 = ay.b(b, c, d);
        for(int l2 = 0; l2 < list.size(); l2++) {
            om om1 = (om)list.get(l2);
            double d5 = om1.f(b, c, d) / (double)f;
            if(d5 <= 1.0D) {
                double d7 = om1.aI - b;
                double d9 = om1.aJ - c;
                double d11 = om1.aK - d;
                double d12 = gq.a(d7 * d7 + d9 * d9 + d11 * d11);
                d7 /= d12;
                d9 /= d12;
                d11 /= d12;
                double d13 = i.a(ay1, om1.aS);
                double d14 = (1.0D - d5) * d13;
                om1.a(e, (int)(((d14 * d14 + d14) / 2D) * 8D * (double)f + 1.0D));
                double d15 = d14;
                om1.aL += d7 * d15;
                om1.aM += d9 * d15;
                om1.aN += d11 * d15;
            }
        }

        f = f1;
        ArrayList arraylist = new ArrayList();
        arraylist.addAll(g);
        if(a) {
            for(int i3 = arraylist.size() - 1; i3 >= 0; i3--) {
                rm rm1 = (rm)arraylist.get(i3);
                int j3 = rm1.a;
                int k3 = rm1.b;
                int l3 = rm1.c;
                int i4 = i.a(j3, k3, l3);
                int j4 = i.a(j3, k3 - 1, l3);
                if(i4 == 0 && qk.o[j4] && h.nextInt(3) == 0)
                    i.e(j3, k3, l3, qk.ar.bk);
            }

        }
    }

    public void b() {
        // =================================================================================================
        if(creeper) {
            if(ZMod.optBoomSafeRange == -1) return;
            if(ZMod.optBoomSafeRange > 0) {
                int x1=eX-ZMod.optBoomSafeRange,x2=eX+ZMod.optBoomSafeRange,y1=eY-ZMod.optBoomSafeRange,y2=eY+ZMod.optBoomSafeRange,z1=eZ-ZMod.optBoomSafeRange,z2=eZ+ZMod.optBoomSafeRange;
                for(int x=x1;x<=x2;x++) for(int y=y1;y<=y2;y++) for(int z=z1;z<=z2;z++) if((ZMod.block[ZMod.worldGetId(x,y,z)] & ZMod.CRAFT)!=0) return;
            }
        }
        // =================================================================================================

        i.a(b, c, d, "random.explode", 4F, (1.0F + (i.k.nextFloat() - i.k.nextFloat()) * 0.2F) * 0.7F);
        ArrayList arraylist = new ArrayList();
        arraylist.addAll(g);
        for(int j = arraylist.size() - 1; j >= 0; j--) {
            rm rm1 = (rm)arraylist.get(j);
            int k = rm1.a;
            int l = rm1.b;
            int i1 = rm1.c;
            int j1 = i.a(k, l, i1);
            for(int k1 = 0; k1 < 1; k1++) {
                double d1 = (float)k + i.k.nextFloat();
                double d2 = (float)l + i.k.nextFloat();
                double d3 = (float)i1 + i.k.nextFloat();
                double d4 = d1 - b;
                double d5 = d2 - c;
                double d6 = d3 - d;
                double d7 = gq.a(d4 * d4 + d5 * d5 + d6 * d6);
                d4 /= d7;
                d5 /= d7;
                d6 /= d7;
                double d8 = 0.5D / (d7 / (double)f + 0.10000000000000001D);
                d8 *= i.k.nextFloat() * i.k.nextFloat() + 0.3F;
                d4 *= d8;
                d5 *= d8;
                d6 *= d8;
                i.a("explode", (d1 + b * 1.0D) / 2D, (d2 + c * 1.0D) / 2D, (d3 + d * 1.0D) / 2D, d4, d5, d6);
                i.a("smoke", d1, d2, d3, d4, d5, d6);
            }

            // ================================================================
            float chance = 0.3f;
            if(ZMod.modBoomEnabled && !ZMod.isMultiplayer) {
                int id = j1; // update : id
                if((ZMod.block[id] & ZMod.ORE) != 0) chance = ZMod.optBoomDropOreChance;
                else chance = ZMod.optBoomDropChance;
            }
            // ================================================================

            if(j1 > 0) {
                qk.m[j1].a(i, k, l, i1, i.e(k, l, i1), chance); // UPDATE THIS TOO YOU MORON !
                i.e(k, l, i1, 0);
                qk.m[j1].c(i, k, l, i1);
            }
        }

    }

    public boolean a;
    private Random h;
    private dt i;
    public double b, c, d;
    public om e;
    public float f;
    public Set g;
}
