// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.lang.reflect.*;

public class oj extends ll implements jc {

    protected static final boolean zmodmarker = true;

    public oj() {
        h = new gz[3];
        a = 0;
        b = 0;
        c = 0;
    }

    public int a() {
        return h.length;
    }

    public gz c_(int j) {
        return h[j];
    }

    public gz a(int j, int k) {
        if(h[j] != null) {
            if(h[j].a <= k) {
                gz gz1 = h[j];
                h[j] = null;
                return gz1;
            }
            gz gz2 = h[j].a(k);
            if(h[j].a == 0)
                h[j] = null;
            return gz2;
        } else {
            return null;
        }
    }

    public void a(int j, gz gz1) {
        h[j] = gz1;
        if(gz1 != null && gz1.a > d())
            gz1.a = d();
    }

    public String c() {
        return "Furnace";
    }

    public void a(ks ks1) {
        super.a(ks1);
        oo oo1 = ks1.l("Items");
        h = new gz[a()];
        for(int j = 0; j < oo1.c(); j++) {
            ks ks2 = (ks)oo1.a(j);
            byte byte0 = ks2.c("Slot");
            if(byte0 >= 0 && byte0 < h.length)
                h[byte0] = new gz(ks2);
        }

        a = ks1.d("BurnTime");
        c = ks1.d("CookTime");
        b = a(h[1]);
    }

    public void b(ks ks1) {
        super.b(ks1);
        ks1.a("BurnTime", (short)a);
        ks1.a("CookTime", (short)c);
        oo oo1 = new oo();
        for(int j = 0; j < h.length; j++)
            if(h[j] != null) {
                ks ks2 = new ks();
                ks2.a("Slot", (byte)j);
                h[j].a(ks2);
                oo1.a(ks2);
            }

        ks1.a("Items", oo1);
    }

    public int d() {
        return 64;
    }

    public int b(int j) {
        // -----------------------------------------------------------------------------------------------------------------------
        int time = ZMod.isMultiplayer || !ZMod.modFurnaceEnabled ? 200 : ZMod.optFurnaceSmeltingTime;
        return (c * j) / time;
        // -----------------------------------------------------------------------------------------------------------------------
    }

    public int c(int j) {
        if(b == 0)
            b = 200;
        return (a * j) / b;
    }

    public boolean b() {
        return a > 0;
    }

    public void m_() {
        boolean flag = a > 0;
        boolean flag1 = false;
        // -----------------------------------------------------------------------------------------------------------------------
        if(a>0 && (ZMod.isMultiplayer || !ZMod.modFurnaceEnabled || (ZMod.optFurnaceInfiniteFuel > a && (ZMod.optFurnaceFuelWaste || i())))) a--;
        // -----------------------------------------------------------------------------------------------------------------------
        if(!d.t) {
            if(a == 0 && i()) {
                b = a = a(h[1]);
                if(a > 0) {
                    flag1 = true;
                    if(h[1] != null) {
                        h[1].a--;
                        if(h[1].a == 0)
                            h[1] = null;
                    }
                }
            }
            if(b() && i()) {
                c++;
                // ---------------------------------------------------------------------------------------------------------------
                int done = ZMod.isMultiplayer || !ZMod.modFurnaceEnabled ? 200 : ZMod.optFurnaceSmeltingTime;
                if(c >= done) { // update == to >=
                // ---------------------------------------------------------------------------------------------------------------
                    c = 0;
                    g();
                    flag1 = true;
                }
            // -------------------------------------------------------------------------------------------------------------------
            } else if(ZMod.isMultiplayer || !ZMod.modFurnaceEnabled || ZMod.optFurnaceFuelWaste) {
            // -------------------------------------------------------------------------------------------------------------------
                c = 0;
            }
            if(flag != (a > 0)) {
                flag1 = true;
                oz.a(a > 0, d, e, f, g);
            }
        }
        if(flag1)
            r_();
    }

    private boolean i() {
        if(h[0] == null) return false;
        // -----------------------------------------------------------------------------------------------------------------------
        gz gz1 = null;
        if(ZMod.modFurnaceEnabled && !ZMod.isMultiplayer && ZMod.furnaceSmelting!=null) gz1 = (gz)(ZMod.furnaceSmelting.get(Integer.valueOf(   h[0].a().bc   )));
        if(gz1 == null) gz1 = dp.a().a(h[0].a().bc);
        // -----------------------------------------------------------------------------------------------------------------------
        if(gz1 == null) return false;
        if(h[2] == null) return true;
        if(!h[2].a(gz1)) return false;
        if(h[2].a < d() && h[2].a < h[2].c()) return true;
        return h[2].a < gz1.c();
    }

    public void g() {
        if(!i()) return;
        // -----------------------------------------------------------------------------------------------------------------------
        gz gz1 = null;
        if(ZMod.modFurnaceEnabled && !ZMod.isMultiplayer && ZMod.furnaceSmelting!=null) gz1 = (gz)(ZMod.furnaceSmelting.get(Integer.valueOf(   h[0].a().bc   )));
        if(gz1 == null) gz1 = dp.a().a(h[0].a().bc);
        // -----------------------------------------------------------------------------------------------------------------------
        if(h[2] == null) h[2] = gz1.k();
        else if(h[2].c == gz1.c) h[2].a++;
        h[0].a--;
        if(h[0].a <= 0) h[0] = null;
    }

    // ===========================================================================================================================
    private static boolean mlInit = false;
    private static Class mlClass;
    private static Method mlMethod;

    private int a(gz gz1) {
        if(gz1 == null) return 0;
        int j = gz1.a().bc;
        if(!ZMod.isMultiplayer && ZMod.modFurnaceEnabled && ZMod.furnaceFuel!=null && ZMod.furnaceFuel.containsKey(Integer.valueOf(  j  ))) return ZMod.furnaceFuel.get(Integer.valueOf(  j  )); // update: j
        if(j < 256 && qk.m[j].bv == iu.c) return !ZMod.isMultiplayer && ZMod.modFurnaceEnabled ? ZMod.optFurnaceWoodFuel : 300;
        if(j == ex.B.bc) return 100;
        if(j == ex.k.bc) return 1600;
        if(j == ex.aw.bc) return 20000; // update
        try {
            if(!mlInit) {
                mlInit = true;
                mlClass = Class.forName("ModLoader");
                mlMethod = mlClass.getDeclaredMethod("AddAllFuel", new Class[]{ Integer.TYPE });
            }
            if(mlMethod != null) return (Integer)(mlMethod.invoke(null, new Object[]{ j })); // update: j
        } catch(Exception whatever) { }
        return 0;
    }
    // ===========================================================================================================================

    public boolean a_(fd fd1) {
        if(d.b(e, f, g) != this)
            return false;
        return fd1.e((double)e + 0.5D, (double)f + 0.5D, (double)g + 0.5D) <= 64D;
    }

    private gz h[];
    public int a, b, c;
}
