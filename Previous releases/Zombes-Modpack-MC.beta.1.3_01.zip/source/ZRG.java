
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.*;

// search: cloud
public class ZRG extends h {

    public ZRG(Minecraft minecraft, hf renderengine) {
        super(minecraft, renderengine);
    }

    public void callSuper(float f) {
        super.b(f);
    }

    // the found cloud is inside this function - it draws the plane clouds and calls fancy clouds also
    public void b(float f) {
        ZMod.pingDrawHandle(f);
    }

    // this is called after matrix setup and before drawing geometry [you find it called in fuction that calls the function setting up matrixes - search: glu]
    public int a(iz iz1, int i1, double d1) {
        ZMod.pingStartHandle();
        return super.a(iz1, i1, d1);
    }
    
}
