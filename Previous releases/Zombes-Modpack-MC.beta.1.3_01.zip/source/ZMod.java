
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.*;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import java.sql.Timestamp;
import java.nio.*;

public class ZMod {
    public static final String version = "4.9";

    // ----------------------------------------------------------------------------------------------------------------
    private static final class Mark {
        public float x,y,z;
        public byte r,g,b;
        public Mark(int bx, int by, int bz) { x = 0.5f + bx; y = by + 0.13f; z = 0.5f + bz; }
        public Mark(int bx, int by, int bz, int c) { x = 0.5f + bx; y = 0.5f + by; z = 0.5f + bz; loadColor(c); }
        public Mark(int bx, int by, int bz, Mark c) { x = 0.5f + bx; y = 0.5f + by; z = 0.5f + bz; r = c.r; g = c.g; b = c.b; }
        public Mark() { }
        public Mark(int color) { loadColor(color); }
        public void loadColor(int color) { b = (byte)(color & 255); g = (byte)((color>>8) & 255); r = (byte)((color>>16) & 255); }
        public boolean loadColor(String color) {
            int c = names.containsKey(color) ? (Integer)(names.get(color)) : ZMod.parseUnsigned(color);
            if(c < 0) return false;
            loadColor(c);
            return true;
        }
    }

    public static final int KNOWN=1, SOLID=2, LIQUID=4, CRAFT=8, BASIC=16, SPACE=32, TREE=64, GRASS=128, COBBLE=256, DECAL=512, SAND=1024, GRAVEL=2048, ORE=4096, OBSIDIAN=8192, SPAWN=16384, TOUCH=32768;
    public static final int GHAST=1, COW=2, SPIDER=3, SHEEP=4, SKELLY=5, CREEPER=6, ZOMBIE=7, SLIME=8, PIG=9, CHICKEN=10, SQUID=11, PIGZOMBIE=12, PLAYER=13, LIVING=14, MAXTYPE=15;
    private static final int IGNORE = 0, NAMEMAP = 1, RECIPES = 2, FUEL = 3, SMELTING = 4;

    // ----------------------------------------------------------------------------------------------------------------
    public static Minecraft mc;
    public static Random rnd = new Random();
    public static int block[] = new int[256];
    private static String path; // mod data folder path
    private static PrintStream out; // log output stream
    private static String logPath; // log file location
    private static String firstError; // first encountered error
    private static ZFR text; // our FontRenderer replacement
    private static ZRG render; // our RenderGlobal replacement
    private static Properties conf; // configuration
    private static boolean exceptionReported; // used to show only one reflection error
    private static boolean keys[] = new boolean[Keyboard.KEYBOARD_SIZE]; // used to detect key presses
    private static HashMap names;
    
    // ================================================================================================================ mod-vars
    public static int keyBaseInfo;
    public static boolean optBaseDisableWarning, optBaseShowInfo;
    // ---------------------------------------------------------------------------------------------------------------- cloud
    public static boolean modCloudEnabled;
    public static String tagCloudVanilla;
    public static int keyCloudToggle, keyCloudUp, keyCloudDown, keyCloudVanilla;
    public static boolean optCloudShow, optCloudVanilla;
    public static float optCloudOffset;
    // ---------------------------------------------------------------------------------------------------------------- cart
    public static boolean modCartEnabled;
    public static String tagCartPerpetual;
    public static int keyCartStop, keyCartPerpetual;
    public static boolean optCartPerpetual, optCartInfiniteFuel;
    public static float optCartSpeedAccumCap, optCartAcceleration;
    private static double cartSpeed;
    // ---------------------------------------------------------------------------------------------------------------- wield
    public static boolean modWieldEnabled;
    public static int keyWield;
    public static boolean optWieldBowFirst;
    // ---------------------------------------------------------------------------------------------------------------- build
    public static boolean modBuildEnabled;
    public static String tagBuildEnabled;
    public static int keyBuildToggle, keyBuildA, keyBuildB, keyBuildMark, keyBuildCopy, keyBuildPaste, keyBuildSet, keyBuildFill, keyBuildRemove, keyBuildDown, keyBuildDeselect;
    public static boolean optBuild, optBuildExtension, optBuildLockQuantity;
    private static boolean buildActive;
    private static int buildSets[][], buildBufBlock[], buildBufExtra[];
    private static int buildSX, buildEX, buildSY, buildEY, buildSZ, buildEZ, buildMark = 0;
    private static int buildSizeX = 0, buildSizeY = 0, buildSizeZ = 0;
    private static float buildOriginal[];
    // ---------------------------------------------------------------------------------------------------------------- compass
    public static boolean modCompassEnabled;
    public static String tagCompassAlternate;
    public static int keyCompassSet, keyCompassToggle;
    public static boolean optCompassShowPos;
    private static boolean compassHaveOrig, compassHaveMine, compassShowOrig = true;
    private static int compassOX, compassOY, compassOZ, compassMX, compassMY, compassMZ;
    // ---------------------------------------------------------------------------------------------------------------- sun
    public static boolean modSunEnabled;
    public static String tagSunTime;
    public static int keySunTimeAdd, keySunTimeSub, keySunStop, keySunTimeNormal;
    public static int optSunTimeStep;
    public static boolean sunTimeStop, sunSleeping;
    public static long sunTimeOffset, sunTimeMoment;
    // ---------------------------------------------------------------------------------------------------------------- craft
    public static boolean modCraftEnabled;
    public static int keyCraftAll;
    // ---------------------------------------------------------------------------------------------------------------- fly
    public static boolean modFlyEnabled;
    public static String tagFly;
    public static int keyFlyOn, keyFlyOff, keyFlyUp, keyFlyDown, keyFlySpeed, keyFlyToggle;
    public static double optFlySpeedVertical, optFlySpeedMulNormal, optFlySpeedMulModifier;
    public static boolean fly;
    // ---------------------------------------------------------------------------------------------------------------- path
    public static boolean modPathEnabled;
    public static int keyPathShow, keyPathDelete;
    public static boolean optPathShow;
    public static int optPathPoints, optPathSpacing;
    public static float optPathMin, optPathAnimSpeed;
    public static Mark optPathColor;
    private static int pathCount, pathLast;
    private static float pathAnimCur, pathf[];
    // ---------------------------------------------------------------------------------------------------------------- recipe
    public static boolean modRecipeEnabled;
    public static boolean optRecipeShowId, optRecipeDump;
    private static List recipesSP, recipesMP;
    // ---------------------------------------------------------------------------------------------------------------- safe
    public static boolean modSafeEnabled;
    public static String tagSafe;
    public static int keySafeShow;
    public static Mark optSafeDangerColor;
    private static final int safeMax = 1024;
    private static Mark safeMark[];
    private static boolean safeShow;
    private static int safeCur, safeUpdate;
    // ---------------------------------------------------------------------------------------------------------------- boom
    public static boolean modBoomEnabled;
    public static int optBoomSafeRange;
    public static float optBoomDropOreChance, optBoomDropChance, optBoomScaleTNT, optBoomScaleCreeper;
    // ---------------------------------------------------------------------------------------------------------------- spawn
    public static boolean modSpawnEnabled;
    public static boolean optSpawnSupportMods, optSpawnAllowInNonAir, optSpawnAllowOnNonNatural, optSpawnAllowOnGrass, optSpawnAllowOnCobble, optSpawnAllowOnSand, optSpawnAllowOnGravel, optSpawnAllowOnTree;
    public static int optSpawnPigReduction, optSpawnChickenReduction, optSpawnCowReduction, optSpawnSheepReduction, optSpawnSquidReduction, optSpawnGhastReduction;
    public static int optSpawnSpiderReduction, optSpawnSkeletonReduction, optSpawnCreeperReduction, optSpawnZombieReduction, optSpawnSlimeReduction, optSpawnPigZombieReduction;
    // ---------------------------------------------------------------------------------------------------------------- ore
    public static boolean modOreEnabled;
    public static boolean optOreLavaFloor;
    public static int[] optOreCoalRule, optOreIronRule, optOreGoldRule, optOreBlueRule, optOreRedRule, optOreDiamondRule;
    /*public static boolean modOreEnabled;
    public static boolean optOreLavaFloor, optOreFlatten;
    public static int optOreRedistributionNr;
    public static int oreOres[];
    public static ArrayList<Integer> oreRules;
    private static final int oreBits = 5;*/
    // ---------------------------------------------------------------------------------------------------------------- teleport
    public static boolean modTeleportEnabled;
    private static int optTeleportItem, optTeleportPlayer, optTeleportCritter;
    // ---------------------------------------------------------------------------------------------------------------- cheat
    public static boolean modCheatEnabled;
    public static String tagCheater;
    public static int keyCheatShowMobs, keyCheatShowOres, keyCheat, keyCheatSee;
    public static boolean optCheatFallDamage, optCheatRestoreHealth, optCheatShowDangerous, optCheatShowNeutral, optCheat, optCheatSeeIsToggle;
    public static float optCheatSeeDist;
    private static final int cheatMax = 2048;
    private static Mark cheatMobs[], cheatOres[], cheatMark[];
    private static boolean cheating = false, cheatShowMobs = false, cheatShowOres = false, cheatSee;
    private static int cheatCur = 0;
    private static float cheatRefresh;
    // ---------------------------------------------------------------------------------------------------------------- resize
    public static boolean modResizeEnabled;
    private static int resizeChanceBig[], resizeChanceSmall[];
    public static float resizeSize[];
    // ---------------------------------------------------------------------------------------------------------------- furnace
    public static boolean modFurnaceEnabled;
    public static boolean optFurnaceFuelWaste;
    public static int optFurnaceWoodFuel, optFurnaceInfiniteFuel, optFurnaceSmeltingTime;
    public static HashMap<Integer,Integer> furnaceFuel;
    public static HashMap<Integer,Object> furnaceSmelting;
    // ---------------------------------------------------------------------------------------------------------------- dig
    public static boolean modDigEnabled;
    public static float optDigSpeed;

    private static Object cmanager; // used in reflection + recipe init
    private static Field fCMRecipes, fCBTable, fDamage, fSpawnX, fSpawnY, fSpawnZ, fTime, fFMSmelting;

    // ################################################################################################################ INITIALIZE
    public static void initialize(Minecraft minecraft) {
        mc = minecraft;
        // init block list
        block[ 0] = KNOWN | SPACE | BASIC;
        block[ 1] = KNOWN | SOLID | BASIC;
        block[ 2] = KNOWN | SOLID | GRASS;
        block[ 3] = KNOWN | SOLID | BASIC;
        block[ 4] = KNOWN | SOLID | COBBLE;
        block[ 5] = KNOWN | SOLID | CRAFT;
        block[ 6] = KNOWN | SPACE | DECAL;
        block[ 7] = KNOWN | SOLID | BASIC;
        block[ 8] = KNOWN | SPACE | LIQUID;
        block[ 9] = KNOWN | SPACE | LIQUID;
        block[10] = KNOWN | LIQUID;
        block[11] = KNOWN | LIQUID;
        block[12] = KNOWN | SOLID | SAND;
        block[13] = KNOWN | SOLID | GRAVEL;
        block[14] = KNOWN | SOLID | ORE | BASIC;
        block[15] = KNOWN | SOLID | ORE | BASIC;
        block[16] = KNOWN | SOLID | ORE | BASIC;
        block[17] = KNOWN | SOLID | TREE;
        block[18] = KNOWN | SOLID | TREE;
        block[19] = KNOWN | SOLID | CRAFT;
        block[20] = KNOWN | SOLID | CRAFT;
        block[21] = KNOWN | SOLID | ORE | BASIC;
        block[22] = KNOWN | SOLID | CRAFT;
        block[23] = KNOWN | SOLID | CRAFT;
        block[24] = KNOWN | SOLID | CRAFT;
        block[25] = KNOWN | SOLID | CRAFT;
        block[26] = KNOWN | SOLID | CRAFT;
        block[35] = KNOWN | SOLID | CRAFT;
        block[37] = KNOWN | SPACE | DECAL;
        block[38] = KNOWN | SPACE | DECAL;
        block[39] = KNOWN | SPACE | DECAL;
        block[40] = KNOWN | SPACE | DECAL;
        block[41] = KNOWN | SOLID | CRAFT;
        block[42] = KNOWN | SOLID | CRAFT;
        block[43] = KNOWN | SOLID | CRAFT;
        block[44] = KNOWN | SOLID | CRAFT;
        block[45] = KNOWN | SOLID | CRAFT;
        block[46] = KNOWN | SOLID | CRAFT;
        block[47] = KNOWN | SOLID | CRAFT;
        block[48] = KNOWN | SOLID | BASIC;
        block[49] = KNOWN | SOLID | OBSIDIAN;
        block[50] = KNOWN | SPACE | DECAL;
        block[51] = KNOWN | SPACE | DECAL;
        block[52] = KNOWN | SOLID | BASIC;
        block[53] = KNOWN | SOLID | CRAFT;
        block[54] = KNOWN | SOLID | CRAFT;
        block[55] = KNOWN | SPACE | DECAL;
        block[56] = KNOWN | SOLID | ORE | BASIC;
        block[57] = KNOWN | SOLID | CRAFT;
        block[58] = KNOWN | SOLID | CRAFT;
        block[59] = KNOWN | SPACE | DECAL;
        block[60] = KNOWN | SOLID | CRAFT;
        block[61] = KNOWN | SOLID | CRAFT;
        block[62] = KNOWN | SOLID | CRAFT;
        block[63] = KNOWN | SPACE | DECAL | TOUCH;
        block[64] = KNOWN | SPACE | DECAL | TOUCH;
        block[65] = KNOWN | SPACE | DECAL;
        block[66] = KNOWN | SPACE | DECAL;
        block[67] = KNOWN | SOLID | CRAFT;
        block[68] = KNOWN | SPACE | DECAL | TOUCH;
        block[69] = KNOWN | SPACE | DECAL | TOUCH;
        block[70] = KNOWN | SPACE | DECAL;
        block[71] = KNOWN | SPACE | DECAL | TOUCH;
        block[72] = KNOWN | SPACE | DECAL;
        block[73] = KNOWN | SOLID | ORE | BASIC;
        block[74] = KNOWN | SOLID | ORE | BASIC;
        block[75] = KNOWN | SPACE | DECAL;
        block[76] = KNOWN | SPACE | DECAL;
        block[77] = KNOWN | SPACE | DECAL;
        block[78] = KNOWN | SPACE;
        block[79] = KNOWN | SOLID | BASIC;
        block[80] = KNOWN | SOLID | CRAFT;
        block[81] = KNOWN | SOLID | BASIC;
        block[82] = KNOWN | SOLID | BASIC;
        block[83] = KNOWN | SPACE | DECAL;
        block[84] = KNOWN | SOLID | CRAFT;
        block[85] = KNOWN | SOLID | CRAFT;
        block[86] = KNOWN | SOLID | BASIC;
        block[87] = KNOWN | SOLID | BASIC;
        block[88] = KNOWN | SOLID | BASIC;
        block[89] = KNOWN | SOLID | ORE | BASIC;
        block[90] = KNOWN | SPACE;
        block[91] = KNOWN | SOLID | CRAFT;
        block[92] = KNOWN | SOLID | CRAFT | TOUCH;
        block[93] = KNOWN | SOLID | CRAFT | TOUCH; // redstone repeater OFF - ok???
        block[94] = KNOWN | SOLID | CRAFT | TOUCH; // redstone repeater ON - ok???
        for(int i=0;i<256;i++) if(spawnCheckA(i)) block[i] |= SPAWN;
        // get path - getPath : b  ? search: public static File * only static function that returns File and takes no parameters
        try { path = Minecraft.b().getCanonicalPath(); } catch(Exception whatever) { path = ""; }
        path += File.separatorChar + "mods" + File.separatorChar + "zombe" + File.separatorChar;
        try { File make = new File(path); make.mkdirs(); } catch(Exception whatever) { path = ""; }
        // open log
        try { File tmp = new File(path + "log.txt"); out = new PrintStream(tmp); logPath = tmp.getCanonicalPath(); } catch(Exception whatever) { logPath = "failed to create one :("; out = System.out; }
        out.println("=========== logging ===========");
        out.println("ZModPack: version "+version);
        out.println("Log started at: "+(new Timestamp((new Date()).getTime())));
        // load config
        conf = new Properties();
        try {
            Properties tmp;
            (tmp = new Properties()).load(new FileInputStream(path + "config.txt"));
            conf = tmp;
            log("info: processing configuration");
        } catch(Exception error) {
            err("error: failed to load configuration from config.txt", error);
        }
        // total fuckup log
        try {
        // reflection
        fDamage = getField(gz.class, "d"); // ItemStack.damage  : gz.d   ? search: "Damage"
        fCBTable = getField(jv.class, "a"); // update - intemstack[] in matchRecipe parameter class
        fCMRecipes = getField(fr.class, "b"); // update - only List in CraftingManager (###)
        fSpawnX = getField(dc.class, "b"); // update - World.spawn* : dc.b/c/d ? search: "Spawn
        fSpawnY = getField(dc.class, "c"); // update
        fSpawnZ = getField(dc.class, "d"); // update
        fTime = getField(dc.class, "e"); // update - search for "Time" : e = ???.?("Time");
        // base config
        keyBaseInfo               = getBind("keyBaseInfo",        Keyboard.KEY_F8);
        optBaseDisableWarning     = getBool("optBaseDisableWarning", false);
        getNames();
        int mods = 0;
        // cloud mod
        if((modCloudEnabled       = getBool("modCloudEnabled", false))==true) {
            log("info: loading config for \"cloud\"");
            keyCloudToggle        = getBind("keyCloudToggle",     Keyboard.KEY_MULTIPLY);
            keyCloudVanilla       = getBind("keyCloudVanilla",    Keyboard.KEY_V);
            keyCloudUp            = getBind("keyCloudUp",         Keyboard.KEY_NONE);
            keyCloudDown          = getBind("keyCloudDown",       Keyboard.KEY_NONE);
            optCloudShow          = getBool("optCloudShow", true);
            optCloudOffset        = getFloat("optCloudOffset", 24F, -64F, 64F);
            tagCloudVanilla       = getString("tagCloudVanilla", "no-could-mod");
            mods++;
        }
        // cart mod
        if((modCartEnabled = getBool("modCartEnabled", false))==true) {
            log("info: loading config for \"cart\"");
            keyCartStop           = getBind("keyCartStop",        Keyboard.KEY_RETURN);
            keyCartPerpetual      = getBind("keyCartPerpetual",   Keyboard.KEY_UP);
            optCartSpeedAccumCap  = getFloat("optCartSpeedAccumCap", 1f, 0.5f, 5f);
            optCartAcceleration   = getFloat("optCartAcceleration", 2f, 0.5f, 10f);
            tagCartPerpetual      = getString("tagCartPerpetual", "perpetual");
            optCartInfiniteFuel   = getBool("optCartInfiniteFuel", true);
            mods++;
        }
        // wield mod
        if((modWieldEnabled = getBool("modWieldEnabled", false))==true) {
            log("info: loading config for \"wield\"");
            keyWield              = getBind("keyWield",           Keyboard.KEY_R);
            optWieldBowFirst      = getBool("optWieldBowFirst", true);
            mods++;
        }
        // build mod
        if((modBuildEnabled = getBool("modBuildEnabled", false))==true) {
            log("info: loading config for \"build\"");
            keyBuildToggle        = getBind("keyBuildToggle",     Keyboard.KEY_B);
            keyBuildA             = getBind("keyBuildA",          Keyboard.KEY_LSHIFT);
            keyBuildB             = getBind("keyBuildB",          Keyboard.KEY_LCONTROL);
            keyBuildMark          = getBind("keyBuildMark",       Keyboard.KEY_X);
            keyBuildCopy          = getBind("keyBuildCopy",       Keyboard.KEY_C);
            keyBuildPaste         = getBind("keyBuildPaste",      Keyboard.KEY_P);
            keyBuildSet           = getBind("keyBuildSet",        Keyboard.KEY_Z);
            keyBuildFill          = getBind("keyBuildFill",       Keyboard.KEY_LSHIFT);
            keyBuildRemove        = getBind("keyBuildRemove",     Keyboard.KEY_RSHIFT);
            keyBuildDown          = getBind("keyBuildDown",       Keyboard.KEY_LCONTROL);
            keyBuildDeselect      = getBind("keyBuildDeselect",   Keyboard.KEY_NONE);
            optBuildExtension     = getBool("optBuildExtension", false);
            if(!optBuildExtension) log("info: build extension is disabled");
            optBuild              = getBool("optBuild", false);
            optBuildLockQuantity  = getBool("optBuildLockQuantity", true);
            tagBuildEnabled       = getString("tagBuildEnabled", "builder");
            String sets[] = new String[]{
                getString("optBuildA1", "smooth, cobble, grass, dirt, sand, gravel, clay, obsidian, sandstone"),
                getString("optBuildA2", "trunk, pine, birch, wood, shelves, chest, workbench, jukebox, furnace"),
                getString("optBuildA3", "woolYellow, woolOrange, woolRed, woolPink, woolMagenta, woolPurple, woolBlue, woolCyan, woolLightBlue"),
                getString("optBuildA4", "wool, woolLightGray, woolGray, woolBlack, woolBrown, woolGreen, woolLime, cage, sponge"),
                getString("optBuildA5", "snowcap, ice, snow, water, lava, fire, glass, pumpkinC, torch"),
                getString("optBuildA6", "sapling, leaves, flowerY, flowerR, shroomB, shroomR, cactus, pumpkin, reed"),
                getString("optBuildA7", "blockG, blockI, blockD, blockB, blockL, mossy, nether, soul, 0"),
                getString("optBuildA8", "oreG, oreI, oreC, oreD, oreR, oreY, oreL, 0, torch"),
                getString("optBuildA9", "doorW, doorI, switch, red, plateS, plateW, button, dispenser, note"),
                getString("optBuildB1", "ladder, tracks, fence, stairC, stairW, sign, half, double, picture"),
                getString("optBuildB2", "pickD, cart, boat, saddle, tnt, cake, 0, 0, torch"),
                getString("optBuildB3", ""),
                getString("optBuildB4", ""),
                getString("optBuildB5", ""),
                getString("optBuildB6", ""),
                getString("optBuildB7", ""),
                getString("optBuildB8", "arrow, compass"),
                getString("optBuildB9", "bucketW, watch, glass, appleG, swordD, bow, shovelD, pickD, torch")
            };
            buildSets = new int[sets.length][9];
            for(int set=0;set<sets.length;set++) if(!sets[set].equals("")) {
                String got[] = sets[set].split("[\\t ]*,[\\t ]*");
                int defs = got.length; if(defs>9) defs = 9;
                for(int slot=0;slot<defs;slot++) {
                    if(names.containsKey(got[slot])) buildSets[set][slot] = (Integer)(names.get(got[slot]));
                    else {
                        int id = parseIdInfo(got[slot]);
                        if(id==-1) err("error: config.txt @ optBuild"+(set>9?"B":"A")+((set%9)+1)+" - unknown item name or invalid code: \""+got[slot]+"\"");
                        else buildSets[set][slot] = id;
                    }
                }
            }
            mods++;
        }
        // compass mod
        if((modCompassEnabled = getBool("modCompassEnabled", false))==true) {
            log("info: loading config for \"compass\"");
            keyCompassSet = getBind("keyCompassSet",              Keyboard.KEY_INSERT);
            keyCompassToggle = getBind("keyCompassToggle",        Keyboard.KEY_HOME);
            tagCompassAlternate = getString("tagCompassAlternate", "altSpawn");
            optCompassShowPos = getBool("optCompassShowPos", true);
            mods++;
        }
        // sun mod
        if((modSunEnabled = getBool("modSunEnabled", false))==true) {
            log("info: loading config for \"sun\"");
            keySunTimeAdd = getBind("keySunTimeAdd",              Keyboard.KEY_ADD);
            keySunTimeSub = getBind("keySunTimeSub",              Keyboard.KEY_SUBTRACT);
            keySunStop = getBind("keySunStop",                    Keyboard.KEY_END);
            keySunTimeNormal = getBind("keySunTimeNormal",        Keyboard.KEY_EQUALS);
            optSunTimeStep = getInt("optSunTimeStep", 30, 1, 600) * 20;
            tagSunTime = getString("tagSunTime", "time");
            if(!checkClass(sd.class)) { err("error: sd.class has not been installed - sun mod disabled"); modSunEnabled = false; } // update - search: 24000F
            else mods++;
        }
        // craft mod
        if((modCraftEnabled = getBool("modCraftEnabled", false))==true) {
            log("info: loading config for \"craft\"");
            keyCraftAll = getBind("keyCraftAll",                  Keyboard.KEY_LSHIFT);
            if(!checkClass(gg.class)) { err("error: gg.class has not been installed - craft mod disabled"); modCraftEnabled = false; } // update - search: = -999;
            else mods++;
        }
        // fly mod
        if((modFlyEnabled = getBool("modFlyEnabled", false))==true) {
            log("info: loading config for \"fly\"");
            keyFlyOn = getBind("keyFlyOn",                        Keyboard.KEY_NONE);
            keyFlyOff = getBind("keyFlyOff",                      Keyboard.KEY_NONE);
            keyFlyUp = getBind("keyFlyUp",                        Keyboard.KEY_E);
            keyFlyDown = getBind("keyFlyDown",                    Keyboard.KEY_Q);
            keyFlySpeed = getBind("keyFlySpeed",                  Keyboard.KEY_LSHIFT);
            keyFlyToggle = getBind("keyFlyToggle",                Keyboard.KEY_F);
            optFlySpeedVertical = getFloat("optFlySpeedVertical", 0.2f, 0.1f, 1.0f);
            optFlySpeedMulNormal = getFloat("optFlySpeedMulNormal", 1.0f, 0.1f, 10.0f);
            optFlySpeedMulModifier = getFloat("optFlySpeedMulModifier", 2.0f, 1.0f, 10.0f);
            tagFly = getString("tagFly", "flying");
            if(!checkClass(fd.class)) { err("error: fd.class has not been installed - fly mod disabled"); modFlyEnabled = false; } // update - search: "humanoid"
            else mods++;
        }
        // path mod
        if((modPathEnabled = getBool("modPathEnabled", false))==true) {
            log("info: loading config for \"path\"");
            keyPathShow = getBind("keyPathShow",                  Keyboard.KEY_BACK);
            keyPathDelete = getBind("keyPathDelete",              Keyboard.KEY_DELETE);
            optPathPoints = getInt("optPathPoints", 8192, 256, 32768); pathf = new float[3 * optPathPoints];
            optPathSpacing = getInt("optPathSpacing", 6, 0, 32) + 2;
            optPathMin = getFloat("optPathMin", 0.25f, 0.1f, 4f); optPathMin *= optPathMin;
            optPathAnimSpeed = getFloat("optPathAnimSpeed", 8f, 0f, 32f);
            optPathShow = getBool("optPathShow", false);
            optPathColor = getColor("optPathColor", 0xff0000);
            mods++;
        }
        // recipe mod
        if((modRecipeEnabled = getBool("modRecipeEnabled", false))==true) {
            log("info: loading config for \"recipe\"");
            optRecipeShowId = getBool("optRecipeShowId", true);
            optRecipeDump = getBool("optRecipeDump", false);
            cmanager = fr.a(); // This also forces ModLoader to initialize. update - search: ### * only function that returns CraftingManager
            recipesSP = (List)getValue(fCMRecipes, cmanager);
            recipesMP = new ArrayList();
            log("info: "+recipesSP.size()+" SP recipes before loading mod");
            parse(recipesSP, "recipes.txt",    RECIPES); Collections.sort(recipesSP, new ii((fr)cmanager)); // update
            log("info: "+recipesSP.size()+" SP recipes after loading mod");
            parse(recipesMP, "recipes-mp.txt", RECIPES); Collections.sort(recipesMP, new ii((fr)cmanager)); // update
            log("info: "+recipesMP.size()+" vanilla recipes for MP compatibility");
            if(optRecipeDump) {
                log("==== recipe dump ====");
                Field fWidth = getField(gv.class, "b"), fHeight = getField(gv.class, "c"), fMap = getField(gv.class, "d"), fResA = getField(gv.class, "e"); // UPDATE
                Field fList = getField(pp.class, "b"), fResB = getField(pp.class, "a");                                                                     // UPDATE
                String res;
                Object obj, items;
                for(int i=0;i<recipesSP.size();i++) {
                    if(recipesSP.get(i) instanceof gv) { // update
                        obj = recipesSP.get(i);
                        items = getValue(fResA, obj);
                        Object arr[] = (Object[])getValue(fMap, obj);
                        res = "type normal    : " + getItemsId(items)+"/"+getItemsInfo(items) + " " + getValue(fWidth, obj) + " " + getValue(fHeight, obj);
                        for(int m=0;m<arr.length;m++) res += arr[m]==null ? " 0" : (" "+getItemsId(arr[m])+"/"+getItemsInfo(arr[m]));
                    } else if(recipesSP.get(i) instanceof pp) { // update
                        obj = recipesSP.get(i);
                        items = getValue(fResB, obj);
                        List arr = (List)getValue(fList, obj);
                        res = "type shapeless : " + getItemsId(items)+"/"+getItemsInfo(items) + " " + arr.size() + " 0";
                        for(int m=0;m<arr.size();m++) res += " "+getItemsId(arr.get(m))+"/"+getItemsInfo(arr.get(m));
                    } else {
                        res = "type: KST " + recipesSP.get(i);
                    }
                    log(res);
                }
            }
            mods++;
        }
        // safe mod
        if((modSafeEnabled = getBool("modSafeEnabled", false))==true) {
            safeMark = new Mark[safeMax];
            log("info: loading config for \"safe\"");
            keySafeShow = getBind("keySafeShow",                  Keyboard.KEY_L);
            optSafeDangerColor = getColor("optSafeDangerColor", 0xff0000);
            tagSafe = getString("tagSafe", "safe");
            mods++;
        }
        // boom mod
        if((modBoomEnabled = getBool("modBoomEnabled", false))==true) {
            log("info: loading config for \"boom\"");
            optBoomDropChance = (float)getInt("optBoomDropChance", 30, 0, 100) / 100f;
            optBoomDropOreChance = (float)getInt("optBoomDropOreChance", 100, 0, 100) / 100f;
            optBoomScaleTNT = getFloat("optBoomScaleTNT", 1f, 0.1f, 10f);
            optBoomScaleCreeper = getFloat("optBoomScaleCreeper", 1f, 0.1f, 10f);
            optBoomSafeRange  = getInt("optBoomSafeRange", 16, -1, 32);
            if(!checkClass(getClass("na"))) { err("error: na.class has not been installed - boom mod disabled"); modBoomEnabled = false; } // update - search: "random.explode"
            else mods++;
        }
        // spawn mod
        if((modSpawnEnabled = getBool("modSpawnEnabled", false))==true) {
            log("info: loading config for \"spawn\"");
            optSpawnSupportMods = getBool("optSpawnSupportMods", true);
            optSpawnAllowInNonAir = getBool("optSpawnAllowInNonAir", false);
            optSpawnAllowOnNonNatural = getBool("optSpawnAllowOnNonNatural", false);
            optSpawnAllowOnGrass = getBool("optSpawnAllowOnGrass", true);
            optSpawnAllowOnCobble = getBool("optSpawnAllowOnCobble", false);
            optSpawnAllowOnSand = getBool("optSpawnAllowOnSand", true);
            optSpawnAllowOnGravel = getBool("optSpawnAllowOnGravel", true);
            optSpawnAllowOnTree = getBool("optSpawnAllowOnTree", false);

            optSpawnPigReduction = getInt("optSpawnPigReduction", 75, 0, 100);
            optSpawnChickenReduction = getInt("optSpawnChickenReduction", 0, 0, 100);
            optSpawnCowReduction = getInt("optSpawnCowReduction", 0, 0, 100);
            optSpawnSheepReduction = getInt("optSpawnSheepReduction", 0, 0, 100);
            optSpawnSquidReduction = getInt("optSpawnSquidReduction", 0, 0, 100);

            optSpawnSpiderReduction = getInt("optSpawnSpiderReduction", 0, 0, 100);
            optSpawnSkeletonReduction = getInt("optSpawnSkeletonReduction", 0, 0, 100);
            optSpawnCreeperReduction = getInt("optSpawnCreeperReduction", 0, 0, 100);
            optSpawnZombieReduction = getInt("optSpawnZombieReduction", 0, 0, 100);
            optSpawnSlimeReduction = getInt("optSpawnSlimeReduction", 0, 0, 100);

            optSpawnGhastReduction = getInt("optSpawnGhastReduction", 0, 0, 100);
            optSpawnPigZombieReduction = getInt("optSpawnPigZombieReduction", 0, 0, 100);
            mods++;
        }
        // ore mod
        if((modOreEnabled = getBool("modOreEnabled", false))==true) {
            log("info: loading config for \"ore\"");
            optOreLavaFloor   = getBool("optOreLavaFloor", true);
            // chance_for_chunk / max_height / min_height / attempts / size / what_must_be_above
            optOreCoalRule    = parseRule(getString("optOreCoalRule"   , "75/80/48/8/16/1  10/120/32/128/4/1 5/120/64/1/128/1"));
            optOreIronRule    = parseRule(getString("optOreIronRule"   , "100/80/16/8/16/1 100/96/8/16/8/1   5/120/64/128/1/1"));
            optOreGoldRule    = parseRule(getString("optOreGoldRule"   , "50/32/4/4/16/1   5/96/8/8/64/1"));
            optOreBlueRule    = parseRule(getString("optOreBlueRule"   , "100/32/8/2/8/1   5/56/48/64/2/1    5/96/48/1/32/1/1"));
            optOreRedRule     = parseRule(getString("optOreRedRule"    , "100/32/8/2/8/1   10/120/96/64/1/1"));
            optOreDiamondRule = parseRule(getString("optOreDiamondRule", "75/16/4/2/8/1    100/32/2/128/2/11 10/120/16/2/8/1"));
            mods++;
        }
        /*if((modOreEnabled = getBool("modOreEnabled", false))==true) {
            oreOres = new int[256];
            oreRules = new ArrayList<Integer>();
            log("info: loading config for \"ore\"");
            optOreLavaFloor   = getBool("optOreLavaFloor", true);
            optOreFlatten     = getBool("optOreFlatten", true);
            optOreRedistributionNr = getInt("optOreRedistributionNr", 1, 1, (1<<oreBits)-1);

            String abc[] = new String[]{"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
            for(int i=0;i<abc.length;i++) {
                String name = "optOreRule" + abc[i];
                String val = getString(name, null);
                if(val == null) continue;
                String got[] = val.split("[\\t ]*,[\\t ]*");
                if(got.length != 9) { err("error: config.txt @ "+name+" - invalid distribution rule - ore mod disabled"); modOreEnabled = false; continue; }
                int alg = oreRules.add( parseUnsigned(got[0]) );
                if(alg != 0) { err("error: config.txt @ "+name+" - invalid rule algorithm - ore mod disabled"); modOreEnabled = false; continue; }
                int ore = oreRules.add( ( names.containsKey(got[1]) ? (Integer)names.get(got[1]) : parseIdInfo(got[1]) ) & 0xffff );
                if(ore < 0 || ore > 255) { err("error: config.txt @ "+name+" - unknown or invalid ore - ore mod disabled"); modOreEnabled = false; continue; }
                int replace = oreRules.add( ( names.containsKey(got[2]) ? (Integer)names.get(got[2]) : parseIdInfo(got[2]) ) & 0xffff );
                if(replace < 0 || replace > 255) { err("error: config.txt @ "+name+" - unknown or invalid ore replacement - ore mod disabled"); modOreEnabled = false; continue; }
                int chunk = oreRules.add( parseUnsigned(got[3]) );
                if(chunk < 1 || chunk > 100) { err("error: config.txt @ "+name+" - chunk chance is out of bounds [1..100] - ore mod disabled"); modOreEnabled = false; continue; }
                int max = oreRules.add( parseUnsigned(got[4]) );
                if(max < 1 || max > 127) { err("error: config.txt @ "+name+" - max is out of bounds [1..127] - ore mod disabled"); modOreEnabled = false; continue; }
                int min = oreRules.add( parseUnsigned(got[5]) );
                if(min < 0 || min > max) { err("error: config.txt @ "+name+" - min is out of bounds [0..max] - ore mod disabled"); modOreEnabled = false; continue; }
                int tries = oreRules.add( parseUnsigned(got[6]) );
                if(tries < 1 || tries > 512) { err("error: config.txt @ "+name+" - tries is out of bounds [1..512] - ore mod disabled"); modOreEnabled = false; continue; }
                int size = oreRules.add( parseUnsigned(got[7]) );
                if(size < 1 || size > 512) { err("error: config.txt @ "+name+" - size is out of bounds [1..512] - ore mod disabled"); modOreEnabled = false; continue; }
                int below = oreRules.add( ( names.containsKey(got[8]) ? (Integer)names.get(got[8]) : parseIdInfo(got[8]) ) & 0xffff );
                if(below < 0 || below > 255) { err("error: config.txt @ "+name+" - belowWhat is unknown or invalid - ore mod disabled"); modOreEnabled = false; continue; }
            }

            if(getDeprecated("optOreCoalRule") || getDeprecated("optOreIronRule") || getDeprecated("optOreGoldRule") || getDeprecated("optOreBlueRule") || getDeprecated("optOreRedRule") || getDeprecated("optOreDiamondRule")) {
                err("error: deprecated options in config.txt - ore mod disabled to prevent damage");
                modOreEnabled = false;
            }
            if(modOreEnabled) mods++;
        }*/
        // teleport mod
        if((modTeleportEnabled = getBool("modTeleportEnabled", false))==true) {
            log("info: loading config for \"teleport\"");
            String got = null;
            try {
                got = getString("optTeleportItem", "blockI");    optTeleportItem    = names.containsKey(got) ? (Integer)names.get(got) : new Integer(got);
                got = getString("optTeleportPlayer", "blockG");  optTeleportPlayer  = names.containsKey(got) ? (Integer)names.get(got) : new Integer(got);
                got = getString("optTeleportCritter", "blockD"); optTeleportCritter = names.containsKey(got) ? (Integer)names.get(got) : new Integer(got);
                mods++;
            } catch(Exception error) {
                modTeleportEnabled = false;
                err("error: invalid item name or id - teleport mod disabled : \""+got+"\"", error);
            }
        }
        // cheat mod
        if((modCheatEnabled = getBool("modCheatEnabled", false))==true) {
            cheatMobs = new Mark[MAXTYPE]; cheatOres = new Mark[256]; cheatMark = new Mark[cheatMax];
            log("info: loading config for \"cheat\"");
            keyCheat = getBind("keyCheat",                        Keyboard.KEY_Y);
            keyCheatShowMobs = getBind("keyCheatShowMobs",        Keyboard.KEY_M);
            keyCheatShowOres = getBind("keyCheatShowOres",        Keyboard.KEY_O);
            keyCheatSee = getBind("keyCheatSee",                  Keyboard.KEY_I);
            optCheatFallDamage = getBool("optCheatFallDamage", true);
            optCheatRestoreHealth = getBool("optCheatRestoreHealth", false);
            optCheatSeeIsToggle = getBool("optCheatSeeIsToggle", false);
            optCheatSeeDist = getFloat("optCheatSeeDist", 4.0f, 1.0f, 32.0f);
            String val[];
            val = getString("optCheatShowOres", "15/0x008888, 82/0x00ffff, 14/0xffee00, 56/0xeeffff, 48/0x00ff00, 21/0x0000ff, 73/0xff0000, 52/0xff00ff").split("[\\t ]*,[\\t ]*");
            for(int i=0;i<val.length;i++) {
                String got[] = val[i].split("/");
                if(got.length == 2) {
                    Mark color = new Mark();
                    int id = names.containsKey(got[0]) ? (Integer)(names.get(got[0])) : parseUnsigned(got[0]);
                    if(id>0 && id<256 && color.loadColor(got[1])) { cheatOres[id] = color; continue; }
                }
                err("error: config.txt @ optCheatOres - invalid ore/color pair \""+val[i]+"\"");
            }
            val = getString("optCheatShowMobs", "1/0x000088, 3/0x880000, 5/0x888888, 6/0x008800, 7/0x888800, 8/0x880088, 12/0x008888, 11/0x000044, 2/0x444400, 4/0x444444, 9/0x440000, 10/0x004444, 14/0x004400").split("[\\t ]*,[\\t ]*");
            for(int i=0;i<val.length;i++) {
                String got[] = val[i].split("/");
                if(got.length == 2) {
                    Mark color = new Mark();
                    int id = names.containsKey(got[0]) ? (Integer)(names.get(got[0])) : parseUnsigned(got[0]);
                    if(id>0 && id<MAXTYPE && color.loadColor(got[1])) { cheatMobs[id] = color; continue; }
                }
                err("error: config.txt @ optCheatMobs - invalid mob/color pair \""+val[i]+"\"");
            }
            tagCheater = getString("tagCheater", "cheater");
            getDeprecated("optCheatSpecialOre");
            mods++;
        }
        // resize mod
        if((modResizeEnabled = getBool("modResizeEnabled", false))==true) {
            resizeChanceBig = new int[MAXTYPE]; resizeChanceSmall = new int[MAXTYPE]; resizeSize = new float[MAXTYPE];
            log("info: loading config for \"resize\"");
            for(int i=0;i<MAXTYPE;i++) resizeChanceBig[i] = 100;
            // big
            resizeChanceBig[COW]    = 100 - getInt("optResizeCowBig"   , 10, 0, 100);
            resizeChanceBig[SPIDER] = 100 - getInt("optResizeSpiderBig", 10, 0, 100);
            resizeChanceBig[SHEEP]  = 100 - getInt("optResizeSheepBig" , 10, 0, 100);
            resizeChanceBig[SKELLY] = 100 - getInt("optResizeSkellyBig", 20, 0, 100);
            resizeChanceBig[ZOMBIE] = 100 - getInt("optResizeZombieBig", 20, 0, 100);
            resizeChanceBig[PIG]    = 100 - getInt("optResizePigBig"   , 10, 0, 100);
            // small
            resizeChanceSmall[COW]    = getInt("optResizeCowSmall"   , 30, 0, 100);
            resizeChanceSmall[SPIDER] = getInt("optResizeSpiderSmall", 50, 0, 100);
            resizeChanceSmall[SHEEP]  = getInt("optResizeSheepSmall" , 30, 0, 100);
            resizeChanceSmall[SKELLY] = getInt("optResizeSkellySmall", 10, 0, 100);
            resizeChanceSmall[ZOMBIE] = getInt("optResizeZombieSmall", 30, 0, 100);
            resizeChanceSmall[PIG]    = getInt("optResizePigSmall"   , 50, 0, 100);
            if(!checkClass(getClass("ff"))) { err("error: ff.class has not been installed - resize mod disabled"); modResizeEnabled = false; } // update - search: "deadmau5"
            else mods++;
        }
        // furnace mod
        if((modFurnaceEnabled = getBool("modFurnaceEnabled", false))==true) {
            pFuel = furnaceFuel = new HashMap<Integer,Integer>();
            pSmelt = furnaceSmelting = new HashMap<Integer,Object>();
            log("info: loading config for \"furnace\"");
            optFurnaceWoodFuel = getInt("optFurnaceWoodFuel", 300, 1, 819200);
            optFurnaceInfiniteFuel = getInt("optFurnaceInfiniteFuel", 819200, 1, 819200);
            optFurnaceSmeltingTime = getInt("optFurnaceSmeltingTime", 200, 1, 1000);
            optFurnaceFuelWaste = getBool("optFurnaceFuelWaste", true);
            parse(null, "fuel.txt", FUEL);
            parse(null, "smelting.txt", SMELTING);
            if(!checkClass(getClass("oj"))) { err("error: oj.class has not been installed - furnace mod disabled"); modFurnaceEnabled = false; } // update - search: "CookTime"
            else mods++;
        }
        // dig mod
        if((modDigEnabled = getBool("modDigEnabled", false))==true) {
            log("info: loading config for \"dig\"");
            optDigSpeed = getFloat("optDigSpeed", 2.0f, 0.1f, 10.0f);
            if(!checkClass(getClass("lk"))) { err("error: lk.class has not been installed - dig mod disabled"); modDigEnabled = false; } // update - search: = -180F
            else mods++;
        }
        // done
        if(mods==0 && !optBaseDisableWarning) err("warning: no mods are enabled! Read the readme.txt!");
        log("info: configuration loaded");
        // total fuckup log
        } catch(Exception error) {
            err("error: initialization failed", error);
        }
    }

    // ################################################################################################################ OVERRIDES
    public static void initOverrides() {
        try {
        // overload FontRenderer - mc.? = new ?(mc.?, ..., mc.?) ? search "/font/default.png"
        log("info: init text"); mc.p = text = new ZFR(mc.x, "/font/default.png", mc.o);
        // overload RenderGlobal - n ? search: "Post startup" * f = new ?(this, o); just before viewport
        log("info: init render"); mc.f = render = new ZRG(mc, mc.o);
        // total fuckup log
        } catch(Exception error) {
            err("error: overrides failed", error);
        }
    }
    
    // ################################################################################################################ START
    public static void pingStartHandle() {
        try {
        // update "cheat"
        if(!isMultiplayer && cheating) {
            if(optCheatSeeIsToggle) { if(keyPress(keyCheatSee)) cheatSee = !cheatSee; }
            else cheatSee = keyDown(keyCheatSee);
            if(cheatSee) obliqueNearPlaneClip(0.0f, 0.0f, -1.0f, -optCheatSeeDist);
        }
        // total fuckup log
        } catch(Exception error) {
            err("error: start-handle failed", error);
        }
    }
    
    // ################################################################################################################ UPDATE
    public static fd player;
    public static dt world;
    public static mh renderer;
    public static boolean isMenu, isMultiplayer, isHell;
    public static double posX, posY, posZ;
    public static double motionX, motionY, motionZ;
    public static om inWhat;
    public static gy inv;
    public static gz invItems[];
    public static dc spawn;
    public static void pingUpdateHandle() {
        int i;
        if(keyPress(keyBaseInfo)) optBaseShowInfo = !optBaseShowInfo;
        try {
        // update state
        player = mc.g;          // Minecraft.player      : g    ? only field of that ("portal.trigger") type in mc
        world = mc.e;           // Minecraft.world : e ? only field of that (0x3c6ef35f) type
        renderer = mc.s;        // Minecraft.renderer : s ? only EntityRenderer (?glu) type field - gives 2 results, but only one is in Minecraft
        if(player == null || world == null || renderer == null) return;
        isMenu = mc.q != null;  // Minecraft.gui : q  ? search: if\([a-z]+ instanceof * take the one which has 2 matches
        isMultiplayer = mc.k(); // Minecraft.isMultiplayer : k ? search: public boolean [a-z]+\(\) * only match in Minecraft
        posX = getEntityPosX(player); posY = getEntityPosY(player); posZ = getEntityPosZ(player);
        motionX = player.aL; motionY = player.aM; motionZ = player.aN; // search: "Motion" * aL, aM, aN
        isHell = worldGetId(fix(posX),127,fix(posZ))==7;
        inWhat = player.aD; // second Entity field in Entity ("Motion")
        inv = player.f; // search: . = new ..\(this\); * the one in constructor
        invItems = inv.a; // search: \[36\] * the one with 2 matches - found line assigns it
        spawn = world.v(); // only function that returns world (0x3c6ef35f) type
        // update "cloud"
        if(modCloudEnabled && !isMenu) {
            if(keyPress(keyCloudVanilla)) optCloudVanilla = !optCloudVanilla;
            if(keyPress(keyCloudToggle)) { if(optCloudVanilla) optCloudVanilla = false; else optCloudShow = !optCloudShow; }
            if(keyPress(keyCloudUp))     { if(optCloudVanilla) optCloudVanilla = false; else optCloudOffset += 1f; }
            if(keyPress(keyCloudDown))   { if(optCloudVanilla) optCloudVanilla = false; else optCloudOffset -= 1f; }
        }
        // update "cart"
        if(!isMultiplayer && modCartEnabled && (inWhat instanceof tj)) { // EntityMinecart : sd   ? search: "Fuel"
            double mx = inWhat.aL + motionX * optCartAcceleration, my = inWhat.aN + motionZ * optCartAcceleration; // update
            double speed = Math.sqrt(mx*mx+my*my), rate;
            if(!isMenu && keyPress(keyCartPerpetual)) {
                optCartPerpetual = !optCartPerpetual;
                if(optCartPerpetual) cartSpeed = speed;
            }
            if((speed > optCartSpeedAccumCap) || (optCartPerpetual && speed > 0.001d )) {
                rate = optCartPerpetual ? (cartSpeed / speed) : (optCartSpeedAccumCap / speed);
                mx *= rate; my *= rate;
            }
            if(!isMenu && keyDown(keyCartStop)) { mx = my = 0.0d; optCartPerpetual = false; }
            inWhat.aL = mx; inWhat.aN = my; // update
            // handle powered minecarts
            if(optCartInfiniteFuel) {
                List list = getEntities();
                Iterator it = list.iterator();
                while(it.hasNext()) {
                    Object ent = it.next();
                    if(!(ent instanceof tj)) continue; // update ("Fuel")
                    tj cart = (tj)ent; // update
                    if(cart.d != 2) continue; // update - d = "Type"
                    if(cart.e > 0) cart.e = 1200; // replenish fuel - update - e = "Fuel"
                }
            }
        }
        // update "wield"
        if(modWieldEnabled && !isMenu && keyPress(keyWield)) {
            int bow = -1, swd = -1, cur = getInvCur();
            boolean arrows = false;
            for(i=0;i<invItems.length;i++) {
                int id = invItems[i]==null ? 0 : getItemsId(invItems[i]);
                if(id==262) arrows = true;
                if(i<9) { if(id==261) bow = i; else if(id==268 || id==272 || id==267 || id==276) swd = i; }
            }
            if(!arrows) bow = -1;
            if(bow == -1) bow = swd; else if(swd == -1) swd = bow;
            int set = optWieldBowFirst ? bow : swd;
            if(cur == set) set = set==bow ? swd : bow;
            if(set != -1) setInvCur(set);
        }
        // update "build"
        if(!isMultiplayer && modBuildEnabled) {
            // Block.blockList : qk.m ? search: public static final [a-z]+ [a-z]+\[\]; * the one that is at the end of file
            //  .destroyTime   :  bj  ? search: 1.0F / [a-z]+ / 100F; * field is in the middle
            if(buildOriginal == null) {
                buildOriginal = new float[256];
                for(i=0;i<256;i++) if(qk.m[i] != null) buildOriginal[i] = qk.m[i].bl; // update
            }
            if(!isMenu) {
                if(keyPress(keyBuildToggle)) optBuild = !optBuild;
                if(optBuild) {
                    if(!buildActive) {
                        for(i=0;i<256;i++) if(qk.m[i] != null) qk.m[i].bl = (block[i] & TOUCH) != 0 ? buildOriginal[i] : 0.0f; // update
                        buildActive = true;
                    }
                    int set = -1;
                    if(keyDown(keyBuildA)) for(i=Keyboard.KEY_1;i<=Keyboard.KEY_9;i++) if(keyPress(i)) set = i - Keyboard.KEY_1;
                    if(keyDown(keyBuildB)) for(i=Keyboard.KEY_1;i<=Keyboard.KEY_9;i++) if(keyPress(i)) set = 9 + i - Keyboard.KEY_1;
                    if(set!=-1) for(int slot=0;slot<9;slot++) if(buildSets[set][slot]!=0) invItems[slot] = newItemsE(buildSets[set][slot], 8);
                    // world edit part of mod follows
                    int x = fix(posX),y = fix(posY),z = fix(posZ);
                    if(keyPress(keyBuildDeselect)) buildMark = 0; // deselect
                    if(optBuildExtension && keyPress(keyBuildMark)) {
                        if(buildMark==1) { buildEX = x; buildEY = keyDown(keyBuildDown) ? y - 1 : y; buildEZ = z; buildMark = 2; }
                        else { buildSX = x; buildSY = keyDown(keyBuildDown) ? y - 1 : y; buildSZ = z; buildMark = 1; }
                    } else if(buildMark==2) {
                        // fix coords
                        int tmp;
                        if(buildSX > buildEX) { tmp = buildSX; buildSX = buildEX; buildEX = tmp; }
                        if(buildSY > buildEY) { tmp = buildSY; buildSY = buildEY; buildEY = tmp; }
                        if(buildSZ > buildEZ) { tmp = buildSZ; buildSZ = buildEZ; buildEZ = tmp; }
                        // ready
                        if(keyPress(keyBuildSet)) {
                            int id = 0, got, meta = 0;
                            if(invItems[getInvCur()] != null) {
                                id = getItemsId(invItems[getInvCur()]);
                                meta = getItemsInfo(invItems[getInvCur()]);
                            }
                            if(keyDown(keyBuildFill)) {
                                for(x=buildSX;x<=buildEX;x++) for(y=buildSY;y<=buildEY;y++) for(z=buildSZ;z<=buildEZ;z++) if(worldGetId(x,y,z)==0) worldSetIdMeta(x,y,z,id,meta);
                            } else if(keyDown(keyBuildRemove)) {
                                for(x=buildSX;x<=buildEX;x++) for(y=buildSY;y<=buildEY;y++) for(z=buildSZ;z<=buildEZ;z++) if((got=worldGetId(x,y,z))==id || (id==8 && got==9) || (id==10 && got==11)) worldSetIdMeta(x,y,z,0,0);
                            } else {
                                for(x=buildSX;x<=buildEX;x++) for(y=buildSY;y<=buildEY;y++) for(z=buildSZ;z<=buildEZ;z++) worldSetIdMeta(x,y,z,id,meta);
                            }
                        } else if(keyPress(keyBuildCopy)) {
                            buildMark = 0;
                            buildSizeX = 1 + buildEX - buildSX;
                            buildSizeY = 1 + buildEY - buildSY;
                            buildSizeZ = 1 + buildEZ - buildSZ;
                            int size = buildSizeX * buildSizeY * buildSizeZ, at = 0;
                            buildBufBlock = new int[size];
                            buildBufExtra = new int[size];
                            for(x=buildSX;x<=buildEX;x++) for(y=buildSY;y<=buildEY;y++) for(z=buildSZ;z<=buildEZ;z++) {
                                buildBufBlock[at] = worldGetId(x,y,z);
                                buildBufExtra[at] = worldGetMeta(x,y,z);
                                at++;
                            }
                        } else if(keyPress(keyBuildPaste) && buildBufBlock!=null) {
                            int sx = 1 + buildEX - buildSX; sx = sx > buildSizeX ? sx % buildSizeX : 0;
                            int sy = 1 + buildEY - buildSY; sy = sy > buildSizeY ? sy % buildSizeY : 0;
                            int sz = 1 + buildEZ - buildSZ; sz = sz > buildSizeZ ? sz % buildSizeZ : 0;
                            if(sx!=0 || sy!=0 || sz!=0) { // adjust selection (try to avoid partial copy)
                                buildEX -= sx; buildEY -= sy; buildEZ -= sz;
                            } else if(keyDown(keyBuildFill)) { // fill space
                                for(x=buildSX;x<=buildEX;x++) for(y=buildSY;y<=buildEY;y++) for(z=buildSZ;z<=buildEZ;z++) if(worldGetId(x,y,z)==0) {
                                    int cx = (x-buildSX) % buildSizeX, cy = (y-buildSY) % buildSizeY, cz = (z-buildSZ) % buildSizeZ;
                                    int at = (cx*buildSizeY + cy)*buildSizeZ + cz;
                                    worldSetIdMeta(x,y,z,buildBufBlock[at],buildBufExtra[at]);
                                }
                            } else if(keyDown(keyBuildRemove)) { // remove matching
                                for(x=buildSX;x<=buildEX;x++) for(y=buildSY;y<=buildEY;y++) for(z=buildSZ;z<=buildEZ;z++) {
                                    int cx = (x-buildSX) % buildSizeX, cy = (y-buildSY) % buildSizeY, cz = (z-buildSZ) % buildSizeZ;
                                    int at = (cx*buildSizeY + cy)*buildSizeZ + cz;
                                    int id = buildBufBlock[at], got = worldGetId(x,y,z);
                                    if(id == got || (id==8 && got==9) || (id==10 && got==11)) worldSetIdMeta(x,y,z,0,0);
                                }
                            } else { // replace
                                for(x=buildSX;x<=buildEX;x++) for(y=buildSY;y<=buildEY;y++) for(z=buildSZ;z<=buildEZ;z++) {
                                    int cx = (x-buildSX) % buildSizeX, cy = (y-buildSY) % buildSizeY, cz = (z-buildSZ) % buildSizeZ;
                                    int at = (cx*buildSizeY + cy)*buildSizeZ + cz;
                                    worldSetIdMeta(x,y,z,buildBufBlock[at],buildBufExtra[at]);
                                }
                            }
                        }
                    } else if(buildMark==1 && keyPress(keyBuildPaste)) {
                        buildEX = buildSX + buildSizeX - 1; buildEY = buildSY + buildSizeY - 1; buildEZ = buildSZ + buildSizeZ - 1; buildMark = 2;
                    }
                } else {
                    buildMark = 0; // deselect if build mode is not active
                }
            }
            if(optBuild && optBuildLockQuantity) for(i=0;i<invItems.length;i++) if(invItems[i]!=null) setItemsCount(invItems[i], 8);
        }
        if(buildActive && (!optBuild || isMultiplayer)) {
            for(i=0;i<256;i++) if(qk.m[i] != null) qk.m[i].bl = buildOriginal[i]; // update
            buildActive = false;
        }
        // update "compass"
        if(modCompassEnabled) {
            int cX = (Integer)getValue(fSpawnX, spawn);
            int cY = (Integer)getValue(fSpawnY, spawn);
            int cZ = (Integer)getValue(fSpawnZ, spawn);
            int pX = fix(posX), pY = fix(posY), pZ = fix(posZ); // update
            if(!compassHaveOrig || ((cX!=compassOX || cY!=compassOY || cZ!=compassOZ) && (cX!=compassMX || cY!=compassMY || cZ!=compassMZ))) {
                compassOX = cX; compassOY = cY; compassOZ = cZ; compassHaveOrig = true;
            }
            if(!isMenu) {
                if(keyPress(keyCompassToggle)) compassShowOrig = !compassShowOrig;
                if(keyPress(keyCompassSet)) {
                    compassMX = pX; compassMY = pY; compassMZ = pZ;
                    compassHaveMine = true;
                    compassShowOrig = false;
                }
            }
            if(compassShowOrig) { cX = compassOX; cY = compassOY; cZ = compassOZ; } else { cX = compassMX; cY = compassMY; cZ = compassMZ; }
            setValue(fSpawnX, spawn, cX);
            setValue(fSpawnY, spawn, cY);
            setValue(fSpawnZ, spawn, cZ);
        }
        // update "sun"
        if(modSunEnabled) {
            long time = (Long)getValue(fTime, spawn);
            if(player.K()) sunSleeping = true;
            else if(sunSleeping) { sunSleeping = false; sunTimeOffset = 0; }
            if(!isMenu) {
                if(keyPress(keySunTimeAdd)) { if(sunTimeStop) sunTimeMoment += optSunTimeStep; sunTimeOffset += optSunTimeStep; }
                if(keyPress(keySunTimeSub)) { if(sunTimeStop) sunTimeMoment -= optSunTimeStep; sunTimeOffset -= optSunTimeStep; }
                if(keyPress(keySunStop)) { sunTimeStop = !sunTimeStop; if(sunTimeStop) sunTimeMoment = time; }
                if(keyPress(keySunTimeNormal)) { sunTimeStop = false; sunTimeOffset = 0; }
            }
            if(sunTimeStop) { sunTimeOffset -= time - sunTimeMoment; sunTimeMoment = time; }
        }
        // update "fly"
        if(modFlyEnabled && !isMenu) {
            if(keyPress(keyFlyToggle)) fly = !fly;
            else if(keyDown(keyFlyOn)) fly = true;
            else if(keyDown(keyFlyOff)) fly = false;
        }
        // update "path"
        if(modPathEnabled && !isMenu) {
            if(keyPress(keyPathShow)) optPathShow = !optPathShow;
            if(keyPress(keyPathDelete)) pathCount = 0;
        }
        // update "recipe"
        if(modRecipeEnabled) {
            setValue(fCMRecipes, cmanager, isMultiplayer ? recipesMP : recipesSP);
        }
        // update "safe"
        if(modSafeEnabled && !isMenu && keyPress(keySafeShow)) {
            safeShow = !safeShow;
        }
        // update "spawn"
        if(modSpawnEnabled && !isMultiplayer) {
            List list = getEntities();
            Iterator it = list.iterator();
            int mask = 0;
            if(!optSpawnAllowOnGrass) mask |= GRASS;
            if(!optSpawnAllowOnCobble) mask |= COBBLE;
            if(!optSpawnAllowOnSand) mask |= SAND;
            if(!optSpawnAllowOnGravel) mask |= GRAVEL;
            if(!optSpawnAllowOnTree) mask |= TREE;
            if(!optSpawnAllowOnNonNatural) mask |= CRAFT;
            while(it.hasNext()) {
                om ent = (om)it.next(); // update: entity : om ? search "Pos"
                if(getEntityAge(ent)!=3) continue; // 3, just in case i miss the first beat or two
                boolean kill = false;
                switch(getEntityType(ent)) {
                    case GHAST:     if(optSpawnGhastReduction     != 0 && rnd.nextInt(100)<optSpawnGhastReduction    ) kill = true; break;
                    case COW:       if(optSpawnCowReduction       != 0 && rnd.nextInt(100)<optSpawnCowReduction      ) kill = true; break;
                    case SPIDER:    if(optSpawnSpiderReduction    != 0 && rnd.nextInt(100)<optSpawnSpiderReduction   ) kill = true; break;
                    case SHEEP:     if(optSpawnSheepReduction     != 0 && rnd.nextInt(100)<optSpawnSheepReduction    ) kill = true; break;
                    case SKELLY:    if(optSpawnSkeletonReduction  != 0 && rnd.nextInt(100)<optSpawnSkeletonReduction ) kill = true; break;
                    case CREEPER:   if(optSpawnCreeperReduction   != 0 && rnd.nextInt(100)<optSpawnCreeperReduction  ) kill = true; break;
                    case ZOMBIE:    if(optSpawnZombieReduction    != 0 && rnd.nextInt(100)<optSpawnZombieReduction   ) kill = true; break;
                    case SLIME:     if(optSpawnSlimeReduction     != 0 && rnd.nextInt(100)<optSpawnSlimeReduction    ) kill = true; break;
                    case PIG:       if(optSpawnPigReduction       != 0 && rnd.nextInt(100)<optSpawnPigReduction      ) kill = true; break;
                    case CHICKEN:   if(optSpawnChickenReduction   != 0 && rnd.nextInt(100)<optSpawnChickenReduction  ) kill = true; break;
                    case SQUID:     if(optSpawnSquidReduction     != 0 && rnd.nextInt(100)<optSpawnSquidReduction    ) kill = true; break;
                    case PIGZOMBIE: if(optSpawnPigZombieReduction != 0 && rnd.nextInt(100)<optSpawnPigZombieReduction) kill = true; break;
                    case LIVING:    if(!optSpawnSupportMods) continue; break;
                    default: continue;
                }
                if(!kill) {
                    int x = fix(getEntityPosX(ent)), y = fix(getEntityPosY(ent)), z = fix(getEntityPosZ(ent));
                    if(!optSpawnAllowInNonAir && (block[worldGetId(x,y,z)] & DECAL)!=0) kill = true;
                    if(mask!=0 && (block[worldGetId(x,y-1,z)] & mask)!=0) kill = true;
                }
                if(kill) ent.H(); // UPDATE: search: = 600; * next function calls setEntityDead : H
            }
        }
        // update "ore"
        if(modOreEnabled && !isMultiplayer && !isHell) {
            int cx = fix(posX) >> 4, cz = fix(posZ) >> 4, tx, ty, tz, id;
            for(int cxi=cx-3;cxi<=cx+3;cxi++) for(int czi=cz-3;czi<=cz+3;czi++) {
                tx = (cxi<<4)+3; ty = (czi<<4)+3;
                byte data[] = worldGetChunkData(cxi, czi);
                if(data[1024] != 7) continue; // already done
                data[1024] = 0; data[1025] = 7; // mark the chunk done
                for(i=0;i<data.length;i++) {
                    id = (int)data[i] & 255; // fucking Java with his lack of unsigned types x_x.
                    if((block[id] & ORE) != 0) data[i] = 1;
                    else if(id == 7 && (i & 127) > 1) data[i] = optOreLavaFloor ? (byte)11 : (byte)1;
                    else if((i & 127) == 1) data[i] = 7;
                }
                oreDistribute(data, optOreCoalRule   , (byte)16);
                oreDistribute(data, optOreIronRule   , (byte)15);
                oreDistribute(data, optOreGoldRule   , (byte)14);
                oreDistribute(data, optOreBlueRule   , (byte)21);
                oreDistribute(data, optOreRedRule    , (byte)73);
                oreDistribute(data, optOreDiamondRule, (byte)56);
                chunkNeedsUpdate(cxi, czi); // request update
            }
        }
        /*if(modOreEnabled && !isMultiplayer && !isHell) {
            int cx = fix(posX) >> 4, cz = fix(posZ) >> 4, tx, ty, tz, id;
            for(int cxi=cx-3;cxi<=cx+3;cxi++) for(int czi=cz-3;czi<=cz+3;czi++) {
                tx = (cxi<<4)+3; ty = (czi<<4)+3;
                byte data[] = worldGetChunkData(cxi, czi);
                boolean redistribute = false; // block!=7 => bit is up
                for(int bit=0;bit<oreBits;bit++) {
                    int at = 1024 + (bit<<7);
                    boolean target = ((optOreRedistributionNr & (1<<bit)) != 0);
                    if((data[at] != 7) != target) {
                        redistribute = true;
                        data[at] = target ? 0 : 7;
                        data[at+1] = 7;
                    }
                }
                if(!redistribute) continue; // already done
                
                for(i=0;i<data.length;i++) {
                    id = (int)data[i] & 255; // fucking Java with his lack of unsigned types x_x.
                    if((block[id] & ORE) != 0) data[i] = 1;
                    else if(id == 7 && (i & 127) > 1) data[i] = optOreLavaFloor ? (byte)11 : (byte)1;
                    else if((i & 127) == 1) data[i] = 7;
                }
                oreDistribute(data, optOreCoalRule   , (byte)16);
                oreDistribute(data, optOreIronRule   , (byte)15);
                oreDistribute(data, optOreGoldRule   , (byte)14);
                oreDistribute(data, optOreBlueRule   , (byte)21);
                oreDistribute(data, optOreRedRule    , (byte)73);
                oreDistribute(data, optOreDiamondRule, (byte)56);
                chunkNeedsUpdate(cxi, czi); // request update
            }
        }*/
        // update "teleport"
        if(modTeleportEnabled && !isMultiplayer) { // blocking buggy MP support
            List list = getEntities();
            Iterator it = list.iterator();
            int type, x, y, z, id, ofs;
            
            try { // hack

            while(it.hasNext()) {
                om ent = (om)it.next(); // update: entity : om ? search "Pos"
                type = getEntityType(ent);
                if(isMultiplayer && ent!=player) continue;
                x = fix(getEntityPosX(ent)); y = fix(getEntityPosY(ent)) - 1; z = fix(getEntityPosZ(ent)); ofs=0;
                // find solid ground / teleportation pad
                id = worldGetId(x,y,z);
                if((block[id] & SOLID) == 0) { id = worldGetId(x,--y,z); ofs++; }
                // check pad type vs entity type
                if(type == 0 && (id != optTeleportItem || !(ent instanceof fs))) continue; // UPDATE: ? "Age"
                if(type != 0 && type != PLAYER && id != optTeleportCritter) continue;
                if(type == PLAYER && id != optTeleportPlayer) continue;
                // get sign text
                String sign[] = null;
                id = worldGetId(x, y+1, z); if(id == 63 || id == 68) sign = getSignText(x, y+1, z);
                id = worldGetId(x, y+2, z); if(id == 63 || id == 68) sign = getSignText(x, y+2, z);
                id = worldGetId(x, y-1, z); if(id == 63 || id == 68) sign = getSignText(x, y-1, z);
                if(sign == null) continue;
                // read teleportation info from sign and TP
                try {
                    x = 0; y = -1; z = 0;
                    for(i=0;i<sign.length;i++) if(sign[i]!=null && sign[i].length()>1) {
                        if(sign[i].charAt(0)=='!') {
                            String part[] = sign[i].substring(1).split(",");
                            if(part.length != 3) break;
                            x = new Integer(part[0]);
                            y = new Integer(part[1]);
                            z = new Integer(part[2]);
                        } else if(sign[i].charAt(0)=='?') {
                            String filter = sign[i].substring(1);
                            id = names.containsKey(filter) ? (Integer)names.get(filter) : parseIdInfo(filter);
                            id &= 0xffff; // strip "damage" / info
                            if(type != 0 && type != PLAYER && id == type) continue; // mob filter match
                            if(type == 0 && getItemsId(((fs)ent).a) == id) continue; // item filter match: UPDATE: ? "Age" * only itemstack type field there
                            y=-1; break;
                        }
                    }
                    if(y==-1) continue;
                    // check target coordinates - multiplayer only
                    if(isMultiplayer) {
                        // is target chunk missing?
                        if(worldGetId(x,0,z)!=7) { noiseTP(ent); break; }
                        // is target area clear?
                        if((block[worldGetId(x,y+1,z)] & SOLID)!=0 || (block[worldGetId(x,y+0,z)] & SOLID)!=0 || (block[worldGetId(x,y-1,z)] & SOLID)!=0) { noiseTP(ent); break; }
                    }
                    // teleport
                    setEntityPos(ent, 0.5+x, 0.5+(y+ofs), 0.5+z);
                    //if(isMultiplayer) ((pg)player).bI.a(new x(0.5+x, player.aS.b, 0.5+(y+ofs), 0.5+z, player.aT)); // player search: -999D * the other stuff (new x...) you will also find there
                    if(type==PLAYER) noiseTP(ent);
                } catch(Exception whatever) {} // failsafe
                break; // this will not help against ConcurrentModificationException :/
            }
            
            } catch(ConcurrentModificationException why) {} // hack to prevent it from dying
        }
        // update "cheat"
        if(modCheatEnabled && !isMultiplayer) {
            if(!isMenu && keyPress(keyCheat)) {
                cheating = !cheating;
                if(optCheatRestoreHealth && !cheating) player.V = 20; // restore-health: update
            }
            if(cheating) {
                if(!isMenu) {
                    if(keyPress(keyCheatShowMobs)) cheatShowMobs = !cheatShowMobs;
                    if(keyPress(keyCheatShowOres)) cheatShowOres = !cheatShowOres;
                }
                if(optCheatRestoreHealth) {
                    player.V = 2000; // update: "Health"
                    player.bs = 0; // update: "Fire"
                    player.bw = 300; // update: "Air"
                }
                if(!optCheatFallDamage) {
                    player.bg = 0; // update: "FallDistance"
                }
            }
        }
        // update "resize"
        if(modResizeEnabled && !isMultiplayer) {
            List list = getEntities();
            Iterator it = list.iterator();
            int chance;
            while(it.hasNext()) {
                om ent = (om)it.next(); // update: entity : om ? search "Pos"
                if(getEntityAge(ent)!=3) continue;
                int type = getEntityType(ent);
                if(type==0 || type==LIVING) continue;
                chance = rnd.nextInt(100);
                resizeSize[type] = ent.bb; // store original size - update
                if(resizeChanceSmall[type]>chance) {
                    ent.bb *= 0.5;                  // update ... search: mob/slime
                    ent.bc *= 0.5;                  // update
                    ((iz)ent).V >>= 1;              // update
                    ent.c(ent.aI, ent.aJ, ent.aK);  // update
                } else if(resizeChanceBig[type]<chance) {
                    ent.bb *= 1.5;                  // update
                    ent.bc *= 1.5;                  // update
                    ((iz)ent).V <<= 1;              // update
                    ent.c(ent.aI, ent.aJ, ent.aK);  // update
                }
            }
        }
        // total fuckup log
        } catch(Exception error) {
            err("error: update-handle failed", error);
        }
    }

    // ################################################################################################################ DRAW
    private static long prevTick, curTick;
    private static float seconds; // current frame delta time
    public static void pingDrawHandle(float delta) {
        try {
        if(player == null || world == null || renderer == null) return;
        // update player position
        posX = getEntityPosX(player); posY = getEntityPosY(player); posZ = getEntityPosZ(player);
        // update time
        curTick = System.nanoTime();
        float seconds = ((float)(curTick - prevTick)) * 0.000000001f;
        if(seconds > 1f) seconds = 0f;
        prevTick = curTick;
        // draw in 3d
        float px = (float)posX, py = (float)posY, pz = (float)posZ;
        float mx = (float)player.bh, my = (float)player.bi ,mz = (float)player.bj;   // update - Player.prevPos? : bh, bi, bj ? search "Pos" ... next function has ? = prevPosX = posX
        float x = mx + ( px - mx ) * delta, y = my + ( py - my ) * delta, z = mz + ( pz - mz ) * delta;
        // draw "cheat"
        if(!isMultiplayer && modCheatEnabled && cheating && (cheatShowMobs || cheatShowOres)) {
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glDisable(GL11.GL_DEPTH_TEST);
            GL11.glBegin(GL11.GL_LINES);
            if(cheatShowMobs) {
                List list = getEntities();
                Iterator it=list.iterator();
                while(it.hasNext()) {
                    Object ent = it.next();
                    int type = getEntityType(ent);
                    if(cheatMobs[type] == null) continue;
                    GL11.glColor3ub(cheatMobs[type].r, cheatMobs[type].g, cheatMobs[type].b);
                    mx = (float)getEntityPosX(ent) - x; my = (float)getEntityPosY(ent) - y; mz = (float)getEntityPosZ(ent) - z;
                    GL11.glVertex3f(mx,my+2.0f,mz); GL11.glVertex3f(mx,my,mz); // use entity size? (om)ent.bb
                }
            }
            if(cheatShowOres) {
                cheatRefresh += seconds;
                if(cheatRefresh > 0.3f) {
                    cheatReCheck(fix(posX), fix(posY), fix(posZ));
                    cheatRefresh -= 0.3f;
                }
                for(int i=0;i<cheatCur;i++) {
                    Mark got = cheatMark[i];
                    GL11.glColor3ub(got.r,got.g,got.b);
                    mx = got.x - x; my = got.y - y; mz = got.z - z;
                    GL11.glVertex3f(mx+0.25f,my+0.25f,mz+0.25f); GL11.glVertex3f(mx-0.25f,my-0.25f,mz-0.25f);
                    GL11.glVertex3f(mx+0.25f,my+0.25f,mz-0.25f); GL11.glVertex3f(mx-0.25f,my-0.25f,mz+0.25f);
                    GL11.glVertex3f(mx+0.25f,my-0.25f,mz+0.25f); GL11.glVertex3f(mx-0.25f,my+0.25f,mz-0.25f);
                    GL11.glVertex3f(mx+0.25f,my-0.25f,mz-0.25f); GL11.glVertex3f(mx-0.25f,my+0.25f,mz+0.25f);
                }
            }
            GL11.glEnd();
            GL11.glEnable(GL11.GL_DEPTH_TEST);
            GL11.glEnable(GL11.GL_TEXTURE_2D);
        }
        // draw "path"
        if(modPathEnabled) {
            // get previous location
            float tx = pathf[pathLast] - px, ty = pathf[pathLast+1] - (py - 1.25f), tz = pathf[pathLast+2] - pz;
            float dist = tx*tx + ty*ty + tz*tz;
            // do we have a new pathpoint
            if(dist > optPathMin) {
                pathLast += 3; if(pathLast >= pathf.length) pathLast = 0;
                if(pathCount < optPathPoints) pathCount++;
                pathf[pathLast] = px;
                pathf[pathLast+1] = py - 1.25f;
                pathf[pathLast+2] = pz;
            }
            // draw the path?
            if(optPathShow && pathCount>3) {
                pathAnimCur += seconds * optPathAnimSpeed;
                if(pathAnimCur > optPathSpacing) pathAnimCur -= optPathSpacing;
                float x1 = pathf[pathLast] - x, y1 = pathf[pathLast+1] - y, z1 = pathf[pathLast+2] - z, x2, y2, z2;
                int cnt = pathCount-1, at = pathLast, anim = ((pathf.length - pathLast) / 3 + (int)pathAnimCur) % optPathSpacing;
                int skip = 4;
                GL11.glDisable(GL11.GL_TEXTURE_2D);
                GL11.glColor3ub(optPathColor.r,optPathColor.g,optPathColor.b);
                GL11.glBegin(GL11.GL_LINES);
                    do {
                        x2 = x1; y2 = y1; z2 = z1;
                        at -= 3; if(at<0) at = pathf.length - 3;
                        x1 = pathf[at] - x; y1 = pathf[at+1] - y; z1 = pathf[at+2] - z;
                        if(optPathSpacing > 2) {
                            if(++anim == optPathSpacing) anim = 0;
                            if(anim <= 1 && skip < 0) { GL11.glVertex3f(x1,y1,z1); GL11.glVertex3f(x2,y2,z2); }
                        } else if(skip < 0) { GL11.glVertex3f(x1,y1,z1); GL11.glVertex3f(x2,y2,z2); }
                        skip--;
                    } while((--cnt) != 0);
                GL11.glEnd();
                GL11.glEnable(GL11.GL_TEXTURE_2D);
            }
        }
        // draw "safe"
        if(modSafeEnabled && safeShow) {
            if(--safeUpdate<0) {
                safeUpdate = 16;
                reCheckSafe(fix(posX), fix(posY), fix(posZ));
            }
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glColor3ub(optSafeDangerColor.r,optSafeDangerColor.g,optSafeDangerColor.b);
            GL11.glBegin(GL11.GL_LINES);
            for(int i=0;i<safeCur;i++) {
                Mark got = safeMark[i];
                mx = got.x - x; my = got.y - y; mz = got.z - z;
                GL11.glVertex3f(mx+0.5f,my,mz+0.5f); GL11.glVertex3f(mx-0.5f,my,mz-0.5f);
                GL11.glVertex3f(mx+0.5f,my,mz-0.5f); GL11.glVertex3f(mx-0.5f,my,mz+0.5f);
            }
            GL11.glEnd();
            GL11.glEnable(GL11.GL_TEXTURE_2D);
        }
        // draw "build"
        if(modBuildEnabled && !isMultiplayer && buildMark > 0) {
            // calculate selection box
            float sx = (float)buildSX - x - 0.1f, ex = (float)(buildMark==2 ? buildEX : buildSX) - x + 1.1f;
            float sy = (float)buildSY - y - 0.1f, ey = (float)(buildMark==2 ? buildEY : buildSY) - y + 1.1f;
            float sz = (float)buildSZ - z - 0.1f, ez = (float)(buildMark==2 ? buildEZ : buildSZ) - z + 1.1f;
            // change state
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glDepthMask(false);
            GL11.glDisable(GL11.GL_CULL_FACE);
            // draw selection box sides
            if(buildMark == 2) {
                GL11.glEnable(GL11.GL_BLEND); GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
                GL11.glColor4ub((byte)255,(byte)64,(byte)32,(byte)32);
                GL11.glBegin(GL11.GL_QUADS);
                    GL11.glVertex3f(sx,sy,sz); GL11.glVertex3f(sx,sy,ez); GL11.glVertex3f(sx,ey,ez); GL11.glVertex3f(sx,ey,sz);
                    GL11.glVertex3f(ex,sy,sz); GL11.glVertex3f(ex,sy,ez); GL11.glVertex3f(ex,ey,ez); GL11.glVertex3f(ex,ey,sz);
                    GL11.glVertex3f(sx,sy,sz); GL11.glVertex3f(sx,sy,ez); GL11.glVertex3f(ex,sy,ez); GL11.glVertex3f(ex,sy,sz);
                    GL11.glVertex3f(sx,ey,sz); GL11.glVertex3f(sx,ey,ez); GL11.glVertex3f(ex,ey,ez); GL11.glVertex3f(ex,ey,sz);
                    GL11.glVertex3f(sx,sy,sz); GL11.glVertex3f(sx,ey,sz); GL11.glVertex3f(ex,ey,sz); GL11.glVertex3f(ex,sy,sz);
                    GL11.glVertex3f(sx,sy,ez); GL11.glVertex3f(sx,ey,ez); GL11.glVertex3f(ex,ey,ez); GL11.glVertex3f(ex,sy,ez);
                GL11.glEnd();
                GL11.glDisable(GL11.GL_BLEND);
            }
            // draw selection box
            GL11.glColor3ub((byte)32,(byte)64,(byte)255);
            GL11.glBegin(GL11.GL_LINES);
                GL11.glVertex3f(sx,sy,sz); GL11.glVertex3f(sx,sy,ez);
                GL11.glVertex3f(sx,sy,ez); GL11.glVertex3f(sx,ey,ez);
                GL11.glVertex3f(sx,ey,ez); GL11.glVertex3f(sx,ey,sz);
                GL11.glVertex3f(sx,ey,sz); GL11.glVertex3f(sx,sy,sz);
                    
                GL11.glVertex3f(ex,sy,sz); GL11.glVertex3f(ex,sy,ez);
                GL11.glVertex3f(ex,sy,ez); GL11.glVertex3f(ex,ey,ez);
                GL11.glVertex3f(ex,ey,ez); GL11.glVertex3f(ex,ey,sz);
                GL11.glVertex3f(ex,ey,sz); GL11.glVertex3f(ex,sy,sz);

                GL11.glVertex3f(sx,sy,sz); GL11.glVertex3f(ex,sy,sz);
                GL11.glVertex3f(sx,sy,ez); GL11.glVertex3f(ex,sy,ez);
                GL11.glVertex3f(sx,ey,ez); GL11.glVertex3f(ex,ey,ez);
                GL11.glVertex3f(sx,ey,sz); GL11.glVertex3f(ex,ey,sz);
            GL11.glEnd();
            // restore state
            GL11.glEnable(GL11.GL_CULL_FACE);
            GL11.glDepthMask(true);
            GL11.glEnable(GL11.GL_TEXTURE_2D);
        }
        // draw "cloud"
        if(modCloudEnabled && !optCloudVanilla) {
            if(optCloudShow) { // find in file that contains cloud
                double mov = player.bi; // save
                // adjusting equation: player.bi + (player.aJ - player.bi) * f;
                player.bi += ( player.aJ - player.bi ) * delta - optCloudOffset; render.callSuper(0F);
                player.bi = mov; // restore
            }
        } else {
            render.callSuper(delta);
        }
        // done
        // total fuckup log
        } catch(Exception error) {
            err("error: draw-handle failed", error);
        }
    }
    
    // ################################################################################################################ TEXT
    public static String pingTextHandle() {
        if(player == null || world == null || renderer == null) return "";
        String infoLine = "";
        try {
        // text for "cloud"
        if(modCloudEnabled && optCloudVanilla) infoLine += " " + tagCloudVanilla;
        // text for cart
        if(!isMultiplayer && modCartEnabled && optCartPerpetual) infoLine += " " + tagCartPerpetual;
        // text for build
        if(!isMultiplayer && modBuildEnabled && optBuild) infoLine += " " + tagBuildEnabled;
        // text for compass
        if(modCompassEnabled) {
            if(optCompassShowPos) infoLine += " (" + fix(posX) + "," + fix(posY) + "," + fix(posZ) + ")";
            if(!compassShowOrig) infoLine += " " + tagCompassAlternate;
        }
        // text for sun
        if(modSunEnabled && sunTimeOffset!=0) infoLine += " " + tagSunTime + (sunTimeOffset<0 ? "" : "+") + (sunTimeOffset/20);
        // text for fly
        if(modFlyEnabled && fly) infoLine += " " + tagFly;
        // text for recipe
        if(modRecipeEnabled && optRecipeShowId) infoLine += invItems[getInvCur()]==null ? "" : ( " id:" + getItemsId(invItems[getInvCur()]) + "/" + getItemsInfo(invItems[getInvCur()]) );
        // text for safe
        if(modSafeEnabled && safeShow) infoLine += " " + tagSafe;
        // text for cheat
        if(!isMultiplayer && modCheatEnabled && cheating) infoLine += " " + tagCheater;
        // total fuckup log
        } catch(Exception error) {
            err("error: text-handle failed", error);
        }
        // done
        return infoLine;
    }

    // ################################################################################################################
    
    // ---------------------------------------------------------------------------------------------------------------- ore
    private static void oreDistribute(byte data[], int rule[], byte result) {
        int i, chunk, max, min, attempt, size, above, x, y, z, at, cnt;
        for(i=0;i<rule.length;i+=6) {
            chunk = rule[i + 0];
            max = rule[i + 1];
            min = rule[i + 2];
            attempt = rule[i + 3];
            size = rule[i + 4];
            above = rule[i + 5];
            if(chunk<100 && rnd.nextInt(100)>=chunk) continue;
            while(attempt-->0) {
                x = rnd.nextInt(14)+1; y = rnd.nextInt(1+max-min) + min; z = rnd.nextInt(14)+1;
                at = x<<11 | z<<7 | y;
                if(data[at]!=1 || data[at-1]!=1 || data[at+1]!=above || data[at+128]!=1 || data[at-128]!=1 || data[at+2048]!=1 || data[at-2048]!=1) continue;
                cnt = size - 1;
                data[at] = result;
                while(cnt-->0) {
                    switch(rnd.nextInt(7)) {
                        case 0: continue;
                        case 1: at += 1; break;
                        case 2: at -= 1; break;
                        case 3: at += 128; break;
                        case 4: at -= 128; break;
                        case 5: at += 2048; break;
                        case 6: at -= 2048; break;
                    }
                    if(at<0) at += 32768; else if(at>=32768) at -= 32768;
                    if(data[at]==1) data[at] = result;
                }
            }
        }
    }

    // ---------------------------------------------------------------------------------------------------------------- cheat
    private static void cheatReCheck(int pX, int pY, int pZ) {
        cheatCur = 0;
        for(int x=pX-16;x<pX+16;x++) for(int y=pY-64;y<pY+64;y++) for(int z=pZ-16;z<pZ+16;z++) {
            Mark color = cheatOres[worldGetId(x,y,z)];
            if(color == null) continue;
            cheatMark[cheatCur++] = new Mark(x,y,z,color);
            if(cheatCur == cheatMax) return;
        }
    }

    // ---------------------------------------------------------------------------------------------------------------- safe
    // UPDATE: spawnCheckA* : ? find spawn check line in CritterSpawnde (?completed) - find the used function in word
    // ... g(x,y,z) => in world
    private static final boolean spawnCheckA(int id) { return qk.m[id]==null ? false : qk.m[id].a(); }

    private static void reCheckSafe(int pX, int pY, int pZ) { // UPDATE
        safeCur = 0;
        int id, maskA = SPAWN, maskB = SPAWN | LIQUID | SOLID, maskC = SPAWN, maskL = 0;
        if(modSpawnEnabled && !isMultiplayer) {
            if(!optSpawnAllowInNonAir) maskB |= DECAL;
            if(!optSpawnAllowOnNonNatural) maskL |= CRAFT;
            if(!optSpawnAllowOnGrass) maskL |= GRASS;
            if(!optSpawnAllowOnCobble) maskL |= COBBLE;
            if(!optSpawnAllowOnSand) maskL |= SAND;
            if(!optSpawnAllowOnGravel) maskL |= GRAVEL;
            if(!optSpawnAllowOnTree) maskL |= TREE;
        }
        for(int x=pX-16;x<pX+16;x++) for(int y=pY-16;y<pY+16;y++) for(int z=pZ-16;z<pZ+16;z++) {
            int onWhat;
            if(((onWhat = block[worldGetId(x,y,z)]) & maskA) == 0) continue; // !dn1.g(i, j - 1, k)
            if((onWhat & maskL) != 0) continue; // spawn limitations from "spawn" mod
            if((block[worldGetId(x,y+1,z)] & maskB) != 0) continue; // dn1.g(i, j, k) || dn1.f(i, j, k).d()
            if((block[worldGetId(x,y+2,z)] & maskC) != 0) continue; // dn1.g(i, j + 1, k)
            // light level check
            if(world.c(x >> 4, z >> 4).c(x & 0xf, y+1, z & 0xf, 16) > 7) continue;      // update ... ugh ... where do i find it? FIXME
            safeMark[safeCur++] = new Mark(x,y+1,z);
            if(safeCur == safeMax) return;
        }
    }

    // ---------------------------------------------------------------------------------------------------------------- fly
    public static double flyMX, flyMY, flyMZ;
    public static void calculate(double motionX, double motionY, double motionZ) {
        flyMX = motionX;  flyMY = motionY;  flyMZ = motionZ;
        if(!fly) return;
        flyMY = 0d;
        if(!isMenu) {
            if(keyDown(keyFlyUp)) flyMY += optFlySpeedVertical;
            if(keyDown(keyFlyDown)) flyMY -= optFlySpeedVertical;
            double mul = keyDown(keyFlySpeed) ? optFlySpeedMulModifier : optFlySpeedMulNormal;
            flyMX*=mul; flyMY*=mul; flyMZ*=mul;
        }
    }

    // ----------------------------------------------------------------------------------------------------------------
    private static HashMap getNames() {
        if(names != null) return names;
        parse(null, "names.txt", NAMEMAP);
        return names = pNames;
    }

    // ================================================================================================================ helpers
    // Entity : om ? search: "Pos"
    // UPDATE search: public int [a-z]+\(int [a-z0-9]+, int [a-z0-9]+, int [a-z0-9]+\)
    public static final int worldGetId(int x, int y, int z) { return world.a(x,y,z); } // first result - returns X(...).Y(...)
    private static final int worldGetMeta(int x, int y, int z) { return world.e(x,y,z); } // second result - has "&= 0xf;" in it
    // UPDATE search: public boolean [a-z]+\(int [a-z0-9]+, int [a-z0-9]+, int [a-z0-9]+, int [a-z0-9]+, int [a-z0-9]+\)
    private static final void worldSetIdMeta(int x, int y, int z, int id, int meta) { world.b(x,y,z,id,meta); } // second match - the one without bounds checks
    private static final void worldSetId(int x, int y, int z, int id) { world.b(x,y,z,id); } // search: [a-zA-Z]+\([a-zA-Z0-9]+ \+ [a-zA-Z0-9]+, [a-zA-Z0-9]+ \+ [a-zA-Z0-9]+, [a-zA-Z0-9]+ \+ [a-zA-Z0-9]+, [a-zA-Z0-9]+ < 4 \? [a-zA-Z0-9_]+ : 0\);
    private static final byte[] worldGetChunkData(int cx, int cz) { return world.c(cx, cz).b; } // search: return [a-zA-Z]+\([a-z0-9]+ >> 4, [a-z0-9]+ >> 4\)\.[a-zA-Z]+\([a-z0-9]+ & 0xf, [a-z0-9]+, [a-z0-9]+ & 0xf\);
    private static final void chunkNeedsUpdate(int cx, int cz) { cx <<= 4; cz <<= 4; world.b(cx, 0, cz, cx+15, 127, cz+15); } // update: in world ? search: public void [a-z]+\(int[^,]+, int[^,]+, int[^,]+, int[^,]+, int[^,]+, int[^,]+\)
    private static final gz newItemsE(int id, int count) { return newItems(id & 0xffff, count, id >> 16); }
    private static final gz newItems(int id, int count, int param) { return new gz(id, count, param == 9999 ? -1 : param); } // ItemStack     : gz ? search: "Damage"
    private static final gz newItems(int id, int count) { return newItems(id, count, 0); }
    private static final int getInvCur() { return inv.c; } // .currentItem : c ? only int field in class (\[36\])
    private static final void setInvCur(int cur) { inv.c = cur; }
    private static final int getItemsId(Object items) { return ((gz)items).c; } // ItemStack.itemID      : c    ? search: "id" * has ItemId = ??.?("id"); in it
    private static final void setItemsCount(Object items, int cnt) { ((gz)items).a = cnt; } // search: "Count"
    private static final int getItemsInfo(Object items) { return ((gz)items).i(); } // returns d / "Damage"
    private static final String[] getSignText(int x, int y, int z) { return getSign(x,y,z).a; } // (remember sign class name) search: "Text1"
    private static final ti getSign(int x, int y, int z) { return (ti)world.b(x,y,z); } // search: \(class-name\) * C c1 = (C)world.?(x,y,z)
    private static final List getEntities() { return world.b; } // update: entities : b ? seacrh: / 16D * ?.add in the function
    private static final int getEntityAge(Object ent) { return ((om)ent).bq; } // search: [a-z]+ % 20\) \* 12 == 0
    private static final double getEntityPosX(Object ent) { return ((om)ent).aI; } // UPDATE
    private static final double getEntityPosY(Object ent) { return ((om)ent).aJ; } // UPDATE
    private static final double getEntityPosZ(Object ent) { return ((om)ent).aK; } // UPDATE
    public static int getEntityType(Object ent) {
        if(ent instanceof fd) return PLAYER; // char - ensure it is player
        if(ent instanceof aw) return GHAST;
        if(ent instanceof bc) return COW;
        if(ent instanceof bp) return SPIDER; // ts = spider_eyes
        if(ent instanceof cl) return SHEEP; // sx = sheep_fur?
        if(ent instanceof eg) return SKELLY;
        if(ent instanceof ep) return CREEPER;
        if(ent instanceof qo || ent instanceof kr) return ZOMBIE;
        if(ent instanceof qm) return SLIME;
        if(ent instanceof rn) return PIG;
        if(ent instanceof rx) return CHICKEN;
        if(ent instanceof ss) return SQUID;
        if(ent instanceof sz) return PIGZOMBIE;
        if(ent instanceof iz) return LIVING; // char - ensure it is not player
        return 0;
    }
    private static final void setEntityPos(om ent, double x, double y, double z) { // search: "Pos"    * aI, aJ, aK
        ent.c(0.0D, 0.0D, 0.0D);
        ent.aF = ent.bh = ent.aI = x;
        ent.aG = ent.bi = ent.aJ = y;
        ent.aH = ent.bj = ent.aK = z;
        ent.c(x, y, z);
    }
    private static void noiseTP(om ent) { // update
        world.a(ent, "mob.slime", 0.4f,( (rnd.nextFloat() - rnd.nextFloat())*0.2f + 1.0f )*0.8f); // UPDATE "mob.slime"
    }

    // ================================================================================================================ log
    public static void log(String text) {
        out.println(text);
    }

    public static void err(String text) {
        if(firstError == null) firstError = text;
        log(text);
        setMsg("ZMerror", "ZMod: errors detected - one or more mods affected\nFirst "+firstError+"\nLog: "+logPath,2,36,0xff8888);
    }

    public static void err(String text, Exception e) {
        err(text);
        log("### Exception: " + e.toString());
        e.printStackTrace(out);
    }
    
    // ================================================================================================================ config
    public static int getBind(String name, int init) {
        String val = conf.getProperty(name);
        if(val == null || val.equals("")) return init;
        int i = Keyboard.getKeyIndex(val);
        if(i == Keyboard.KEY_NONE) { err("error: config.txt @ "+name+" - invalid key name \""+val+"\""); return init; }
        return i;
    }

    public static float getFloat(String name, float init, float min, float max) {
        String val = conf.getProperty(name);
        if(val == null) return init;
        float f = new Float(val);
        if(f<min || f>max) { err("error: config.txt @ "+name+" - must be between "+min+" and "+max); return init; }
        return f;
    }

    public static int getInt(String name, int init, int min, int max) {
        String val = conf.getProperty(name);
        if(val == null) return init;
        int i = new Integer(val);
        if(i<min || i>max) { err("error: config.txt @ "+name+" - must be between "+min+" and "+max); return init; }
        return i;
    }

    public static String getString(String name, String init) {
        String val = conf.getProperty(name);
        if(val == null) return init;
        return val;
    }

    public static boolean getBool(String name, boolean init) {
        String val = conf.getProperty(name);
        if(val == null) return init;
        if(val.equals("1") || val.equals("yes") || val.equals("true") || val.equals("on")) return true;
        if(val.equals("0") || val.equals("no") || val.equals("false") || val.equals("off")) return false;
        err("error: config.txt @ "+name+" - must be one of (1, yes, true, on, 0, no, false, off)");
        return init;
    }
    
    public static Mark getColor(String name, int color) {
        Mark res = new Mark(color);
        String val = conf.getProperty(name);
        if(val == null) return res;
        if(!res.loadColor(val)) err("error: config.txt @ "+name+" - undefined or invalid color \""+val+"\"");
        return res;
    }
    
    public static boolean getDeprecated(String name) {
        if(conf.getProperty(name) == null) return false;
        log("notice: config.txt @ "+name+" - this option is deprecated");
        return true;
    }
    
    // ================================================================================================================ reflect
    private static void reportException(Exception error) {
        if(exceptionReported) return;
        exceptionReported = true;
        err("exception in reflection code encountered !", error);
    }
    public static Field getField(Class c, String name) { try { Field field = c.getDeclaredField(name); field.setAccessible(true); return field; } catch(Exception error) { reportException(error); } return null; }
    public static Object getValue(Field field, Object obj) { try { return field.get(obj); } catch(Exception error) { reportException(error); } return null; }
    public static void setValue(Field field, Object obj, Object val) { try { field.set(obj, val); } catch(Exception error) { reportException(error); } }
    public static Class getClass(String name) { try { return Class.forName(name); } catch(Exception error) { reportException(error); } return null; }
    public static Constructor getConstructor(Class c, Class param[]) { try { return c.getConstructor(param); } catch(Exception error) { reportException(error); } return null; }
    public static Method getMethod(Class c, String name, Class param[]) { try { Method method = c.getDeclaredMethod(name, param); method.setAccessible(true); return method; } catch(Exception error) { reportException(error); } return null; }
    public static Method getMethod(Class c, String name) { return getMethod(c,name,new Class[]{}); }
    public static Method getMethod(Class c, String name, Class p1) { return getMethod(c,name,new Class[]{p1}); }
    public static Method getMethod(Class c, String name, Class p1, Class p2) { return getMethod(c,name,new Class[]{p1,p2}); }
    public static Method getMethod(Class c, String name, Class p1, Class p2, Class p3) { return getMethod(c,name,new Class[]{p1,p2,p3}); }
    public static Method getMethod(Class c, String name, Class p1, Class p2, Class p3, Class p4) { return getMethod(c,name,new Class[]{p1,p2,p3,p4}); }
    public static Object getNew(Constructor cc, Object param[]) { try { return cc.newInstance(param); } catch(Exception error) { reportException(error); } return null; }
    public static Object getNew(Constructor cc, Object p1) { return getNew(cc, new Object[]{p1}); }
    public static Object getNew(Constructor cc, Object p1, Object p2) { return getNew(cc, new Object[]{p1,p2}); }
    public static Object getNew(Constructor cc, Object p1, Object p2, Object p3) { return getNew(cc, new Object[]{p1,p2,p3}); }
    public static Object getNew(Constructor cc, Object p1, Object p2, Object p3, Object p4) { return getNew(cc, new Object[]{p1,p2,p3,p4}); }
    public static Object getNew(Class c) { try { return c.newInstance(); } catch(Exception error) { reportException(error); } return null; }
    public static Object getResult(Method m, Object obj, Object param[]) { try { return m.invoke(obj, param); } catch(Exception error) { reportException(error); } return null; }
    public static Object getResult(Method m) { return getResult(m, null, new Object[]{}); }
    public static Object getResult(Method m, Object obj) { return getResult(m, obj, new Object[]{}); }
    public static Object getResult(Method m, Object obj, Object p1) { return getResult(m, obj, new Object[]{p1}); }
    public static Object getResult(Method m, Object obj, Object p1, Object p2) { return getResult(m, obj, new Object[]{p1,p2}); }
    public static Object getResult(Method m, Object obj, Object p1, Object p2, Object p3) { return getResult(m, obj, new Object[]{p1,p2,p3}); }
    public static Object getResult(Method m, Object obj, Object p1, Object p2, Object p3, Object p4) { return getResult(m, obj, new Object[]{p1,p2,p3,p4}); }
    public static boolean checkClass(Class c) { try { Field field = c.getDeclaredField("zmodmarker"); return field != null; } catch(Exception whatever) { } return false; }

    // ================================================================================================================ util
    private static final int fix(double d) { return (int)Math.floor(d); } // returns correct integer coordinate
    public static void delMsg(String tag) { text.delMsg(tag); }
    public static void setMsg(String msg) { setMsg("debug", msg, 50, 50, 0xffffff); }
    public static void setMsg(String tag, String msg, int x, int y) { setMsg(tag, msg, x, y, 0xffffff); }
    public static void setMsg(String tag, String msg, int x, int y, int color) { text.setMsg(tag, msg, x, y, color); }
    public static boolean keyPress(int key) { boolean res = !keys[key]; return (keys[key] = Keyboard.isKeyDown(key)) && res; }
    public static boolean keyDown(int key) { return Keyboard.isKeyDown(key); }
    private static final float sgn(float f) { return f<0f ? -1f : (f>0f ? 1f : 0f); }
    private static void obliqueNearPlaneClip(float a, float b, float c, float d) {
        float matrix[] = new float[16];
        float x, y, z, w, dot;
        ByteBuffer temp = ByteBuffer.allocateDirect(64);
        temp.order(ByteOrder.nativeOrder());
        GL11.glGetFloat(GL11.GL_PROJECTION_MATRIX, (FloatBuffer)temp.asFloatBuffer());
        (temp.asFloatBuffer()).get(matrix);
        x = (sgn(a) + matrix[8]) / matrix[0];
        y = (sgn(b) + matrix[9]) / matrix[5];
        z = -1.0F;
        w = (1.0F + matrix[10]) / matrix[14];
        dot = a*x + b*y + c*z + d*w;
        matrix[2] = a * (2f / dot);
        matrix[6] = b * (2f / dot);
        matrix[10] = c * (2f / dot) + 1.0F;
        matrix[14] = d * (2f / dot);
        (temp.asFloatBuffer()).put(matrix);
        GL11.glMatrixMode(GL11.GL_PROJECTION);
        GL11.glLoadMatrix((FloatBuffer)temp.asFloatBuffer());
        GL11.glMatrixMode(GL11.GL_MODELVIEW);
    }

    // ================================================================================================================ parser
    private static HashMap pNames;
    private static HashSet<String> pFiles;
    private static HashMap<Integer, Integer> pFuel;
    private static HashMap<Integer, Object> pSmelt;
    private static List pList;

    private static void parse(List list, String file, int section) {
        pList = list;
        pNames = names==null ? new HashMap() : (HashMap)(((HashMap)names).clone());
        pFiles = new HashSet<String>();
        parseFile(file, section);
    }
    
    private static void parseFile(String file, int section) {
        if(!pFiles.add(file)) {
            err("error: recursion detected - \""+file+"\" is already included");
            return;
        }
        String data = "", fn = path + file;
        try {
            byte[] buffer = new byte[(int) new File(fn).length()];
            BufferedInputStream stream = new BufferedInputStream(new FileInputStream(fn));
            stream.read(buffer);
            stream.close();
            data = new String(buffer);
            log("info: parsing \""+file+"\"");
        } catch(Exception error) {
            err("error: failed to load \""+file+"\"", error);
            data = "";
        }
        String lines[] = data.split("\\r?\\n");
        int at;
        for(int line=0;line<lines.length;line++) {
            if(lines[line].startsWith("[IGNORE]")) section = IGNORE;
            else if(lines[line].startsWith("[NAMEMAP]")) section = NAMEMAP;
            else if(lines[line].startsWith("[RECIPES]")) section = RECIPES;
            else if(lines[line].startsWith("[FUEL]")) section = FUEL;
            else if(lines[line].startsWith("[SMELTING]")) section = SMELTING;
            else if(lines[line].startsWith("[NAMEMAP=")) parseFile(lines[line].substring(9).replaceAll("\\].*\\z",""), NAMEMAP);
            else if(lines[line].startsWith("[RECIPES=")) parseFile(lines[line].substring(9).replaceAll("\\].*\\z",""), RECIPES);
            else if(lines[line].startsWith("[FUEL=")) parseFile(lines[line].substring(9).replaceAll("\\].*\\z",""), FUEL);
            else if(lines[line].startsWith("[SMELTING=")) parseFile(lines[line].substring(9).replaceAll("\\].*\\z",""), SMELTING);
            else if(section == NAMEMAP) parseNames(lines[line], file, line + 1);
            else if(section == RECIPES) parseRecipe(lines[line], file, line + 1);
            else if(section == FUEL) parseFuel(lines[line], file, line + 1);
            else if(section == SMELTING) parseSmelting(lines[line], file, line + 1);
        }
    }
    
    public static int parseUnsigned(String str) {
        try {
            return Integer.decode(str);
        } catch(Exception whatever) {
            return -1;
        }
    }
        
    private static int parseIdInfo(String text) {
        try {
            String part[] = text.split("/");
            if(part.length>2) return -1;
            int id = Integer.decode(part[0]);
            if(part.length==2) {
                int info = Integer.decode(part[1]);
                if(info<0) info = 9999;
                id += info << 16;
            }
            return id;
        } catch(Exception error) {
            return -1;
        }
    }
    
    private static void parseFuel(String src, String file, int line) {
        String got[] = src.replaceAll("\\A[\\t ]*","").replaceAll("[\\t ]*(|//.*)\\z","").split("[ \\t]+");
        if(got.length != 2) {
            if(got.length == 1 && !got[0].equals("")) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid fuel definition");
        } else {
            int fuel = ( pNames.containsKey(got[0]) ? (Integer)pNames.get(got[0]) : parseUnsigned(got[0]) ) & 0xffff;
            int time = parseUnsigned(got[1]);
            if(fuel<=0) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid fuel definition (\""+got[0]+"\" is unknown or invalid)");
            else if(time<=0) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid fuel definition (\""+got[1]+"\" is invalid time)");
            else pFuel.put(fuel, time);
        }
    }
    
    private static void parseSmelting(String src, String file, int line) {
        String got[] = src.replaceAll("\\A[\\t ]*","").replaceAll("[\\t ]*(|//.*)\\z","").split("[ \\t]+");
        if(got.length != 2) {
            if(got.length == 1 && !got[0].equals("")) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid smelt definition");
        } else {
            int itemId = pNames.containsKey(got[0]) ? (Integer)pNames.get(got[0]) : parseIdInfo(got[0]);
            int id = ( pNames.containsKey(got[1]) ? (Integer)pNames.get(got[1]) : parseUnsigned(got[1]) ) & 0xffff;
            Object item = itemId>0 ? newItemsE(itemId, 1) : null;
            if(id<=0) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid smelting definition (\""+got[0]+"\" is unknown or invalid)");
            else if(item==null) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid smelting definition (\""+got[1]+"\" is unknown or invalid)");
            else pSmelt.put(id, item);
        }
    }

    private static void parseNames(String src, String file, int line) {
        String got[] = src.replaceAll("\\A[\\t ]*","").replaceAll("[\\t ]*(|//.*)\\z","").split("[ \\t]+");
        if((got.length & 1) != 0) {
            if(got.length != 1 && !got[0].equals("")) err("error: "+file+" @ line#" + line + " \"" + src + "\" - incomplete name definition");
        } else for(int at=0;at<got.length;at+=2) {
            int id = parseIdInfo(got[at+1]);
            if(id==-1) err("error: "+file+" @ line#" + line + " \"" + src + "\" - non numbers in name definition");
            else pNames.put(got[at], id);
        }
    }
    
    // CraftingRecipe   : gv   ? b.add(new gv(?, ?, ?, ?));
    //   .matchRecipe   : a    ? only function there that returns bool and takes one parameter
    private static void addRecipe(int width, int height, gz recipeMap[], int id, int count) {
        boolean normal = height > 0;
        gz search[] = recipeMap; // update
        List list = null;
        if(!normal) {
            search = new gz[9]; // update
            list = new ArrayList();
            for(int i=0;i<recipeMap.length;i++) list.add(search[i] = recipeMap[i]);
            width = height = 3;
        }
        jv match = new jv(null, width, height); // update
        setValue(fCBTable, match, search);
        // find and remove match
        for(int i=0;i<pList.size();i++) if(((cs)pList.get(i)).a(match)) pList.remove(i);   // update: cs - CraftingRecipe's interface
        // add new
        if(id!=0) pList.add( normal
            ? new gv(width, height, recipeMap, newItemsE(id, count))  // update
            : new pp(newItemsE(id, count), list)                      // update
        );
    }

    private static void parseRecipe(String src, String file, int line) {
        String trouble = ""; // parsing trouble - will contain the offending substring
        String got[] = src.replaceAll("\\A[\\t ]*","").replaceAll("[\\t ]*(|//.*)\\z","").split("[ \\t]+");
        if(got.length < 5) {
            if(got.length != 1 && !got[0].equals("")) log("error: "+file+" @ line#" + line + " \"" + src + "\" - incomplete recipe definition");
            return;
        }
        try {
            trouble = got[0];
            int width = Integer.decode(got[2]), height = Integer.decode(got[3]), count = Integer.decode(got[1]);
            int itemnr = pNames.containsKey(got[0]) ? (Integer)pNames.get(got[0]) : parseIdInfo(got[0]);
            if(itemnr<0 || count<0 || (itemnr>0 && count<=0)) {
                err("error: "+file+" @ line#" + line + " \"" + src + "\" - bad recipe result");
                return;
            }
            if(height != 0 && (width*height+4 != got.length || width <= 0 || height <= 0 || width > 3 || height > 3)) {
                err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid recipe size (" + width + "," + height + ")");
                return;
            } else if(height == 0 && (width+4 != got.length || width <= 0)) {
                err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid recipe size (" + width + ")");
                return;
            }
            gz recipeMap[] = new gz[width*(height==0?1:height)]; // UPDATE
            for(int at=4;at<got.length;at++) {
                trouble = got[at];
                int value = pNames.containsKey(got[at]) ? (Integer)pNames.get(got[at]) : parseIdInfo(got[at]);
                if(value == -1 || (height==0 && value==0)) throw new Exception("("+value+" "+got[at]+" "+(pNames.containsKey(got[at])?"+":"-")+")");
                recipeMap[at - 4] = value<=0 ? null : newItemsE(value, 1);
            }
            addRecipe(width, height, recipeMap, itemnr, count);
        } catch(Exception whatever) {
            err("error: "+file+" @ line#" + line + " \"" + src + "\" - \"" + trouble + "\" is unknown or malformed");
            err("???",whatever);
        }
    }

    private static int[] parseRule(String rule) {
        String got[] = rule.split("[\t ]+"), part[];
        int res[] = new int[got.length * 6];
        for(int i=0;i<got.length;i++) {
            part = got[i].split("/");
            if(part.length != 6) { modOreEnabled = false; err("error : ore-mod disabled - invalid ore rule found \""+rule+"\""); continue; }
            res[i*6 + 0] = new Integer(part[0]);
            res[i*6 + 1] = new Integer(part[1]);
            res[i*6 + 2] = new Integer(part[2]);
            res[i*6 + 3] = new Integer(part[3]);
            res[i*6 + 4] = new Integer(part[4]);
            res[i*6 + 5] = new Integer(part[5]);
        }
        return res;
    }

}
