// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.util.List;
import java.util.Random;

// EntityPlayer : fd ? search: "humanoid"
public abstract class fd extends iz {

    protected static final boolean zmodmarker = true;

    // moveEntity   : b   ? search: double d9 = 0\.050000000000000003D; - it is in the function
    // fallDistance : bg  ? search "FallDistance"
    // onGround     : aT  ? search "OnGround"
    // stepCounter  : be  ? search: 59999999999999998D * Entity class: stepCounter += (double)??.?(? * ? + ? + ?)*0.59999999999999998D;
    private static boolean flew = false;
    public void b(double mx, double my, double mz) {
        if(ZMod.modFlyEnabled && this == ZMod.player) {
            float tmp = be;                                 // update
            ZMod.calculate(mx, my, mz);
            if(ZMod.fly) { bg = 0f; aM = 0f; flew = true; } // update
            super.b(ZMod.flyMX, ZMod.flyMY, ZMod.flyMZ);    // update
            if(ZMod.fly) { bg = 0f; aT = true; be = tmp; }  // update
            else if(flew && !aT) { bg = 0f; aT = true; }    // update
            else flew = false;
        } else {
            super.b(mx,my,mz);                              // update
        }
    }


    public fd(dt dt1) {
        super(dt1);
        f = new gy(this);
        i = 0;
        j = 0;
        m = false;
        n = 0;
        d = 0;
        A = null;
        g = new t(f, !dt1.t);
        h = g;
        ba = 1.62F;
        av av1 = dt1.s();
        c((double)av1.a + 0.5D, av1.b + 1, (double)av1.c + 0.5D, 0.0F, 0.0F);
        V = 20;
        O = "humanoid";
        N = 180F;
        br = 20;
        L = "/mob/char.png";
    }

    protected void b() {
        super.b();
        bA.a(16, Byte.valueOf((byte)0));
    }

    public void q_() {
        if(K()) {
            c++;
            if(c > 100)
                c = 100;
            if(!q())
                a(true, true);
            else
            if(!aE.t && aE.e())
                a(false, true);
        } else
        if(c > 0) {
            c++;
            if(c >= 110)
                c = 0;
        }
        super.q_();
        if(!aE.t && h != null && !h.b(this)) {
            p();
            h = g;
        }
        r = u;
        s = v;
        t = w;
        double d1 = aI - u;
        double d2 = aJ - v;
        double d3 = aK - w;
        double d4 = 10D;
        if(d1 > d4)
            r = u = aI;
        if(d3 > d4)
            t = w = aK;
        if(d2 > d4)
            s = v = aJ;
        if(d1 < -d4)
            r = u = aI;
        if(d3 < -d4)
            t = w = aK;
        if(d2 < -d4)
            s = v = aJ;
        u += d1 * 0.25D;
        w += d3 * 0.25D;
        v += d2 * 0.25D;
    }

    protected boolean v() {
        return V <= 0 || K();
    }

    protected void p() {
        h = g;
    }

    public void w() {
        q = (new StringBuilder()).append("http://s3.amazonaws.com/MinecraftCloaks/").append(o).append(".png").toString();
        by = q;
    }

    public void x() {
        super.x();
        k = l;
        l = 0.0F;
    }

    public void y() {
        ba = 1.62F;
        a(0.6F, 1.8F);
        super.y();
        V = 20;
        aa = 0;
    }

    protected void d_() {
        if(m) {
            n++;
            if(n == 8) {
                n = 0;
                m = false;
            }
        } else {
            n = 0;
        }
        U = (float)n / 8F;
    }

    public void m() {
        if(aE.j == 0 && V < 20 && (bq % 20) * 12 == 0)
            c(1);
        f.e();
        k = l;
        super.m();
        float f1 = gq.a(aL * aL + aN * aN);
        float f2 = (float)Math.atan(-aM * 0.20000000298023224D) * 15F;
        if(f1 > 0.1F)
            f1 = 0.1F;
        if(!aT || V <= 0)
            f1 = 0.0F;
        if(aT || V <= 0)
            f2 = 0.0F;
        l += (f1 - l) * 0.4F;
        ad += (f2 - ad) * 0.8F;
        if(V > 0) {
            List list = aE.b(this, aS.b(1.0D, 0.0D, 1.0D));
            if(list != null) {
                for(int i1 = 0; i1 < list.size(); i1++) {
                    om om1 = (om)list.get(i1);
                    if(!om1.aZ)
                        j(om1);
                }

            }
        }
    }

    private void j(om om1) {
        om1.b(this);
    }

    public int z() {
        return j;
    }

    public void b(om om1) {
        super.b(om1);
        a(0.2F, 0.2F);
        c(aI, aJ, aK);
        aM = 0.10000000149011612D;
        if(o.equals("Notch"))
            a(new gz(ex.h, 1), true);
        f.g();
        if(om1 != null) {
            aL = -gq.b(((Z + aO) * 3.141593F) / 180F) * 0.1F;
            aN = -gq.a(((Z + aO) * 3.141593F) / 180F) * 0.1F;
        } else {
            aL = aN = 0.0D;
        }
        ba = 0.1F;
    }

    public void c(om om1, int i1) {
        j += i1;
    }

    public void A() {
        a(f.a(f.c, 1), false);
    }

    public void a(gz gz1) {
        a(gz1, false);
    }

    public void a(gz gz1, boolean flag) {
        if(gz1 == null)
            return;
        fs fs1 = new fs(aE, aI, (aJ - 0.30000001192092896D) + (double)B(), aK, gz1);
        fs1.c = 40;
        float f1 = 0.1F;
        if(flag) {
            float f3 = bp.nextFloat() * 0.5F;
            float f5 = bp.nextFloat() * 3.141593F * 2.0F;
            fs1.aL = -gq.a(f5) * f3;
            fs1.aN = gq.b(f5) * f3;
            fs1.aM = 0.20000000298023224D;
        } else {
            float f2 = 0.3F;
            fs1.aL = -gq.a((aO / 180F) * 3.141593F) * gq.b((aP / 180F) * 3.141593F) * f2;
            fs1.aN = gq.b((aO / 180F) * 3.141593F) * gq.b((aP / 180F) * 3.141593F) * f2;
            fs1.aM = -gq.a((aP / 180F) * 3.141593F) * f2 + 0.1F;
            f2 = 0.02F;
            float f4 = bp.nextFloat() * 3.141593F * 2.0F;
            f2 *= bp.nextFloat();
            fs1.aL += Math.cos(f4) * (double)f2;
            fs1.aM += (bp.nextFloat() - bp.nextFloat()) * 0.1F;
            fs1.aN += Math.sin(f4) * (double)f2;
        }
        a(fs1);
    }

    protected void a(fs fs1) {
        aE.a(fs1);
    }

    public float a(qk qk1) {
        float f1 = f.a(qk1);
        if(a(iu.f))
            f1 /= 5F;
        if(!aT)
            f1 /= 5F;
        return f1;
    }

    public boolean b(qk qk1) {
        return f.b(qk1);
    }

    public void b(ks ks1) {
        super.b(ks1);
        oo oo1 = ks1.l("Inventory");
        f.b(oo1);
        p = ks1.e("Dimension");
        a = ks1.m("Sleeping");
        c = ks1.d("SleepTimer");
        if(a) {
            b = new av(gq.b(aI), gq.b(aJ), gq.b(aK));
            a(true, true);
        }
    }

    public void a(ks ks1) {
        super.a(ks1);
        ks1.a("Inventory", f.a(new oo()));
        ks1.a("Dimension", p);
        ks1.a("Sleeping", a);
        ks1.a("SleepTimer", (short)c);
    }

    public void a(jc jc) {
    }

    public void a(int i1, int j1, int k1) {
    }

    public void b(om om1, int i1) {
    }

    public float B() {
        return 0.12F;
    }

    protected void C() {
        ba = 1.62F;
    }

    public boolean a(om om1, int i1) {
        as = 0;
        if(V <= 0)
            return false;
        if(K())
            a(true, true);
        if((om1 instanceof fi) || (om1 instanceof ok)) {
            if(aE.j == 0)
                i1 = 0;
            if(aE.j == 1)
                i1 = i1 / 3 + 1;
            if(aE.j == 3)
                i1 = (i1 * 3) / 2;
        }
        if(i1 == 0)
            return false;
        else
            return super.a(om1, i1);
    }

    protected void b(int i1) {
        int j1 = 25 - f.f();
        int k1 = i1 * j1 + d;
        f.e(i1);
        i1 = k1 / 25;
        d = k1 % 25;
        super.b(i1);
    }

    public void a(oj oj) {
    }

    public void a(ak ak) {
    }

    public void a(ti ti) {
    }

    public void c(om om1) {
        if(om1.a(this))
            return;
        gz gz1 = D();
        if(gz1 != null && (om1 instanceof iz)) {
            gz1.b((iz)om1);
            if(gz1.a <= 0) {
                gz1.a(this);
                E();
            }
        }
    }

    public gz D() {
        return f.b();
    }

    public void E() {
        f.a(f.c, null);
    }

    public double F() {
        return (double)(ba - 0.5F);
    }

    public void G() {
        n = -1;
        m = true;
    }

    public void d(om om1) {
        int i1 = f.a(om1);
        if(i1 > 0) {
            om1.a(this, i1);
            gz gz1 = D();
            if(gz1 != null && (om1 instanceof iz)) {
                gz1.a((iz)om1);
                if(gz1.a <= 0) {
                    gz1.a(this);
                    E();
                }
            }
        }
    }

    public void t() {
    }

    public abstract void u();

    public void b(gz gz1) {
    }

    public void H() {
        super.H();
        g.a(this);
        if(h != null)
            h.a(this);
    }

    public boolean I() {
        return !a && super.I();
    }

    public boolean b(int i1, int j1, int k1) {
        if(K() || !R())
            return false;
        if(aE.m.c)
            return false;
        if(aE.e())
            return false;
        if(Math.abs(aI - (double)i1) > 3D || Math.abs(aJ - (double)j1) > 2D || Math.abs(aK - (double)k1) > 3D)
            return false;
        a(0.2F, 0.2F);
        ba = 0.2F;
        if(aE.h(i1, j1, k1)) {
            int l1 = aE.e(i1, j1, k1);
            int i2 = qt.c(l1);
            float f1 = 0.5F;
            float f2 = 0.5F;
            switch(i2) {
            case 0: // '\0'
                f2 = 0.9F;
                break;

            case 2: // '\002'
                f2 = 0.1F;
                break;

            case 1: // '\001'
                f1 = 0.1F;
                break;

            case 3: // '\003'
                f1 = 0.9F;
                break;
            }
            e(i2);
            c((float)i1 + f1, (float)j1 + 0.9375F, (float)k1 + f2);
        } else {
            c((float)i1 + 0.5F, (float)j1 + 0.9375F, (float)k1 + 0.5F);
        }
        a = true;
        c = 0;
        b = new av(i1, j1, k1);
        aL = aN = aM = 0.0D;
        if(!aE.t)
            aE.w();
        return true;
    }

    private void e(int i1) {
        x = 0.0F;
        z = 0.0F;
        switch(i1) {
        case 0: // '\0'
            z = -1.8F;
            break;

        case 2: // '\002'
            z = 1.8F;
            break;

        case 1: // '\001'
            x = 1.8F;
            break;

        case 3: // '\003'
            x = -1.8F;
            break;
        }
    }

    public void a(boolean flag, boolean flag1) {
        a(0.6F, 1.8F);
        C();
        av av1 = b;
        if(av1 != null && aE.a(av1.a, av1.b, av1.c) == qk.S.bk) {
            qt.a(aE, av1.a, av1.b, av1.c, false);
            av av2 = qt.g(aE, av1.a, av1.b, av1.c, 0);
            c((float)av2.a + 0.5F, (float)av2.b + ba + 0.1F, (float)av2.c + 0.5F);
        }
        a = false;
        if(!aE.t && flag1)
            aE.w();
        if(flag)
            c = 0;
        else
            c = 100;
    }

    private boolean q() {
        return aE.a(b.a, b.b, b.c) == qk.S.bk;
    }

    public float J() {
        if(b != null) {
            int i1 = aE.e(b.a, b.b, b.c);
            int j1 = qt.c(i1);
            switch(j1) {
            case 0: // '\0'
                return 90F;

            case 1: // '\001'
                return 0.0F;

            case 2: // '\002'
                return 270F;

            case 3: // '\003'
                return 180F;
            }
        }
        return 0.0F;
    }

    public boolean K() {
        return a;
    }

    public boolean L() {
        return a && c >= 100;
    }

    public int M() {
        return c;
    }

    public void b(String s1) {
    }

    public gy f;
    public ct g, h;
    public byte i;
    public int j, n, p;
    public float k, l, x, y, z;
    public boolean m;
    public String o, q;
    public double r, s, t, u, v;
    public double w;
    private boolean a;
    private av b;
    private int c, d;
    public jd A;
}
