
Zombe's modpack for minecraft.

=========================================================== Mods ==========================================================

* fly     - Enables flying.
            Supported game modes: Singleplayer and Multiplayer
* recipe  - Enables user customizable crafting recipes.
            Supported game modes: Singleplayer
* cart    - Allows you to drive the minecart using your regular moving keys.
            Supported game modes: Singleplayer
* wield   - Provides a "panic" button. If pressed - a bow or sword is wielded (depending on
            your preference and what you have available). If you have both bow and sword then
            pressing the wield key again will swap between them. Bow is not an option if
            you do not have any arrows.
            Supported game modes: Singleplayer and Multiplayer
* compass - Adds an alternate spawnpoint you can use with compass (Current spawnpoint is also
            saved in singleplayer - allowing thereby to move your spawpoint).
            Supported game modes: Singleplayer and Multiplayer
* build   - Infinite supply of whatever blocks do you have in inventory. Fast destruction of
            blocks without needing tools. Easy access to other blocks by mouse wheel.
* cloud   - Can change cloud level or turn them off.
            Supported game modes: Singleplayer and Multiplayer
* sun     - Can change time or even stop it.
            Supported game modes: Singleplayer and Multiplayer
* path    - Shows a onscreen path you have taken.
            Supported game modes: Singleplayer and Multiplayer
* spawn   - Disable spawning on various surfaces and reduce some spawns.
            Supported game modes: Singleplayer
* safe    - Marks the spots that do not have enough non-sun light to prevent spawning.
            Supported game modes: Singleplayer and Multiplayer
* craft   - Crafts as many times as prossible with only one click.
            Supported game modes: Singleplayer and Multiplayer
* boom    - Alter explosion behaviour. Remove creeper damage near man-made objects, prevent
            explosions from destroying ores, alter tnt and creeper explosion force.
            Supported game modes: Singleplayer
* ore     - Redistribute all ores by customizable rules. Works even in already explored parts
            of map - easy way to add the new ores to old worlds.
            Supported game modes: Singleplayer
* teleport- Added functionality to user defined blocks to enable teleportation of player,
            critters and items. Teleportation can also be limited to only work for a specific
            critter or item type.
            Supported game modes: Singleplayer
* cheat   - A few helpers for tough times or just useful things in conjunction with other mods
            (ore redistribution mod / creative building / etc).
            Supported game modes: Singleplayer
* resize  - Varies the sizes and health of various critters and mobs.
            Supported game modes: Singleplayer
* furnace - Alter furnace functionality and change fuels / smelting recipes.
            Supported game modes: Singleplayer
* dig     - Alter digging speed
            Supported game modes: Singleplayer

====================================================== Installation =======================================================

* SHUT DOWN THE MINECRAFT GAME - Failure to do this will prevent changes to the minecraft.jar file.
* Find minecraft.jar and open it (WinRar or similar).
* Delete the META-INF folder, if you have not deleted it already.
* Add all the files in the "classes" folder to the minecraft.jar file (overwriting what was there before).
  Look in the "Compatibility" section in this file for further details on which files you can omit.
  NB! TooManyItems and fly-mod are compatible - read the compatibility section of TooManyItems thread.
  NB! ModLoader and furnace-mod are compatible - install this mod after ModLoader.
* Add all the files in the "config" folder to ".minecraft/mods/zombe" folder (if the folder does not exist then create it).
* Open config.txt in ".minecraft/mods/zombe" folder and enable the mods you want (all mods are disabled by default).
  For example: to enable the flying mod you need to delete the "#" from the "#modFlyEnabled = yes" line in config.txt.

NB! If you have used my mods before then it is strongly recommended that you delete all the old files
    from ".minecraft/mods/zombe". Also, delete the zmod-log.txt file in ".minecraft/mods" folder to prevent confusion.
    
NB! If in trouble - the log file is ".minecraft/mods/zombe/log.txt". The contents of it might help you solve the problem.

===================================================== Compatibility =======================================================
Not all of the files are mandatory. You can omit the listed files if you do not want to use the named mod.
* "fly" mod needs: fd.class
* "craft" mod needs: gg.class
* "sun" mod needs: sd.class
* "boom" mod needs: na.class
* "resize" mod needs: ff.class
* "furnace" mod needs: oj.class
* "dig" mod needs: lk.class

========================================================== Notes ==========================================================

Default keybindings assume the following keybinds (recommended):
* walk forward  = W
* walk back     = S
* strafe left   = A
* strafe right  = D
* inventory     = TAB
* crouch        = CTRL
* drop item     = T
* draw distance = G
* chat          = C

Look in config.txt for complete list of current settings.

### fly-mod ### aka - Flying
* ascend  = E
* descend = Q
* speed   = LSHIFT

### recipe-mod ### aka - Custom Crafting Recipies
Recipes are defined in "mods/zombe/recipes.txt" - further instructions are in there.

Additional info for advanced users: [NAMEMAP], [RECIPES] and [IGNORE] tags tell how minecraft should interpret the lines that
follow - until told otherwise by another tag. [NAMEMAP] is for defining names for blocks and items. [RECIPES] is for defining
crafting recipes. [IGNORE] is for disabling large sections of definitions. All tags may be present multiple times in any order.
However, you can use only thous names in recipes that you have define earlier in the file.

Tags that include a file do not begin a section themselves - section start counts only for the file it includes.

### cart ### aka - Cart Control
* use your regular movement keys to move
* toggle perpetual movement mode = UP

### wield ### aka - Wield Key
wield = R

### compass ### aka - Compass
set home = INSERT
change home (switches between original and alternate home) = HOME

### build ### aka - Classic Building
enable build mode = B
Item sets  1- 9   = LSHIFT   + number
Item sets 10-19   = LCONTROL + number
Set selection marker = X
Copy selection to buffer = C
Copy buffer to selection = P
Fill selection with current item = Z

P & Z key functionality can also be altered with:
  LSHIFT - replace only empty space.
  RSHIFT - remove from selection blocks that match with source block (block in buffer [P] or current item [Z]).
  
X key functionality can be altered with:
  LCONTROL - marker will be set on feet level instead of head level.

NB! World editing is disabled by default to prevent accidental damage.
NB! There is no undo! Make backups!

Example 1 : remove all water from area
* set two markers to denote the area (selected area is shown as red transparent block with blue borders).
* select water block in inventory (4th item in A5 itemset [LSHIFT+5] - if you do not have that item already).
* hold down RSHIFT and press Z.

Example 2 : fill area with cobblestone
* set two markers to denote the area (selected area is shown as red transparent block with blue borders).
* select water block in inventory (2th item in A1 itemset [LSHIFT+1] - if you do not have that item already).
* press Z.

Example 3 : delete all blocks from area
* set two markers to denote the area (selected area is shown as red transparent block with blue borders).
* select nothing (barehanded).
* press Z.

Example 4 : copy stuff around (one to many. adding - not replaceing)
* set two markers to denote the area you want to copy (selected area is shown as red transparent block with blue borders).
* press C.
* set two markers to denote the area you want to copy to (select much bigger area than source area was).
* press P (if area was not the right size then it will be resized automatically and you have to press P again).

NB! if you have only set one marker then P will add the other marker itself (press P again to confirm).

### cloud ### aka - Cloud Control
show/hide clouds = MULTIPLY

### path ### aka - Path Tracker
show/hide path = BACKSPACE
delete path    = DELETE

### sun ### aka - Sun Control
add time           = ADD
subtract time      = SUBTRACT
stop sun           = END
resume normal time = EQUALS

### safe ### aka - Critter Spawn Highlighter
show/hide unsafe spots = L

### craft ### aka - Craft All Key
hold left shift while crafting to craft all with one click

### boom ### aka - Damage Control

### ore ### aka - Ore Redistribution
Default redistribution rules makes the ground much more rich of ore and a lava rich layer
is added near bedrock by removing the stray blocks of bedrock found there. While the mod
alters the savegame - the savegame stays completely independent of the mod. You do not need
to explore new areas - the mod will immediately take effect in any place where ever you are.

### teleport ### aka - Teleportation
Default blocks for teleportation are:
* Gold = Player
* Iron = Items
* Diamond = Critters
If player/item/critter gets above it and there is also a sign (either on stick or on wall
directly above the block [2 meter range]) the subject will be teleported, if the sign allows,
to where the sign tells to.

Teleportation target is written as "!x,y,z" (Use my compass mod or some other means to get
the coordinates) - it must be on a separate line.
Example: "!0,65,0"

Teleportation filter, if you wish to filter, is written as "?item-or-mob-name".
Example: "?bone" or "?skelly"

### cheat ### aka - Cheat
Toggle cheat mode on / off    = Y
Show / hide monsters          = M
Show / hide ores              = O
See through everything nearby = I

### resize ### aka - Critter size variety
Beware or tiny spiders.

### furnace ### aka - Custom Smelting Recipes
Default setting are identical to vanilla game. Settings with instructions are in fuel.txt,
smelting.txt and config.txt.

### dig ### aka - Digging Speed Adjustment
By default - doubles digging speed.
