// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb safe 
// Source File Name:   SourceFile

import net.minecraft.client.Minecraft;

// search: = -180F * the one without "false" in constructor (most likely the first matching)
// NEED TO DECOMPILE SEPARATELY WITH SAFE MODE ON
public class nu extends nf {

    protected static final boolean zmodmarker = true;

    public nu(Minecraft minecraft) {
        super(minecraft);
        c = -1;
        d = -1;
        e = -1;
        f = 0.0F;
        g = 0.0F;
        h = 0.0F;
        i = 0;
    }

    public void a(gh gh1) {
        gh1.aQ = -180F;
    }

    public boolean b(int j, int k, int l, int i1) {
        int j1 = a.e.a(j, k, l);
        int k1 = a.e.e(j, k, l);
        boolean flag = super.b(j, k, l, i1);
        ii ii1 = a.g.H();
        boolean flag1 = a.g.b(to.m[j1]);
        // -----------------------------------------------------------------------------------------------------------------------
        flag1 = ZMod.harvestableHandle(flag1);
        // -----------------------------------------------------------------------------------------------------------------------
        if(ii1 != null) {
            ii1.a(j1, j, k, l, ((gh) (a.g)));
            if(ii1.a == 0) {
                ii1.a(((gh) (a.g)));
                a.g.I();
            }
        }
        if(flag && flag1)
            to.m[j1].a(a.e, ((gh) (a.g)), j, k, l, k1);
        return flag;
    }

    public void a(int j, int k, int l, int i1) {
        int j1 = a.e.a(j, k, l);
        if(j1 > 0 && f == 0.0F)
            to.m[j1].b(a.e, j, k, l, ((gh) (a.g)));
        if(j1 > 0 && to.m[j1].a(((gh) (a.g))) >= 1.0F)
            b(j, k, l, i1);
    }

    public void a() {
        f = 0.0F;
        i = 0;
    }

    public void c(int j, int k, int l, int i1) {
        if(i > 0) {
            i--;
            return;
        }
        if(j == c && k == d && l == e) {
            int j1 = a.e.a(j, k, l);
            if(j1 == 0)
                return;
            to to1 = to.m[j1];
            // -------------------------------------------------------------------------------------------------------------------
            float add;
            f += add = ZMod.digProgressHandle( to1.a(((gh) (a.g))), j1 );
            int skip = add > 1.0f ? (int)(6f / add - 0.99999f) : 5;
            // -------------------------------------------------------------------------------------------------------------------
            if(h % 4F == 0.0F && to1 != null)
                a.A.b(to1.bw.d(), (float)j + 0.5F, (float)k + 0.5F, (float)l + 0.5F, (to1.bw.b() + 1.0F) / 8F, to1.bw.c() * 0.5F);
            h++;
            if(f >= 1.0F) {
                b(j, k, l, i1);
                f = 0.0F;
                g = 0.0F;
                h = 0.0F;
                i = skip; // ****** UPDATE ******
            }
        } else {
            f = 0.0F;
            g = 0.0F;
            h = 0.0F;
            c = j;
            d = k;
            e = l;
        }
    }

    public void a(float f1) {
        if(f <= 0.0F) {
            a.u.b = 0.0F;
            a.f.i = 0.0F;
        } else {
            float f2 = g + (f - g) * f1;
            a.u.b = f2;
            a.f.i = f2;
        }
    }

    public float b() {
        return 4F;
    }

    public void a(et et1) {
        super.a(et1);
    }

    public void c() {
        g = f;
        a.A.c();
    }

    private int c, d, e, i;
    private float f, g, h;
}
