// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.awt.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MinecraftApplet;

// MinecraftImpl ? search: "Center"
public class p extends Minecraft {

    public p(MinecraftApplet minecraftapplet, Component component, Canvas canvas, MinecraftApplet minecraftapplet1, int i, int j, boolean flag) {
        super(component, canvas, minecraftapplet1, i, j, flag);
        a = minecraftapplet;
        ZMod.initialize(this); // initialization
    }

    public void a(lk lk) {
        a.removeAll();
        a.setLayout(new BorderLayout());
        a.add(new bu(lk), "Center");
        a.validate();
    }

    // xxxfunc : a ? search: "/font/default.png" * function contains it
    public void a() {
        super.a();
        ZMod.initOverrides();
    }

    // called before "Pre render" just before continue command
    public void j() {
        ZMod.pingUpdateHandle();
        super.j();
    }

    final MinecraftApplet a;
}
