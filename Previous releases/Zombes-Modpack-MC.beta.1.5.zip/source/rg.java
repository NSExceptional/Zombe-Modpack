// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.lang.reflect.*;

// search: "BurnTime"
public class rg extends nx implements la {

    protected static final boolean zmodmarker = true;

    public rg() {
        h = new ii[3];
        a = 0;
        b = 0;
        c = 0;
    }

    public int a() {
        return h.length;
    }

    public ii d_(int j) {
        return h[j];
    }

    public ii a(int j, int k) {
        if(h[j] != null) {
            if(h[j].a <= k) {
                ii ii1 = h[j];
                h[j] = null;
                return ii1;
            }
            ii ii2 = h[j].a(k);
            if(h[j].a == 0)
                h[j] = null;
            return ii2;
        } else {
            return null;
        }
    }

    public void a(int j, ii ii1) {
        h[j] = ii1;
        if(ii1 != null && ii1.a > d())
            ii1.a = d();
    }

    public String c() {
        return "Furnace";
    }

    public void a(my my1) {
        super.a(my1);
        rl rl1 = my1.l("Items");
        h = new ii[a()];
        for(int j = 0; j < rl1.c(); j++) {
            my my2 = (my)rl1.a(j);
            byte byte0 = my2.c("Slot");
            if(byte0 >= 0 && byte0 < h.length)
                h[byte0] = new ii(my2);
        }

        a = my1.d("BurnTime");
        c = my1.d("CookTime");
        b = a(h[1]);
    }

    public void b(my my1) {
        super.b(my1);
        my1.a("BurnTime", (short)a);
        my1.a("CookTime", (short)c);
        rl rl1 = new rl();
        for(int j = 0; j < h.length; j++)
            if(h[j] != null) {
                my my2 = new my();
                my2.a("Slot", (byte)j);
                h[j].a(my2);
                rl1.a(my2);
            }

        my1.a("Items", rl1);
    }

    public int d() {
        return 64;
    }

    public int b(int j) {
        // -----------------------------------------------------------------------------------------------------------------------
        return (c * j) / ZMod.furnaceSmeltTimeHandle();
        // -----------------------------------------------------------------------------------------------------------------------
    }

    public int c(int j) {
        // -----------------------------------------------------------------------------------------------------------------------
        if(b == 0) b = ZMod.furnaceSmeltTimeHandle();
        // -----------------------------------------------------------------------------------------------------------------------
        return (a * j) / b;
    }

    public boolean b() {
        return a > 0;
    }

    public void m_() {
        boolean flag = a > 0;
        boolean flag1 = false;
        // -----------------------------------------------------------------------------------------------------------------------
        if(a>0 && ZMod.furnaceUseFuelHandle(  a, i()  )) a--;
        // -----------------------------------------------------------------------------------------------------------------------
        if(!d.v) {
            if(a == 0 && i()) {
                b = a = a(h[1]);
                if(a > 0) {
                    flag1 = true;
                    if(h[1] != null) {
                        h[1].a--;
                        if(h[1].a == 0)
                            h[1] = null;
                    }
                }
            }
            if(b() && i()) {
                c++;
                // ---------------------------------------------------------------------------------------------------------------
                if(c >= ZMod.furnaceSmeltTimeHandle()) { // update == to >=
                // ---------------------------------------------------------------------------------------------------------------
                    c = 0;
                    g();
                    flag1 = true;
                }
            // -------------------------------------------------------------------------------------------------------------------
            } else if(ZMod.furnaceWasteHandle()) {
            // -------------------------------------------------------------------------------------------------------------------
                c = 0;
            }
            // -------------------------------------------------------------------------------------------------------------------
            if(flag != (a > 0) || ZMod.furnaceWorldUpdateHandle(a, e, f, g)) {
            // -------------------------------------------------------------------------------------------------------------------
                flag1 = true;
                ry.a(a > 0, d, e, f, g);
            }
        }
        if(flag1)
            y_();
    }

    private boolean i() {
        if(h[0] == null)
            return false;
        // -----------------------------------------------------------------------------------------------------------------------
        ii ii1 = (ii)ZMod.furnaceSmeltingHandle(  h[0].a().bd  );
        if(ii1 == null) ii1 = eo.a().a(h[0].a().bd);
        // -----------------------------------------------------------------------------------------------------------------------
        if(ii1 == null)
            return false;
        if(h[2] == null)
            return true;
        if(!h[2].a(ii1))
            return false;
        if(h[2].a < d() && h[2].a < h[2].c())
            return true;
        return h[2].a < ii1.c();
    }

    public void g() {
        if(!i())
            return;
        // -----------------------------------------------------------------------------------------------------------------------
        ii ii1 = (ii)ZMod.furnaceSmeltingHandle(  h[0].a().bd  );
        if(ii1 == null) ii1 = eo.a().a(h[0].a().bd);
        // -----------------------------------------------------------------------------------------------------------------------
        if(h[2] == null)
            h[2] = ii1.k();
        else
        if(h[2].c == ii1.c)
            h[2].a++;
        h[0].a--;
        if(h[0].a <= 0)
            h[0] = null;
    }

    // ===========================================================================================================================
    private static boolean mlInit = false;
    private static Class mlClass;
    private static Method mlMethod;

    private int a(ii ii1) {
        if(ii1 == null)
            return 0;
        int j = ii1.a().bd;
        int fuel = ZMod.furnaceFuelHandle(  j  ); if(fuel!=0) return fuel; // update: j
        if(j < 256 && to.m[j].by == kr.c) return ZMod.furnaceWoodFuelHandle();
        if(j == gb.B.bd)
            return 100;
        if(j == gb.k.bd)
            return 1600;
        if(j == gb.aw.bd)
            return 20000;
        if(j == to.y.bl) return 100;
        try {
            if(!mlInit) {
                mlInit = true;
                mlClass = Class.forName("ModLoader");
                mlMethod = mlClass.getDeclaredMethod("AddAllFuel", new Class[]{ Integer.TYPE });
            }
            if(mlMethod != null) return (Integer)(mlMethod.invoke(null, new Object[]{ j })); // update: j
        } catch(Exception whatever) { }
        return 0;
    }
    // ===========================================================================================================================

    public boolean a_(gh gh1) {
        if(d.b(e, f, g) != this)
            return false;
        return gh1.e((double)e + 0.5D, (double)f + 0.5D, (double)g + 0.5D) <= 64D;
    }

    private ii h[];
    public int a, b, c;
}
