// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.lang.reflect.*;

// search: "BurnTime"
public class oy extends ma implements jp {

    protected static final boolean zmodmarker = true;

    public oy() {
        h = new hi[3];
        a = 0;
        b = 0;
        c = 0;
    }

    public int a() {
        return h.length;
    }

    public hi c_(int j) {
        return h[j];
    }

    public hi a(int j, int k) {
        if(h[j] != null) {
            if(h[j].a <= k) {
                hi hi1 = h[j];
                h[j] = null;
                return hi1;
            }
            hi hi2 = h[j].a(k);
            if(h[j].a == 0)
                h[j] = null;
            return hi2;
        } else {
            return null;
        }
    }

    public void a(int j, hi hi1) {
        h[j] = hi1;
        if(hi1 != null && hi1.a > d())
            hi1.a = d();
    }

    public String c() {
        return "Furnace";
    }

    public void a(lg lg1) {
        super.a(lg1);
        pd pd1 = lg1.l("Items");
        h = new hi[a()];
        for(int j = 0; j < pd1.c(); j++) {
            lg lg2 = (lg)pd1.a(j);
            byte byte0 = lg2.c("Slot");
            if(byte0 >= 0 && byte0 < h.length)
                h[byte0] = new hi(lg2);
        }

        a = lg1.d("BurnTime");
        c = lg1.d("CookTime");
        b = a(h[1]);
    }

    public void b(lg lg1) {
        super.b(lg1);
        lg1.a("BurnTime", (short)a);
        lg1.a("CookTime", (short)c);
        pd pd1 = new pd();
        for(int j = 0; j < h.length; j++)
            if(h[j] != null) {
                lg lg2 = new lg();
                lg2.a("Slot", (byte)j);
                h[j].a(lg2);
                pd1.a(lg2);
            }

        lg1.a("Items", pd1);
    }

    public int d() {
        return 64;
    }

    public int b(int j) {
        // -----------------------------------------------------------------------------------------------------------------------
        int time = ZMod.isMultiplayer || !ZMod.modFurnaceEnabled ? 200 : ZMod.optFurnaceSmeltingTime;
        return (c * j) / time;
        // -----------------------------------------------------------------------------------------------------------------------
    }

    public int c(int j) {
        if(b == 0)
            b = 200;               // FIXME: hm ... what is this?
        return (a * j) / b;
    }

    public boolean b() {
        return a > 0;
    }

    public void n_() {
        boolean flag = a > 0;
        boolean flag1 = false;
        // -----------------------------------------------------------------------------------------------------------------------
        if(a>0 && (ZMod.isMultiplayer || !ZMod.modFurnaceEnabled || (ZMod.optFurnaceInfiniteFuel > a && (ZMod.optFurnaceFuelWaste || i())))) a--;
        // -----------------------------------------------------------------------------------------------------------------------
        if(!d.t) {
            if(a == 0 && i()) {
                b = a = a(h[1]);
                if(a > 0) {
                    flag1 = true;
                    if(h[1] != null) {
                        h[1].a--;
                        if(h[1].a == 0)
                            h[1] = null;
                    }
                }
            }
            if(b() && i()) {
                c++;
                // ---------------------------------------------------------------------------------------------------------------
                int done = ZMod.isMultiplayer || !ZMod.modFurnaceEnabled ? 200 : ZMod.optFurnaceSmeltingTime;
                if(c >= done) { // update == to >=
                // ---------------------------------------------------------------------------------------------------------------
                    c = 0;
                    g();
                    flag1 = true;
                }
            // -------------------------------------------------------------------------------------------------------------------
            } else if(ZMod.isMultiplayer || !ZMod.modFurnaceEnabled || ZMod.optFurnaceFuelWaste) {
            // -------------------------------------------------------------------------------------------------------------------
                c = 0;
            }
            if(flag != (a > 0)) {
                flag1 = true;
                po.a(a > 0, d, e, f, g);
            }
        }
        if(flag1)
            y_();
    }

    private boolean i() {
        if(h[0] == null) return false;
        // -----------------------------------------------------------------------------------------------------------------------
        hi hi1 = null;
        if(ZMod.modFurnaceEnabled && !ZMod.isMultiplayer && ZMod.furnaceSmelting!=null) hi1 = (hi)(ZMod.furnaceSmelting.get(Integer.valueOf(   h[0].a().bd   )));
        if(hi1 == null) hi1 = dx.a().a(h[0].a().bd);
        // -----------------------------------------------------------------------------------------------------------------------
        if(hi1 == null) return false;
        if(h[2] == null) return true;
        if(!h[2].a(hi1)) return false;
        if(h[2].a < d() && h[2].a < h[2].c()) return true;
        return h[2].a < hi1.c();
    }

    public void g() {
        if(!i()) return;
        // -----------------------------------------------------------------------------------------------------------------------
        hi hi1 = null;
        if(ZMod.modFurnaceEnabled && !ZMod.isMultiplayer && ZMod.furnaceSmelting!=null) hi1 = (hi)(ZMod.furnaceSmelting.get(Integer.valueOf(   h[0].a().bd   )));
        if(hi1 == null) hi1 = dx.a().a(h[0].a().bd);
        // -----------------------------------------------------------------------------------------------------------------------
        if(h[2] == null) h[2] = hi1.k();
        else if(h[2].c == hi1.c) h[2].a++;
        h[0].a--;
        if(h[0].a <= 0) h[0] = null;
    }

    // ===========================================================================================================================
    private static boolean mlInit = false;
    private static Class mlClass;
    private static Method mlMethod;

    private int a(hi hi1) {
        if(hi1 == null) return 0;
        int j = hi1.a().bd;
        if(!ZMod.isMultiplayer && ZMod.modFurnaceEnabled && ZMod.furnaceFuel!=null && ZMod.furnaceFuel.containsKey(Integer.valueOf(  j  ))) return ZMod.furnaceFuel.get(Integer.valueOf(  j  )); // update: j
        if(j < 256 && ra.m[j].bw == jh.c) return !ZMod.isMultiplayer && ZMod.modFurnaceEnabled ? ZMod.optFurnaceWoodFuel : 300;
        if(j == fg.B.bd) return 100;
        if(j == fg.k.bd) return 1600;
        if(j == fg.aw.bd) return 20000;
        try {
            if(!mlInit) {
                mlInit = true;
                mlClass = Class.forName("ModLoader");
                mlMethod = mlClass.getDeclaredMethod("AddAllFuel", new Class[]{ Integer.TYPE });
            }
            if(mlMethod != null) return (Integer)(mlMethod.invoke(null, new Object[]{ j })); // update: j
        } catch(Exception whatever) { }
        return 0;
    }
    // ===========================================================================================================================

    public boolean a_(fm fm1) {
        if(d.b(e, f, g) != this)
            return false;
        return fm1.e((double)e + 0.5D, (double)f + 0.5D, (double)g + 0.5D) <= 64D;
    }

    private hi h[];
    public int a, b, c;
}
