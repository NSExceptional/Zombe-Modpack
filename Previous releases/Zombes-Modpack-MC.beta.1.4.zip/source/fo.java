// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;

// search: "deadmau5" * the one with simpler IF
public class fo extends be {

    protected static final boolean zmodmarker = true;

    public fo(in in1, float f1) {
        e = in1;
        c = f1;
    }

    public void a(in in1) {
        f = in1;
    }

    public void a(jm jm1, double d1, double d2, double d3, 
            float f1, float f2) {
        GL11.glPushMatrix();
        GL11.glDisable(2884);
        e.m = d(jm1, f2);
        e.n = jm1.ag();
        if(f != null)
            f.n = e.n;
        try {
            float f3 = jm1.F + (jm1.E - jm1.F) * f2;
            float f4 = jm1.aR + (jm1.aP - jm1.aR) * f2;
            float f5 = jm1.aS + (jm1.aQ - jm1.aS) * f2;
            b(jm1, d1, d2, d3);
            float f6 = c(jm1, f2);
            a(jm1, f6, f3, f2);
            float f7 = 0.0625F;
            GL11.glEnable(32826);
            GL11.glScalef(-1F, -1F, 1.0F);
            a(jm1, f2);
            GL11.glTranslatef(0.0F, -24F * f7 - 0.0078125F, 0.0F);
            float f8 = jm1.ah + (jm1.ai - jm1.ah) * f2;
            float f9 = jm1.aj - jm1.ai * (1.0F - f2);
            if(f8 > 1.0F)
                f8 = 1.0F;
            a(jm1.bx, jm1.r_());
            GL11.glEnable(3008);
            e.a(jm1, f9, f8, f2);
            e.a(f9, f8, f6, f4 - f3, f5, f7);
            for(int i = 0; i < 4; i++)
                if(a(jm1, i, f2)) {
                    f.a(f9, f8, f6, f4 - f3, f5, f7);
                    GL11.glDisable(3042);
                    GL11.glEnable(3008);
                }

            b(jm1, f2);
            float f10 = jm1.a(f2);
            int j = a(jm1, f10, f2);
            if((j >> 24 & 0xff) > 0 || jm1.X > 0 || jm1.aa > 0) {
                GL11.glDisable(3553);
                GL11.glDisable(3008);
                GL11.glEnable(3042);
                GL11.glBlendFunc(770, 771);
                GL11.glDepthFunc(514);
                if(jm1.X > 0 || jm1.aa > 0) {
                    GL11.glColor4f(f10, 0.0F, 0.0F, 0.4F);
                    e.a(f9, f8, f6, f4 - f3, f5, f7);
                    for(int k = 0; k < 4; k++)
                        if(a(jm1, k, f2)) {
                            GL11.glColor4f(f10, 0.0F, 0.0F, 0.4F);
                            f.a(f9, f8, f6, f4 - f3, f5, f7);
                        }

                }
                if((j >> 24 & 0xff) > 0) {
                    float f11 = (float)(j >> 16 & 0xff) / 255F;
                    float f12 = (float)(j >> 8 & 0xff) / 255F;
                    float f13 = (float)(j & 0xff) / 255F;
                    float f14 = (float)(j >> 24 & 0xff) / 255F;
                    GL11.glColor4f(f11, f12, f13, f14);
                    e.a(f9, f8, f6, f4 - f3, f5, f7);
                    for(int l = 0; l < 4; l++)
                        if(a(jm1, l, f2)) {
                            GL11.glColor4f(f11, f12, f13, f14);
                            f.a(f9, f8, f6, f4 - f3, f5, f7);
                        }

                }
                GL11.glDepthFunc(515);
                GL11.glDisable(3042);
                GL11.glEnable(3008);
                GL11.glEnable(3553);
            }
            GL11.glDisable(32826);
        }
        catch(Exception exception) {
            exception.printStackTrace();
        }
        GL11.glEnable(2884);
        GL11.glPopMatrix();
        a(jm1, d1, d2, d3);
    }

    protected void b(jm jm1, double d1, double d2, double d3) {
        GL11.glTranslatef((float)d1, (float)d2, (float)d3);
    }

    protected void a(jm jm1, float f1, float f2, float f3) {
        GL11.glRotatef(180F - f2, 0.0F, 1.0F, 0.0F);
        if(jm1.aa > 0) {
            float f4 = ((((float)jm1.aa + f3) - 1.0F) / 20F) * 1.6F;
            f4 = gz.c(f4);
            if(f4 > 1.0F)
                f4 = 1.0F;
            GL11.glRotatef(f4 * a(jm1), 0.0F, 0.0F, 1.0F);
        }
    }

    protected float d(jm jm1, float f1) {
        return jm1.d(f1);
    }

    protected float c(jm jm1, float f1) {
        return (float)jm1.bq + f1;
    }

    protected void b(jm jm1, float f1) {
    }

    protected boolean a(jm jm1, int i, float f1) {
        return false;
    }

    protected float a(jm jm1) {
        return 90F;
    }

    protected int a(jm jm1, float f1, float f2) {
        return 0;
    }

    protected void a(jm jm1, float f1) { // UPDATE
        if(!ZMod.modResizeEnabled || ZMod.isMultiplayer || ZMod.resizeSize==null) return;
        float resize = ZMod.resizeSize[ZMod.getEntityType(jm1)];
        if(resize<=0.000001f) return;
        float scale = jm1.bc / resize;
        GL11.glScalef(scale, scale, scale);
    }

    protected void a(jm jm1, double d1, double d2, double d3) {
        if(Minecraft.v())
            a(jm1, Integer.toString(jm1.aA), d1, d2, d3, 64);
    }

    protected void a(jm jm1, String s, double d1, double d2, double d3, int i) {
        float f1 = jm1.f(b.h);
        if(f1 > (float)i)
            return;
        ox ox1 = a();
        float f2 = 1.6F;
        float f3 = 0.01666667F * f2;
        GL11.glPushMatrix();
        GL11.glTranslatef((float)d1 + 0.0F, (float)d2 + 2.3F, (float)d3);
        GL11.glNormal3f(0.0F, 1.0F, 0.0F);
        GL11.glRotatef(-b.i, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(b.j, 1.0F, 0.0F, 0.0F);
        GL11.glScalef(-f3, -f3, f3);
        GL11.glDisable(2896);
        GL11.glDepthMask(false);
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        lj lj1 = lj.a;
        byte byte0 = 0;
        if(s.equals("deadmau5"))
            byte0 = -10;
        GL11.glDisable(3553);
        lj1.b();
        int j = ox1.a(s) / 2;
        lj1.a(0.0F, 0.0F, 0.0F, 0.25F);
        lj1.a(-j - 1, -1 + byte0, 0.0D);
        lj1.a(-j - 1, 8 + byte0, 0.0D);
        lj1.a(j + 1, 8 + byte0, 0.0D);
        lj1.a(j + 1, -1 + byte0, 0.0D);
        lj1.a();
        GL11.glEnable(3553);
        ox1.b(s, -ox1.a(s) / 2, byte0, 0x20ffffff);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        ox1.b(s, -ox1.a(s) / 2, byte0, -1);
        GL11.glEnable(2896);
        GL11.glDisable(3042);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glPopMatrix();
    }

    public void a(pb pb, double d1, double d2, double d3,
            float f1, float f2) {
        a((jm)pb, d1, d2, d3, f1, f2);
    }

    protected in e, f;
}
