// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb safe 
// Source File Name:   SourceFile

import net.minecraft.client.Minecraft;

// search: = -180F * the one without "false" in constructor (most likely the first matching)
// NEED TO DECOMPILE SEPARATELY WITH SAFE MODE ON
public class lz extends ln {

    protected static final boolean zmodmarker = true;

    public lz(Minecraft minecraft) {
        super(minecraft);
        c = -1;
        d = -1;
        e = -1;
        f = 0.0F;
        g = 0.0F;
        h = 0.0F;
        i = 0;
    }

    public void a(fm fm1) {
        fm1.aP = -180F;
    }

    public boolean b(int j, int k, int l, int i1) {
        int j1 = a.e.a(j, k, l);
        int k1 = a.e.e(j, k, l);
        boolean flag = super.b(j, k, l, i1);
        hi hi1 = a.g.F();
        boolean flag1 = a.g.b(ra.m[j1]);
        if(hi1 != null) {
            hi1.a(j1, j, k, l, ((fm) (a.g)));
            if(hi1.a == 0) {
                hi1.a(((fm) (a.g)));
                a.g.G();
            }
        }
        if(flag && flag1)
            ra.m[j1].a(a.e, ((fm) (a.g)), j, k, l, k1);
        return flag;
    }

    public void a(int j, int k, int l, int i1) {
        int j1 = a.e.a(j, k, l);
        if(j1 > 0 && f == 0.0F)
            ra.m[j1].b(a.e, j, k, l, ((fm) (a.g)));
        if(j1 > 0 && ra.m[j1].a(((fm) (a.g))) >= 1.0F)
            b(j, k, l, i1);
    }

    public void a() {
        f = 0.0F;
        i = 0;
    }

    public void c(int j, int k, int l, int i1) {
        if(i > 0) {
            i--;
            return;
        }
        if(j == c && k == d && l == e) {
            int j1 = a.e.a(j, k, l);
            if(j1 == 0)
                return;
            ra ra1 = ra.m[j1];
            // -------------------------------------------------------------------------------------------------------------------
            f += ra1.a(((fm) (a.g))) * (ZMod.modDigEnabled ? ZMod.optDigSpeed : 1f);
            // -------------------------------------------------------------------------------------------------------------------
            if(h % 4F == 0.0F && ra1 != null)
                a.A.b(ra1.bu.d(), (float)j + 0.5F, (float)k + 0.5F, (float)l + 0.5F, (ra1.bu.b() + 1.0F) / 8F, ra1.bu.c() * 0.5F);
            h++;
            if(f >= 1.0F) {
                b(j, k, l, i1);
                f = 0.0F;
                g = 0.0F;
                h = 0.0F;
                i = 5;
            }
        } else {
            f = 0.0F;
            g = 0.0F;
            h = 0.0F;
            c = j;
            d = k;
            e = l;
        }
    }

    public void a(float f1) {
        if(f <= 0.0F) {
            a.u.b = 0.0F;
            a.f.i = 0.0F;
        } else {
            float f2 = g + (f - g) * f1;
            a.u.b = f2;
            a.f.i = f2;
        }
    }

    public float b() {
        return 4F;
    }

    public void a(eb eb1) {
        super.a(eb1);
    }

    public void c() {
        g = f;
        a.A.c();
    }

    private int c, d, e, i;
    private float f, g, h;
}
