// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.util.*;
import java.lang.reflect.*;

// EntityPlayer ? search: "humanoid"
public abstract class sz extends wd {

    public static Method getClassMethod(String c, String m, Class param[]) { try { return Class.forName(c).getMethod(m, param); } catch(Exception e) { e.printStackTrace(); return null; } }
    public static Field getClassField(String c, String m) { try { return Class.forName(c).getField(m); } catch(Exception e) { e.printStackTrace(); return null; } }
    public static Object getResult(Method m, Object obj, Object param[]) { try { return m.invoke(obj, param); } catch(Exception whatever) { } return null; }
    public static Object getValue(Field field, Object obj) { try { return field.get(obj); } catch(Exception whatever) { } return null; }

    // ---------------------------------------------------------------------------------------------------------------------------
    protected static boolean zmodmarker = true;
    private static Method flyHandle, flyCancel, flyJump;
    // moveEntity ? search: double d9 = 0\.050000000000000003D; - it is in the function
    public final void callSuper(double mx, double my, double mz) { super.b(mx,my,mz); }
    private static void flyInitialize() {
        try {
            Class mod = Class.forName("ZMod");
            flyHandle = mod.getDeclaredMethod("flyHandle", new Class[]{Object.class, Double.TYPE, Double.TYPE, Double.TYPE});
            flyCancel = mod.getDeclaredMethod("flyDickmoveCancel", new Class[]{});
            flyJump = mod.getDeclaredMethod("flyJumpHandle", new Class[]{});
        } catch(Exception whatever) { zmodmarker=false; flyHandle = flyCancel = null; }
    }
    public void b(double mx, double my, double mz) { // ZMod.flyHandle(this,mx,my,mz);
      if(zmodmarker && flyHandle==null) flyInitialize();
      if(flyHandle!=null) try { flyHandle.invoke(null, new Object[]{this, mx, my, mz}); } catch(Exception whatever) { flyHandle = null; callSuper(mx,my,mz); }
      else callSuper(mx,my,mz);
    }

    // this thing is in this class: add firt variable (noclip)
    public boolean H() {
        return !S && !aN && super.H();
    }

    // ... as is this: first chance to undo the dickmove
    public void p() {
        if(zmodmarker && flyCancel==null) flyInitialize(); if(flyCancel!=null) try { flyCancel.invoke(null, new Object[]{}); } catch(Exception whatever) {} // undo.
        if(aw > 0)
            aw--;
        if(this.k.v == 0 && bz < 20 && (V % 20) * 12 == 0)
            e(1);
        as.g();
        az = aA;
        super.p();
        bv = ba;
        bw = bb;
        if(Q()) {
            bv += (double)ba * 0.29999999999999999D;
            bw += (double)bb * 0.29999999999999999D;
        }
        float f = et.a(r * r + t * t);
        float f1 = (float)Math.atan(-s * 0.20000000298023224D) * 15F;
        if(f > 0.1F)
            f = 0.1F;
        if(!z || bz <= 0)
            f = 0.0F;
        if(z || bz <= 0)
            f1 = 0.0F;
        aA += (f - aA) * 0.4F;
        bH += (f1 - bH) * 0.8F;
        if(bz > 0) {
            List list = this.k.b(this, y.b(1.0D, 0.0D, 1.0D));
            if(list != null) {
                for(int k = 0; k < list.size(); k++) {
                    kj kj1 = (kj)list.get(k);
                    if(!kj1.G)
                        j(kj1);
                }

            }
        }
    }

    // ... as is this
    // search: 41999998688697815D  * is in the function ... no it is not anymore - that is in parent imp.
    protected void ar() {
        super.ar();
        // -----------------------------------------------------------------------------------------------------------------------
        double jump = 0.41999998688697815D;
        if(flyJump != null) try {
            jump = (Double)flyJump.invoke(null, new Object[]{});
        } catch(Exception whatever) {
            flyJump = null;
            jump = 0.41999998688697815D;
        }
        s = jump;
        //s = 0.41999998688697815D;
        // -----------------------------------------------------------------------------------------------------------------------
/*        if(Q()) {
            float f1 = u * 0.01745329F;
            r -= et.a(f1) * 0.2F;
            t += et.b(f1) * 0.2F;
        }
        ao = true; */
        // original
        a(fd.u, 1);
        if(Q())
            d(0.8F);
        else
            d(0.2F);
    }


/*    protected void R() {
        double jump = 0.41999998688697815D;
        if(flyJump != null) try {
            jump = (Double)flyJump.invoke(null, new Object[]{});
        } catch(Exception whatever) {
            flyJump = null;
            jump = 0.41999998688697815D;
        }
        aQ = jump;
        a(jl.u, 1);
    }

    protected void ar() { // original
        super.ar();
        a(fd.u, 1);
        if(Q())
            d(0.8F);
        else
            d(0.2F);
    }
*/

    // ---------------------------------------------------------------------------------------------------------------------------

    public sz(rv rv1) {
        super(rv1);
        as = new ui(this);
        av = new kc();
        aw = 0;
        ax = 0;
        ay = 0;
        aB = false;
        aC = 0;
        aG = 0;
        aS = 20;
        aT = false;
        aW = new nb();
        ba = 0.1F;
        bb = 0.02F;
        ap = 0;
        bc = null;
        at = new r(as, !rv1.I);
        au = at;
        H = 1.62F;
        ps ps1 = rv1.u();
        c((double)ps1.a + 0.5D, ps1.b + 1, (double)ps1.c + 0.5D, 0.0F, 0.0F);
        bz = 20;
        bq = "humanoid";
        bp = 180F;
        W = 20;
        bn = "/mob/char.png";
    }

    protected void b() {
        super.b();
        af.a(16, Byte.valueOf((byte)0));
        af.a(17, Byte.valueOf((byte)0));
    }

    public ul X() {
        return d;
    }

    public int Y() {
        return e;
    }

    public boolean Z() {
        return d != null;
    }

    public int aa() {
        if(Z())
            return d.m() - e;
        else
            return 0;
    }

    public void ab() {
        if(d != null)
            d.a(k, this, e);
        ac();
    }

    public void ac() {
        d = null;
        e = 0;
        if(!k.I)
            d(false);
    }

    public boolean ad() {
        return Z() && sv.f[d.c].b(d) == un.c;
    }

    public void w_() {
        if(d != null) {
            ul ul1 = as.b();
            if(ul1 != d) {
                ac();
            } else {
                if(e <= 25 && e % 4 == 0)
                    a(ul1, 5);
                if(--e == 0 && !this.k.I)
                    ae();
            }
        }
        if(aG > 0)
            aG--;
        if(an()) {
            a++;
            if(a > 100)
                a = 100;
            if(!this.k.I)
                if(!aF())
                    a(true, true, false);
                else
                if(this.k.k())
                    a(false, true, true);
        } else
        if(a > 0) {
            a++;
            if(a >= 110)
                a = 0;
        }
        super.w_();
        if(!this.k.I && au != null && !au.b(this)) {
            U();
            au = at;
        }
        if(aW.b) {
            for(int k = 0; k < 8; k++);
        }
        if(X > 0 && aW.a)
            X = 0;
        aH = aK;
        aI = aL;
        aJ = aM;
        double d1 = o - aK;
        double d2 = p - aL;
        double d3 = q - aM;
        double d4 = 10D;
        if(d1 > d4)
            aH = aK = o;
        if(d3 > d4)
            aJ = aM = q;
        if(d2 > d4)
            aI = aL = p;
        if(d1 < -d4)
            aH = aK = o;
        if(d3 < -d4)
            aJ = aM = q;
        if(d2 < -d4)
            aI = aL = p;
        aK += d1 * 0.25D;
        aM += d3 * 0.25D;
        aL += d2 * 0.25D;
        a(fd.k, 1);
        if(j == null)
            c = null;
        if(!this.k.I)
            av.a(this);
    }

    // WORKAROUND
    Method ax_b = getClassMethod("ax", "b", new Class[]{Double.TYPE, Double.TYPE, Double.TYPE});
    protected void a(ul ul1, int k) {
        if(ul1.n() == un.b) {
            for(int l = 0; l < k; l++) {
                ax ax1 = (ax)getResult(ax_b, null, new Object[]{((double)U.nextFloat() - 0.5D) * 0.10000000000000001D, Math.random() * 0.10000000000000001D + 0.10000000000000001D, 0.0D});
                // ax.b(((double)U.nextFloat() - 0.5D) * 0.10000000000000001D, Math.random() * 0.10000000000000001D + 0.10000000000000001D, 0.0D);
                ax1.a((-v * 3.141593F) / 180F);
                ax1.b((-u * 3.141593F) / 180F);
                ax ax2 = (ax)getResult(ax_b, null, new Object[]{((double)U.nextFloat() - 0.5D) * 0.29999999999999999D, (double)(-U.nextFloat()) * 0.59999999999999998D - 0.29999999999999999D, 0.59999999999999998D});
                // ax.b(((double)U.nextFloat() - 0.5D) * 0.29999999999999999D, (double)(-U.nextFloat()) * 0.59999999999999998D - 0.29999999999999999D, 0.59999999999999998D);
                ax2.a((-v * 3.141593F) / 180F);
                ax2.b((-u * 3.141593F) / 180F);
                ax2 = ax2.c(o, p + (double)B(), q);
                this.k.a((new StringBuilder()).append("iconcrack_").append(ul1.a().br).toString(), ax2.a, ax2.b, ax2.c, ax1.a, ax1.b + 0.050000000000000003D, ax1.c);
            }

            this.k.a(this, "mob.eat", 0.5F + 0.5F * (float)U.nextInt(2), (U.nextFloat() - U.nextFloat()) * 0.2F + 1.0F);
        }
    }

    protected void ae() {
        if(d != null) {
            a(d, 16);
            int k = d.a;
            ul ul1 = d.b(this.k, this);
            if(ul1 != d || ul1 != null && ul1.a != k) {
                as.a[as.c] = ul1;
                if(ul1.a == 0)
                    as.a[as.c] = null;
            }
            ac();
        }
    }

    public void a(byte byte0) {
        if(byte0 == 9)
            ae();
        else
            super.a(byte0);
    }

    protected boolean af() {
        return bz <= 0 || an();
    }

    protected void U() {
        au = at;
    }

    public void M() {
        aF = (new StringBuilder()).append("http://s3.amazonaws.com/MinecraftCloaks/").append(aD).append(".png").toString();
        ad = aF;
    }

    public void I() {
        double d1 = o;
        double d2 = p;
        double d3 = q;
        super.I();
        az = aA;
        aA = 0.0F;
        j(o - d1, p - d2, q - d3);
    }

    public void u() {
        H = 1.62F;
        a(0.6F, 1.8F);
        super.u();
        bz = 20;
        bE = 0;
    }

    private int aE() {
        if(a(ud.e))
            return 6 - (1 + b(ud.e).c()) * 1;
        if(a(ud.f))
            return 6 + (1 + b(ud.f).c()) * 2;
        else
            return 6;
    }

    protected void o_() {
        int k = aE();
        if(aB) {
            aC++;
            if(aC >= k) {
                aC = 0;
                aB = false;
            }
        } else {
            aC = 0;
        }
        by = (float)aC / (float)k;
    }

    private void j(kj kj1) {
        kj1.a_(this);
    }

    public int ag() {
        return ay;
    }

    public void a(je je1) {
        super.a(je1);
        a(0.2F, 0.2F);
        d(o, p, q);
        s = 0.10000000149011612D;
        if(aD.equals("Notch"))
            a(new ul(sv.k, 1), true);
        as.i();
        if(je1 != null) {
            r = -et.b(((bD + u) * 3.141593F) / 180F) * 0.1F;
            t = -et.a(((bD + u) * 3.141593F) / 180F) * 0.1F;
        } else {
            r = t = 0.0D;
        }
        H = 0.1F;
        a(fd.y, 1);
    }

    public void a(kj kj1, int k) {
        ay += k;
        if(kj1 instanceof sz)
            a(fd.A, 1);
        else
            a(fd.z, 1);
    }

    public void ah() {
        a(as.a(as.c, 1), false);
    }

    public void a(ul ul1) {
        a(ul1, false);
    }

    public void a(ul ul1, boolean flag) {
        if(ul1 == null)
            return;
        ee ee1 = new ee(k, o, (p - 0.30000001192092896D) + (double)B(), q, ul1);
        ee1.c = 40;
        float f = 0.1F;
        if(flag) {
            float f2 = U.nextFloat() * 0.5F;
            float f4 = U.nextFloat() * 3.141593F * 2.0F;
            ee1.r = -et.a(f4) * f2;
            ee1.t = et.b(f4) * f2;
            ee1.s = 0.20000000298023224D;
        } else {
            float f1 = 0.3F;
            ee1.r = -et.a((u / 180F) * 3.141593F) * et.b((v / 180F) * 3.141593F) * f1;
            ee1.t = et.b((u / 180F) * 3.141593F) * et.b((v / 180F) * 3.141593F) * f1;
            ee1.s = -et.a((v / 180F) * 3.141593F) * f1 + 0.1F;
            f1 = 0.02F;
            float f3 = U.nextFloat() * 3.141593F * 2.0F;
            f1 *= U.nextFloat();
            ee1.r += Math.cos(f3) * (double)f1;
            ee1.s += (U.nextFloat() - U.nextFloat()) * 0.1F;
            ee1.t += Math.sin(f3) * (double)f1;
        }
        a(ee1);
        a(fd.v, 1);
    }

    protected void a(ee ee1) {
        k.a(ee1);
    }

    public float a(lr lr1) {
        float f = as.a(lr1);
        if(a(wa.g))
            f /= 5F;
        if(!z)
            f /= 5F;
        if(a(ud.e))
            f *= 1.0F + (float)(b(ud.e).c() + 1) * 0.2F;
        if(a(ud.f))
            f *= 1.0F - (float)(b(ud.f).c() + 1) * 0.2F;
        return f;
    }

    public boolean b(lr lr1) {
        return as.b(lr1);
    }

    public void a(xb xb1) {
        super.a(xb1);
        kk kk1 = xb1.l("Inventory");
        as.b(kk1);
        aE = xb1.e("Dimension");
        aN = xb1.m("Sleeping");
        a = xb1.d("SleepTimer");
        aX = xb1.e("Xp");
        aY = xb1.e("XpLevel");
        aZ = xb1.e("XpTotal");
        if(aN) {
            aO = new ps(et.b(o), et.b(p), et.b(q));
            a(true, true, false);
        }
        if(xb1.b("SpawnX") && xb1.b("SpawnY") && xb1.b("SpawnZ"))
            b = new ps(xb1.e("SpawnX"), xb1.e("SpawnY"), xb1.e("SpawnZ"));
        av.a(xb1);
    }

    public void b(xb xb1) {
        super.b(xb1);
        xb1.a("Inventory", as.a(new kk()));
        xb1.a("Dimension", aE);
        xb1.a("Sleeping", aN);
        xb1.a("SleepTimer", (short)a);
        xb1.a("Xp", aX);
        xb1.a("XpLevel", aY);
        xb1.a("XpTotal", aZ);
        if(b != null) {
            xb1.a("SpawnX", b.a);
            xb1.a("SpawnY", b.b);
            xb1.a("SpawnZ", b.c);
        }
        av.b(xb1);
    }

    public void a(gl gl) {
    }

    public void a(int k, int l, int i1) {
    }

    public void b(kj kj1, int k) {
    }

    public float B() {
        return 0.12F;
    }

    protected void r() {
        H = 1.62F;
    }

    public boolean a(je je1, int k) {
        if(aW.a && !je1.d())
            return false;
        ca = 0;
        if(bz <= 0)
            return false;
        if(an() && !this.k.I)
            a(true, true, false);
        kj kj1 = je1.a();
        if((kj1 instanceof tb) || (kj1 instanceof ki)) {
            if(this.k.v == 0)
                k = 0;
            if(this.k.v == 1)
                k = k / 3 + 1;
            if(this.k.v == 3)
                k = (k * 3) / 2;
        }
        if(k == 0)
            return false;
        kj kj2 = kj1;
        if((kj2 instanceof ki) && ((ki)kj2).c != null)
            kj2 = ((ki)kj2).c;
        if(kj2 instanceof wd)
            a((wd)kj2, false);
        a(fd.x, k);
        return super.a(je1, k);
    }

    protected boolean ai() {
        return false;
    }

    protected void a(wd wd1, boolean flag) {
        if((wd1 instanceof sn) || (wd1 instanceof pt))
            return;
        if(wd1 instanceof ss) {
            ss ss1 = (ss)wd1;
            if(ss1.ab() && aD.equals(ss1.Y()))
                return;
        }
        if((wd1 instanceof sz) && !ai())
            return;
        List list = k.a(ss.class, rp.b(o, p, q, o + 1.0D, p + 1.0D, q + 1.0D).b(16D, 4D, 16D));
        Iterator iterator = list.iterator();
        do {
            if(!iterator.hasNext())
                break;
            kj kj1 = (kj)iterator.next();
            ss ss2 = (ss)kj1;
            if(ss2.ab() && ss2.ag() == null && aD.equals(ss2.Y()) && (!flag || !ss2.Z())) {
                ss2.e(false);
                ss2.h(wd1);
            }
        } while(true);
    }

    protected void b(je je1, int k) {
        if(!je1.b() && ad())
            k = 1 + k >> 1;
        if(!je1.b()) {
            int l = 25 - as.h();
            int i1 = k * l + ap;
            as.f(k);
            k = i1 / 25;
            ap = i1 % 25;
        }
        d(je1.c());
        super.b(je1, k);
    }

    public void a(aaa aaa) {
    }

    public void a(an an1) {
    }

    public void a(od od) {
    }

    public void c(kj kj1) {
        if(kj1.b(this))
            return;
        ul ul1 = aj();
        if(ul1 != null && (kj1 instanceof wd)) {
            ul1.a((wd)kj1);
            if(ul1.a <= 0) {
                ul1.a(this);
                ak();
            }
        }
    }

    public ul aj() {
        return as.b();
    }

    public void ak() {
        as.a(as.c, null);
    }

    public double J() {
        return (double)(H - 0.5F);
    }

    public void al() {
        if(!aB || aC >= aE() / 2 || aC < 0) {
            aC = -1;
            aB = true;
        }
    }

    public void h(kj kj1) {
        int k = as.a(kj1);
        if(k > 0) {
            boolean flag = s < 0.0D && !z && !n() && !A();
            if(flag)
                k = (k * 3) / 2 + 1;
            boolean flag1 = kj1.a(je.a(this), k);
            if(flag1) {
                if(Q()) {
                    kj1.c(-et.a((u * 3.141593F) / 180F) * 1.0F, 0.10000000000000001D, et.b((u * 3.141593F) / 180F) * 1.0F);
                    r *= 0.59999999999999998D;
                    t *= 0.59999999999999998D;
                    c(false);
                }
                if(flag)
                    b(kj1);
            }
            ul ul1 = aj();
            if(ul1 != null && (kj1 instanceof wd)) {
                ul1.a((wd)kj1, this);
                if(ul1.a <= 0) {
                    ul1.a(this);
                    ak();
                }
            }
            if(kj1 instanceof wd) {
                if(kj1.G())
                    a((wd)kj1, true);
                a(fd.w, k);
            }
            d(0.3F);
        }
    }

    public void b(kj kj1) {
    }

    public void W() {
    }

    public abstract void s();

    public void b(ul ul1) {
    }

    public void v() {
        super.v();
        at.a(this);
        if(au != null)
            au.a(this);
    }

    // WORKAROUND
    Field bm_e = getClassField("bm", "e");
    Field bm_a = getClassField("bm", "a");
    Field bm_b = getClassField("bm", "b");
    Field bm_c = getClassField("bm", "c");
    Field bm_d = getClassField("bm", "d");
    public bm d(int k, int l, int i1) {
        if(!this.k.I) {
            if(an() || !G())
                return (bm)getValue(bm_e, null);
            if(this.k.y.c)
                return (bm)getValue(bm_b, null);
            if(this.k.k())
                return (bm)getValue(bm_c, null);
            if(Math.abs(o - (double)k) > 3D || Math.abs(p - (double)l) > 2D || Math.abs(q - (double)i1) > 3D)
                return (bm)getValue(bm_d, null);
        }
        a(0.2F, 0.2F);
        H = 0.2F;
        if(this.k.d(k, l, i1)) {
            int j1 = this.k.e(k, l, i1);
            int k1 = ly.d(j1);
            float f = 0.5F;
            float f1 = 0.5F;
            switch(k1) {
            case 0: // '\0'
                f1 = 0.9F;
                break;

            case 2: // '\002'
                f1 = 0.1F;
                break;

            case 1: // '\001'
                f = 0.1F;
                break;

            case 3: // '\003'
                f = 0.9F;
                break;
            }
            b(k1);
            d((float)k + f, (float)l + 0.9375F, (float)i1 + f1);
        } else {
            d((float)k + 0.5F, (float)l + 0.9375F, (float)i1 + 0.5F);
        }
        aN = true;
        a = 0;
        aO = new ps(k, l, i1);
        r = t = s = 0.0D;
        if(!this.k.I)
            this.k.y();
        return (bm)getValue(bm_a, null);
    }

    private void b(int k) {
        aP = 0.0F;
        aR = 0.0F;
        switch(k) {
        case 0: // '\0'
            aR = -1.8F;
            break;

        case 2: // '\002'
            aR = 1.8F;
            break;

        case 1: // '\001'
            aP = 1.8F;
            break;

        case 3: // '\003'
            aP = -1.8F;
            break;
        }
    }

    public void a(boolean flag, boolean flag1, boolean flag2) {
        a(0.6F, 1.8F);
        r();
        ps ps1 = aO;
        ps ps2 = aO;
        if(ps1 != null && k.a(ps1.a, ps1.b, ps1.c) == lr.T.bA) {
            ly.a(k, ps1.a, ps1.b, ps1.c, false);
            ps ps3 = ly.f(k, ps1.a, ps1.b, ps1.c, 0);
            if(ps3 == null)
                ps3 = new ps(ps1.a, ps1.b + 1, ps1.c);
            d((float)ps3.a + 0.5F, (float)ps3.b + H + 0.1F, (float)ps3.c + 0.5F);
        }
        aN = false;
        if(!k.I && flag1)
            k.y();
        if(flag)
            a = 0;
        else
            a = 100;
        if(flag2)
            a(aO);
    }

    private boolean aF() {
        return k.a(aO.a, aO.b, aO.c) == lr.T.bA;
    }

    public static ps a(rv rv1, ps ps1) {
        bf bf1 = rv1.w();
        bf1.c(ps1.a - 3 >> 4, ps1.c - 3 >> 4);
        bf1.c(ps1.a + 3 >> 4, ps1.c - 3 >> 4);
        bf1.c(ps1.a - 3 >> 4, ps1.c + 3 >> 4);
        bf1.c(ps1.a + 3 >> 4, ps1.c + 3 >> 4);
        if(rv1.a(ps1.a, ps1.b, ps1.c) != lr.T.bA) {
            return null;
        } else {
            ps ps2 = ly.f(rv1, ps1.a, ps1.b, ps1.c, 0);
            return ps2;
        }
    }

    public float am() {
        if(aO != null) {
            int k = this.k.e(aO.a, aO.b, aO.c);
            int l = ly.d(k);
            switch(l) {
            case 0: // '\0'
                return 90F;

            case 1: // '\001'
                return 0.0F;

            case 2: // '\002'
                return 270F;

            case 3: // '\003'
                return 180F;
            }
        }
        return 0.0F;
    }

    public boolean an() {
        return aN;
    }

    public boolean ao() {
        return aN && a >= 100;
    }

    public int ap() {
        return a;
    }

    public void b(String s1) {
    }

    public ps aq() {
        return b;
    }

    public void a(ps ps1) {
        if(ps1 != null)
            b = new ps(ps1);
        else
            b = null;
    }

    public void a(acc acc) {
        a(acc, 1);
    }

    public void a(acc acc, int k) {
    }

    public void a_(float f, float f1) {
        double d1 = o;
        double d2 = p;
        double d3 = q;
        if(aW.b) {
            double d4 = s;
            float f2 = bw;
            bw = 0.05F;
            super.a_(f, f1);
            s = d4 * 0.59999999999999998D;
            bw = f2;
        } else {
            super.a_(f, f1);
        }
        i(o - d1, p - d2, q - d3);
    }

    public void i(double d1, double d2, double d3) {
        if(j != null)
            return;
        if(a(wa.g)) {
            int k = Math.round(et.a(d1 * d1 + d2 * d2 + d3 * d3) * 100F);
            if(k > 0) {
                a(fd.q, k);
                d(0.015F * (float)k * 0.01F);
            }
        } else
        if(A()) {
            int l = Math.round(et.a(d1 * d1 + d3 * d3) * 100F);
            if(l > 0) {
                a(fd.m, l);
                d(0.015F * (float)l * 0.01F);
            }
        } else
        if(n()) {
            if(d2 > 0.0D)
                a(fd.o, (int)Math.round(d2 * 100D));
        } else
        if(z) {
            int i1 = Math.round(et.a(d1 * d1 + d3 * d3) * 100F);
            if(i1 > 0) {
                a(fd.l, i1);
                if(Q())
                    d(0.09999999F * (float)i1 * 0.01F);
                else
                    d(0.01F * (float)i1 * 0.01F);
            }
        } else {
            int j1 = Math.round(et.a(d1 * d1 + d3 * d3) * 100F);
            if(j1 > 25)
                a(fd.p, j1);
        }
    }

    private void j(double d1, double d2, double d3) {
        if(j != null) {
            int k = Math.round(et.a(d1 * d1 + d2 * d2 + d3 * d3) * 100F);
            if(k > 0)
                if(j instanceof ads) {
                    a(fd.r, k);
                    if(c == null)
                        c = new ps(et.b(o), et.b(p), et.b(q));
                    else
                    if(c.a(et.b(o), et.b(p), et.b(q)) >= 1000D)
                        a(cp.q, 1);
                } else
                if(j instanceof di)
                    a(fd.s, k);
                else
                if(j instanceof mx)
                    a(fd.t, k);
        }
    }

    protected void c(float f) {
        if(aW.c)
            return;
        if(f >= 2.0F)
            a(fd.n, (int)Math.round((double)f * 100D));
        super.c(f);
    }

    public void a(wd wd1) {
        if(wd1 instanceof tb)
            a(((acc) (cp.s)));
    }

    public int c(ul ul1) {
        int k = super.c(ul1);
        if(ul1.c == sv.aS.br && bc != null)
            k = ul1.b() + 16;
        else
        if(d != null && ul1.c == sv.l.br) {
            int l = ul1.m() - e;
            if(l >= 18)
                return 133;
            if(l > 13)
                return 117;
            if(l > 0)
                return 101;
        }
        return k;
    }

    public void L() {
        if(aS > 0) {
            aS = 10;
            return;
        } else {
            aT = true;
            return;
        }
    }

    public void c(int k) {
        aX += k;
        aZ += k;
        for(; aX >= as(); aG())
            aX -= as();

    }

    public int as() {
        return (aY + 1) * 10;
    }

    private void aG() {
        aY++;
    }

    public void d(float f) {
        if(aW.a)
            return;
        if(!k.I)
            av.a(f);
    }

    public kc at() {
        return av;
    }

    public boolean b(boolean flag) {
        return (flag || av.c()) && !aW.a;
    }

    public boolean au() {
        return bz > 0 && bz < 20;
    }

    public void b(ul ul1, int k) {
        if(ul1 == d)
            return;
        d = ul1;
        e = k;
        if(!this.k.I)
            d(true);
    }

    public boolean e(int k, int l, int i1) {
        return true;
    }

    protected int a(sz sz1) {
        return aZ >> 1;
    }

    protected boolean av() {
        return true;
    }

    public ui as;
    public cf at, au;
    protected kc av;
    protected int aw;
    public byte ax;
    public int ay, aC, aE, aG, aS;
    public float az, aA, aP, aQ, aR;
    public boolean aB;
    public String aD, aF;
    public double aH, aI, aJ, aK, aL;
    public double aM;
    protected boolean aN, aT;
    public ps aO;
    private int a, e, ap;
    private ps b, c;
    public float aU, aV;
    public nb aW;
    public int aX, aY, aZ;
    private ul d;
    protected float ba, bb;
    public wg bc;
}
