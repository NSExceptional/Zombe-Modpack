
// search: [a-z]+ = new [a-z]+\[4\]; * new Objects!
public class ZINV extends ui {

    public ZINV(sz player) { super(player); } // update
    
    // function with two for loops over inventory and armor
    public void i() {
        if(ZMod.dropAllHandle()) super.i();
    }

}
