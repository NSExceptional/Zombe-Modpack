// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.lang.reflect.*;

// search: "BurnTime"
public class aaa extends ij
    implements gl {

    protected static final boolean zmodmarker = true;

    public aaa() {
        d = new ul[3];
        a = 0;
        b = 0;
        c = 0;
    }

    public int a() {
        return d.length;
    }

    public ul d_(int i) {
        return d[i];
    }

    public ul a(int i, int j) {
        if(d[i] != null) {
            if(d[i].a <= j) {
                ul ul1 = d[i];
                d[i] = null;
                return ul1;
            }
            ul ul2 = d[i].a(j);
            if(d[i].a == 0)
                d[i] = null;
            return ul2;
        } else {
            return null;
        }
    }

    public void a(int i, ul ul1) {
        d[i] = ul1;
        if(ul1 != null && ul1.a > d())
            ul1.a = d();
    }

    public String c() {
        return "Furnace";
    }

    public void a(xb xb1) {
        super.a(xb1);
        kk kk1 = xb1.l("Items");
        d = new ul[a()];
        for(int i = 0; i < kk1.c(); i++) {
            xb xb2 = (xb)kk1.a(i);
            byte byte0 = xb2.c("Slot");
            if(byte0 >= 0 && byte0 < d.length)
                d[byte0] = ul.a(xb2);
        }

        a = xb1.d("BurnTime");
        c = xb1.d("CookTime");
        b = a(d[1]);
    }

    public void b(xb xb1) {
        super.b(xb1);
        xb1.a("BurnTime", (short)a);
        xb1.a("CookTime", (short)c);
        kk kk1 = new kk();
        for(int i = 0; i < d.length; i++)
            if(d[i] != null) {
                xb xb2 = new xb();
                xb2.a("Slot", (byte)i);
                d[i].b(xb2);
                kk1.a(xb2);
            }

        xb1.a("Items", kk1);
    }

    public int d() {
        return 64;
    }

    public int b(int i) {
        // -----------------------------------------------------------------------------------------------------------------------
        return (c * i) / ZMod.furnaceSmeltTimeHandle();
        // -----------------------------------------------------------------------------------------------------------------------
    }

    public int c(int i) {
        // -----------------------------------------------------------------------------------------------------------------------
        if(b == 0) b = ZMod.furnaceSmeltTimeHandle();
        // -----------------------------------------------------------------------------------------------------------------------
        return (a * i) / b;
    }

    public boolean g() {
        return a > 0;
    }

    public void b_() {
        boolean flag = a > 0;
        boolean flag1 = false;
        // -----------------------------------------------------------------------------------------------------------------------
        boolean burned = false;
        if(a < 0) a = 32000;
        if(a>0 && ZMod.furnaceUseFuelHandle(  a, burned = o() )) { a--; burned = true; }
        // -----------------------------------------------------------------------------------------------------------------------
        if(!i.I) {
            if(a == 0 && o()) {
                b = a = a(d[1]);
                if(a > 0) {
                    flag1 = true;
                    if(d[1] != null) {
                        // -------------------------------------------------------------------------------------------------------
                        d[1] = (ul)ZMod.furnaceDecFuelHandle( d[1] ); // update
                        // -------------------------------------------------------------------------------------------------------
                    }
                }
            }
            if(g() && o()) {
                c++;
                // ---------------------------------------------------------------------------------------------------------------
                if(c >= ZMod.furnaceSmeltTimeHandle()) {
                // ---------------------------------------------------------------------------------------------------------------
                    c = 0;
                    n();
                    flag1 = true;
                }
            // -------------------------------------------------------------------------------------------------------------------
            } else if(ZMod.furnaceWasteHandle()) {
            // -------------------------------------------------------------------------------------------------------------------
                c = 0;
            }
            // -------------------------------------------------------------------------------------------------------------------
            //boolean mustBurn = a > 0 && burned;
            //if(ZMod.furnaceWorldUpdateHandle(mustBurn, j, k, l)) { // update explodes if done at different time
            if(flag != (a > 0)) {
            // -------------------------------------------------------------------------------------------------------------------
                flag1 = true;
                aag.a(a > 0, i, j, k, l);
            }
        }
        if(flag1)
            l();
    }

    private boolean o() {
        if(d[0] == null)
            return false;
        // -----------------------------------------------------------------------------------------------------------------------
        ul ul1 = (ul)ZMod.furnaceSmeltingHandle(  d[0].a().br  );
        if(ul1 == null) ul1 = cx.a().a(d[0].a().br);
        // -----------------------------------------------------------------------------------------------------------------------
        if(ul1 == null)
            return false;
        if(d[2] == null)
            return true;
        if(!d[2].a(ul1))
            return false;
        if(d[2].a < d() && d[2].a < d[2].c())
            return true;
        return d[2].a < ul1.c();
    }

    public void n() {
        if(!o())
            return;
        // -----------------------------------------------------------------------------------------------------------------------
        ul ul1 = (ul)ZMod.furnaceSmeltingHandle(  d[0].a().br  );
        if(ul1 == null) ul1 = cx.a().a(d[0].a().br);
        // -----------------------------------------------------------------------------------------------------------------------
        if(d[2] == null)
            d[2] = ul1.k();
        else
        if(d[2].c == ul1.c)
            d[2].a++;
        d[0].a--;
        if(d[0].a <= 0)
            d[0] = null;
    }

    // ===========================================================================================================================
    private static boolean mlInit = false;
    private static Class mlClass;
    private static Method mlMethod;
    private int a(ul ul1) {
        if(ul1 == null)
            return 0;
        int i = ul1.a().br;
        // -----------------------------------------------------------------------------------------------------------------------
        int fuel = ZMod.furnaceFuelHandle(  i  ); if(fuel!=0) return fuel; //
        if(i < 256 && lr.m[i].bN == wa.d) return ZMod.furnaceWoodFuelHandle(); //
        // -----------------------------------------------------------------------------------------------------------------------
        if(i == sv.E.br)
            return 100;
        if(i == sv.n.br)
            return 1600;
        if(i == sv.az.br)
            return 20000;
        // -----------------------------------------------------------------------------------------------------------------------
        if(i == lr.z.bA) return 100; //
        try {
            if(!mlInit) {
                mlInit = true;
                mlClass = Class.forName("ModLoader");
                mlMethod = mlClass.getDeclaredMethod("AddAllFuel", new Class[]{ Integer.TYPE });
            }
            if(mlMethod != null) return (Integer)(mlMethod.invoke(null, new Object[]{ i })); // update: i
        } catch(Exception whatever) { }
        return 0;
        // -----------------------------------------------------------------------------------------------------------------------
    }
    // ===========================================================================================================================

    public boolean a(sz sz1) {
        if(i.b(j, k, l) != this)
            return false;
        return sz1.f((double)j + 0.5D, (double)k + 0.5D, (double)l + 0.5D) <= 64D;
    }

    public void x_() {
    }

    public void y_() {
    }

    private ul d[];
    public int a, b, c;
}
