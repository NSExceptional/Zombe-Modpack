// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.util.List;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

// search: = -999;
public abstract class em extends qr {

    protected static final boolean zmodmarker = true;

    public em(cf cf1) {
        b = 176;
        c = 166;
        d = cf1;
    }

    public void a() {
        super.a();
        l.h.au = d;
    }

    public void a(int i, int j, float f) {
        k();
        int k = (m - b) / 2;
        int l = (n - c) / 2;
        a(f);
        GL11.glPushMatrix();
        GL11.glRotatef(120F, 1.0F, 0.0F, 0.0F);
        ow.b();
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(k, l, 0.0F);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glEnable(32826);
        sx sx1 = null;
        int i1 = 240;
        int k1 = 240;
        GL13.glMultiTexCoord2f(33985, (float)i1 / 1.0F, (float)k1 / 1.0F);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        for(int j1 = 0; j1 < d.e.size(); j1++) {
            sx sx2 = (sx)d.e.get(j1);
            a(sx2);
            if(a(sx2, i, j)) {
                sx1 = sx2;
                GL11.glDisable(2896);
                GL11.glDisable(2929);
                int l1 = sx2.c;
                int j2 = sx2.d;
                a(l1, j2, l1 + 16, j2 + 16, 0x80ffffff, 0x80ffffff);
                GL11.glEnable(2896);
                GL11.glEnable(2929);
            }
        }

        ui ui1 = this.l.h.as;
        if(ui1.j() != null) {
            GL11.glTranslatef(0.0F, 0.0F, 32F);
            a.a(q, this.l.p, ui1.j(), i - k - 8, j - l - 8);
            a.b(q, this.l.p, ui1.j(), i - k - 8, j - l - 8);
        }
        GL11.glDisable(32826);
        ow.a();
        GL11.glDisable(2896);
        GL11.glDisable(2929);
        c();
        if(ui1.j() == null && sx1 != null && sx1.b()) {
            String s = (new StringBuilder()).append("").append(wv.a().b(sx1.a().l())).toString().trim();
            if(s.length() > 0) {
                int i2 = (i - k) + 12;
                int k2 = j - l - 12;
                int l2 = q.a(s);
                a(i2 - 3, k2 - 3, i2 + l2 + 3, k2 + 8 + 3, 0xc0000000, 0xc0000000);
                q.a(s, i2, k2, -1);
            }
        }
        GL11.glPopMatrix();
        super.a(i, j, f);
        GL11.glEnable(2896);
        GL11.glEnable(2929);
    }

    protected void c() {
    }

    protected abstract void a(float f);

    private void a(sx sx1) {
        int i = sx1.c;
        int j = sx1.d;
        ul ul1 = sx1.a();
        if(ul1 == null) {
            int k = sx1.e();
            if(k >= 0) {
                GL11.glDisable(2896);
                l.p.b(l.p.b("/gui/items.png"));
                b(i, j, (k % 16) * 16, (k / 16) * 16, 16, 16);
                GL11.glEnable(2896);
                return;
            }
        }
        a.a(q, l.p, ul1, i, j);
        a.b(q, l.p, ul1, i, j);
    }

    private sx a(int i, int j) {
        for(int k = 0; k < d.e.size(); k++) {
            sx sx1 = (sx)d.e.get(k);
            if(a(sx1, i, j))
                return sx1;
        }

        return null;
    }

    protected void a(int i, int j, int k) {
        super.a(i, j, k);
        if(k == 0 || k == 1) {
            sx sx1 = a(i, j);
            int l = (m - b) / 2;
            int i1 = (n - c) / 2;
            boolean flag = i < l || j < i1 || i >= l + b || j >= i1 + c;
            int j1 = -1;
            if(sx1 != null)
                j1 = sx1.b;
            if(flag)
                j1 = -999;
            if(j1 != -1) {
                boolean flag1 = j1 != -999 && (Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54));
                a(sx1, j1, k, flag1);
            }
        }
    }

    private boolean a(sx sx1, int i, int j) {
        int k = (m - b) / 2;
        int l = (n - c) / 2;
        i -= k;
        j -= l;
        return i >= sx1.c - 1 && i < sx1.c + 16 + 1 && j >= sx1.d - 1 && j < sx1.d + 16 + 1;
    }

    protected void a(sx sx1, int i, int j, boolean flag) {
        if(sx1 != null)
            i = sx1.b;
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        int infinite = 1; // yes ... this is horrible hack - sue me
        if(i==0 && sx1!=null && sx1.getClass()!=sx.class) infinite = ZMod.craftingHandle();
        flag &= infinite == 1;
        if(sx1 != null) i = sx1.b; // from orig fn
        while(   l.c.a(d.f, i, j, flag, l.h)   != null && --infinite > 0);
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //l.c.a(d.f, i, j, flag, l.h); // orig
    }

    protected void b(int i, int j, int k) {
        if(k != 0);
    }

    protected void a(char c1, int i) {
        if(i == 1 || i == l.z.r.d)
            l.h.U();
    }

    public void d() {
        if(l.h == null) {
            return;
        } else {
            d.a(l.h);
            l.c.a(d.f, l.h);
            return;
        }
    }

    public boolean e() {
        return false;
    }

    public void p_() {
        super.p_();
        if(!l.h.G() || l.h.G)
            l.h.U();
    }

    protected static pj a = new pj();
    protected int b, c;
    public cf d;

}
