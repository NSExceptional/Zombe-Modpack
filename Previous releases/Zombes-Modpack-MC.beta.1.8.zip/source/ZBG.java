
import java.util.Random;

// BlockGlass
public final class ZBG extends rz {

    public ZBG() {
        super(20, 49, wa.q, false);
        c(0.3F).a(j).a("glass"); // "glass" * drop the last function.
    }

    public int a(Random random) { // only function with random
        return 1;
    }

    public int a(int i1, Random random) {
        return 20;
    }

}
