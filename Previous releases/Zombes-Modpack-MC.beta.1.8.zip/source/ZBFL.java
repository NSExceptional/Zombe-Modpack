
// BlockFarmland
public final class ZBFL extends abx {

    public ZBFL() {
        super(60);
        c(0.6F).a(f).a("farmland"); // "farmland" * drop the last function.
    }

    // function with  nextInt(4) == 0  in it
    public void b(rv map, int x, int y, int z, kj kj) {
        return;
    }

}
