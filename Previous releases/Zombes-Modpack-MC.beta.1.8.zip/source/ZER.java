
import net.minecraft.client.Minecraft;

// search:  = 32D;
public final class ZER extends iw {

    public ZER(Minecraft minecraft) {
        super(minecraft);
        //c = new jn(minecraft);
        //d = minecraft.p.a(new BufferedImage(16, 16, 1));
    }

    public void b(float f1) {
        super.b(f1);
        ZMod.pingDrawGUIHandle();
    }
    
    // search: environment/snow.png
    protected void c(float f1) {
        if(ZMod.drawRainHandle()) super.c(f1);
    }

}
