
import java.util.Random;

// BlockIce
public final class ZBI extends hp {

    public ZBI() {
        super(79, 67);
        c(0.5F).e(3).a(j).a("ice"); // "ice" * drop the last function.
    }
    
    public int a(Random random) { // only function with random
        return 1;
    }

    public int a(int i1, Random random) {
        return 79;
    }

    public void a(rv map, sz player, int x, int y, int z, int meta) { // \], 1\); * function in base class
        if(map.a(x, y - 1, z) != 9) // mapGetId
            map.c(x, y, z, 0); // search: ???
        super.a(map, player, x, y, z, meta);
    }

}
