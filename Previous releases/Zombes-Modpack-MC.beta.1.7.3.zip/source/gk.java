// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.util.Random;

public class gk extends uu {

    public gk(int i, int j) {
        super(i, j, ln.n);
    }

    public void c(fd fd1, int i, int j, int k) {
        fd1.c(i, j, k, bn, e());
    }

    public void b(fd fd1, int i, int j, int k, int l) {
        fd1.c(i, j, k, bn, e());
    }

    public void a(fd fd1, int i, int j, int k, Random random) {
        h(fd1, i, j, k);
    }

    private void h(fd fd1, int i, int j, int k) {
        if(ZMod.fallCheckHandle(i,j,k)) return; //
        int l = i;
        int i1 = j;
        int j1 = k;
        if(c_(fd1, l, i1 - 1, j1) && i1 >= 0) {
            byte byte0 = 32;
            if(a || !fd1.a(i - byte0, j - byte0, k - byte0, i + byte0, j + byte0, k + byte0)) {
                fd1.f(i, j, k, 0);
                for(; c_(fd1, i, j - 1, k) && j > 0; j--);
                if(j > 0)
                    fd1.f(i, j, k, bn);
            } else {
                ju ju1 = new ju(fd1, (float)i + 0.5F, (float)j + 0.5F, (float)k + 0.5F, bn);
                fd1.b(ju1);
            }
        }
    }

    public int e() {
        return 3;
    }

    public static boolean c_(fd fd1, int i, int j, int k) {
        int l = fd1.a(i, j, k);
        if(l == 0)
            return true;
        if(l == uu.as.bn)
            return true;
        ln ln1 = uu.m[l].bA;
        if(ln1 == ln.g)
            return true;
        return ln1 == ln.h;
    }

    public static boolean a = false;

}
