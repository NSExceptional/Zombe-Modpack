// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb safe 
// Source File Name:   SourceFile

import net.minecraft.client.Minecraft;

// search: = -180F * the one without "false" in constructor (most likely the first matching)
// NEED TO DECOMPILE SEPARATELY WITH SAFE MODE ON
public class os extends ob {

    protected static final boolean zmodmarker = true;

    public os(Minecraft minecraft) {
        super(minecraft);
        c = -1;
        d = -1;
        e = -1;
        f = 0.0F;
        g = 0.0F;
        h = 0.0F;
        i = 0;
    }

    public void a(gs gs1) {
        gs1.aS = -180F;
    }

    public boolean b(int j, int k, int l, int i1) {
        int j1 = a.f.a(j, k, l);
        int k1 = a.f.e(j, k, l);
        boolean flag = super.b(j, k, l, i1);
        iz iz1 = a.h.G();
        boolean flag1 = a.h.b(uu.m[j1]);
        // -----------------------------------------------------------------------------------------------------------------------
        flag1 = ZMod.harvestableHandle(flag1);
        // -----------------------------------------------------------------------------------------------------------------------
        if(iz1 != null) {
            iz1.a(j1, j, k, l, ((gs) (a.h)));
            if(iz1.a == 0) {
                iz1.a(((gs) (a.h)));
                a.h.H();
            }
        }
        if(flag && flag1)
            uu.m[j1].a(a.f, ((gs) (a.h)), j, k, l, k1);
        return flag;
    }

    public void a(int j, int k, int l, int i1) {
        a.f.a(((gs) (a.h)), j, k, l, i1);
        int j1 = a.f.a(j, k, l);
        if(j1 > 0 && f == 0.0F)
            uu.m[j1].b(a.f, j, k, l, ((gs) (a.h)));
        if(j1 > 0 && uu.m[j1].a(((gs) (a.h))) >= 1.0F)
            b(j, k, l, i1);
    }

    public void a() {
        f = 0.0F;
        i = 0;
    }

    public void c(int j, int k, int l, int i1) {
        if(i > 0) {
            i--;
            return;
        }
        if(j == c && k == d && l == e) {
            int j1 = a.f.a(j, k, l);
            if(j1 == 0)
                return;
            uu uu1 = uu.m[j1];
            // -------------------------------------------------------------------------------------------------------------------
            float add;
            f += add = ZMod.digProgressHandle( uu1.a(((gs) (a.h))), j1 );
            int skip = add > 1.0f ? (int)(6f / add - 0.99999f) : 5;
            // -------------------------------------------------------------------------------------------------------------------
            if(h % 4F == 0.0F && uu1 != null)
                a.B.b(uu1.by.d(), (float)j + 0.5F, (float)k + 0.5F, (float)l + 0.5F, (uu1.by.b() + 1.0F) / 8F, uu1.by.c() * 0.5F);
            h++;
            if(f >= 1.0F) {
                b(j, k, l, i1);
                f = 0.0F;
                g = 0.0F;
                h = 0.0F;
                i = skip; // ****** UPDATE ******
            }
        } else {
            f = 0.0F;
            g = 0.0F;
            h = 0.0F;
            c = j;
            d = k;
            e = l;
        }
    }

    public void a(float f1) {
        if(f <= 0.0F) {
            a.v.b = 0.0F;
            a.g.i = 0.0F;
        } else {
            float f2 = g + (f - g) * f1;
            a.v.b = f2;
            a.g.i = f2;
        }
    }

    public float b() {
        // -----------------------------------------------------------------------------------------------------------------------
        return ZMod.digReachHandle();
        // -----------------------------------------------------------------------------------------------------------------------
    }

    public void a(fd fd1) {
        super.a(fd1);
    }

    public void c() {
        g = f;
        a.B.c();
    }

    private int c, d, e, i;
    private float f, g, h;
}
