// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.util.List;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

// search: = -999;
public abstract class id extends da {

    protected static final boolean zmodmarker = true;

    public id(dw dw1) {
        a = 176;
        i = 166;
        j = dw1;
    }

    public void b() {
        super.b();
        b.h.e = j;
    }

    public void a(int i1, int j1, float f) {
        i();
        int k1 = (c - a) / 2;
        int l1 = (d - i) / 2;
        a(f);
        GL11.glPushMatrix();
        GL11.glRotatef(120F, 1.0F, 0.0F, 0.0F);
        u.b();
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(k1, l1, 0.0F);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glEnable(32826);
        gp gp1 = null;
        for(int i2 = 0; i2 < j.e.size(); i2++) {
            gp gp2 = (gp)j.e.get(i2);
            a(gp2);
            if(a(gp2, i1, j1)) {
                gp1 = gp2;
                GL11.glDisable(2896);
                GL11.glDisable(2929);
                int j2 = gp2.b;
                int l2 = gp2.c;
                a(j2, l2, j2 + 16, l2 + 16, 0x80ffffff, 0x80ffffff);
                GL11.glEnable(2896);
                GL11.glEnable(2929);
            }
        }

        ix ix1 = b.h.c;
        if(ix1.i() != null) {
            GL11.glTranslatef(0.0F, 0.0F, 32F);
            l.a(g, b.p, ix1.i(), i1 - k1 - 8, j1 - l1 - 8);
            l.b(g, b.p, ix1.i(), i1 - k1 - 8, j1 - l1 - 8);
        }
        GL11.glDisable(32826);
        u.a();
        GL11.glDisable(2896);
        GL11.glDisable(2929);
        k();
        if(ix1.i() == null && gp1 != null && gp1.b()) {
            String s = (new StringBuilder()).append("").append(nh.a().b(gp1.a().l())).toString().trim();
            if(s.length() > 0) {
                int k2 = (i1 - k1) + 12;
                int i3 = j1 - l1 - 12;
                int j3 = g.a(s);
                a(k2 - 3, i3 - 3, k2 + j3 + 3, i3 + 8 + 3, 0xc0000000, 0xc0000000);
                g.a(s, k2, i3, -1);
            }
        }
        GL11.glPopMatrix();
        super.a(i1, j1, f);
        GL11.glEnable(2896);
        GL11.glEnable(2929);
    }

    protected void k() {
    }

    protected abstract void a(float f);

    private void a(gp gp1) {
        int i1 = gp1.b;
        int j1 = gp1.c;
        iz iz1 = gp1.a();
        if(iz1 == null) {
            int k1 = gp1.e();
            if(k1 >= 0) {
                GL11.glDisable(2896);
                b.p.b(b.p.b("/gui/items.png"));
                b(i1, j1, (k1 % 16) * 16, (k1 / 16) * 16, 16, 16);
                GL11.glEnable(2896);
                return;
            }
        }
        l.a(g, b.p, iz1, i1, j1);
        l.b(g, b.p, iz1, i1, j1);
    }

    private gp a(int i1, int j1) {
        for(int k1 = 0; k1 < j.e.size(); k1++) {
            gp gp1 = (gp)j.e.get(k1);
            if(a(gp1, i1, j1))
                return gp1;
        }

        return null;
    }

    private boolean a(gp gp1, int i1, int j1) {
        int k1 = (c - a) / 2;
        int l1 = (d - i) / 2;
        i1 -= k1;
        j1 -= l1;
        return i1 >= gp1.b - 1 && i1 < gp1.b + 16 + 1 && j1 >= gp1.c - 1 && j1 < gp1.c + 16 + 1;
    }

    protected void a(int i1, int j1, int k1) {
        super.a(i1, j1, k1);
        if(k1 == 0 || k1 == 1) {
            gp gp1 = a(i1, j1);
            int l1 = (c - a) / 2;
            int i2 = (d - i) / 2;
            boolean flag = i1 < l1 || j1 < i2 || i1 >= l1 + a || j1 >= i2 + i;
            int j2 = -1;
            if(gp1 != null)
                j2 = gp1.a;
            if(flag)
                j2 = -999;
            if(j2 != -1) {
                boolean flag1 = j2 != -999 && (Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54));
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                int infinite = 1; // yes ... this is horrible hack - sue me
                if(j2==0 && gp1!=null && gp1.getClass()!=gp.class) infinite = ZMod.craftingHandle();
                flag1 &= infinite == 1;
                while(   b.c.a(j.f, j2, k1, flag1, b.h)   != null && --infinite > 0);
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            }
        }
    }

    protected void b(int i1, int j1, int k1) {
        if(k1 != 0);
    }

    protected void a(char c1, int i1) {
        if(i1 == 1 || i1 == b.z.r.b)
            b.h.r();
    }

    public void h() {
        if(b.h == null) {
            return;
        } else {
            b.c.a(j.f, b.h);
            return;
        }
    }

    public boolean c() {
        return false;
    }

    public void a() {
        super.a();
        if(!b.h.W() || b.h.be)
            b.h.r();
    }

    private static bb l = new bb();
    protected int a, i;
    public dw j;

}
