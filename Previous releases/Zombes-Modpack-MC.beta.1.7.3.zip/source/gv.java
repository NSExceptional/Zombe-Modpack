// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;

// search: "deadmau5" * the one with simpler IF
public class gv extends bw {

    protected static final boolean zmodmarker = true;

    public gv(ko ko1, float f1) {
        e = ko1;
        c = f1;
    }

    public void a(ko ko1) {
        f = ko1;
    }

    public void a(ls ls1, double d1, double d2, double d3, 
            float f1, float f2) {
        GL11.glPushMatrix();
        GL11.glDisable(2884);
        e.m = d(ls1, f2);
        if(f != null)
            f.m = e.m;
        e.n = ls1.al();
        if(f != null)
            f.n = e.n;
        try {
            float f3 = ls1.I + (ls1.H - ls1.I) * f2;
            float f4 = ls1.aU + (ls1.aS - ls1.aU) * f2;
            float f5 = ls1.aV + (ls1.aT - ls1.aV) * f2;
            b(ls1, d1, d2, d3);
            float f6 = c(ls1, f2);
            a(ls1, f6, f3, f2);
            float f7 = 0.0625F;
            GL11.glEnable(32826);
            GL11.glScalef(-1F, -1F, 1.0F);
            a(ls1, f2);
            GL11.glTranslatef(0.0F, -24F * f7 - 0.0078125F, 0.0F);
            float f8 = ls1.ak + (ls1.al - ls1.ak) * f2;
            float f9 = ls1.am - ls1.al * (1.0F - f2);
            if(f8 > 1.0F)
                f8 = 1.0F;
            a(ls1.bA, ls1.q_());
            GL11.glEnable(3008);
            e.a(ls1, f9, f8, f2);
            e.a(f9, f8, f6, f4 - f3, f5, f7);
            for(int i = 0; i < 4; i++)
                if(a(ls1, i, f2)) {
                    f.a(f9, f8, f6, f4 - f3, f5, f7);
                    GL11.glDisable(3042);
                    GL11.glEnable(3008);
                }

            b(ls1, f2);
            float f10 = ls1.a(f2);
            int j = a(ls1, f10, f2);
            if((j >> 24 & 0xff) > 0 || ls1.aa > 0 || ls1.ad > 0) {
                GL11.glDisable(3553);
                GL11.glDisable(3008);
                GL11.glEnable(3042);
                GL11.glBlendFunc(770, 771);
                GL11.glDepthFunc(514);
                if(ls1.aa > 0 || ls1.ad > 0) {
                    GL11.glColor4f(f10, 0.0F, 0.0F, 0.4F);
                    e.a(f9, f8, f6, f4 - f3, f5, f7);
                    for(int k = 0; k < 4; k++)
                        if(b(ls1, k, f2)) {
                            GL11.glColor4f(f10, 0.0F, 0.0F, 0.4F);
                            f.a(f9, f8, f6, f4 - f3, f5, f7);
                        }

                }
                if((j >> 24 & 0xff) > 0) {
                    float f11 = (float)(j >> 16 & 0xff) / 255F;
                    float f12 = (float)(j >> 8 & 0xff) / 255F;
                    float f13 = (float)(j & 0xff) / 255F;
                    float f14 = (float)(j >> 24 & 0xff) / 255F;
                    GL11.glColor4f(f11, f12, f13, f14);
                    e.a(f9, f8, f6, f4 - f3, f5, f7);
                    for(int l = 0; l < 4; l++)
                        if(b(ls1, l, f2)) {
                            GL11.glColor4f(f11, f12, f13, f14);
                            f.a(f9, f8, f6, f4 - f3, f5, f7);
                        }

                }
                GL11.glDepthFunc(515);
                GL11.glDisable(3042);
                GL11.glEnable(3008);
                GL11.glEnable(3553);
            }
            GL11.glDisable(32826);
        }
        catch(Exception exception) {
            exception.printStackTrace();
        }
        GL11.glEnable(2884);
        GL11.glPopMatrix();
        a(ls1, d1, d2, d3);
    }

    protected void b(ls ls1, double d1, double d2, double d3) {
        GL11.glTranslatef((float)d1, (float)d2, (float)d3);
    }

    protected void a(ls ls1, float f1, float f2, float f3) {
        GL11.glRotatef(180F - f2, 0.0F, 1.0F, 0.0F);
        if(ls1.ad > 0) {
            float f4 = ((((float)ls1.ad + f3) - 1.0F) / 20F) * 1.6F;
            f4 = in.c(f4);
            if(f4 > 1.0F)
                f4 = 1.0F;
            GL11.glRotatef(f4 * a(ls1), 0.0F, 0.0F, 1.0F);
        }
    }

    protected float d(ls ls1, float f1) {
        return ls1.d(f1);
    }

    protected float c(ls ls1, float f1) {
        return (float)ls1.bt + f1;
    }

    protected void b(ls ls1, float f1) {
    }

    protected boolean b(ls ls1, int i, float f1) {
        return a(ls1, i, f1);
    }

    protected boolean a(ls ls1, int i, float f1) {
        return false;
    }

    protected float a(ls ls1) {
        return 90F;
    }

    protected int a(ls ls1, float f1, float f2) {
        return 0;
    }

    protected void a(ls ls1, float f1) {
        // -----------------------------------------------------------------------------------------------------------------------
        ZMod.resizeHandle(ls1);
        // -----------------------------------------------------------------------------------------------------------------------
    }

    protected void a(ls ls1, double d1, double d2, double d3) {
        if(Minecraft.w())
            a(ls1, Integer.toString(ls1.aD), d1, d2, d3, 64);
    }

    protected void a(ls ls1, String s, double d1, double d2, double d3, int i) {
        float f1 = ls1.f(b.h);
        if(f1 > (float)i)
            return;
        sj sj1 = a();
        float f2 = 1.6F;
        float f3 = 0.01666667F * f2;
        GL11.glPushMatrix();
        GL11.glTranslatef((float)d1 + 0.0F, (float)d2 + 2.3F, (float)d3);
        GL11.glNormal3f(0.0F, 1.0F, 0.0F);
        GL11.glRotatef(-b.i, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(b.j, 1.0F, 0.0F, 0.0F);
        GL11.glScalef(-f3, -f3, f3);
        GL11.glDisable(2896);
        GL11.glDepthMask(false);
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        nw nw1 = nw.a;
        byte byte0 = 0;
        if(s.equals("deadmau5"))
            byte0 = -10;
        GL11.glDisable(3553);
        nw1.b();
        int j = sj1.a(s) / 2;
        nw1.a(0.0F, 0.0F, 0.0F, 0.25F);
        nw1.a(-j - 1, -1 + byte0, 0.0D);
        nw1.a(-j - 1, 8 + byte0, 0.0D);
        nw1.a(j + 1, 8 + byte0, 0.0D);
        nw1.a(j + 1, -1 + byte0, 0.0D);
        nw1.a();
        GL11.glEnable(3553);
        sj1.b(s, -sj1.a(s) / 2, byte0, 0x20ffffff);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        sj1.b(s, -sj1.a(s) / 2, byte0, -1);
        GL11.glEnable(2896);
        GL11.glDisable(3042);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glPopMatrix();
    }

    public void a(sn sn, double d1, double d2, double d3,
            float f1, float f2) {
        a((ls)sn, d1, d2, d3, f1, f2);
    }

    protected ko e, f;
}
