
import java.util.Random;

// BlockGlass
public final class ZBG extends fk {

    public ZBG() {
        super(20, 49, ln.p, false);
        c(0.3F).a(j).a("glass"); // "glass" * drop the last function.
    }

    public int a(Random random) { // only function with random
        return 1;
    }

}
