
import java.io.DataInputStream;
import java.io.DataOutputStream;

public class ZP250 extends ki {

	public nu nbtData;
	public ZP250(){}

    // last 4 abstract methods in parent class
    // search: "TAG_End"  * gives the nbt class - find the class dealing with compounds + code/decode in its parent class (takes Data* as parameter)

	public void a(DataInputStream in) {
		nbtData = (nu)ij.b(in);
	}

	public void a(DataOutputStream out) {
		ij.a(nbtData, out);
	}

	public void a(ti handler) {
		ZMod.packet250Handle(this);
	}

    // packet size
	public int a() {
		return 1;
	}

	public static void init(){
		a(250, true, true, ZP250.class); // found in parent class
	}
}
