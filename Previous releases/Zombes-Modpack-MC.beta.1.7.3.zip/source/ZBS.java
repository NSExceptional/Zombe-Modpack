
import java.util.Random;

// BlockIce
public final class ZBS extends xf {

    public ZBS() {
        super(19);
        c(0.6F).a(g).a("sponge"); // "sponge"
    }
    
    public void c(fd map, int x, int y, int z) { // onBlockAdd
        boolean water = false;
        if(map.f(x+1, y, z) == ln.g) water = true; // present in the original implementation of this function
        else if(map.f(x, y, z+1) == ln.g) water = true;
        else if(map.f(x-1, y, z) == ln.g) water = true;
        else if(map.f(x, y, z-1) == ln.g) water = true;
        if(water && map.f(x, y+1, z) != ln.g) {
            map.a(x,y,z, 19, 1); // mark it as an eater block    == mapSetIdMetaNoUpdate
            map.c(x,y,z, 19, 5); // scheduleBlockUpdate  search: , [a-z]+\[[a-z0-9]+\] \* 2\);
        }
    }

    public void b(fd map, int x, int y, int z) { } // onBlockRemove

    public void a(fd map, int x, int y, int z, Random rnd) { // onUpdate  search: \[[a-z0-9]+\]\.[a-z]+\(this, [a-z0-9]+ \+
        int meta = map.e(x,y,z); // get meta == mapGetMeta
        if(meta == 0) return;
        map.b(x,y,z,0,0); // remove the block  == mapSetIdMeta
        if(map.f(x, y+1, z) == ln.g) return;
        // spread
        if(map.f(x+1, y, z) == ln.g) { map.b(x+1,y,z, 19, 1); map.c(x+1,y,z, 19, 5); }
        if(map.f(x, y, z+1) == ln.g) { map.b(x,y,z+1, 19, 1); map.c(x,y,z+1, 19, 5); }
        if(map.f(x-1, y, z) == ln.g) { map.b(x-1,y,z, 19, 1); map.c(x-1,y,z, 19, 5); }
        if(map.f(x, y, z-1) == ln.g) { map.b(x,y,z-1, 19, 1); map.c(x,y,z-1, 19, 5); }
    }
    
    public int e() { // tickRate  search: \.[a-z]+\([a-z0-9]+, [a-z0-9]+, [a-z0-9]+, [a-z]+ - 1, [a-z]\(\)\);  * last parameter
        return 5;
    }

}
