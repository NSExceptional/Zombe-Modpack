// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.util.List;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;

// search: = -999;
public abstract class ft extends by {

    protected static final boolean zmodmarker = true;

    public ft(cp cp1) {
        a = 176;
        h = 166;
        i = cp1;
    }

    public void a() {
        super.a();
        b.g.h = i;
    }

    public void a(int l, int i1, float f) {
        i();
        int j1 = (c - a) / 2;
        int k1 = (d - h) / 2;
        a(f);
        GL11.glPushMatrix();
        GL11.glRotatef(180F, 1.0F, 0.0F, 0.0F);
        p.b();
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(j1, k1, 0.0F);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glEnable(32826);
        eq eq1 = null;
        for(int l1 = 0; l1 < i.e.size(); l1++) {
            eq eq2 = (eq)i.e.get(l1);
            a(eq2);
            if(a(eq2, l, i1)) {
                eq1 = eq2;
                GL11.glDisable(2896);
                GL11.glDisable(2929);
                int i2 = eq2.b;
                int k2 = eq2.c;
                a(i2, k2, i2 + 16, k2 + 16, 0x80ffffff, 0x80ffffff);
                GL11.glEnable(2896);
                GL11.glEnable(2929);
            }
        }

        gl gl1 = b.g.f;
        if(gl1.i() != null) {
            GL11.glTranslatef(0.0F, 0.0F, 32F);
            k.a(g, b.n, gl1.i(), l - j1 - 8, i1 - k1 - 8);
            k.b(g, b.n, gl1.i(), l - j1 - 8, i1 - k1 - 8);
        }
        GL11.glDisable(32826);
        p.a();
        GL11.glDisable(2896);
        GL11.glDisable(2929);
        j();
        if(gl1.i() == null && eq1 != null && eq1.c()) {
            String s = (new StringBuilder()).append("").append(n.a().b(eq1.b().l())).toString().trim();
            if(s.length() > 0) {
                int j2 = (l - j1) + 12;
                int l2 = i1 - k1 - 12;
                int i3 = g.a(s);
                a(j2 - 3, l2 - 3, j2 + i3 + 3, l2 + 8 + 3, 0xc0000000, 0xc0000000);
                g.a(s, j2, l2, -1);
            }
        }
        GL11.glEnable(2896);
        GL11.glEnable(2929);
        GL11.glPopMatrix();
    }

    protected void j() {
    }

    protected abstract void a(float f);

    private void a(eq eq1) {
        int l = eq1.b;
        int i1 = eq1.c;
        gm gm1 = eq1.b();
        if(gm1 == null) {
            int j1 = eq1.f();
            if(j1 >= 0) {
                GL11.glDisable(2896);
                b.n.b(b.n.a("/gui/items.png"));
                b(l, i1, (j1 % 16) * 16, (j1 / 16) * 16, 16, 16);
                GL11.glEnable(2896);
                return;
            }
        }
        k.a(g, b.n, gm1, l, i1);
        k.b(g, b.n, gm1, l, i1);
    }

    private eq a(int l, int i1) {
        for(int j1 = 0; j1 < i.e.size(); j1++) {
            eq eq1 = (eq)i.e.get(j1);
            if(a(eq1, l, i1))
                return eq1;
        }

        return null;
    }

    private boolean a(eq eq1, int l, int i1) {
        int j1 = (c - a) / 2;
        int k1 = (d - h) / 2;
        l -= j1;
        i1 -= k1;
        return l >= eq1.b - 1 && l < eq1.b + 16 + 1 && i1 >= eq1.c - 1 && i1 < eq1.c + 16 + 1;
    }

    protected void a(int l, int i1, int j1) {
        if(j1 == 0 || j1 == 1) {
            eq eq1 = a(l, i1);
            int k1 = (c - a) / 2;
            int l1 = (d - h) / 2;
            boolean flag = l < k1 || i1 < l1 || l >= k1 + a || i1 >= l1 + h;
            int i2 = -1;
            if(eq1 != null)
                i2 = eq1.a;
            if(flag)
                i2 = -999;
            if(i2 != -1)
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                if(ZMod.modCraftEnabled && i2==0 && eq1!=null && eq1.getClass()!=eq.class && ZMod.keyDown(ZMod.keyCraftAll)) {
                    int infinite = 64; // yes ... this is horrible hack - sue me
                    while(b.b.a(i.f, i2, j1, b.g) != null && --infinite > 0);
                } else {
                    b.b.a(i.f, i2, j1, b.g); // original code
                }
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        }
    }

    protected void b(int l, int i1, int j1) {
        if(j1 != 0);
    }

    protected void a(char c, int l) {
        if(l == 1 || l == b.y.p.b)
            b.g.p();
    }

    public void h() {
        if(b.g == null) {
            return;
        } else {
            b.b.a(i.f, b.g);
            return;
        }
    }

    public boolean b() {
        return false;
    }

    private static al k = new al();
    protected int a, h;
    public cp i;

}
