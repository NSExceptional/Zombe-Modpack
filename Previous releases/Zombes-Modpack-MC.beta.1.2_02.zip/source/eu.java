// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.util.List;
import java.util.Random;

// EntityPlayer : eu ? search: "humanoid"
public abstract class eu extends ig {

    protected static final boolean zmodmarker = true;

    // moveEntity   : d   ? search: double d9 = 0\.050000000000000003D; - it is in the function
    // fallDistance : bd  ? search "fallDistance"
    // onGround     : aQ  ? search "onGround"
    // stepCounter  : bb  ? search: 59999999999999998D * Entity class: stepCounter += (double)??.?(? * ? + ? + ?)*0.59999999999999998D;
    public void d(double mx, double my, double mz) {
        if(ZMod.modFlyEnabled && this == ZMod.player) {
            float tmp = bb;                              // update
            ZMod.calculate(mx, my, mz);
            if(ZMod.fly) { bd = 0f; aJ = 0f; }           // update
            super.d(ZMod.flyMX, ZMod.flyMY, ZMod.flyMZ);
            if(ZMod.fly) { aQ = true; bb = tmp; }        // update
        } else {
            super.d(mx,my,mz);
        }
    }

    public eu(dn dn1) {
        super(dn1);
        f = new gl(this);
        i = 0;
        j = 0;
        m = false;
        n = 0;
        a = 0;
        x = null;
        g = ((cp) (new t(f, !dn1.z)));
        h = g;
        aX = 1.62F;
        c((double)dn1.m + 0.5D, dn1.n + 1, (double)dn1.o + 0.5D, 0.0F, 0.0F);
        S = 20;
        L = "humanoid";
        K = 180F;
        bo = 20;
        I = "/mob/char.png";
    }

    public void q_() {
        super.q_();
        if(!aB.z && h != null && !h.b(this)) {
            p();
            h = g;
        }
        r = u;
        s = v;
        t = w;
        double d1 = aF - u;
        double d2 = aG - v;
        double d3 = aH - w;
        double d4 = 10D;
        if(d1 > d4)
            r = u = aF;
        if(d3 > d4)
            t = w = aH;
        if(d2 > d4)
            s = v = aG;
        if(d1 < -d4)
            r = u = aF;
        if(d3 < -d4)
            t = w = aH;
        if(d2 < -d4)
            s = v = aG;
        u += d1 * 0.25D;
        w += d3 * 0.25D;
        v += d2 * 0.25D;
    }

    protected void p() {
        h = g;
    }

    public void v() {
        q = (new StringBuilder()).append("http://s3.amazonaws.com/MinecraftCloaks/").append(o).append(".png").toString();
        bv = q;
    }

    public void w() {
        super.w();
        k = l;
        l = 0.0F;
    }

    public void x() {
        aX = 1.62F;
        a(0.6F, 1.8F);
        super.x();
        S = 20;
        X = 0;
    }

    protected void d_() {
        if(m) {
            n++;
            if(n == 8) {
                n = 0;
                m = false;
            }
        } else {
            n = 0;
        }
        R = (float)n / 8F;
    }

    public void m() {
        if(aB.k == 0 && S < 20 && (bn % 20) * 12 == 0)
            c(1);
        f.e();
        k = l;
        super.m();
        float f1 = gd.a(aI * aI + aK * aK);
        float f2 = (float)Math.atan(-aJ * 0.20000000298023224D) * 15F;
        if(f1 > 0.1F)
            f1 = 0.1F;
        if(!aQ || S <= 0)
            f1 = 0.0F;
        if(aQ || S <= 0)
            f2 = 0.0F;
        l += (f1 - l) * 0.4F;
        aa += (f2 - aa) * 0.8F;
        if(S > 0) {
            List list = aB.b(((nl) (this)), aP.b(1.0D, 0.0D, 1.0D));
            if(list != null) {
                for(int i1 = 0; i1 < list.size(); i1++) {
                    nl nl1 = (nl)list.get(i1);
                    if(!nl1.aW)
                        j(nl1);
                }

            }
        }
    }

    private void j(nl nl1) {
        nl1.b(this);
    }

    public int y() {
        return j;
    }

    public void b(nl nl1) {
        super.b(nl1);
        a(0.2F, 0.2F);
        b(aF, aG, aH);
        aJ = 0.10000000149011612D;
        if(o.equals("Notch"))
            a(new gm(eo.h, 1), true);
        f.g();
        if(nl1 != null) {
            aI = -gd.b(((W + aL) * 3.141593F) / 180F) * 0.1F;
            aK = -gd.a(((W + aL) * 3.141593F) / 180F) * 0.1F;
        } else {
            aI = aK = 0.0D;
        }
        aX = 0.1F;
    }

    public void c(nl nl1, int i1) {
        j += i1;
    }

    public void z() {
        a(f.a(f.c, 1), false);
    }

    public void a(gm gm1) {
        a(gm1, false);
    }

    public void a(gm gm1, boolean flag) {
        if(gm1 == null)
            return;
        fh fh1 = new fh(aB, aF, (aG - 0.30000001192092896D) + (double)A(), aH, gm1);
        fh1.c = 40;
        float f1 = 0.1F;
        if(flag) {
            float f3 = bm.nextFloat() * 0.5F;
            float f5 = bm.nextFloat() * 3.141593F * 2.0F;
            fh1.aI = -gd.a(f5) * f3;
            fh1.aK = gd.b(f5) * f3;
            fh1.aJ = 0.20000000298023224D;
        } else {
            float f2 = 0.3F;
            fh1.aI = -gd.a((aL / 180F) * 3.141593F) * gd.b((aM / 180F) * 3.141593F) * f2;
            fh1.aK = gd.b((aL / 180F) * 3.141593F) * gd.b((aM / 180F) * 3.141593F) * f2;
            fh1.aJ = -gd.a((aM / 180F) * 3.141593F) * f2 + 0.1F;
            f2 = 0.02F;
            float f4 = bm.nextFloat() * 3.141593F * 2.0F;
            f2 *= bm.nextFloat();
            fh1.aI += Math.cos(f4) * (double)f2;
            fh1.aJ += (bm.nextFloat() - bm.nextFloat()) * 0.1F;
            fh1.aK += Math.sin(f4) * (double)f2;
        }
        a(fh1);
    }

    protected void a(fh fh1) {
        aB.a(((nl) (fh1)));
    }

    public float a(pj pj) {
        float f1 = f.a(pj);
        if(a(ic.f))
            f1 /= 5F;
        if(!aQ)
            f1 /= 5F;
        return f1;
    }

    public boolean b(pj pj) {
        return f.b(pj);
    }

    public void b(jw jw1) {
        super.b(jw1);
        nn nn1 = jw1.l("Inventory");
        f.b(nn1);
        p = jw1.e("Dimension");
    }

    public void a(jw jw1) {
        super.a(jw1);
        jw1.a("Inventory", ((fy) (f.a(new nn()))));
        jw1.a("Dimension", p);
    }

    public void a(ij ij) {
    }

    public void a(int i1, int j1, int k1) {
    }

    public void b(nl nl1, int i1) {
    }

    public float A() {
        return 0.12F;
    }

    public boolean a(nl nl1, int i1) {
        ap = 0;
        if(S <= 0)
            return false;
        if((nl1 instanceof ey) || (nl1 instanceof nj)) {
            if(aB.k == 0)
                i1 = 0;
            if(aB.k == 1)
                i1 = i1 / 3 + 1;
            if(aB.k == 3)
                i1 = (i1 * 3) / 2;
        }
        if(i1 == 0)
            return false;
        else
            return super.a(nl1, i1);
    }

    protected void b(int i1) {
        int j1 = 25 - f.f();
        int k1 = i1 * j1 + a;
        f.e(i1);
        i1 = k1 / 25;
        a = k1 % 25;
        super.b(i1);
    }

    public void a(ni ni) {
    }

    public void a(ak ak) {
    }

    public void a(sc sc) {
    }

    public void c(nl nl1) {
        if(nl1.a(this))
            return;
        gm gm1 = B();
        if(gm1 != null && (nl1 instanceof ig)) {
            gm1.b((ig)nl1);
            if(gm1.a <= 0) {
                gm1.a(this);
                C();
            }
        }
    }

    public gm B() {
        return f.b();
    }

    public void C() {
        f.a(f.c, ((gm) (null)));
    }

    public double D() {
        return (double)(aX - 0.5F);
    }

    public void E() {
        n = -1;
        m = true;
    }

    public void d(nl nl1) {
        int i1 = f.a(nl1);
        if(i1 > 0) {
            nl1.a(((nl) (this)), i1);
            gm gm1 = B();
            if(gm1 != null && (nl1 instanceof ig)) {
                gm1.a((ig)nl1);
                if(gm1.a <= 0) {
                    gm1.a(this);
                    C();
                }
            }
        }
    }

    public void u() {
    }

    public void b(gm gm1) {
    }

    public void F() {
        super.F();
        g.a(this);
        if(h != null)
            h.a(this);
    }

    public gl f;
    public cp g, h;
    public byte i;
    public int j, n, p;
    public float k, l;
    public boolean m;
    public String o, q;
    public double r, s, t, u, v;
    public double w;
    private int a;
    public ik x;
}
