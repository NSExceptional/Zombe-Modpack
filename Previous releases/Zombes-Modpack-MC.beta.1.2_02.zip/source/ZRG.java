
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.*;

// search: cloud
public class ZRG extends h {

    public ZRG(Minecraft minecraft, gs renderengine) {
        super(minecraft, renderengine);
    }

    public void callSuper(float f) {
        super.b(f);
    }

    // the found cloud is inside this function - it draws the plane clouds and calls fancy clouds also
    public void b(float f) {
        ZMod.pingDrawHandle(f);
    }
    
}
