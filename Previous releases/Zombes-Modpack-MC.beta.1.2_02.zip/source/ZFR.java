
import java.util.HashMap;

// FontRenderer : nh ? search: "0123456789abcdef"
public class ZFR extends nh {

    private static HashMap<String, Text> texts = new HashMap<String, Text>();
    private static final class Text { public String msg; public int x, y, color; }
    
    // get from constructor
    //   GameSettings : hq
    //   RenderEngine : gs
    public ZFR(hq gamesettings, String fontfile, gs renderengine) { super(gamesettings, fontfile, renderengine); }

    public static void delMsg(String tag) {
        texts.remove(tag);
    }

    public static void setMsg(String tag, String msg, int x, int y, int color) {
        Text tmp;
        if(texts.containsKey(tag)) tmp = texts.get(tag); else texts.put(tag, tmp = new Text());
        tmp.msg = msg;
        tmp.x = x;
        tmp.y = y;
        tmp.color = color;
    }

    private void show(String str, int x, int y, int color) {
        String lines[] = str.split("\n");
        for(int i=0;i<lines.length;i++,y+=10) super.a(lines[i], x, y, color); // drawStringWithShadow !
    }

    // drawStringWithShadow : a ? first 2-line function in base class
    public void a(String str, int x, int y, int color) {
        if(color==0xffffff && x==2 && y==2 && str.length()<26 && str.startsWith("Minecraft")) {
            str += ZMod.pingTextHandle();
            for(String key : texts.keySet()) { Text tmp = texts.get(key); show(tmp.msg, tmp.x, tmp.y, tmp.color); }
        }
        super.a(str, x, y, color);
    }

}
