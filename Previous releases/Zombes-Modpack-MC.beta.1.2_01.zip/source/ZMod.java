
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.*;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import java.sql.Timestamp;

public class ZMod {
    public static final String version = "4.1";

    public static Minecraft mc;
    private static String path; // mod data folder path
    private static PrintStream out; // log output stream
    private static String logPath; // log file location
    private static String firstError; // first encountered error
    private static ZFR text; // our FontRenderer replacement
    private static ZRG render; // our RenderGlobal replacement
    private static Properties conf; // configuration
    private static boolean exceptionReported; // used to show only one reflection error
    private static boolean keys[] = new boolean[Keyboard.KEYBOARD_SIZE]; // used to detect key presses
    public static Random rnd = new Random();

    private static final class Mark {
        public float x,y,z;
        public Mark(int bx, int by, int bz) { x = 0.5f + bx; y = by + 0.13f; z = 0.5f + bz; }
    }

    public static boolean modCloudEnabled, modCartEnabled, modWieldEnabled, modBuildEnabled, modCompassEnabled, modSunEnabled;
    public static boolean modCraftEnabled, modFlyEnabled, modPathEnabled, modRecipeEnabled, modSafeEnabled, modBoomEnabled;
    public static boolean modSpawnEnabled, modOreEnabled, modTeleportEnabled;

    // probably should section thous per mod - but can not be arsed
    public static int keyBaseInfo, keyCloudToggle, keyCloudUp, keyCloudDown, keyCloudVanilla, keyCartStop, keyCartPerpetual, keyWield, keyBuildToggle, keyBuildA, keyBuildB;
    public static int keyCompassSet, keyCompassToggle, keySunTimeAdd, keySunTimeSub, keySunStop, keySunTimeNormal, keyCraftAll, keyPathShow, keyPathDelete;
    public static int keyFlyOn, keyFlyOff, keyFlyUp, keyFlyDown, keyFlySpeed, keyFlyToggle, keySafeShow;
    public static boolean optBaseDisableWarning, optBaseShowInfo, optCloudShow, optCloudVanilla, optCartPerpetual, optWieldBowFirst, optBuild;
    public static boolean optCompassShowPos, optPathShow, optRecipeShowId, optRecipeDump, optBuildLockQuantity, optOreLavaFloor;
    public static float optCloudOffset, optCartSpeedAccumCap, optCartAcceleration, optPathMin, optPathAnimSpeed, optBoomScaleTNT, optBoomScaleCreeper;
    public static double optFlySpeedVertical, optFlySpeedMulNormal, optFlySpeedMulModifier;
    public static int optSunTimeStep, optPathPoints, optPathSpacing, optBoomSafeRange;
    public static String tagCloudVanilla, tagCartPerpetual, tagBuildEnabled, tagCompassAlternate, tagSunTime, tagFly, tagSafe;
    public static float optBoomDropOreChance, optBoomDropChance;
    public static boolean optSpawnAllowInNonAir, optSpawnAllowOnNonNatural, optSpawnAllowOnGrass, optSpawnAllowOnCobble, optSpawnAllowOnSand, optSpawnAllowOnGravel, optSpawnAllowOnTree;
    public static int optSpawnPigReduction, optSpawnChickenReduction, optSpawnCowReduction, optSpawnSheepReduction, optSpawnSquidReduction, optSpawnGhastReduction;
    public static int optSpawnSpiderReduction, optSpawnSkeletonReduction, optSpawnCreeperReduction, optSpawnZombieReduction, optSpawnSlimeReduction, optSpawnPigZombieReduction;
    public static boolean optSpawnSupportMods;
    public static int[] optOreCoalRule, optOreIronRule, optOreGoldRule, optOreBlueRule, optOreRedRule, optOreDiamondRule;
    private static int optTeleportItem, optTeleportPlayer, optTeleportCritter;

    private static final int safeMax = 1024;
    private static boolean buildActive;
    private static double cartSpeed;
    private static float buildOriginal[], pathAnimCur, pathf[];
    private static int buildSets[][], pathCount, pathLast;
    private static int compassOX, compassOY, compassOZ, compassMX, compassMY, compassMZ;
    private static boolean compassHaveOrig, compassHaveMine, compassShowOrig = true;
    public static long sunTimeOffset = 0, sunTimeMoment;
    public static boolean sunTimeStop = false, fly = false;
    private static List recipesSP, recipesMP;
    private static Object cmanager;
    private static Mark safeMark[] = new Mark[safeMax];
    private static int safeCur, safeUpdate;
    private static boolean safeShow;
    private static HashMap teleportNames;

    private static Field fCMRecipes, fCBTable, fDamage;
    
    public static int block[] = new int[256];
    public static int KNOWN=1, SOLID=2, LIQUID=4, CRAFT=8, BASIC=16, SPACE=32, TREE=64, GRASS=128, COBBLE=256, DECAL=512, SAND=1024, GRAVEL=2048, ORE=4096, OBSIDIAN=8192, SPAWN=16384, TOUCH=32768;
    public static void initialize(Minecraft minecraft) {
        mc = minecraft;
        // init block list
        block[ 0] = KNOWN | SPACE | BASIC;
        block[ 1] = KNOWN | SOLID | BASIC;
        block[ 2] = KNOWN | SOLID | GRASS;
        block[ 3] = KNOWN | SOLID | BASIC;
        block[ 4] = KNOWN | SOLID | COBBLE;
        block[ 5] = KNOWN | SOLID | CRAFT;
        block[ 6] = KNOWN | SPACE | DECAL;
        block[ 7] = KNOWN | SOLID | BASIC;
        block[ 8] = KNOWN | SPACE | LIQUID;
        block[ 9] = KNOWN | SPACE | LIQUID;
        block[10] = KNOWN | LIQUID;
        block[11] = KNOWN | LIQUID;
        block[12] = KNOWN | SOLID | SAND;
        block[13] = KNOWN | SOLID | GRAVEL;
        block[14] = KNOWN | SOLID | ORE | BASIC;
        block[15] = KNOWN | SOLID | ORE | BASIC;
        block[16] = KNOWN | SOLID | ORE | BASIC;
        block[17] = KNOWN | SOLID | TREE;
        block[18] = KNOWN | SOLID | TREE;
        block[19] = KNOWN | SOLID | CRAFT;
        block[20] = KNOWN | SOLID | CRAFT;
        block[21] = KNOWN | SOLID | ORE | BASIC;
        block[22] = KNOWN | SOLID | CRAFT;
        block[23] = KNOWN | SOLID | CRAFT;
        block[24] = KNOWN | SOLID | CRAFT;
        block[25] = KNOWN | SOLID | CRAFT;
        block[35] = KNOWN | SOLID | CRAFT;
        block[37] = KNOWN | SPACE | DECAL;
        block[38] = KNOWN | SPACE | DECAL;
        block[39] = KNOWN | SPACE | DECAL;
        block[40] = KNOWN | SPACE | DECAL;
        block[41] = KNOWN | SOLID | CRAFT;
        block[42] = KNOWN | SOLID | CRAFT;
        block[43] = KNOWN | SOLID | CRAFT;
        block[44] = KNOWN | SOLID | CRAFT;
        block[45] = KNOWN | SOLID | CRAFT;
        block[46] = KNOWN | SOLID | CRAFT;
        block[47] = KNOWN | SOLID | CRAFT;
        block[48] = KNOWN | SOLID | BASIC;
        block[49] = KNOWN | SOLID | OBSIDIAN;
        block[50] = KNOWN | SPACE | DECAL;
        block[51] = KNOWN | SPACE | DECAL;
        block[52] = KNOWN | SOLID | BASIC;
        block[53] = KNOWN | SOLID | CRAFT;
        block[54] = KNOWN | SOLID | CRAFT;
        block[55] = KNOWN | SPACE | DECAL;
        block[56] = KNOWN | SOLID | ORE | BASIC;
        block[57] = KNOWN | SOLID | CRAFT;
        block[58] = KNOWN | SOLID | CRAFT;
        block[59] = KNOWN | SPACE | DECAL;
        block[60] = KNOWN | SOLID | CRAFT;
        block[61] = KNOWN | SOLID | CRAFT;
        block[62] = KNOWN | SOLID | CRAFT;
        block[63] = KNOWN | SPACE | DECAL | TOUCH;
        block[64] = KNOWN | SPACE | DECAL | TOUCH;
        block[65] = KNOWN | SPACE | DECAL;
        block[66] = KNOWN | SPACE | DECAL;
        block[67] = KNOWN | SOLID | CRAFT;
        block[68] = KNOWN | SPACE | DECAL | TOUCH;
        block[69] = KNOWN | SPACE | DECAL | TOUCH;
        block[70] = KNOWN | SPACE | DECAL;
        block[71] = KNOWN | SPACE | DECAL | TOUCH;
        block[72] = KNOWN | SPACE | DECAL;
        block[73] = KNOWN | SOLID | ORE | BASIC;
        block[74] = KNOWN | SOLID | ORE | BASIC;
        block[75] = KNOWN | SPACE | DECAL;
        block[76] = KNOWN | SPACE | DECAL;
        block[77] = KNOWN | SPACE | DECAL;
        block[78] = KNOWN | SPACE;
        block[79] = KNOWN | SOLID | BASIC;
        block[80] = KNOWN | SOLID | CRAFT;
        block[81] = KNOWN | SOLID | BASIC;
        block[82] = KNOWN | SOLID | BASIC;
        block[83] = KNOWN | SPACE | DECAL;
        block[84] = KNOWN | SOLID | CRAFT;
        block[85] = KNOWN | SOLID | CRAFT;
        block[86] = KNOWN | SOLID | BASIC;
        block[87] = KNOWN | SOLID | BASIC;
        block[88] = KNOWN | SOLID | BASIC;
        block[89] = KNOWN | SOLID | BASIC;
        block[90] = KNOWN | SPACE;
        block[91] = KNOWN | SOLID | CRAFT;
        block[92] = KNOWN | SOLID | CRAFT | TOUCH;
        for(int i=0;i<256;i++) if(spawnCheckA(i)) block[i] |= SPAWN;
        // get path - getPath : b  ? search: public static File * only static function that returns File and takes no parameters
        try { path = Minecraft.b().getCanonicalPath(); } catch(Exception whatever) { path = ""; }
        path += File.separatorChar + "mods" + File.separatorChar + "zombe" + File.separatorChar;
        try { File make = new File(path); make.mkdirs(); } catch(Exception whatever) { path = ""; }
        // open log
        try { File tmp = new File(path + "log.txt"); out = new PrintStream(tmp); logPath = tmp.getCanonicalPath(); } catch(Exception whatever) { logPath = "failed to create one :("; out = System.out; }
        out.println("=========== logging ===========");
        out.println("ZModPack: version "+version);
        out.println("Log started at: "+(new Timestamp((new Date()).getTime())));
        // load config
        conf = new Properties();
        try {
            Properties tmp;
            (tmp = new Properties()).load(new FileInputStream(path + "config.txt"));
            conf = tmp;
            log("info: processing configuration");
        } catch(Exception error) {
            err("error: failed to load configuration from config.txt", error);
        }
        // total fuckup log
        try {
        // reflection
        fDamage = getField(gm.class, "d"); // ItemStack.damage  : gm.d   ? search: "Damage"
        fCBTable = getField(jb.class, "a"); // update - intemstack[] in matchRecipe parameter class
        fCMRecipes = getField(fg.class, "b"); // update - only List in CraftingManager (###)
        // base config
        keyBaseInfo               = getBind("keyBaseInfo",        Keyboard.KEY_F8);
        optBaseDisableWarning     = getBool("optBaseDisableWarning", false);
        int mods = 0;
        // cloud mod
        if((modCloudEnabled       = getBool("modCloudEnabled", false))==true) {
            log("info: loading config for \"cloud\"");
            keyCloudToggle        = getBind("keyCloudToggle",     Keyboard.KEY_MULTIPLY);
            keyCloudVanilla       = getBind("keyCloudVanilla",    Keyboard.KEY_V);
            keyCloudUp            = getBind("keyCloudUp",         Keyboard.KEY_NONE);
            keyCloudDown          = getBind("keyCloudDown",       Keyboard.KEY_NONE);
            optCloudShow          = getBool("optCloudShow", true);
            optCloudOffset        = getFloat("optCloudOffset", 24F, -64F, 64F);
            tagCloudVanilla       = getString("tagCloudVanilla", "no-could-mod");
            mods++;
        }
        // cart mod
        if((modCartEnabled = getBool("modCartEnabled", false))==true) {
            log("info: loading config for \"cart\"");
            keyCartStop           = getBind("keyCartStop",        Keyboard.KEY_RETURN);
            keyCartPerpetual      = getBind("keyCartPerpetual",   Keyboard.KEY_UP);
            optCartSpeedAccumCap  = getFloat("optCartSpeedAccumCap", 1f, 0.5f, 5f);
            optCartAcceleration   = getFloat("optCartAcceleration", 2f, 0.5f, 10f);
            tagCartPerpetual      = getString("tagCartPerpetual", "perpetual");
            mods++;
        }
        // wield mod
        if((modWieldEnabled = getBool("modWieldEnabled", false))==true) {
            log("info: loading config for \"wield\"");
            keyWield              = getBind("keyWield",           Keyboard.KEY_R);
            optWieldBowFirst      = getBool("optWieldBowFirst", true);
            mods++;
        }
        // build mod
        if((modBuildEnabled = getBool("modBuildEnabled", false))==true) {
            log("info: loading config for \"build\"");
            keyBuildToggle        = getBind("keyBuildToggle",     Keyboard.KEY_B);
            keyBuildA             = getBind("keyBuildA",          Keyboard.KEY_LSHIFT);
            keyBuildB             = getBind("keyBuildB",          Keyboard.KEY_LCONTROL);
            optBuild              = getBool("optBuild", false);
            optBuildLockQuantity  = getBool("optBuildLockQuantity", true);
            tagBuildEnabled       = getString("tagBuildEnabled", "builder");
            String sets[] = new String[]{
                getString("optBuildA1", "smooth, cobble, grass, dirt, sand, gravel, clay, obsidian, sandstone"),
                getString("optBuildA2", "trunk, pine, birch, wood, shelves, chest, workbench, jukebox, furnace"),
                getString("optBuildA3", "woolYellow, woolOrange, woolRed, woolPink, woolMagenta, woolPurple, woolBlue, woolCyan, woolLightBlue"),
                getString("optBuildA4", "wool, woolLightGray, woolGray, woolBlack, woolBrown, woolGreen, woolLime, cage, sponge"),
                getString("optBuildA5", "snowcap, ice, snow, water, lava, fire, glass, pumpkinC, torch"),
                getString("optBuildA6", "sapling, leaves, flowerY, flowerR, shroomB, shroomR, cactus, pumpkin, reed"),
                getString("optBuildA7", "blockG, blockI, blockD, blockB, blockL, mossy, nether, soul, 0"),
                getString("optBuildA8", "oreG, oreI, oreC, oreD, oreR, oreY, oreL, 0, torch"),
                getString("optBuildA9", "doorW, doorI, switch, red, plateS, plateW, button, dispenser, note"),
                getString("optBuildB1", "ladder, tracks, fence, stairC, stairW, sign, half, double, picture"),
                getString("optBuildB2", "pickD, cart, boat, saddle, tnt, cake, 0, 0, torch"),
                getString("optBuildB3", ""),
                getString("optBuildB4", ""),
                getString("optBuildB5", ""),
                getString("optBuildB6", ""),
                getString("optBuildB7", ""),
                getString("optBuildB8", "arrow, compass"),
                getString("optBuildB9", "bucketW, watch, glass, appleG, swordD, bow, shovelD, pickD, torch")
            };
            buildSets = new int[sets.length][9];
            parse(new ArrayList(), "names.txt", NAMEMAP);
            for(int set=0;set<sets.length;set++) if(!sets[set].equals("")) {
                String got[] = sets[set].split("[\t ]*,[\t ]*");
                int defs = got.length; if(defs>9) defs = 9;
                for(int slot=0;slot<defs;slot++) {
                    if(pNames.containsKey(got[slot])) buildSets[set][slot] = (Integer)(pNames.get(got[slot]));
                    else {
                        int id = parseIdInfo(got[slot]);
                        if(id==-1) err("error: config.txt @ optBuild"+(set>9?"B":"A")+((set%9)+1)+" - unknown item name or invalid code "+got[slot]);
                        else buildSets[set][slot] = id;
                    }
                }
            }
            mods++;
        }
        // compass mod
        if((modCompassEnabled = getBool("modCompassEnabled", false))==true) {
            log("info: loading config for \"compass\"");
            keyCompassSet = getBind("keyCompassSet",              Keyboard.KEY_INSERT);
            keyCompassToggle = getBind("keyCompassToggle",        Keyboard.KEY_HOME);
            tagCompassAlternate = getString("tagCompassAlternate", "altSpawn");
            optCompassShowPos = getBool("optCompassShowPos", true);
            mods++;
        }
        // sun mod
        if((modSunEnabled = getBool("modSunEnabled", false))==true) {
            log("info: loading config for \"sun\"");
            keySunTimeAdd = getBind("keySunTimeAdd",              Keyboard.KEY_ADD);
            keySunTimeSub = getBind("keySunTimeSub",              Keyboard.KEY_SUBTRACT);
            keySunStop = getBind("keySunStop",                    Keyboard.KEY_END);
            keySunTimeNormal = getBind("keySunTimeNormal",        Keyboard.KEY_EQUALS);
            optSunTimeStep = getInt("optSunTimeStep", 30, 1, 600) * 20;
            tagSunTime = getString("tagSunTime", "time");
            if(!checkClass(qx.class)) { err("error: qx.class has not been installed - sun mod disabled"); modSunEnabled = false; } // update - search: 24000F
            else mods++;
        }
        // craft mod
        if((modCraftEnabled = getBool("modCraftEnabled", false))==true) {
            log("info: loading config for \"craft\"");
            keyCraftAll = getBind("keyCraftAll",                  Keyboard.KEY_LSHIFT);
            if(!checkClass(ft.class)) { err("error: ft.class has not been installed - craft mod disabled"); modCraftEnabled = false; } // update - search: = -999;
            else mods++;
        }
        // fly mod
        if((modFlyEnabled = getBool("modFlyEnabled", false))==true) {
            log("info: loading config for \"fly\"");
            keyFlyOn = getBind("keyFlyOn",                        Keyboard.KEY_NONE);
            keyFlyOff = getBind("keyFlyOff",                      Keyboard.KEY_NONE);
            keyFlyUp = getBind("keyFlyUp",                        Keyboard.KEY_E);
            keyFlyDown = getBind("keyFlyDown",                    Keyboard.KEY_Q);
            keyFlySpeed = getBind("keyFlySpeed",                  Keyboard.KEY_LSHIFT);
            keyFlyToggle = getBind("keyFlyToggle",                Keyboard.KEY_F);
            optFlySpeedVertical = getFloat("optFlySpeedVertical", 0.2f, 0.1f, 1.0f);
            optFlySpeedMulNormal = getFloat("optFlySpeedMulNormal", 1.0f, 0.1f, 10.0f);
            optFlySpeedMulModifier = getFloat("optFlySpeedMulModifier", 2.0f, 1.0f, 10.0f);
            tagFly = getString("tagFly", "flying");
            if(!checkClass(eu.class)) { err("error: eu.class has not been installed - fly mod disabled"); modFlyEnabled = false; } // update - search: "humanoid"
            else mods++;
        }
        // path mod
        if((modPathEnabled = getBool("modPathEnabled", false))==true) {
            log("info: loading config for \"path\"");
            keyPathShow = getBind("keyPathShow",                  Keyboard.KEY_BACK);
            keyPathDelete = getBind("keyPathDelete",              Keyboard.KEY_DELETE);
            optPathPoints = getInt("optPathPoints", 8192, 256, 32768); pathf = new float[3 * optPathPoints];
            optPathSpacing = getInt("optPathSpacing", 6, 0, 32) + 2;
            optPathMin = getFloat("optPathMin", 0.25f, 0.1f, 4f); optPathMin *= optPathMin;
            optPathAnimSpeed = getFloat("optPathAnimSpeed", 8f, 0f, 32f);
            optPathShow = getBool("optPathShow", false);
            mods++;
        }
        // recipe mod
        if((modRecipeEnabled = getBool("modRecipeEnabled", false))==true) {
            log("info: loading config for \"recipe\"");
            optRecipeShowId = getBool("optRecipeShowId", true);
            optRecipeDump = getBool("optRecipeDump", false);
            cmanager = fg.a(); // update - search: ### * only function that returns CraftingManager
            recipesSP = (List)getValue(fCMRecipes, cmanager);
            recipesMP = new ArrayList();
            log("info: "+recipesSP.size()+" SP recipes before loading mod");
            parse(recipesSP, "recipes.txt",    RECIPES); Collections.sort(recipesSP, new hs((fg)cmanager)); // update
            log("info: "+recipesSP.size()+" SP recipes after loading mod");
            parse(recipesMP, "recipes-mp.txt", RECIPES); Collections.sort(recipesMP, new hs((fg)cmanager)); // update
            log("info: "+recipesMP.size()+" vanilla recipes for MP compatibility");
            if(optRecipeDump) {
                log("==== recipe dump ====");
                Field fWidth = getField(gj.class, "b"), fHeight = getField(gj.class, "c"), fMap = getField(gj.class, "d"), fResA = getField(gj.class, "e"); // UPDATE
                Field fList = getField(om.class, "b"), fResB = getField(om.class, "a");                                                                     // UPDATE
                String res;
                Object obj, items;
                for(int i=0;i<recipesSP.size();i++) {
                    if(recipesSP.get(i) instanceof gj) {
                        obj = recipesSP.get(i);
                        items = getValue(fResA, obj);
                        Object arr[] = (Object[])getValue(fMap, obj);
                        res = "type normal    : " + getItemsId(items)+"/"+getItemsInfo(items) + " " + getValue(fWidth, obj) + " " + getValue(fHeight, obj);
                        for(int m=0;m<arr.length;m++) res += arr[m]==null ? 0 : (" "+getItemsId(arr[m])+"/"+getItemsInfo(arr[m]));
                    } else if(recipesSP.get(i) instanceof om) {
                        obj = recipesSP.get(i);
                        items = getValue(fResB, obj);
                        List arr = (List)getValue(fList, obj);
                        res = "type shapeless : " + getItemsId(items)+"/"+getItemsInfo(items) + " " + arr.size() + " 0";
                        for(int m=0;m<arr.size();m++) res += " "+getItemsId(arr.get(m))+"/"+getItemsInfo(arr.get(m));
                    } else {
                        res = "type: KST " + recipesSP.get(i);
                    }
                    log(res);
                }
            }
            mods++;
        }
        // safe mod
        if((modSafeEnabled = getBool("modSafeEnabled", false))==true) {
            log("info: loading config for \"safe\"");
            keySafeShow = getBind("keySafeShow",                  Keyboard.KEY_L);
            tagSafe = getString("tagSafe", "safe");
            mods++;
        }
        // boom mod
        if((modBoomEnabled = getBool("modBoomEnabled", false))==true) {
            log("info: loading config for \"boom\"");
            optBoomDropChance = (float)getInt("optBoomDropChance", 30, 0, 100) / 100f;
            optBoomDropOreChance = (float)getInt("optBoomDropOreChance", 100, 0, 100) / 100f;
            optBoomScaleTNT = getFloat("optBoomScaleTNT", 1f, 0.1f, 10f);
            optBoomScaleCreeper = getFloat("optBoomScaleCreeper", 1f, 0.1f, 10f);
            optBoomSafeRange  = getInt("optBoomSafeRange", 16, -1, 32);
            if(!checkClass(getClass("mc"))) { err("error: mc.class has not been installed - boom mod disabled"); modBoomEnabled = false; } // update - search: "humanoid"
            else mods++;
        }
        // spawn mod
        if((modSpawnEnabled = getBool("modSpawnEnabled", false))==true) {
            log("info: loading config for \"spawn\"");
            optSpawnSupportMods = getBool("optSpawnSupportMods", true);
            optSpawnAllowInNonAir = getBool("optSpawnAllowInNonAir", false);
            optSpawnAllowOnNonNatural = getBool("optSpawnAllowOnNonNatural", false);
            optSpawnAllowOnGrass = getBool("optSpawnAllowOnGrass", true);
            optSpawnAllowOnCobble = getBool("optSpawnAllowOnCobble", false);
            optSpawnAllowOnSand = getBool("optSpawnAllowOnSand", true);
            optSpawnAllowOnGravel = getBool("optSpawnAllowOnGravel", true);
            optSpawnAllowOnTree = getBool("optSpawnAllowOnTree", false);

            optSpawnPigReduction = getInt("optSpawnPigReduction", 75, 0, 100);
            optSpawnChickenReduction = getInt("optSpawnChickenReduction", 0, 0, 100);
            optSpawnCowReduction = getInt("optSpawnCowReduction", 0, 0, 100);
            optSpawnSheepReduction = getInt("optSpawnSheepReduction", 0, 0, 100);
            optSpawnSquidReduction = getInt("optSpawnSquidReduction", 0, 0, 100);

            optSpawnSpiderReduction = getInt("optSpawnSpiderReduction", 0, 0, 100);
            optSpawnSkeletonReduction = getInt("optSpawnSkeletonReduction", 0, 0, 100);
            optSpawnCreeperReduction = getInt("optSpawnCreeperReduction", 0, 0, 100);
            optSpawnZombieReduction = getInt("optSpawnZombieReduction", 0, 0, 100);
            optSpawnSlimeReduction = getInt("optSpawnSlimeReduction", 0, 0, 100);

            optSpawnGhastReduction = getInt("optSpawnGhastReduction", 0, 0, 100);
            optSpawnPigZombieReduction = getInt("optSpawnPigZombieReduction", 0, 0, 100);
            mods++;
        }
        // ore mod
        if((modOreEnabled = getBool("modOreEnabled", false))==true) {
            log("info: loading config for \"ore\"");
            optOreLavaFloor   = getBool("optOreLavaFloor", true);
            // chance_for_chunk / max_height / min_height / attempts / size / what_must_be_above
            optOreCoalRule    = parseRule(getString("optOreCoalRule"   , "75/80/48/8/16/1  10/120/32/128/4/1 5/120/64/1/128/1"));
            optOreIronRule    = parseRule(getString("optOreIronRule"   , "100/80/16/8/16/1 100/96/8/16/8/1   5/120/64/128/1/1"));
            optOreGoldRule    = parseRule(getString("optOreGoldRule"   , "50/32/4/4/16/1   5/96/8/8/64/1"));
            optOreBlueRule    = parseRule(getString("optOreBlueRule"   , "100/32/8/2/8/1   5/56/48/64/2/1    5/96/48/1/32/1/1"));
            optOreRedRule     = parseRule(getString("optOreRedRule"    , "100/32/8/2/8/1   10/120/96/64/1/1"));
            optOreDiamondRule = parseRule(getString("optOreDiamondRule", "75/16/4/2/8/1    100/32/2/128/2/11 10/120/16/2/8/1"));
            mods++;
        }
        // teleport mod
        if((modTeleportEnabled = getBool("modTeleportEnabled", false))==true) {
            log("info: loading config for \"teleport\"");
            parse(new ArrayList(), "names.txt", NAMEMAP);
            teleportNames = pNames;
            String got;
            got = getString("optTeleportItem", "blockI");    optTeleportItem    = teleportNames.containsKey(got) ? (Integer)teleportNames.get(got) : new Integer(got);
            got = getString("optTeleportPlayer", "blockG");  optTeleportPlayer  = teleportNames.containsKey(got) ? (Integer)teleportNames.get(got) : new Integer(got);
            got = getString("optTeleportCritter", "blockD"); optTeleportCritter = teleportNames.containsKey(got) ? (Integer)teleportNames.get(got) : new Integer(got);
            mods++;
        }
        // done
        if(mods==0 && !optBaseDisableWarning) err("warning: no mods are enabled! Read the readme.txt!");
        log("info: configuration loaded");
        // total fuckup log
        } catch(Exception error) {
            err("error: initialization failed", error);
        }
    }

    public static void initOverrides() {
        // overload FontRenderer - mc.? = new ?(mc.?, ..., mc.?) ? search "/font/default.png"
        log("info: init text"); mc.o = text = new ZFR(mc.y, "/font/default.png", mc.n);
        // overload RenderGlobal - n ? search: "Post startup" * f = new ?(this, n); just before viewport
        log("info: init render"); mc.f = render = new ZRG(mc, mc.n);
    }
    
    public static bz player;
    public static dn world;
    public static ll renderer;
    public static boolean isMenu, isMultiplayer, isHell;
    public static double posX, posY, posZ;
    public static double motionX, motionY, motionZ;
    public static nl inWhat;
    public static gl inv;
    public static gm invItems[];
    public static void pingUpdateHandle() {
        int i;
        if(keyPress(keyBaseInfo)) optBaseShowInfo = !optBaseShowInfo;
        // update state
        player = mc.g;          // Minecraft.player      : g    ? only field of that ("portal.trigger") type in mc
        world = mc.e;           // Minecraft.world : e ? only field of that ("Spawn) type
        renderer = mc.r;        // Minecraft.renderer : r ? only EntityRenderer (?glu) type field
        if(player == null || world == null || renderer == null) return;
        isMenu = mc.p != null;  // Minecraft.gui : p  ? search: if\([a-z]+ instanceof * take the one which has 2 matches
        isMultiplayer = mc.j(); // Minecraft.isMultiplayer : j ? search: public boolean [a-z]+\(\) * only match in Minecraft
        posX = getEntityPosX(player); posY = getEntityPosY(player); posZ = getEntityPosZ(player);
        motionX = player.aI; motionY = player.aJ; motionZ = player.aK; // search: "Motion" * aI, aJ, aK
        isHell = worldGetId((int)posX,127,(int)posZ)==7;
        inWhat = player.aA; // second Entity field in Entity ("Motion")
        inv = player.f; // search: . = new ..\(this\); * the one in constructor
        invItems = inv.a; // search: \[36\] * the one with 2 matches - found line assigns it
        // update "cloud"
        if(modCloudEnabled && !isMenu) {
            if(keyPress(keyCloudVanilla)) optCloudVanilla = !optCloudVanilla;
            if(keyPress(keyCloudToggle)) { if(optCloudVanilla) optCloudVanilla = false; else optCloudShow = !optCloudShow; }
            if(keyPress(keyCloudUp))     { if(optCloudVanilla) optCloudVanilla = false; else optCloudOffset += 1f; }
            if(keyPress(keyCloudDown))   { if(optCloudVanilla) optCloudVanilla = false; else optCloudOffset -= 1f; }
        }
        // update "cart"
        if(!isMultiplayer && modCartEnabled && (inWhat instanceof sd)) { // EntityMinecart : sd   ? search: "Fuel"
            double mx = inWhat.aI + motionX * optCartAcceleration, my = inWhat.aK + motionZ * optCartAcceleration; // update
            double speed = Math.sqrt(mx*mx+my*my), rate;
            if(!isMenu && keyPress(keyCartPerpetual)) {
                optCartPerpetual = !optCartPerpetual;
                if(optCartPerpetual) cartSpeed = speed;
            }
            if((speed > optCartSpeedAccumCap) || (optCartPerpetual && speed > 0.001d )) {
                rate = optCartPerpetual ? (cartSpeed / speed) : (optCartSpeedAccumCap / speed);
                mx *= rate; my *= rate;
            }
            if(!isMenu && keyDown(keyCartStop)) { mx = my = 0.0d; optCartPerpetual = false; }
            inWhat.aI = mx; inWhat.aK = my; // update
        }
        // update "wield"
        if(modWieldEnabled && !isMenu && keyPress(keyWield)) {
            int bow = -1, swd = -1, cur = getInvCur();
            boolean arrows = false;
            for(i=0;i<invItems.length;i++) {
                int id = invItems[i]==null ? 0 : getItemsId(invItems[i]);
                if(id==262) arrows = true;
                if(i<9) { if(id==261) bow = i; else if(id==268 || id==272 || id==267 || id==276) swd = i; }
            }
            if(!arrows) bow = -1;
            if(bow == -1) bow = swd; else if(swd == -1) swd = bow;
            int set = optWieldBowFirst ? bow : swd;
            if(cur == set) set = set==bow ? swd : bow;
            if(set != -1) setInvCur(set);
        }
        // update "build"
        if(!isMultiplayer && modBuildEnabled) {
            // Block.blockList : pj.m ? search: public static final [a-z]+ [a-z]+\[\]; * the one that is at the end of file
            //  .destroyTime   :  bj  ? search: 1.0F / [a-z]+ / 100F; * field is in the middle
            if(buildOriginal == null) {
                buildOriginal = new float[256];
                for(i=0;i<256;i++) if(pj.m[i] != null) buildOriginal[i] = pj.m[i].bj; // update
            }
            if(!isMenu) {
                if(keyPress(keyBuildToggle)) optBuild = !optBuild;
                if(optBuild) {
                    if(!buildActive) {
                        for(i=0;i<256;i++) if(pj.m[i] != null) pj.m[i].bj = (block[i] & TOUCH) != 0 ? buildOriginal[i] : 0.0f; // update
                        buildActive = true;
                    }
                    int set = -1;
                    if(keyDown(keyBuildA)) for(i=Keyboard.KEY_1;i<=Keyboard.KEY_9;i++) if(keyPress(i)) set = i - Keyboard.KEY_1;
                    if(keyDown(keyBuildB)) for(i=Keyboard.KEY_1;i<=Keyboard.KEY_9;i++) if(keyPress(i)) set = 9 + i - Keyboard.KEY_1;
                    if(set!=-1) for(int slot=0;slot<9;slot++) if(buildSets[set][slot]!=0) invItems[slot] = newItemsE(buildSets[set][slot], 16);
                }
            }
            if(optBuild && optBuildLockQuantity) for(i=0;i<invItems.length;i++) if(invItems[i]!=null) setItemsCount(invItems[i], 16);
        }
        if(buildActive && (!optBuild || isMultiplayer)) {
            for(i=0;i<256;i++) if(pj.m[i] != null) pj.m[i].bj = buildOriginal[i]; // update
            buildActive = false;
        }
        // update "compass"
        if(modCompassEnabled) {
            int cX = world.m, cY = world.n, cZ = world.o;       // update - World.spawn* : dd.m/n/o ? search: "Spawn
            int pX = (int)posX, pY = (int)posY, pZ = (int)posZ; // update
            if(!compassHaveOrig || ((cX!=compassOX || cY!=compassOY || cZ!=compassOZ) && (cX!=compassMX || cY!=compassMY || cZ!=compassMZ))) {
                compassOX = cX; compassOY = cY; compassOZ = cZ; compassHaveOrig = true;
            }
            if(!isMenu) {
                if(keyPress(keyCompassToggle)) compassShowOrig = !compassShowOrig;
                if(keyPress(keyCompassSet)) {
                    compassMX = pX; compassMY = pY; compassMZ = pZ;
                    compassHaveMine = true;
                    compassShowOrig = false;
                }
            }
            if(compassShowOrig) { cX = compassOX; cY = compassOY; cZ = compassOZ; } else { cX = compassMX; cY = compassMY; cZ = compassMZ; }
            world.m = cX; world.n = cY; world.o = cZ;           // update
        }
        // update "sun"
        if(modSunEnabled) {
            long time = world.e;                                // update - search for "Time" : e = je2.f("Time");
            if(!isMenu) {
                if(keyPress(keySunTimeAdd)) { if(sunTimeStop) sunTimeMoment += optSunTimeStep; sunTimeOffset += optSunTimeStep; }
                if(keyPress(keySunTimeSub)) { if(sunTimeStop) sunTimeMoment -= optSunTimeStep; sunTimeOffset -= optSunTimeStep; }
                if(keyPress(keySunStop)) { sunTimeStop = !sunTimeStop; if(sunTimeStop) sunTimeMoment = time; }
                if(keyPress(keySunTimeNormal)) { sunTimeStop = false; sunTimeOffset = 0; }
            }
            if(sunTimeStop) { sunTimeOffset -= time - sunTimeMoment; sunTimeMoment = time; }
        }
        // update "fly"
        if(modFlyEnabled && !isMenu) {
            if(keyPress(keyFlyToggle)) fly = !fly;
            else if(keyDown(keyFlyOn)) fly = true;
            else if(keyDown(keyFlyOff)) fly = false;
        }
        // update "path"
        if(modPathEnabled && !isMenu) {
            if(keyPress(keyPathShow)) optPathShow = !optPathShow;
            if(keyPress(keyPathDelete)) pathCount = 0;
        }
        // update "recipe"
        if(modRecipeEnabled) {
            setValue(fCMRecipes, cmanager, isMultiplayer ? recipesMP : recipesSP);
        }
        // update "safe"
        if(modSafeEnabled && !isMenu && keyPress(keySafeShow)) {
            safeShow = !safeShow;
        }
        // update "spawn"
        if(modSpawnEnabled && !isMultiplayer) {
            List list = getEntities();
            Iterator it = list.iterator();
            int mask = 0;
            if(!optSpawnAllowOnGrass) mask |= GRASS;
            if(!optSpawnAllowOnCobble) mask |= COBBLE;
            if(!optSpawnAllowOnSand) mask |= SAND;
            if(!optSpawnAllowOnGravel) mask |= GRAVEL;
            if(!optSpawnAllowOnTree) mask |= TREE;
            if(!optSpawnAllowOnNonNatural) mask |= CRAFT;
            while(it.hasNext()) {
                nl ent = (nl)it.next(); // update: entity : nl ? search "Pos"
                if(getEntityAge(ent)!=3) continue; // 3, just in case i miss the first beat or two
                boolean kill = false;
                switch(getEntityType(ent)) {
                    case GHAST:     if(optSpawnGhastReduction     != 0 && rnd.nextInt(100)<optSpawnGhastReduction    ) kill = true; break;
                    case COW:       if(optSpawnCowReduction       != 0 && rnd.nextInt(100)<optSpawnCowReduction      ) kill = true; break;
                    case SPIDER:    if(optSpawnSpiderReduction    != 0 && rnd.nextInt(100)<optSpawnSpiderReduction   ) kill = true; break;
                    case SHEEP:     if(optSpawnSheepReduction     != 0 && rnd.nextInt(100)<optSpawnSheepReduction    ) kill = true; break;
                    case SKELLY:    if(optSpawnSkeletonReduction  != 0 && rnd.nextInt(100)<optSpawnSkeletonReduction ) kill = true; break;
                    case CREEPER:   if(optSpawnCreeperReduction   != 0 && rnd.nextInt(100)<optSpawnCreeperReduction  ) kill = true; break;
                    case ZOMBIE:    if(optSpawnZombieReduction    != 0 && rnd.nextInt(100)<optSpawnZombieReduction   ) kill = true; break;
                    case SLIME:     if(optSpawnSlimeReduction     != 0 && rnd.nextInt(100)<optSpawnSlimeReduction    ) kill = true; break;
                    case PIG:       if(optSpawnPigReduction       != 0 && rnd.nextInt(100)<optSpawnPigReduction      ) kill = true; break;
                    case CHICKEN:   if(optSpawnChickenReduction   != 0 && rnd.nextInt(100)<optSpawnChickenReduction  ) kill = true; break;
                    case SQUID:     if(optSpawnSquidReduction     != 0 && rnd.nextInt(100)<optSpawnSquidReduction    ) kill = true; break;
                    case PIGZOMBIE: if(optSpawnPigZombieReduction != 0 && rnd.nextInt(100)<optSpawnPigZombieReduction) kill = true; break;
                    case LIVING:    if(!optSpawnSupportMods) continue; break;
                    default: continue;
                }
                if(!kill) {
                    int x = (int)getEntityPosX(ent), y = (int)getEntityPosY(ent), z = (int)getEntityPosZ(ent);
                    if(!optSpawnAllowInNonAir && (block[worldGetId(x,y,z)] & DECAL)!=0) kill = true;
                    if(mask!=0 && (block[worldGetId(x,y-1,z)] & mask)!=0) kill = true;
                }
                if(kill) ent.F(); // UPDATE: search: = 600; * next function calls setEntityDead : F
            }
        }
        // update "ore"
        if(modOreEnabled && !isMultiplayer && !isHell) {
            int cx = ((int)posX) >> 4, cz = ((int)posZ) >> 4, tx, ty, tz, id;
            for(int cxi=cx-3;cxi<=cx+3;cxi++) for(int czi=cz-3;czi<=cz+3;czi++) {
                tx = (cxi<<4)+3; ty = (czi<<4)+3;
                byte data[] = worldGetChunkData(cxi, czi);
                if(data[1024] != 7) continue; // already done
                data[1024] = 0; data[1025] = 7; // mark the chunk done
                for(i=0;i<data.length;i++) {
                    id = data[i];
                    if((block[id] & ORE) != 0) data[i] = 1;
                    else if(id == 7 && (i & 127) > 1) data[i] = optOreLavaFloor ? (byte)11 : (byte)1;
                    else if((i & 127) == 1) data[i] = 7;
                }
                oreDistribute(data, optOreCoalRule   , (byte)16);
                oreDistribute(data, optOreIronRule   , (byte)15);
                oreDistribute(data, optOreGoldRule   , (byte)14);
                oreDistribute(data, optOreBlueRule   , (byte)21);
                oreDistribute(data, optOreRedRule    , (byte)73);
                oreDistribute(data, optOreDiamondRule, (byte)56);
                chunkNeedsUpdate(cxi, czi); // request update
            }
        }
        // update "teleport"
        if(modTeleportEnabled && !isMultiplayer) {
            List list = getEntities();
            Iterator it = list.iterator();
            int type, x, y, z, id, ofs;
            
            try { // hack
            
            while(it.hasNext()) {
                nl ent = (nl)it.next(); // update: entity : nl ? search "Pos"
                type = getEntityType(ent);
                x = (int)getEntityPosX(ent); y = (int)getEntityPosY(ent) - 1; z = (int)getEntityPosZ(ent); ofs=0;
                id = worldGetId(x,y,z);
                if((block[id] & SOLID) == 0) { id = worldGetId(x,--y,z); ofs++; }
                if(type == 0 && (id != optTeleportItem || !(ent instanceof fh))) continue; // UPDATE: ? "Age"
                if(type != 0 && type != PLAYER && id != optTeleportCritter) continue;
                if(type == PLAYER && id != optTeleportPlayer) continue;
                String sign[] = null;
                id = worldGetId(x, y+1, z); if(id == 63 || id == 68) sign = getSignText(x, y+1, z);
                id = worldGetId(x, y+2, z); if(id == 63 || id == 68) sign = getSignText(x, y+2, z);
                if(sign == null) continue;
                // TODO ... perhaps optimize the string handling out of it
                x = 0; y = -1; z = 0;
                for(i=0;i<sign.length;i++) if(sign[i]!=null && sign[i].length()>1) {
                    if(sign[i].charAt(0)=='!') {
                        String part[] = sign[i].substring(1).split(",");
                        if(part.length != 3) break;
                        x = new Integer(part[0]);
                        y = new Integer(part[1]);
                        z = new Integer(part[2]);
                    } else if(sign[i].charAt(0)=='?') {
                        String filter = sign[i].substring(1);
                        id = teleportNames.containsKey(filter) ? (Integer)teleportNames.get(filter) : parseIdInfo(filter);
                        id &= 0xffff; // stip "damage" / info
                        if(type != 0 && type != PLAYER && id == type) continue; // mob filter match
                        if(type == 0 && getItemsId(((fh)ent).a) == id) continue; // item filter match: UPDATE: ? "Age" * only itemstack type field there
                        y=-1; break;
                    }
                }
                if(y==-1) continue;
                // TODO ... check target coordinates
                setEntityPos(ent, 0.5+x, 0.5+(y+ofs), 0.5+z);
                if(type==PLAYER) world.a(ent, "mob.slime", 0.4f,( (rnd.nextFloat() - rnd.nextFloat())*0.2f + 1.0f )*0.8f); // "mob.slime"
                break; // this will not help against ConcurrentModificationException :/
            }
            
            } catch(ConcurrentModificationException why) {} // hack to prevent it from dying
            
        }
    }
    
    private static void oreDistribute(byte data[], int rule[], byte result) {
        int i, chunk, max, min, attempt, size, above, x, y, z, at, cnt;
        for(i=0;i<rule.length;i+=6) {
            chunk = rule[i + 0];
            max = rule[i + 1];
            min = rule[i + 2];
            attempt = rule[i + 3];
            size = rule[i + 4];
            above = rule[i + 5];
            if(chunk<100 && rnd.nextInt(100)>=chunk) continue;
            while(attempt-->0) {
                x = rnd.nextInt(14)+1; y = rnd.nextInt(1+max-min) + min; z = rnd.nextInt(14)+1;
                at = x<<11 | z<<7 | y;
                if(data[at]!=1 || data[at-1]!=1 || data[at+1]!=above || data[at+128]!=1 || data[at-128]!=1 || data[at+2048]!=1 || data[at-2048]!=1) continue;
                cnt = size - 1;
                data[at] = result;
                while(cnt-->0) {
                    switch(rnd.nextInt(7)) {
                        case 0: continue;
                        case 1: at += 1; break;
                        case 2: at -= 1; break;
                        case 3: at += 128; break;
                        case 4: at -= 128; break;
                        case 5: at += 2048; break;
                        case 6: at -= 2048; break;
                    }
                    if(at<0) at += 32768; else if(at>=32768) at -= 32768;
                    if(data[at]==1) data[at] = result;
                }
            }
        }
    }

    private static final void worldSetId(int x, int y, int z, int id) { world.b(x,y,z,id); } // search: [a-zA-Z]+\([a-zA-Z0-9]+ \+ [a-zA-Z0-9]+, [a-zA-Z0-9]+ \+ [a-zA-Z0-9]+, [a-zA-Z0-9]+ \+ [a-zA-Z0-9]+, [a-zA-Z0-9]+ < 4 \? [a-zA-Z0-9_]+ : 0\);
    private static final byte[] worldGetChunkData(int cx, int cz) { return world.c(cx, cz).b; } // search: return [a-zA-Z]+\([a-z0-9]+ >> 4, [a-z0-9]+ >> 4\)\.[a-zA-Z]+\([a-z0-9]+ & 0xf, [a-z0-9]+, [a-z0-9]+ & 0xf\);

    // Entity : nl ? search: "Pos"
    public static final int GHAST=1, COW=2, SPIDER=3, SHEEP=4, SKELLY=5, CREEPER=6, ZOMBIE=7, SLIME=8, PIG=9, CHICKEN=10, SQUID=11, PIGZOMBIE=12, PLAYER=13, LIVING=14;
    public static int getEntityType(Object ent) {
        if(ent instanceof eu) return PLAYER; // char - ensure it is player
        if(ent instanceof av) return GHAST;
        if(ent instanceof bb) return COW;
        if(ent instanceof bn) return SPIDER;
        if(ent instanceof ch) return SHEEP;
        if(ent instanceof dy) return SKELLY;
        if(ent instanceof eh) return CREEPER;
        if(ent instanceof jv || ent instanceof pn) return ZOMBIE;
        if(ent instanceof pl) return SLIME;
        if(ent instanceof qk) return PIG;
        if(ent instanceof qs) return CHICKEN;
        if(ent instanceof rm) return SQUID;
        if(ent instanceof rt) return PIGZOMBIE;
        if(ent instanceof ig) return LIVING; // char - ensure it is not player
        return 0;
    }
    private static final int getEntityAge(Object ent) { return ((nl)ent).bn; } // search: [a-z]+ % 20\) \* 12 == 0

    private static long prevTick, curTick;
    private static float seconds;
    public static void pingDrawHandle(float delta) {
        if(player == null || world == null || renderer == null) return;
        // update player position
        posX = getEntityPosX(player); posY = getEntityPosY(player); posZ = getEntityPosZ(player);
        // update time
        curTick = System.nanoTime();
        float seconds = ((float)(curTick - prevTick)) * 0.000000001f;
        if(seconds > 1f) seconds = 0f;
        prevTick = curTick;
        // draw in 3d
        if( modPathEnabled || modSafeEnabled) {
            float px = (float)posX, py = (float)posY, pz = (float)posZ;
            float mx = (float)player.be, my = (float)player.bf ,mz = (float)player.bg;   // update - Player.prevPos? : be, bf, bg ? search "Pos" ... next function has ? = prevPosX = posX
            float x = mx + ( px - mx ) * delta, y = my + ( py - my ) * delta, z = mz + ( pz - mz ) * delta;
            // draw "path"
            if(modPathEnabled) {
                // get previous location
                float tx = pathf[pathLast] - px, ty = pathf[pathLast+1] - (py - 1.25f), tz = pathf[pathLast+2] - pz;
                float dist = tx*tx + ty*ty + tz*tz;
                // do we have a new pathpoint
                if(dist > optPathMin) {
                    pathLast += 3; if(pathLast >= pathf.length) pathLast = 0;
                    if(pathCount < optPathPoints) pathCount++;
                    pathf[pathLast] = px;
                    pathf[pathLast+1] = py - 1.25f;
                    pathf[pathLast+2] = pz;
                }
                // draw the path?
                if(optPathShow && pathCount>3) {
                    pathAnimCur += seconds * optPathAnimSpeed;
                    if(pathAnimCur > optPathSpacing) pathAnimCur -= optPathSpacing;
                    float x1 = pathf[pathLast] - x, y1 = pathf[pathLast+1] - y, z1 = pathf[pathLast+2] - z, x2, y2, z2;
                    int cnt = pathCount-1, at = pathLast, anim = ((pathf.length - pathLast) / 3 + (int)pathAnimCur) % optPathSpacing;
                    int skip = 4;
                    GL11.glDisable(GL11.GL_TEXTURE_2D);
                    GL11.glColor3ub((byte)255,(byte)32,(byte)32);
                    GL11.glBegin(GL11.GL_LINES);
                        do {
                            x2 = x1; y2 = y1; z2 = z1;
                            at -= 3; if(at<0) at = pathf.length - 3;
                            x1 = pathf[at] - x; y1 = pathf[at+1] - y; z1 = pathf[at+2] - z;
                            if(optPathSpacing > 2) {
                                if(++anim == optPathSpacing) anim = 0;
                                if(anim <= 1 && skip < 0) { GL11.glVertex3f(x1,y1,z1); GL11.glVertex3f(x2,y2,z2); }
                            } else if(skip < 0) { GL11.glVertex3f(x1,y1,z1); GL11.glVertex3f(x2,y2,z2); }
                            skip--;
                        } while((--cnt) != 0);
                    GL11.glEnd();
                    GL11.glEnable(GL11.GL_TEXTURE_2D);
                }
            }
            // draw "safe"
            if(modSafeEnabled && safeShow) {
                if(--safeUpdate<0) {
                    safeUpdate = 16;
                    reCheckSafe((int)posX, (int)posY, (int)posZ);
                }
                GL11.glDisable(GL11.GL_TEXTURE_2D);
                GL11.glColor3ub((byte)255,(byte)0,(byte)0);
                GL11.glBegin(GL11.GL_LINES);
                for(int i=0;i<safeCur;i++) {
                    Mark got = safeMark[i];
                    mx = got.x - x; my = got.y - y; mz = got.z - z;
                    GL11.glVertex3f(mx+0.5f,my,mz+0.5f); GL11.glVertex3f(mx-0.5f,my,mz-0.5f);
                    GL11.glVertex3f(mx+0.5f,my,mz-0.5f); GL11.glVertex3f(mx-0.5f,my,mz+0.5f);
                }
                GL11.glEnd();
                GL11.glEnable(GL11.GL_TEXTURE_2D);
            }
        }
        // draw "cloud"
        if(modCloudEnabled && !optCloudVanilla) {
            if(optCloudShow) { // find in file that contains cloud
                double mov = player.bf; // save
                player.bf += ( player.aG - player.bf ) * delta - optCloudOffset; render.callSuper(0F); // adjusting equation: player.bf + (player.aG - player.bf) * f;
                player.bf = mov; // restore
            }
        } else {
            render.callSuper(delta);
        }
        // done
    }
    
    public static String pingTextHandle() {
        if(player == null || world == null || renderer == null) return "";
        String infoLine = "";
        // text for "cloud"
        if(modCloudEnabled && optCloudVanilla) infoLine += " " + tagCloudVanilla;
        // text for cart
        if(!isMultiplayer && modCartEnabled && optCartPerpetual) infoLine += " " + tagCartPerpetual;
        // text for build
        if(!isMultiplayer && modBuildEnabled && optBuild) infoLine += " " + tagBuildEnabled;
        // text for compass
        if(modCompassEnabled) {
            if(optCompassShowPos) infoLine += " (" + (int)posX + "," + (int)posY + "," + (int)posZ + ")";
            if(!compassShowOrig) infoLine += " " + tagCompassAlternate;
        }
        // text for sun
        if(modSunEnabled && sunTimeOffset!=0) infoLine += " " + tagSunTime + (sunTimeOffset<0 ? "" : "+") + (sunTimeOffset/20);
        // text for fly
        if(modFlyEnabled && fly) infoLine += " " + tagFly;
        // text for recipe
        if(modRecipeEnabled && optRecipeShowId) infoLine += invItems[getInvCur()]==null ? "" : ( " id:" + getItemsId(invItems[getInvCur()]) + "/" + getItemsInfo(invItems[getInvCur()]) );
        // text for safe
        if(modSafeEnabled && safeShow) infoLine += " " + tagSafe;
        // done
        return infoLine;
    }
    
    // ---------------------------------------------------------------------------------------------------------------- safe
    private static final boolean spawnCheckA(int id) { return pj.m[id]==null ? false : pj.m[id].a(); } // UPDATE: spawnCheckA* : ? find spawn check line in CritterSpawnde (?completed) - find the used function in word

    private static void reCheckSafe(int pX, int pY, int pZ) { // UPDATE
        safeCur = 0;
        int id, maskA = SPAWN, maskB = SPAWN | LIQUID | SOLID, maskC = SPAWN, maskL = 0;
        if(modSpawnEnabled && !isMultiplayer) {
            if(!optSpawnAllowInNonAir) maskB |= DECAL;
            if(!optSpawnAllowOnNonNatural) maskL |= CRAFT;
            if(!optSpawnAllowOnGrass) maskL |= GRASS;
            if(!optSpawnAllowOnCobble) maskL |= COBBLE;
            if(!optSpawnAllowOnSand) maskL |= SAND;
            if(!optSpawnAllowOnGravel) maskL |= GRAVEL;
            if(!optSpawnAllowOnTree) maskL |= TREE;
        }
        for(int x=pX-16;x<pX+16;x++) for(int y=pY-16;y<pY+16;y++) for(int z=pZ-16;z<pZ+16;z++) {
            int onWhat;
            if(((onWhat = block[worldGetId(x,y,z)]) & maskA) == 0) continue; // !dn1.g(i, j - 1, k)
            if((onWhat & maskL) != 0) continue; // spawn limitations from "spawn" mod
            if((block[worldGetId(x,y+1,z)] & maskB) != 0) continue; // dn1.g(i, j, k) || dn1.f(i, j, k).d()
            if((block[worldGetId(x,y+2,z)] & maskC) != 0) continue; // dn1.g(i, j + 1, k)
            // light level check
            if(world.c(x >> 4, z >> 4).c(x & 0xf, y+1, z & 0xf, 16) > 7) continue;      // update ... ugh ... where do i find it? FIXME
            safeMark[safeCur++] = new Mark(x,y+1,z);
            if(safeCur == safeMax) return;
        }
    }

    // ---------------------------------------------------------------------------------------------------------------- fly
    public static double flyMX, flyMY, flyMZ;
    public static void calculate(double motionX, double motionY, double motionZ) {
        flyMX = motionX;  flyMY = motionY;  flyMZ = motionZ;
        if(!fly) return;
        flyMY = 0d;
        if(!isMenu) {
            if(keyDown(keyFlyUp)) flyMY += optFlySpeedVertical;
            if(keyDown(keyFlyDown)) flyMY -= optFlySpeedVertical;
            double mul = keyDown(keyFlySpeed) ? optFlySpeedMulModifier : optFlySpeedMulNormal;
            flyMX*=mul; flyMY*=mul; flyMZ*=mul;
        }
    }

    // ================================================================================================================ helpers
    public static final int worldGetId(int x, int y, int z) { return world.a(x,y,z); } // ???
    private static final gm newItemsE(int id, int count) { return newItems(id & 0xffff, count, id >> 16); }
    private static final gm newItems(int id, int count, int param) { return new gm(id, count, param == 9999 ? -1 : param); } // ItemStack     : gm ? search: "Damage"
    private static final gm newItems(int id, int count) { return newItems(id, count, 0); }
    private static final int getInvCur() { return inv.c; } // .currentItem : c ? only int field in class (\[36\])
    private static final void setInvCur(int cur) { inv.c = cur; }
    private static final int getItemsId(Object items) { return ((gm)items).c; } // ItemStack.itemID      : c    ? search: "id" * has ItemId = ??.?("id"); in it
    private static final void setItemsCount(Object items, int cnt) { ((gm)items).a = cnt; } // search: "Count"
    private static final int getItemsInfo(Object items) { return ((gm)items).i(); } // returns d / "Damage"
    private static final String[] getSignText(int x, int y, int z) { return getSign(x,y,z).a; } // search: "Text1"
    private static final sc getSign(int x, int y, int z) { return (sc)world.b(x,y,z); } // search: \(class-name\) * C c1 = (C)world.?(x,y,z)
    private static final List getEntities() { return world.b; } // update: entities : b ? seacrh: "Player count: " * ?.add below found line
    private static final void setEntityPos(nl ent, double x, double y, double z) { // search: "Pos"    * aF, aG, aH
        ent.b(0.0, 0.0, 0.0);
        ent.aC = ent.be = ent.aF = x;
        ent.aD = ent.bf = ent.aG = y;
        ent.aE = ent.bg = ent.aH = z;
        ent.b(x, y, z);
   }
    private static final double getEntityPosX(nl ent) { return ent.aF; }
    private static final double getEntityPosY(nl ent) { return ent.aG; }
    private static final double getEntityPosZ(nl ent) { return ent.aH; }
    private static final void chunkNeedsUpdate(int cx, int cz) { cx <<= 4; cz <<= 4; world.b(cx, 0, cz, cx+15, 127, cz+15); } // update: in world ? search: public void [a-z]+\(int[^,]+, int[^,]+, int[^,]+, int[^,]+, int[^,]+, int[^,]+\)

    // ================================================================================================================ log
    public static void log(String text) {
        out.println(text);
    }

    public static void err(String text) {
        if(firstError == null) firstError = text;
        log(text);
        setMsg("ZMerror", "ZMod: errors detected - one or more mods affected\nFirst "+firstError+"\nLog: "+logPath,2,36,0xff8888);
    }

    public static void err(String text, Exception e) {
        err(text);
        log("### Exception: " + e.toString());
        e.printStackTrace(out);
    }
    
    // ================================================================================================================ config
    public static int getBind(String name, int init) {
        String val = conf.getProperty(name);
        if(val == null || val.equals("")) return init;
        int i = Keyboard.getKeyIndex(val);
        if(i == Keyboard.KEY_NONE) { err("error: config.txt @ "+name+" - invalid key name \""+val+"\""); return init; }
        return i;
    }

    public static float getFloat(String name, float init, float min, float max) {
        String val = conf.getProperty(name);
        if(val == null) return init;
        float f = new Float(val);
        if(f<min || f>max) { err("error: config.txt @ "+name+" - must be between "+min+" and "+max); return init; }
        return f;
    }

    public static int getInt(String name, int init, int min, int max) {
        String val = conf.getProperty(name);
        if(val == null) return init;
        int i = new Integer(val);
        if(i<min || i>max) { err("error: config.txt @ "+name+" - must be between "+min+" and "+max); return init; }
        return i;
    }

    public static String getString(String name, String init) {
        String val = conf.getProperty(name);
        if(val == null) return init;
        return val;
    }

    public static boolean getBool(String name, boolean init) {
        String val = conf.getProperty(name);
        if(val == null) return init;
        if(val.equals("1") || val.equals("yes") || val.equals("true") || val.equals("on")) return true;
        if(val.equals("0") || val.equals("no") || val.equals("false") || val.equals("off")) return false;
        err("error: config.txt @ "+name+" - must be one of (1, yes, true, on, 0, no, false, off)");
        return init;
    }
    
    // ================================================================================================================ reflect
    private static void reportException(Exception error) {
        if(exceptionReported) return;
        exceptionReported = true;
        err("exception in reflection code encountered !", error);
    }
    public static Field getField(Class c, String name) { try { Field field = c.getDeclaredField(name); field.setAccessible(true); return field; } catch(Exception error) { reportException(error); } return null; }
    public static Object getValue(Field field, Object obj) { try { return field.get(obj); } catch(Exception error) { reportException(error); } return null; }
    public static void setValue(Field field, Object obj, Object val) { try { field.set(obj, val); } catch(Exception error) { reportException(error); } }
    public static Class getClass(String name) { try { return Class.forName(name); } catch(Exception error) { reportException(error); } return null; }
    public static Constructor getConstructor(Class c, Class param[]) { try { return c.getConstructor(param); } catch(Exception error) { reportException(error); } return null; }
    public static Method getMethod(Class c, String name, Class param[]) { try { Method method = c.getDeclaredMethod(name, param); method.setAccessible(true); return method; } catch(Exception error) { reportException(error); } return null; }
    public static Method getMethod(Class c, String name) { return getMethod(c,name,new Class[]{}); }
    public static Method getMethod(Class c, String name, Class p1) { return getMethod(c,name,new Class[]{p1}); }
    public static Method getMethod(Class c, String name, Class p1, Class p2) { return getMethod(c,name,new Class[]{p1,p2}); }
    public static Method getMethod(Class c, String name, Class p1, Class p2, Class p3) { return getMethod(c,name,new Class[]{p1,p2,p3}); }
    public static Method getMethod(Class c, String name, Class p1, Class p2, Class p3, Class p4) { return getMethod(c,name,new Class[]{p1,p2,p3,p4}); }
    public static Object getNew(Constructor cc, Object param[]) { try { return cc.newInstance(param); } catch(Exception error) { reportException(error); } return null; }
    public static Object getNew(Constructor cc, Object p1) { return getNew(cc, new Object[]{p1}); }
    public static Object getNew(Constructor cc, Object p1, Object p2) { return getNew(cc, new Object[]{p1,p2}); }
    public static Object getNew(Constructor cc, Object p1, Object p2, Object p3) { return getNew(cc, new Object[]{p1,p2,p3}); }
    public static Object getNew(Constructor cc, Object p1, Object p2, Object p3, Object p4) { return getNew(cc, new Object[]{p1,p2,p3,p4}); }
    public static Object getNew(Class c) { try { return c.newInstance(); } catch(Exception error) { reportException(error); } return null; }
    public static Object getResult(Method m, Object obj, Object param[]) { try { return m.invoke(obj, param); } catch(Exception error) { reportException(error); } return null; }
    public static Object getResult(Method m) { return getResult(m, null, new Object[]{}); }
    public static Object getResult(Method m, Object obj) { return getResult(m, obj, new Object[]{}); }
    public static Object getResult(Method m, Object obj, Object p1) { return getResult(m, obj, new Object[]{p1}); }
    public static Object getResult(Method m, Object obj, Object p1, Object p2) { return getResult(m, obj, new Object[]{p1,p2}); }
    public static Object getResult(Method m, Object obj, Object p1, Object p2, Object p3) { return getResult(m, obj, new Object[]{p1,p2,p3}); }
    public static Object getResult(Method m, Object obj, Object p1, Object p2, Object p3, Object p4) { return getResult(m, obj, new Object[]{p1,p2,p3,p4}); }
    public static boolean checkClass(Class c) { try { Field field = c.getDeclaredField("zmodmarker"); return field != null; } catch(Exception whatever) { } return false; }

    // ================================================================================================================ util
    public static void delMsg(String tag) { text.delMsg(tag); }
    public static void setMsg(String msg) { setMsg("debug", msg, 50, 50, 0xffffff); }
    public static void setMsg(String tag, String msg, int x, int y) { setMsg(tag, msg, x, y, 0xffffff); }
    public static void setMsg(String tag, String msg, int x, int y, int color) { text.setMsg(tag, msg, x, y, color); }
    public static boolean keyPress(int key) { boolean res = !keys[key]; return (keys[key] = Keyboard.isKeyDown(key)) && res; }
    public static boolean keyDown(int key) { return Keyboard.isKeyDown(key); }

    // ================================================================================================================ parser
    private static HashMap pNames;
    private static HashSet<String> pFiles;
    private static List pList;

    private static void parse(List list, String file, int section) {
        pList = list;
        pNames = new HashMap();
        pFiles = new HashSet<String>();
        parseFile(file, section);
    }
    
    private static final int IGNORE = 0, NAMEMAP = 1, RECIPES = 2;
    private static void parseFile(String file, int section) {
        if(!pFiles.add(file)) {
            err("error: recursion detected - \""+file+"\" is already included");
            return;
        }
        String data = "", fn = path + file;
        try {
            byte[] buffer = new byte[(int) new File(fn).length()];
            BufferedInputStream stream = new BufferedInputStream(new FileInputStream(fn));
            stream.read(buffer);
            stream.close();
            data = new String(buffer);
            log("info: parsing \""+file+"\"");
        } catch(Exception error) {
            err("error: failed to load \""+file+"\"", error);
            data = "";
        }
        String lines[] = data.split("\\r?\\n");
        int at;
        for(int line=0;line<lines.length;line++) {
            if(lines[line].startsWith("[IGNORE]")) section = IGNORE;
            else if(lines[line].startsWith("[NAMEMAP]")) section = NAMEMAP;
            else if(lines[line].startsWith("[RECIPES]")) section = RECIPES;
            else if(lines[line].startsWith("[NAMEMAP=")) parseFile(lines[line].substring(9).replaceAll("\\].*\\z",""), NAMEMAP);
            else if(lines[line].startsWith("[RECIPES=")) parseFile(lines[line].substring(9).replaceAll("\\].*\\z",""), RECIPES);
            else if(section == NAMEMAP) parseNames(lines[line], file, line + 1);
            else if(section == RECIPES) parseRecipe(lines[line], file, line + 1);
        }
    }
    
    private static int parseIdInfo(String text) {
        try {
            String part[] = text.split("/");
            if(part.length>2) return -1;
            int id = Integer.decode(part[0]);
            if(part.length==2) {
                int info = Integer.decode(part[1]);
                if(info<0) info = 9999;
                id += info << 16;
            }
            return id;
        } catch(Exception error) {
            return -1;
        }
    }

    private static void parseNames(String src, String file, int line) {
        String got[] = src.replaceAll("\\A[\\t ]*","").replaceAll("[\\t ]*(|//.*)\\z","").split("[ \\t]+");
        if((got.length & 1) != 0) {
            if(got.length != 1 && !got[0].equals("")) err("error: "+file+" @ line#" + line + " \"" + src + "\" - incomplete name definition");
        } else for(int at=0;at<got.length;at+=2) {
            int id = parseIdInfo(got[at+1]);
            if(id==-1) err("error: "+file+" @ line#" + line + " \"" + src + "\" - non numbers in name definition");
            else pNames.put(got[at], id);
        }
    }
    
    // CraftingRecipe   : gj   ? b.add(new gj(?, ?, ?, ?));
    //   .matchRecipe   : a    ? only function there that returns bool and takes one parameter
    private static void addRecipe(int width, int height, gm recipeMap[], int id, int count) {
        boolean normal = height > 0;
        gm search[] = recipeMap;
        List list = null;
        if(!normal) {
            search = new gm[9];
            list = new ArrayList();
            for(int i=0;i<recipeMap.length;i++) list.add(search[i] = recipeMap[i]);
            width = height = 3;
        }
        jb match = new jb(null, width, height);
        setValue(fCBTable, match, search);
        // find and remove match
        for(int i=0;i<pList.size();i++) if(((cn)pList.get(i)).a(match)) pList.remove(i);   // update: cn - CraftingRecipe's interface
        // add new
        if(id!=0) pList.add( normal
            ? new gj(width, height, recipeMap, newItemsE(id, count))  // update
            : new om(newItemsE(id, count), list)                      // update
        );
    }

    private static void parseRecipe(String src, String file, int line) {
        String trouble = ""; // parsing trouble - will contain the offending substring
        String got[] = src.replaceAll("\\A[\\t ]*","").replaceAll("[\\t ]*(|//.*)\\z","").split("[ \\t]+");
        if(got.length < 5) {
            if(got.length != 1 && !got[0].equals("")) log("error: "+file+" @ line#" + line + " \"" + src + "\" - incomplete recipe definition");
            return;
        }
        try {
            trouble = got[0];
            int width = Integer.decode(got[2]), height = Integer.decode(got[3]), count = Integer.decode(got[1]);
            int itemnr = pNames.containsKey(got[0]) ? (Integer)pNames.get(got[0]) : parseIdInfo(got[0]);
            if(itemnr<0 || count<0 || (itemnr>0 && count<=0)) {
                err("error: "+file+" @ line#" + line + " \"" + src + "\" - bad recipe result");
                return;
            }
            if(height != 0 && (width*height+4 != got.length || width <= 0 || height <= 0 || width > 3 || height > 3)) {
                err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid recipe size (" + width + "," + height + ")");
                return;
            } else if(height == 0 && (width+4 != got.length || width <= 0)) {
                err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid recipe size (" + width + ")");
                return;
            }
            gm recipeMap[] = new gm[width*(height==0?1:height)];
            for(int at=4;at<got.length;at++) {
                trouble = got[at];
                int value = pNames.containsKey(got[at]) ? (Integer)pNames.get(got[at]) : parseIdInfo(got[at]);
                if(value == -1 || (height==0 && value==0)) throw new Exception("("+value+" "+got[at]+" "+(pNames.containsKey(got[at])?"+":"-")+")");
                recipeMap[at - 4] = value<=0 ? null : newItemsE(value, 1);
            }
            addRecipe(width, height, recipeMap, itemnr, count);
        } catch(Exception whatever) {
            err("error: "+file+" @ line#" + line + " \"" + src + "\" - \"" + trouble + "\" is unknown or malformed");
            err("???",whatever);
        }
    }

    private static int[] parseRule(String rule) {
        String got[] = rule.split("[\t ]+"), part[];
        int res[] = new int[got.length * 6];
        for(int i=0;i<got.length;i++) {
            part = got[i].split("/");
            if(part.length != 6) { modOreEnabled = false; err("error : ore-mod disabled - invalid ore rule found \""+rule+"\""); continue; }
            res[i*6 + 0] = new Integer(part[0]);
            res[i*6 + 1] = new Integer(part[1]);
            res[i*6 + 2] = new Integer(part[2]);
            res[i*6 + 3] = new Integer(part[3]);
            res[i*6 + 4] = new Integer(part[4]);
            res[i*6 + 5] = new Integer(part[5]);
        }
        return res;
    }

}
