
import net.minecraft.client.Minecraft;

// search:  = 32D;
public final class ZER extends iw {

    public ZER(Minecraft minecraft, iw prev) {
        super(minecraft);
        c = prev.c;
        d = prev.d;
        //m = prev.m;
    }

    public void b(float f1) {
        super.b(f1);
        ZMod.pingDrawGUIHandle(f1);
    }
    
    // search: environment/snow.png
    protected void c(float f1) {
        if(ZMod.drawRainHandle()) super.c(f1);
    }

}
