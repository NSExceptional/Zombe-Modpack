
import java.util.Random;

// BlockBookshelf
public final class ZBB extends dy {

    public ZBB() {
        super(47, 35);
        c(1.5F).a(e).a("bookshelf"); // "bookshelf" * drop the last function.
    }

    public int a(Random random) { // only function with random
        return 1;
    }

}
