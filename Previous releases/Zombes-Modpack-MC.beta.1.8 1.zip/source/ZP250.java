
import java.io.DataInputStream;
import java.io.DataOutputStream;

// search: "Received string length is less than zero! Weird string!"
public class ZP250 extends vl {

	public eq nbtData;
	public ZP250(){}

    // last 4 abstract methods in parent class
    // search: "TAG_End"  * gives the nbt class - find the class dealing with compounds + code/decode in its parent class (takes Data* as parameter)

	public void a(DataInputStream in) {
		nbtData = (eq)xb.b(in);
	}

	public void a(DataOutputStream out) {
		xb.a(nbtData, out);
	}

	public void a(kx handler) {
		ZMod.packet250Handle(this);
	}

    // packet size
	public int a() {
		return 1;
	}

	public static void init(){
		a(250, true, true, ZP250.class); // found in parent class
	}
}
