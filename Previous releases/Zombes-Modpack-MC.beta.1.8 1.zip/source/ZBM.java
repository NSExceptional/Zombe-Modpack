
import java.util.Random;

// BlockMobSpawner
public final class ZBM extends bp {

    public ZBM() {
        super(52, 65);
        c(5F).a(i).a("mobSpawner").r(); // "mobSpawner"
    }
    
    // the one in parent-parent class that has a function call in parameters
    public void a(rv map, int x, int y, int z) {
        super.a(map, x, y, z);
        String mob = ZMod.mobTypeHandle();
        if(mob == null) return;
        bn spawner = (bn)(map.b(x,y,z)); // get tileEntity (class: "EntityId")
        spawner.a(mob); // set spawner
    }

    public int a(int i, Random random) { // both in parent class
        return ZMod.spawnderDropHandle() ? 52 : 0;
    }
    
    public int a(Random random) {
        return ZMod.spawnderDropHandle() ? 1 : 0;
    }

}
