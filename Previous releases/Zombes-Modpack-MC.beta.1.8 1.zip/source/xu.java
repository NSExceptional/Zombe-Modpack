// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb safe 
// Source File Name:   SourceFile

import net.minecraft.client.Minecraft;

// search: = -180F * the one without "false" in constructor (most likely the first matching)
// NEED TO DECOMPILE SEPARATELY WITH SAFE MODE ON
public class xu extends hw {

    protected static final boolean zmodmarker = true;

    public xu(Minecraft minecraft) {
        super(minecraft);
        c = -1;
        d = -1;
        e = -1;
        f = 0.0F;
        g = 0.0F;
        h = 0.0F;
        i = 0;
    }

    public void a(sz sz1) {
        sz1.u = -180F;
    }

    public boolean d() {
        return true;
    }

    public boolean b(int j, int k, int l, int i1) {
        int j1 = a.f.a(j, k, l);
        int k1 = a.f.e(j, k, l);
        boolean flag = super.b(j, k, l, i1);
        ul ul1 = a.h.aj();
        boolean flag1 = a.h.b(lr.m[j1]);
        // -----------------------------------------------------------------------------------------------------------------------
        flag = ZMod.harvestableHandle(flag);
        // -----------------------------------------------------------------------------------------------------------------------
        if(ul1 != null) {
            ul1.a(j1, j, k, l, ((sz) (a.h)));
            if(ul1.a == 0) {
                ul1.a(((sz) (a.h)));
                a.h.ak();
            }
        }
        if(flag && flag1)
            lr.m[j1].a(a.f, ((sz) (a.h)), j, k, l, k1);
        return flag;
    }

    public void a(int j, int k, int l, int i1) {
        if(!a.h.e(j, k, l))
            return;
        a.f.a(((sz) (a.h)), j, k, l, i1);
        int j1 = a.f.a(j, k, l);
        if(j1 > 0 && f == 0.0F)
            lr.m[j1].a(a.f, j, k, l, ((sz) (a.h)));
        if(j1 > 0 && lr.m[j1].a(((sz) (a.h))) >= 1.0F)
            b(j, k, l, i1);
    }

    public void a() {
        f = 0.0F;
        i = 0;
    }

    public void c(int j, int k, int l, int i1) {
        if(i > 0) {
            i--;
            return;
        }
        if(j == c && k == d && l == e) {
            int j1 = a.f.a(j, k, l);
            if(!a.h.e(j, k, l))
                return;
            if(j1 == 0)
                return;
            lr lr1 = lr.m[j1];
            // -------------------------------------------------------------------------------------------------------------------
            float add;
            f += add = ZMod.digProgressHandle( lr1.a(((sz) (a.h))), j1 );
            int skip = add > 1.0f ? (int)(6f / add - 0.99999f) : 5;
            // -------------------------------------------------------------------------------------------------------------------
            if(h % 4F == 0.0F && lr1 != null)
                a.B.b(lr1.bL.d(), (float)j + 0.5F, (float)k + 0.5F, (float)l + 0.5F, (lr1.bL.b() + 1.0F) / 8F, lr1.bL.c() * 0.5F);
            h++;
            if(f >= 1.0F) {
                b(j, k, l, i1);
                f = 0.0F;
                g = 0.0F;
                h = 0.0F;
                i = skip; // ****** UPDATE ******
            }
        } else {
            f = 0.0F;
            g = 0.0F;
            h = 0.0F;
            c = j;
            d = k;
            e = l;
        }
    }

    public void a(float f1) {
        if(f <= 0.0F) {
            a.v.b = 0.0F;
            a.g.g = 0.0F;
        } else {
            float f2 = g + (f - g) * f1;
            a.v.b = f2;
            a.g.g = f2;
        }
    }

    public float b() {
        // -----------------------------------------------------------------------------------------------------------------------
        return ZMod.digReachHandle();
        // -----------------------------------------------------------------------------------------------------------------------
    }

    public void a(rv rv1) {
        super.a(rv1);
    }

    public sz b(rv rv1) {
        sz sz1 = super.b(rv1);
        return sz1;
    }

    public void c() {
        g = f;
        a.B.c();
    }

    public boolean a(sz sz1, rv rv1, ul ul1, int j, int k, int l, int i1) {
        int j1 = rv1.a(j, k, l);
        if(j1 > 0 && lr.m[j1].b(rv1, j, k, l, sz1))
            return true;
        if(ul1 == null)
            return false;
        else
            return ul1.a(sz1, rv1, j, k, l, i1);
    }

    public boolean f() {
        return true;
    }

    private int c, d, e, i;
    private float f, g, h;
}
