// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.util.Random;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

// search: "deadmau5" * the one with simpler IF
public class dt extends px {

    protected static final boolean zmodmarker = true;

    public dt(fo fo1, float f) {
        a = fo1;
        this.f = f;
    }

    public void a(fo fo1) {
        b = fo1;
    }

    public void a(wd wd1, double d1, double d2, double d3, 
            float f, float f1) {
        GL11.glPushMatrix();
        GL11.glDisable(2884);
        a.h = a(wd1, f1);
        if(b != null)
            b.h = a.h;
        a.i = wd1.O();
        if(b != null)
            b.i = a.i;
        try {
            float f2 = wd1.bh + (wd1.bg - wd1.bh) * f1;
            float f3 = wd1.w + (wd1.u - wd1.w) * f1;
            float f4 = wd1.x + (wd1.v - wd1.x) * f1;
            a(wd1, d1, d2, d3);
            float f5 = b(wd1, f1);
            a(wd1, f5, f2, f1);
            float f6 = 0.0625F;
            GL11.glEnable(32826);
            GL11.glScalef(-1F, -1F, 1.0F);
            d(wd1, f1);
            GL11.glTranslatef(0.0F, -24F * f6 - 0.0078125F, 0.0F);
            float f7 = wd1.bM + (wd1.bN - wd1.bM) * f1;
            float f8 = wd1.bO - wd1.bN * (1.0F - f1);
            if(f7 > 1.0F)
                f7 = 1.0F;
            a(wd1.ac, wd1.E());
            GL11.glEnable(3008);
            a.a(wd1, f8, f7, f1);
            a.a(wd1, f8, f7, f5, f3 - f2, f4, f6);
            for(int i = 0; i < 4; i++)
                if(b(wd1, i, f1)) {
                    b.a(wd1, f8, f7, f5, f3 - f2, f4, f6);
                    GL11.glDisable(3042);
                    GL11.glEnable(3008);
                }

            c(wd1, f1);
            float f9 = wd1.b(f1);
            int j = a(wd1, f9, f1);
            GL13.glClientActiveTexture(33985);
            GL13.glActiveTexture(33985);
            GL11.glDisable(3553);
            GL13.glClientActiveTexture(33984);
            GL13.glActiveTexture(33984);
            if((j >> 24 & 0xff) > 0 || wd1.bB > 0 || wd1.bE > 0) {
                GL11.glDisable(3553);
                GL11.glDisable(3008);
                GL11.glEnable(3042);
                GL11.glBlendFunc(770, 771);
                GL11.glDepthFunc(514);
                if(wd1.bB > 0 || wd1.bE > 0) {
                    GL11.glColor4f(f9, 0.0F, 0.0F, 0.4F);
                    a.a(wd1, f8, f7, f5, f3 - f2, f4, f6);
                    for(int k = 0; k < 4; k++)
                        if(a(wd1, k, f1)) {
                            GL11.glColor4f(f9, 0.0F, 0.0F, 0.4F);
                            b.a(wd1, f8, f7, f5, f3 - f2, f4, f6);
                        }

                }
                if((j >> 24 & 0xff) > 0) {
                    float f10 = (float)(j >> 16 & 0xff) / 255F;
                    float f11 = (float)(j >> 8 & 0xff) / 255F;
                    float f12 = (float)(j & 0xff) / 255F;
                    float f13 = (float)(j >> 24 & 0xff) / 255F;
                    GL11.glColor4f(f10, f11, f12, f13);
                    a.a(wd1, f8, f7, f5, f3 - f2, f4, f6);
                    for(int l = 0; l < 4; l++)
                        if(a(wd1, l, f1)) {
                            GL11.glColor4f(f10, f11, f12, f13);
                            b.a(wd1, f8, f7, f5, f3 - f2, f4, f6);
                        }

                }
                GL11.glDepthFunc(515);
                GL11.glDisable(3042);
                GL11.glEnable(3008);
                GL11.glEnable(3553);
            }
            GL11.glDisable(32826);
        }
        catch(Exception exception) {
            exception.printStackTrace();
        }
        GL13.glClientActiveTexture(33985);
        GL13.glActiveTexture(33985);
        GL11.glEnable(3553);
        GL13.glClientActiveTexture(33984);
        GL13.glActiveTexture(33984);
        GL11.glEnable(2884);
        GL11.glPopMatrix();
        b(wd1, d1, d2, d3);
    }

    protected void a(wd wd1, double d1, double d2, double d3) {
        GL11.glTranslatef((float)d1, (float)d2, (float)d3);
    }

    protected void a(wd wd1, float f, float f1, float f2) {
        GL11.glRotatef(180F - f1, 0.0F, 1.0F, 0.0F);
        if(wd1.bE > 0) {
            float f3 = ((((float)wd1.bE + f2) - 1.0F) / 20F) * 1.6F;
            f3 = et.c(f3);
            if(f3 > 1.0F)
                f3 = 1.0F;
            GL11.glRotatef(f3 * a(wd1), 0.0F, 0.0F, 1.0F);
        }
    }

    protected float a(wd wd1, float f) {
        return wd1.f(f);
    }

    protected float b(wd wd1, float f) {
        return (float)wd1.V + f;
    }

    protected void c(wd wd1, float f) {
        if(wd1.bP > 0) {
            ki ki1 = new ki(wd1.k, wd1.o, wd1.p, wd1.q);
            Random random = new Random(wd1.f);
            for(int i = 0; i < wd1.bP; i++) {
                GL11.glPushMatrix();
                yn yn1 = a.a(random);
                yn1.c(0.0625F);
                float f1 = random.nextFloat();
                float f2 = random.nextFloat();
                float f3 = random.nextFloat();
                float f4 = (yn1.i + (yn1.l - yn1.i) * f1) / 16F;
                float f5 = (yn1.j + (yn1.m - yn1.j) * f2) / 16F;
                float f6 = (yn1.k + (yn1.n - yn1.k) * f3) / 16F;
                GL11.glTranslatef(f4, f5, f6);
                f1 = f1 * 2.0F - 1.0F;
                f2 = f2 * 2.0F - 1.0F;
                f3 = f3 * 2.0F - 1.0F;
                f1 *= -1F;
                f2 *= -1F;
                f3 *= -1F;
                float f7 = et.c(f1 * f1 + f3 * f3);
                ki1.w = ki1.u = (float)((Math.atan2(f1, f3) * 180D) / 3.1415927410125732D);
                ki1.x = ki1.v = (float)((Math.atan2(f2, f7) * 180D) / 3.1415927410125732D);
                double d1 = 0.0D;
                double d2 = 0.0D;
                double d3 = 0.0D;
                float f8 = 0.0F;
                d.a(ki1, d1, d2, d3, f8, f);
                GL11.glPopMatrix();
            }

        }
    }

    protected boolean a(wd wd1, int i, float f) {
        return b(wd1, i, f);
    }

    protected boolean b(wd wd1, int i, float f) {
        return false;
    }

    protected float a(wd wd1) {
        return 90F;
    }

    protected int a(wd wd1, float f, float f1) {
        return 0;
    }

    protected void d(wd wd1, float f) {
        // -----------------------------------------------------------------------------------------------------------------------
        ZMod.resizeHandle(wd1);
        // -----------------------------------------------------------------------------------------------------------------------
    }

    protected void b(wd wd1, double d1, double d2, double d3) {
        if(!Minecraft.w());
    }

    protected void a(wd wd1, String s, double d1, double d2, double d3, int i) {
        float f = wd1.d(d.h);
        if(f > (float)i)
            return;
        kh kh1 = a();
        float f1 = 1.6F;
        float f2 = 0.01666667F * f1;
        GL11.glPushMatrix();
        GL11.glTranslatef((float)d1 + 0.0F, (float)d2 + 2.3F, (float)d3);
        GL11.glNormal3f(0.0F, 1.0F, 0.0F);
        GL11.glRotatef(-d.i, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(d.j, 1.0F, 0.0F, 0.0F);
        GL11.glScalef(-f2, -f2, f2);
        GL11.glDisable(2896);
        GL11.glDepthMask(false);
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        xe xe1 = xe.a;
        byte byte0 = 0;
        if(s.equals("deadmau5"))
            byte0 = -10;
        GL11.glDisable(3553);
        xe1.b();
        int j = kh1.a(s) / 2;
        xe1.a(0.0F, 0.0F, 0.0F, 0.25F);
        xe1.a(-j - 1, -1 + byte0, 0.0D);
        xe1.a(-j - 1, 8 + byte0, 0.0D);
        xe1.a(j + 1, 8 + byte0, 0.0D);
        xe1.a(j + 1, -1 + byte0, 0.0D);
        xe1.a();
        GL11.glEnable(3553);
        kh1.b(s, -kh1.a(s) / 2, byte0, 0x20ffffff);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        kh1.b(s, -kh1.a(s) / 2, byte0, -1);
        GL11.glEnable(2896);
        GL11.glDisable(3042);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glPopMatrix();
    }

    public void a(kj kj1, double d1, double d2, double d3,
            float f, float f1) {
        a((wd)kj1, d1, d2, d3, f, f1);
    }

    protected fo a, b;
}
