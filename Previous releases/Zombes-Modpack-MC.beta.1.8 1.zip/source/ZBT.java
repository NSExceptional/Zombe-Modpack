
import java.util.Random;
//import java.lang.reflect.*;

// BlockStairs
public final class ZBT extends kn {

    private final int id;

    //public static Method getClassMethod(String c, String m, Class param[]) { try { return Class.forName(c).getMethod(m, param); } catch(Exception e) { e.printStackTrace(); return null; } }
    //public static Object getResult(Method m, Object obj, Object param[]) { try { return m.invoke(obj, param); } catch(Exception whatever) { } return null; }
    //Method badSuper = getClassMethod("lr", "a", new Class[]{rv.class, Integer.TYPE, Integer.TYPE, Integer.TYPE, Float.TYPE});

    public ZBT(int blockId) {
        // search: "stair
        super(blockId,
               blockId == 53 ? y
            : (blockId == 67 ? x
            : (blockId == 108 ? am
            : (blockId == 109 ? bn
            : null))));
        id = blockId;
        switch(blockId) {
            case 53 : a("stairsWood"); break;
            case 67 : a("stairsStone"); break;
            case 108: a("stairsBrick"); break;
            case 109: a("stairsStoneBrickSmooth"); break;
        }
        k();
    }

    public int a(Random random) { // only function with random
        return 1;
    }

    public int a(int i1, Random random) {
        return id;
    }


    public void a(rv rv1, int i1, int j1, int k1, int l1, float f1) {
        if(rv1.I)
            return;
        int i2 = a(rv1.w);
        for(int j2 = 0; j2 < i2; j2++) {
            if(rv1.w.nextFloat() > f1)
                continue;
            int k2 = a(l1, rv1.w);
            if(k2 > 0)
                a(rv1, i1, j1, k1, new ul(k2, 1, b(l1)));
        }

        //getResult(badSuper, this, new Object[]{par1, par2, par3, par4, par5, par6});
        //a.a(rv1, i, k, l, i1, f1);
    }

}
