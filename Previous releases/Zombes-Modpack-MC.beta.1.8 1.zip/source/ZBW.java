
import java.util.Random;

// BlockWater (non stationary)
public final class ZBW extends _i {

    public ZBW() {
        super(8, wa.g);
        c(100F).e(3).a("water").r(); // "water" * drop the last function.
    }

    private void j(rv rv1, int i, int i1, int j1) {
        int k1 = rv1.e(i, i1, j1);
        rv1.b(i, i1, j1, bA + 1, k1);
        rv1.c(i, i1, j1, i, i1, j1);
        rv1.j(i, i1, j1);
    }

    public void a(rv rv1, int i, int i1, int j1, Random random) {
        int k1 = h(rv1, i, i1, j1);
        byte byte0 = 1;
        if(bN == wa.h && !rv1.y.d)
            byte0 = 2;
        boolean flag = true;
        if(k1 > 0) {
            int l1 = -100;
            a = 0;
            l1 = f(rv1, i - 1, i1, j1, l1);
            l1 = f(rv1, i + 1, i1, j1, l1);
            l1 = f(rv1, i, i1, j1 - 1, l1);
            l1 = f(rv1, i, i1, j1 + 1, l1);
            int i2 = l1 + byte0;
            if(i2 >= 8 || l1 < 0)
                i2 = -1;
            if(h(rv1, i, i1 + 1, j1) >= 0) {
                int k2 = h(rv1, i, i1 + 1, j1);
                if(k2 >= 8)
                    i2 = k2;
                else
                    i2 = k2 + 8;
            }
            if(a >= 2 && bN == wa.g) i2 = 0; // UPDATE
            if(bN == wa.h && k1 < 8 && i2 < 8 && i2 > k1 && random.nextInt(4) != 0) {
                i2 = k1;
                flag = false;
            }
            if(i2 != k1) {
                k1 = i2;
                if(k1 < 0) {
                    rv1.g(i, i1, j1, 0);
                } else {
                    rv1.f(i, i1, j1, k1);
                    rv1.a(i, i1, j1, bA, f());
                    rv1.j(i, i1, j1, bA);
                }
            } else
            if(flag)
                j(rv1, i, i1, j1);
        } else {
            j(rv1, i, i1, j1);
        }
        if(m(rv1, i, i1 - 1, j1)) {
            if(k1 >= 8)
                rv1.d(i, i1 - 1, j1, bA, k1);
            else
                rv1.d(i, i1 - 1, j1, bA, k1 + 8);
        } else
        if(k1 >= 0 && (k1 == 0 || l(rv1, i, i1 - 1, j1))) {
            boolean aflag[] = k(rv1, i, i1, j1);
            int j2 = k1 + byte0;
            if(k1 >= 8)
                j2 = 1;
            if(j2 >= 8)
                return;
            if(aflag[0])
                h(rv1, i - 1, i1, j1, j2);
            if(aflag[1])
                h(rv1, i + 1, i1, j1, j2);
            if(aflag[2])
                h(rv1, i, i1, j1 - 1, j2);
            if(aflag[3])
                h(rv1, i, i1, j1 + 1, j2);
        }
    }

    private void h(rv rv1, int i, int i1, int j1, int k1) {
        if(m(rv1, i, i1, j1)) {
            int l1 = rv1.a(i, i1, j1);
            if(l1 > 0)
                if(bN == wa.h)
                    i(rv1, i, i1, j1);
                else
                    lr.m[l1].g(rv1, i, i1, j1, rv1.e(i, i1, j1));
            rv1.d(i, i1, j1, bA, k1);
        }
    }

    private int b(rv rv1, int i, int i1, int j1, int k1, int l1) {
        int i2 = 1000;
        for(int j2 = 0; j2 < 4; j2++) {
            if(j2 == 0 && l1 == 1 || j2 == 1 && l1 == 0 || j2 == 2 && l1 == 3 || j2 == 3 && l1 == 2)
                continue;
            int k2 = i;
            int l2 = i1;
            int i3 = j1;
            if(j2 == 0)
                k2--;
            if(j2 == 1)
                k2++;
            if(j2 == 2)
                i3--;
            if(j2 == 3)
                i3++;
            if(l(rv1, k2, l2, i3) || rv1.f(k2, l2, i3) == bN && rv1.e(k2, l2, i3) == 0)
                continue;
            if(!l(rv1, k2, l2 - 1, i3))
                return k1;
            if(k1 >= 4)
                continue;
            int j3 = b(rv1, k2, l2, i3, k1 + 1, j2);
            if(j3 < i2)
                i2 = j3;
        }

        return i2;
    }

    private boolean[] k(rv rv1, int i, int i1, int j1) {
        for(int k1 = 0; k1 < 4; k1++) {
            c[k1] = 1000;
            int i2 = i;
            int l2 = i1;
            int i3 = j1;
            if(k1 == 0)
                i2--;
            if(k1 == 1)
                i2++;
            if(k1 == 2)
                i3--;
            if(k1 == 3)
                i3++;
            if(l(rv1, i2, l2, i3) || rv1.f(i2, l2, i3) == bN && rv1.e(i2, l2, i3) == 0)
                continue;
            if(!l(rv1, i2, l2 - 1, i3))
                c[k1] = 0;
            else
                c[k1] = b(rv1, i2, l2, i3, 1, k1);
        }

        int l1 = c[0];
        for(int j2 = 1; j2 < 4; j2++)
            if(c[j2] < l1)
                l1 = c[j2];

        for(int k2 = 0; k2 < 4; k2++)
            b[k2] = c[k2] == l1;

        return b;
    }

    private boolean l(rv rv1, int i, int i1, int j1) {
        int k1 = rv1.a(i, i1, j1);
        if(k1 == lr.aF.bA || k1 == lr.aM.bA || k1 == lr.aE.bA || k1 == lr.aG.bA || k1 == lr.aY.bA)
            return true;
        if(k1 == 0)
            return false;
        wa wa1 = lr.m[k1].bN;
        return wa1.c();
    }

/*    protected int f(rv rv1, int i, int i1, int j1, int k1) {
        int l1 = h(rv1, i, i1, j1);
        if(l1 < 0)
            return k1;
        if(l1 == 0)
            a++;
        if(l1 >= 8)
            l1 = 0;
        return k1 >= 0 && l1 >= k1 ? k1 : l1;
    }*/

    private boolean m(rv rv1, int i, int i1, int j1) {
        wa wa1 = rv1.f(i, i1, j1);
        if(wa1 == bN)
            return false;
        if(wa1 == wa.h)
            return false;
        else
            return !l(rv1, i, i1, j1);
    }

/*    public void a(rv rv1, int i, int i1, int j1) {
        super.a(rv1, i, i1, j1);
        if(rv1.a(i, i1, j1) == bA)
            rv1.a(i, i1, j1, bA, f());
    }

    int a;
    boolean b[];
    int c[];
*/


}

