// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.lang.reflect.*;

// search: "BurnTime"
public class sk extends ow
    implements lw {

    protected static final boolean zmodmarker = true;
    public boolean chk() { return i[1]!=null && i[1].c==327; } // update

    public sk() {
        i = new iz[3];
        a = 0;
        b = 0;
        c = 0;
    }

    public int a() {
        return i.length;
    }

    public iz f_(int j) {
        return i[j];
    }

    public iz a(int j, int i1) {
        if(i[j] != null) {
            if(i[j].a <= i1) {
                iz iz1 = i[j];
                i[j] = null;
                return iz1;
            }
            iz iz2 = i[j].a(i1);
            if(i[j].a == 0)
                i[j] = null;
            return iz2;
        } else {
            return null;
        }
    }

    public void a(int j, iz iz1) {
        i[j] = iz1;
        if(iz1 != null && iz1.a > d())
            iz1.a = d();
    }

    public String c() {
        return "Furnace";
    }

    public void a(nu nu1) {
        super.a(nu1);
        sp sp1 = nu1.l("Items");
        i = new iz[a()];
        for(int j = 0; j < sp1.c(); j++) {
            nu nu2 = (nu)sp1.a(j);
            byte byte0 = nu2.c("Slot");
            if(byte0 >= 0 && byte0 < i.length)
                i[byte0] = new iz(nu2);
        }

        a = nu1.d("BurnTime");
        c = nu1.d("CookTime");
        b = a(i[1]);
    }

    public void b(nu nu1) {
        super.b(nu1);
        nu1.a("BurnTime", (short)a);
        nu1.a("CookTime", (short)c);
        sp sp1 = new sp();
        for(int j = 0; j < i.length; j++)
            if(i[j] != null) {
                nu nu2 = new nu();
                nu2.a("Slot", (byte)j);
                i[j].a(nu2);
                sp1.a(nu2);
            }

        nu1.a("Items", sp1);
    }

    public int d() {
        return 64;
    }

    public int b(int j) {
        // -----------------------------------------------------------------------------------------------------------------------
        return (c * j) / ZMod.furnaceSmeltTimeHandle();
        // -----------------------------------------------------------------------------------------------------------------------
    }

    public int c(int j) {
        // -----------------------------------------------------------------------------------------------------------------------
        if(b == 0) b = ZMod.furnaceSmeltTimeHandle();
        // -----------------------------------------------------------------------------------------------------------------------
        return (a * j) / b;
    }

    public boolean b() {
        return a > 0;
    }

    public void n_() {
        boolean flag = a > 0;
        boolean flag1 = false;
        // -----------------------------------------------------------------------------------------------------------------------
        if(a < 0) a = 32000;
        if(a>0 && ZMod.furnaceUseFuelHandle(  a, l()  )) a--;
        // -----------------------------------------------------------------------------------------------------------------------
        if(!d.B) {
            if(a == 0 && l()) {
                b = a = a(i[1]);
                if(a > 0) {
                    flag1 = true;
                    if(i[1] != null) {
                        // -------------------------------------------------------------------------------------------------------
                        i[1] = (iz)ZMod.furnaceDecFuelHandle( i[1] ); // update
                        // -------------------------------------------------------------------------------------------------------
                    }
                }
            }
            if(b() && l()) {
                c++;
                // ---------------------------------------------------------------------------------------------------------------
                if(c >= ZMod.furnaceSmeltTimeHandle()) {
                // ---------------------------------------------------------------------------------------------------------------
                    c = 0;
                    k();
                    flag1 = true;
                }
            // -------------------------------------------------------------------------------------------------------------------
            } else if(ZMod.furnaceWasteHandle()) {
            // -------------------------------------------------------------------------------------------------------------------
                c = 0;
            }
            // -------------------------------------------------------------------------------------------------------------------
            if(flag != (a > 0) || ZMod.furnaceWorldUpdateHandle(a, e, f, g)) {
            // -------------------------------------------------------------------------------------------------------------------
                flag1 = true;
                tc.a(a > 0, d, e, f, g);
            }
        }
        if(flag1)
            y_();
    }

    private boolean l() {
        if(i[0] == null)
            return false;
        // -----------------------------------------------------------------------------------------------------------------------
        iz iz1 = (iz)ZMod.furnaceSmeltingHandle(  i[0].a().bf  );
        if(iz1 == null) iz1 = ey.a().a(i[0].a().bf);
        // -----------------------------------------------------------------------------------------------------------------------
        if(iz1 == null)
            return false;
        if(i[2] == null)
            return true;
        if(!i[2].a(iz1))
            return false;
        if(i[2].a < d() && i[2].a < i[2].c())
            return true;
        return i[2].a < iz1.c();
    }

    public void k() {
        if(!l())
            return;
        // -----------------------------------------------------------------------------------------------------------------------
        iz iz1 = (iz)ZMod.furnaceSmeltingHandle(  i[0].a().bf  );
        if(iz1 == null) iz1 = ey.a().a(i[0].a().bf);
        // -----------------------------------------------------------------------------------------------------------------------
        if(i[2] == null)
            i[2] = iz1.k();
        else
        if(i[2].c == iz1.c)
            i[2].a++;
        i[0].a--;
        if(i[0].a <= 0)
            i[0] = null;
    }

    // ===========================================================================================================================
    private static boolean mlInit = false;
    private static Class mlClass;
    private static Method mlMethod;

    private int a(iz iz1) {
        if(iz1 == null)
            return 0;
        int j = iz1.a().bf;
        int fuel = ZMod.furnaceFuelHandle(  j  ); if(fuel!=0) return fuel; // update: j
        if(j < 256 && uu.m[j].bA == ln.d) return ZMod.furnaceWoodFuelHandle(); //
        if(j == gm.B.bf)
            return 100;
        if(j == gm.k.bf)
            return 1600;
        if(j == gm.aw.bf)
            return 20000;
        if(j == uu.z.bn) return 100; //
        try {
            if(!mlInit) {
                mlInit = true;
                mlClass = Class.forName("ModLoader");
                mlMethod = mlClass.getDeclaredMethod("AddAllFuel", new Class[]{ Integer.TYPE });
            }
            if(mlMethod != null) return (Integer)(mlMethod.invoke(null, new Object[]{ j })); // update: j
        } catch(Exception whatever) { }
        return 0;
    }
    // ===========================================================================================================================

    public boolean a_(gs gs1) {
        if(d.b(e, f, g) != this)
            return false;
        return gs1.f((double)e + 0.5D, (double)f + 0.5D, (double)g + 0.5D) <= 64D;
    }

    private iz i[];
    public int a, b, c;
}
