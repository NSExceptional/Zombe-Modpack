// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.awt.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MinecraftApplet;

// search: "Center"
public final class kq extends Minecraft {

    public kq(Component component, Canvas canvas, MinecraftApplet minecraftapplet, int i, int j, boolean flag, Frame frame) {
        super(component, canvas, minecraftapplet, i, j, flag);
        a = frame;
        ZMod.initialize(this); // initialization
    }

    public void a(mh mh) {
        a.removeAll();
        a.add(new cb(mh), "Center");
        a.validate();
    }

    // search: "/font/default.png" * function contains it
    public void a() {
        super.a();
        ZMod.initOverrides();
    }

    // called before "Pre render" just before continue command
    public void k() {
        ZMod.pingUpdateHandle();
        super.k();
    }

    // search: "tile.bed.notValid"\) * it is in the function
    public void a(boolean flag, int kst) {
        super.a(flag, kst);
        ZMod.pingRespawnHandle(flag);
    }

    final Frame a;
}
