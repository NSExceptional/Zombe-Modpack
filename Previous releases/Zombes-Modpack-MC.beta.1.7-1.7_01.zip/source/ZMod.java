
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.*;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import java.sql.Timestamp;
import java.nio.*;

public final class ZMod {
    public static final String version = "4.28";

    // ----------------------------------------------------------------------------------------------------------------
    private static final class Mark { // whore class
        public float x,y,z;
        public int min, max;
        public byte r,g,b,a;
        public Mark() { }
        // safe mark
        public Mark(int bx, int by, int bz, boolean sun) { x = 0.5f + bx; y = by + 0.13f; z = 0.5f + bz; r = sun ? (byte)1 : (byte)0; }
        // ore mark
        public Mark(int bx, int by, int bz, Mark c) { x = 0.5f + bx; y = 0.5f + by; z = 0.5f + bz; r = c.r; g = c.g; b = c.b; }
        // range mark
        public Mark(int a, int b) { min = a; max = b; }
        // color mark
        public Mark(int color) { loadColor(color); }
        public void loadColor(int color) { b = (byte)(color & 255); g = (byte)((color>>8) & 255); r = (byte)((color>>16) & 255); }
        public boolean loadColor(String color) {
            int c = names.containsKey(color) ? (Integer)(names.get(color)) : parseUnsigned(color);
            if(c < 0) return false;
            loadColor(c);
            return true;
        }
        // item mark
        public static Mark makeItem(int id) {
            Mark item = new Mark();
            Object obj;
            obj = getItem(id); item.setMaxStack(getItemMax(obj)); item.setMaxDamage(getItemDmgCap(obj));
            if(id >= 256) return item;
            item.setLightEmission(getBlockLight(id)); item.setLightReduction(getBlockOpacity(id));
            obj = getBlock(id); item.setStrength(getBlockStrength(obj)); item.setResistance(getBlockResist(obj)); item.setSlipperiness(getBlockSlip(obj));
            item.setFireBurn(getFireBurn(id)); item.setFireSpread(getFireSpread(id));
            return item;
        }
        public void setMaxStack(int val) { r = (byte)val; }
        public void setMaxDamage(int val) { max = val; }
        public void setLightEmission(int val) { g = (byte)val; }
        public void setLightReduction(int val) { min = val; }
        public void setStrength(float val) { x = val; }
        public void setResistance(float val) { y = val; }
        public void setSlipperiness(float val) { z = val; }
        public void setFireBurn(int val) { b = (byte)val; }
        public void setFireSpread(int val) { a = (byte)val; }
        public void activate(int id) {
            Object obj;
            obj = getItem(id); setItemMax(obj, r); setItemDmgCap(obj, max);
            if(id >= 256) return;
            setBlockLight(id, g); setBlockOpacity(id, min);
            obj = getBlock(id); setBlockStrength(obj, x); setBlockResist(obj, y); setBlockSlip(obj, z);
            ZMod.setFireSpread(id, a); ZMod.setFireBurn(id, b);
        }
    }
    
    private static final class Text {
        public String msg; public int x, y, color;
        public Text(String pmsg, int px, int py, int pcolor) { msg = pmsg; x = px; y = py; color = pcolor; }
    }

    private static final int KNOWN     = 0x00000001, SOLID    = 0x00000002, LIQUID  = 0x00000004, CRAFT  = 0x00000008,
                             BASIC     = 0x00000010, SPACE    = 0x00000020, TREE    = 0x00000040, GRASS  = 0x00000080,
                             COBBLE    = 0x00000100, DECAL    = 0x00000200, SAND    = 0x00000400, GRAVEL = 0x00000800,
                             ORE       = 0x00001000, OBSIDIAN = 0x00002000, SPAWN   = 0x00004000, TOUCH  = 0x00008000,
                             SANDSTONE = 0x00010000, GROW     = 0x00020000, STORAGE = 0x00040000;
    private static final int GHAST=1, COW=2, SPIDER=3, SHEEP=4, SKELLY=5, CREEPER=6, ZOMBIE=7, SLIME=8, PIG=9, CHICKEN=10,
                             SQUID=11, PIGZOMBIE=12, PLAYER=13, LIVING=14, WOLF=15, MAXTYPE=16;
    private static final String typeName[] = { "???", "Ghast", "Cow", "Spider", "Sheep", "Skelly", "Creeper", "Zombie",
                             "Slime", "Pig", "Chicken", "Squid", "PigZombie", "Player", "UnknownCreature", "Wolf" };
    private static final int IGNORE = 0, NAMEMAP = 1, RECIPES = 2, FUEL = 3, SMELTING = 4, ITEMS = 5;
    private static final int MTAG1 = 0, MTAG2 = 1, MINFO = 2, MERR = 3, MDEBUG = 4, MTAGR = 5, MAXMSG = 6;

    // ----------------------------------------------------------------------------------------------------------------
    private static Minecraft mc;
    private static Random rnd = new Random();
    private static int block[] = new int[256];
    private static String path; // mod data folder path
    private static PrintStream out; // log output stream
    private static String logPath; // log file location
    private static String showError; // encountered error to be shown on screen
    private static ZRG render; // our RenderGlobal replacement
    private static Properties conf; // configuration
    private static boolean exceptionReported; // used to show only one reflection error
    private static boolean keys[] = new boolean[Keyboard.KEYBOARD_SIZE]; // used to detect key presses
    private static HashMap names;
    private static boolean chatWelcomed; // servers welcome message has passed
    private static int logErrors = 8;
    private static Text texts[] = new Text[MAXMSG];
    private static boolean deferredInit; // deferred initialization for bugged modLoader

    // ================================================================================================================ mod-vars
    private static int clearDisplayedError;
    // ---------------------------------------------------------------------------------------------------------------- cloud
    private static boolean modCloudEnabled;
    private static String tagCloudVanilla;
    private static int keyCloudToggle, keyCloudUp, keyCloudDown, keyCloudVanilla;
    private static boolean optCloudShow, optCloudVanilla;
    private static float optCloudOffset;
    // ---------------------------------------------------------------------------------------------------------------- cart
    private static boolean modCartEnabled;
    private static String tagCartPerpetual;
    private static int keyCartStop, keyCartPerpetual;
    private static boolean optCartPerpetual, optCartInfiniteFuel;
    private static float optCartSpeedAccumCap, optCartAcceleration;
    private static double cartSpeed;
    // ---------------------------------------------------------------------------------------------------------------- wield
    public static boolean modWieldEnabled;
    public static String tagWieldAmmo;
    public static int keyWield;
    public static boolean optWieldBowFirst, optWieldShowAmmo;
    // ---------------------------------------------------------------------------------------------------------------- build
    private static boolean modBuildEnabled;
    private static String tagBuildEnabled;
    private static int keyBuildToggle, keyBuildA, keyBuildB, keyBuildMark, keyBuildCopy, keyBuildPaste, keyBuildSet, keyBuildFill, keyBuildRemove, keyBuildDown, keyBuildDeselect;
    private static int optBuildLockQuantityToNr, optBuildHarvestRule;
    private static float optBuildDigSpeed;
    private static boolean optBuild, optBuildExtension, optBuildLockQuantity;
    private static int buildSets[][], buildBufBlock[], buildBufExtra[];
    private static int buildSX, buildEX, buildSY, buildEY, buildSZ, buildEZ, buildMark = 0;
    private static int buildSizeX = 0, buildSizeY = 0, buildSizeZ = 0;
    private static int buildHandSlot, buildHandCount;
    private static Object buildHand;
    // ---------------------------------------------------------------------------------------------------------------- compass
    private static boolean modCompassEnabled;
    private static String tagCompassAlternate;
    private static int keyCompassSet, keyCompassToggle;
    private static boolean optCompassShowPos;
    private static boolean compassHaveOrig, compassHaveMine, compassShowOrig = true;
    private static int compassOX, compassOY, compassOZ, compassMX, compassMY, compassMZ;
    // ---------------------------------------------------------------------------------------------------------------- sun
    private static boolean modSunEnabled;
    private static String tagSunTime;
    private static String optSunServerCmd;
    private static int keySunTimeAdd, keySunTimeSub, keySunStop, keySunTimeNormal, keySunServer;
    private static int optSunTimeStep;
    private static boolean optSunServerCmdPlus;
    private static boolean sunTimeStop, sunSleeping;
    private static long sunTimeOffset, sunTimeMoment;
    // ---------------------------------------------------------------------------------------------------------------- craft
    private static boolean modCraftEnabled;
    private static int keyCraftAll;
    // ---------------------------------------------------------------------------------------------------------------- fly
    private static boolean modFlyEnabled, modFlyAllowed;
    private static String tagFly, tagFlyNoClip;
    private static int keyFlyOn, keyFlyOff, keyFlyUp, keyFlyDown, keyFlySpeed, keyFlyToggle, keyFlyRun, keyFlyNoClip;
    private static double optFlySpeedVertical, optFlySpeedMulNormal, optFlySpeedMulModifier, optFlyRunSpeedMul;
    private static boolean optFlySpeedIsToggle, optFlyRunSpeedIsToggle, optFlyNoClip;
    private static boolean fly, flySpeed, flyRun, flyNoClip;
    // ---------------------------------------------------------------------------------------------------------------- path
    private static boolean modPathEnabled;
    private static int keyPathShow, keyPathDelete;
    private static boolean optPathShow;
    private static int optPathPoints, optPathSpacing;
    private static float optPathMin, optPathAnimSpeed;
    private static Mark optPathColor;
    private static int pathCount, pathLast;
    private static float pathAnimCur, pathf[];
    // ---------------------------------------------------------------------------------------------------------------- recipe
    private static boolean modRecipeEnabled;
    private static boolean optRecipeShowId, optRecipeDump;
    private static List recipesSP, recipesMP;
    // ---------------------------------------------------------------------------------------------------------------- safe
    private static boolean modSafeEnabled;
    private static String tagSafe;
    private static int keySafeShow;
    private static Mark optSafeDangerColor, optSafeDangerColorSun;
    private static boolean optSafeShowWithSun;
    private static final int safeMax = 2048;
    private static Mark safeMark[];
    private static boolean safeShow;
    private static int safeCur, safeUpdate;
    // ---------------------------------------------------------------------------------------------------------------- boom
    private static boolean modBoomEnabled;
    private static int optBoomSafeRange;
    private static float optBoomDropOreChance, optBoomDropChance, optBoomScaleTNT, optBoomScaleCreeper;
    // ---------------------------------------------------------------------------------------------------------------- spawn
    private static boolean modSpawnEnabled;
    private static boolean optSpawnSupportMods, optSpawnAllowInNonAir, optSpawnAllowOnNonNatural, optSpawnAllowOnGrass, optSpawnAllowOnCobble, optSpawnAllowOnSand, optSpawnAllowOnGravel, optSpawnAllowOnTree, optSpawnAllowOnSandstone;
    private static int optSpawnPigReduction, optSpawnChickenReduction, optSpawnCowReduction, optSpawnSheepReduction, optSpawnSquidReduction, optSpawnGhastReduction, optSpawnWolfReduction;
    private static int optSpawnSpiderReduction, optSpawnSkeletonReduction, optSpawnCreeperReduction, optSpawnZombieReduction, optSpawnSlimeReduction, optSpawnPigZombieReduction;
    // ---------------------------------------------------------------------------------------------------------------- ore
    private static boolean modOreEnabled;
    private static boolean optOreLavaFloor;
    private static int[] optOreCoalRule, optOreIronRule, optOreGoldRule, optOreBlueRule, optOreRedRule, optOreDiamondRule;
    // ---------------------------------------------------------------------------  ----------------------------------- teleport
    private static boolean modTeleportEnabled;
    private static int keyTeleportUp, keyTeleportDown, keyTeleportCursor;
    private static boolean optTeleportIsSelected;
    private static int optTeleportUseItem;
    private static int optTeleportItem, optTeleportPlayer, optTeleportCritter;
    // ---------------------------------------------------------------------------------------------------------------- cheat
    private static boolean modCheatEnabled, modCheatAllowed;
    private static String tagCheater;
    private static int keyCheatShowMobs, keyCheatShowOres, keyCheat, keyCheatSee, keyCheatHighlight, keyCheatRemoveFire, keyCheatView, keyCheatHealth;
    private static boolean optCheatFallDamage, optCheatRestoreHealth, optCheatShowDangerous, optCheatShowNeutral, optCheat, optCheatSeeIsToggle, optCheatShowMobsSize;
    private static boolean optCheatInfArrows, optCheatInfArmor, optCheatInfSword, optCheatInfTools, optCheatFireImmune, optCheatShowHealth;
    private static int optCheatHighlightMode;
    private static float optCheatSeeDist;
    private static final int cheatMax = 2048, cheatItems = 400;
    private static Mark cheatMobs[], cheatOres[], cheatMark[];
    private static boolean cheating = false, cheatShowMobs = false, cheatShowOres = false, cheatSee, cheatDamage[], cheatHighlight;
    private static int cheatCur = 0;
    private static float cheatRefresh;
    private static FloatBuffer cheatAmbItems, cheatAmbGeom;
    private static Object cheatView;
    // ---------------------------------------------------------------------------------------------------------------- resize
    private static boolean modResizeEnabled;
    private static int resizeChanceBig[], resizeChanceSmall[];
    private static float resizeSize[];
    // ---------------------------------------------------------------------------------------------------------------- furnace
    private static boolean modFurnaceEnabled;
    private static boolean optFurnaceFuelWaste, optFurnaceReturnBucket;
    private static int optFurnaceWoodFuel, optFurnaceInfiniteFuel, optFurnaceSmeltingTime;
    private static HashMap<Integer,Integer> furnaceFuel;
    private static HashMap<Integer,Object> furnaceSmelting;
    // ---------------------------------------------------------------------------------------------------------------- dig
    private static boolean modDigEnabled;
    private static boolean optDigHarvestAlways;
    private static float optDigSpeed;
    // ---------------------------------------------------------------------------------------------------------------- weather
    private static boolean modWeatherEnabled;
    private static int keyWeatherRain, keyWeatherThunderstorm, keyWeatherMayhem, keyWeatherLightning;
    private static boolean optWeatherLocked, optWeatherNoDraw;
    private static int optWeatherThunderChance, optWeatherThunderMayhemChance;
    private static Mark optWeatherRainTime, optWeatherNoRainTime, optWeatherThunderTime, optWeatherNoThunderTime;
    private static String tagWeatherRaining, tagWeatherThundering, tagWeatherMayhem;
    private static boolean weatherMayhem;
    // ---------------------------------------------------------------------------------------------------------------- growth
    private static boolean modGrowthEnabled;
    private static boolean optGrowthRooting, optGrowthPlanting;
    private static int optGrowthFlower, optGrowthShroom, optGrowthPumpkin, optGrowthSappling, optGrowthReed, optGrowthRootingSpace, optGrowthRootingTime;
    private static float growthSqrRadius;
    // ---------------------------------------------------------------------------------------------------------------- chest
    private static boolean modChestEnabled;
    private static boolean optChestStore;
    private static int optChestStoreRadius, optChestStoreBlock;
    // ---------------------------------------------------------------------------------------------------------------- icon
    private static boolean modIconEnabled;
    private static boolean optIconShowChest, optIconShowDispenser, optIconShowFurnace;
    // ---------------------------------------------------------------------------------------------------------------- info
    private static boolean modInfoEnabled;
    private static int keyInfoToggle;
    private static boolean optInfoShowPos, optInfoShowTime, optInfoShowBiome, optInfoShowHealth;
    private static int optInfoTimeOffset;
    private static boolean infoShow;
    // ---------------------------------------------------------------------------------------------------------------- death
    private static boolean modDeathEnabled;
    private static boolean optDeathDropInv;
    private static ZI deathInv;
    // ---------------------------------------------------------------------------------------------------------------- item
    private static boolean modItemEnabled;
    private static boolean optItemChangeFence, optItemChangeGlass, optItemChangeIce, optItemChangeLeaves, optItemChangeTorch, optItemChangeFarmland;
    private static Object itemFenceO, itemGlassO, itemIceO, itemLeavesO, itemTorchO, itemFarmlandO;
    private static Object itemFenceM, itemGlassM, itemIceM, itemLeavesM, itemTorchM, itemFarmlandM;
    private static int optItemLeavesDrop, optItemOakChance, optItemOakSpecial, optItemBirchChance, optItemBirchSpecial, optItemPineChance, optItemPineSpecial;
    private static boolean itemModified;
    private static Mark itemOrig[], itemMine[];
    
    // ################################################################################################################ INITIALIZE
    public static void initialize(Minecraft minecraft) {
        log("*** initialization ***"); // also initializes log and path.
        // my precious ...
        mc = minecraft;
        // init block list
        block[ 0] = KNOWN | SPACE | BASIC;         // air
        block[ 1] = KNOWN | SOLID | BASIC;         // stone
        block[ 2] = KNOWN | SOLID | GRASS;         // grass
        block[ 3] = KNOWN | SOLID | BASIC;         // dirt
        block[ 4] = KNOWN | SOLID | COBBLE;        // cobble
        block[ 5] = KNOWN | SOLID | CRAFT;         // plank
        block[ 6] = KNOWN | SPACE | DECAL | GROW;  // sapling
        block[ 7] = KNOWN | SOLID | BASIC;         // bedrock
        block[ 8] = KNOWN | SPACE | LIQUID;        // water - updating
        block[ 9] = KNOWN | SPACE | LIQUID;        // water
        block[10] = KNOWN | LIQUID;                // lava - updating
        block[11] = KNOWN | LIQUID;                // lava
        block[12] = KNOWN | SOLID | SAND;          // sand
        block[13] = KNOWN | SOLID | GRAVEL;        // gravel
        block[14] = KNOWN | SOLID | ORE | BASIC;   // gold ore
        block[15] = KNOWN | SOLID | ORE | BASIC;   // iron ore
        block[16] = KNOWN | SOLID | ORE | BASIC;   // coal ore
        block[17] = KNOWN | SOLID | TREE;          // trunk
        block[18] = KNOWN | SOLID | TREE;          // leaves
        block[19] = KNOWN | SOLID | CRAFT;         // sponge
        block[20] = KNOWN | SOLID | CRAFT;         // glass
        block[21] = KNOWN | SOLID | ORE | BASIC;   // blue ore
        block[22] = KNOWN | SOLID | CRAFT;         // blue block
        block[23] = KNOWN | SOLID | CRAFT | STORAGE;// dispenser
        block[24] = KNOWN | SOLID | SANDSTONE;     // sandstone
        block[25] = KNOWN | SOLID | CRAFT | TOUCH; // note
        block[26] = KNOWN | SOLID | CRAFT;         // bed
        block[27] = KNOWN | SPACE | DECAL;         // rail booster
        block[28] = KNOWN | SPACE | DECAL;         // rail detector
        block[30] = KNOWN | SPACE | DECAL;         // web
        block[31] = KNOWN | SPACE | DECAL;         // tall grass
        block[32] = KNOWN | SPACE | DECAL;         // dead shrubs
        block[35] = KNOWN | SOLID | CRAFT;         // wool
        block[37] = KNOWN | SPACE | DECAL | GROW;  // yellow flower
        block[38] = KNOWN | SPACE | DECAL | GROW;  // red flower
        block[39] = KNOWN | SPACE | DECAL | GROW;  // brown mushroom
        block[40] = KNOWN | SPACE | DECAL | GROW;  // red mushroom
        block[41] = KNOWN | SOLID | CRAFT;         // gold block
        block[42] = KNOWN | SOLID | CRAFT;         // iron block
        block[43] = KNOWN | SOLID | CRAFT;         // double slab
        block[44] = KNOWN | SOLID | CRAFT;         // slab
        block[45] = KNOWN | SOLID | CRAFT;         // brick
        block[46] = KNOWN | SOLID | CRAFT;         // tnt
        block[47] = KNOWN | SOLID | CRAFT;         // bookshelf
        block[48] = KNOWN | SOLID | BASIC;         // mossy
        block[49] = KNOWN | SOLID | OBSIDIAN;      // obsidian
        block[50] = KNOWN | SPACE | DECAL;         // torch
        block[51] = KNOWN | SPACE | DECAL;         // fire
        block[52] = KNOWN | SOLID | BASIC;         // spawner
        block[53] = KNOWN | SOLID | CRAFT;         // wooden stairs
        block[54] = KNOWN | SOLID | CRAFT | STORAGE;// chest
        block[55] = KNOWN | SPACE | DECAL;         // wire
        block[56] = KNOWN | SOLID | ORE | BASIC;   // diamond ore
        block[57] = KNOWN | SOLID | CRAFT;         // diamond block
        block[58] = KNOWN | SOLID | CRAFT;         // bench
        block[59] = KNOWN | SPACE | DECAL;         // wheat
        block[60] = KNOWN | SOLID | CRAFT;         // farmland
        block[61] = KNOWN | SOLID | CRAFT | STORAGE;// furnace
        block[62] = KNOWN | SOLID | CRAFT | STORAGE;// furnace - burning
        block[63] = KNOWN | SPACE | DECAL | TOUCH; // sign on post
        block[64] = KNOWN | SPACE | DECAL | TOUCH; // wooden door
        block[65] = KNOWN | SPACE | DECAL;         // ladder
        block[66] = KNOWN | SPACE | DECAL;         // rails
        block[67] = KNOWN | SOLID | CRAFT;         // cobble stairs
        block[68] = KNOWN | SPACE | DECAL | TOUCH; // sign on wall
        block[69] = KNOWN | SPACE | DECAL | TOUCH; // lever
        block[70] = KNOWN | SPACE | DECAL;         // stone plate
        block[71] = KNOWN | SPACE | DECAL | TOUCH; // iron door
        block[72] = KNOWN | SPACE | DECAL;         // wooden plate
        block[73] = KNOWN | SOLID | ORE | BASIC;   // redstone ore
        block[74] = KNOWN | SOLID | ORE | BASIC;   // redstone ore - glowing
        block[75] = KNOWN | SPACE | DECAL;         // red torch - off
        block[76] = KNOWN | SPACE | DECAL;         // red torch - on
        block[77] = KNOWN | SPACE | DECAL | TOUCH; // button
        block[78] = KNOWN | SPACE;                 // snowcap
        block[79] = KNOWN | SOLID | BASIC;         // ice
        block[80] = KNOWN | SOLID | CRAFT;         // snow block
        block[81] = KNOWN | SOLID | BASIC;         // cactus
        block[82] = KNOWN | SOLID | BASIC;         // clay
        block[83] = KNOWN | SPACE | DECAL | GROW;  // reed
        block[84] = KNOWN | SOLID | CRAFT;         // jukebox
        block[85] = KNOWN | SOLID | CRAFT;         // fence
        block[86] = KNOWN | SOLID | BASIC | GROW;  // pumpkin
        block[87] = KNOWN | SOLID | BASIC;         // netherrack
        block[88] = KNOWN | SOLID | BASIC;         // soul sand
        block[89] = KNOWN | SOLID | ORE | BASIC;   // glowstone
        block[90] = KNOWN | SPACE;                 // portal
        block[91] = KNOWN | SOLID | CRAFT;         // pumpkin - torch
        block[92] = KNOWN | SOLID | CRAFT | TOUCH; // cacke
        block[93] = KNOWN | SOLID | CRAFT | TOUCH; // redstone repeater - off
        block[94] = KNOWN | SOLID | CRAFT | TOUCH; // redstone repeater - on
        block[95] = KNOWN | SOLID | CRAFT;         // locked chest
        block[96] = KNOWN | SOLID | CRAFT;         // trapdoor
        for(int i=0;i<256;i++) if(getBlockIsSpawn(i)) block[i] |= SPAWN;
        // load config
        conf = new Properties();
        try {
            Properties tmp;
            (tmp = new Properties()).load(new FileInputStream(path + "config.txt"));
            conf = tmp;
            log("info: processing configuration");
        } catch(Exception error) {
            err("error: failed to load configuration from config.txt", error);
        }
        // total fuckup log
        try {
        // base config
        getDeprecated("keyBaseInfo");
        getDeprecated("optBaseDisableWarning");
        if(getBool("disableAllMods", false)) {
            log("info: all mods disabled");
            return;
        }
        clearDisplayedError = getBind("clearDisplayedError", Keyboard.KEY_F10);
        int mods = 0;
        parse(null, "names.txt", NAMEMAP);
        names = pNames;
        // item mod
        if((modItemEnabled = getBool("modItemEnabled", false))==true) {
            log("info: loading config for \"item\" - deferred");
            if(optItemChangeFence = getBool("optItemChangeFence", true)) { itemFenceO = getBlock(85); setBlock(85, null); itemFenceM = new ZBF(); setBlock(85, itemFenceO); }
            if(optItemChangeGlass = getBool("optItemChangeGlass", true)) { itemGlassO = getBlock(20); setBlock(20, null); itemGlassM = new ZBG(); setBlock(20, itemGlassO); }
            if(optItemChangeIce = getBool("optItemChangeIce", true)) { itemIceO = getBlock(79); setBlock(79, null); itemIceM = new ZBI(); setBlock(79, itemIceO); }
            if(optItemChangeLeaves = getBool("optItemChangeLeaves", true)) { itemLeavesO = getBlock(18); setBlock(18, null); itemLeavesM = new ZBL(); setBlock(18, itemLeavesO); }
            getDeprecated("optItemChangeTorch");
            //if(optItemChangeTorch = getBool("optItemChangeTorch", true)) { itemTorchO = getBlock(50); setBlock(50, null); itemTorchM = new ZBT(); setBlock(50, itemTorchO); }
            if(optItemChangeFarmland = getBool("optItemChangeFarmland", true)) { itemFarmlandO = getBlock(60); setBlock(60, null); itemFarmlandM = new ZBFL(); setBlock(60, itemFarmlandO); }
            if(optItemChangeLeaves) {
                optItemLeavesDrop = getInt("optItemLeavesDrop", 20, 1, 100);
                optItemOakChance = getInt("optItemOakChance", 3, 0, 100);
                optItemOakSpecial = getItemId("optItemOakSpecial", 260);
                optItemBirchChance = getInt("optItemBirchChance", 1, 0, 100);
                optItemBirchSpecial = getItemId("optItemBirchSpecial", 351 | (3 << 16));
                optItemPineChance = getInt("optItemPineChance", 5, 0, 100);
                optItemPineSpecial = getItemId("optItemPineSpecial", 344);
            }
            mods++;
        }
        // death mod
        if((modDeathEnabled = getBool("modDeathEnabled", false))==true) {
            log("info: loading config for \"death\"");
            optDeathDropInv = getBool("optDeathDropInv", false);
            mods++;
        }
        // info mod
        if((modInfoEnabled = getBool("modInfoEnabled", false))==true) {
            log("info: loading config for \"info\"");
            keyInfoToggle = getBind("keyInfoToggle", Keyboard.KEY_F12);
            optInfoShowPos = getBool("optInfoShowPos", true);
            optInfoShowTime = getBool("optInfoShowTime", true);
            optInfoShowBiome = getBool("optInfoShowBiome", false);
            optInfoShowHealth = getBool("optInfoShowHealth", false);
            optInfoTimeOffset = getInt("optInfoTimeOffset", 300, 0, 1199) * 20;
            mods++;
        }
        // icon mod
        if((modIconEnabled = getBool("modIconEnabled", false))==true) {
            log("info: loading config for \"icon\"");
            optIconShowChest = getBool("optIconShowChest", true);
            optIconShowDispenser = getBool("optIconShowDispenser", true);
            optIconShowFurnace = getBool("optIconShowFurnace", true);
            mods++;
        }
        // chest mod
        if((modChestEnabled = getBool("modChestEnabled", false))==true) {
            log("info: loading config for \"chest\"");
            optChestStore = getBool("optChestStore", true);
            optChestStoreRadius = getInt("optChestStoreRadius", 2, 0, 8); // 0 = off
            optChestStoreBlock = getBlockId("optChestStoreBlock", 58); // workbench
            mods++;
        }
        // cloud mod
        if((modCloudEnabled = getBool("modCloudEnabled", false))==true) {
            log("info: loading config for \"cloud\"");
            keyCloudToggle        = getBind("keyCloudToggle",     Keyboard.KEY_MULTIPLY);
            keyCloudVanilla       = getBind("keyCloudVanilla",    Keyboard.KEY_V);
            keyCloudUp            = getBind("keyCloudUp",         Keyboard.KEY_NONE);
            keyCloudDown          = getBind("keyCloudDown",       Keyboard.KEY_NONE);
            optCloudShow          = getBool("optCloudShow", true);
            optCloudOffset        = getFloat("optCloudOffset", 24F, -64F, 64F);
            tagCloudVanilla       = getString("tagCloudVanilla", "no-cloud-mod");
            mods++;
        }
        // cart mod
        if((modCartEnabled = getBool("modCartEnabled", false))==true) {
            log("info: loading config for \"cart\"");
            keyCartStop           = getBind("keyCartStop",        Keyboard.KEY_RETURN);
            keyCartPerpetual      = getBind("keyCartPerpetual",   Keyboard.KEY_UP);
            optCartSpeedAccumCap  = getFloat("optCartSpeedAccumCap", 1f, 0.5f, 5f);
            optCartAcceleration   = getFloat("optCartAcceleration", 2f, 0.5f, 10f);
            tagCartPerpetual      = getString("tagCartPerpetual", "perpetual");
            optCartInfiniteFuel   = getBool("optCartInfiniteFuel", true);
            mods++;
        }
        // wield mod
        if((modWieldEnabled = getBool("modWieldEnabled", false))==true) {
            log("info: loading config for \"wield\"");
            keyWield              = getBind("keyWield",           Keyboard.KEY_R);
            optWieldBowFirst      = getBool("optWieldBowFirst", true);
            optWieldShowAmmo      = getBool("optWieldShowAmmo", true);
            tagWieldAmmo          = getString("tagWieldAmmo", "Arrows :") + " ";
            mods++;
        }
        // build mod
        if((modBuildEnabled = getBool("modBuildEnabled", false))==true) {
            log("info: loading config for \"build\"");
            keyBuildToggle        = getBind("keyBuildToggle",     Keyboard.KEY_B);
            keyBuildA             = getBind("keyBuildA",          Keyboard.KEY_LSHIFT);
            keyBuildB             = getBind("keyBuildB",          Keyboard.KEY_LCONTROL);
            keyBuildMark          = getBind("keyBuildMark",       Keyboard.KEY_X);
            keyBuildCopy          = getBind("keyBuildCopy",       Keyboard.KEY_C);
            keyBuildPaste         = getBind("keyBuildPaste",      Keyboard.KEY_P);
            keyBuildSet           = getBind("keyBuildSet",        Keyboard.KEY_Z);
            keyBuildFill          = getBind("keyBuildFill",       Keyboard.KEY_LSHIFT);
            keyBuildRemove        = getBind("keyBuildRemove",     Keyboard.KEY_RSHIFT);
            keyBuildDown          = getBind("keyBuildDown",       Keyboard.KEY_LCONTROL);
            keyBuildDeselect      = getBind("keyBuildDeselect",   Keyboard.KEY_NONE);
            optBuildExtension     = getBool("optBuildExtension", false);
            if(!optBuildExtension) log("info: build extension is disabled");
            optBuild              = getBool("optBuild", false);
            optBuildLockQuantity  = getBool("optBuildLockQuantity", true);
            optBuildLockQuantityToNr = getInt("optBuildLockQuantityToNr", 0, 0, 32);
            tagBuildEnabled       = getString("tagBuildEnabled", "builder");
            optBuildDigSpeed      = getFloat("optBuildDigSpeed", 1f, 0.1f, 6f);
            optBuildHarvestRule   = getInt("optBuildHarvestRule", -1, -1, 1);
            String sets[] = new String[]{
                getString("optBuildA1", "smooth, cobble, grass, dirt, sand, gravel, clay, obsidian, sandstone"),
                getString("optBuildA2", "trunk, pine, birch, wood, shelves, chest, workbench, jukebox, furnace"),
                getString("optBuildA3", "woolYellow, woolOrange, woolRed, woolPink, woolMagenta, woolPurple, woolBlue, woolCyan, woolLightBlue"),
                getString("optBuildA4", "wool, woolLightGray, woolGray, woolBlack, woolBrown, woolGreen, woolLime, cage, sponge"),
                getString("optBuildA5", "snowcap, ice, snow, water, lava, fire, glass, pumpkinC, torch"),
                getString("optBuildA6", "sapling, leaves, flowerY, flowerR, shroomB, shroomR, cactus, pumpkin, reed"),
                getString("optBuildA7", "blockG, blockI, blockD, blockB, blockL, mossy, nether, soul, web"),
                getString("optBuildA8", "oreG, oreI, oreC, oreD, oreR, oreY, oreL, repeater, torch"),
                getString("optBuildA9", "doorW, doorI, switch, red, plateS, plateW, button, dispenser, note"),
                getString("optBuildB1", "ladder, tracks, fence, stairC, stairW, sign, half, double, picture"),
                getString("optBuildB2", "pickD, cart, boat, saddle, tnt, cake, bed, bonemeal, torch"),
                getString("optBuildB3", "halfSand, halfWood, halfCobble, saplingNormal, saplingPine, saplingBirch, bonemeal"),
                getString("optBuildB4", "red, cart, tracks, railDetect, railPowered"),
                getString("optBuildB5", ""),
                getString("optBuildB6", ""),
                getString("optBuildB7", ""),
                getString("optBuildB8", "arrow, compass, glass, appleG, swordD, bow, shovelD, pickD, torch"),
                getString("optBuildB9", "bucketW, watch, glass, appleG, swordD, bow, shovelD, pickD, torch")
            };
            buildSets = new int[sets.length][9];
            for(int set=0;set<sets.length;set++) if(!sets[set].equals("")) {
                String got[] = sets[set].split("[\\t ]*,[\\t ]*");
                int defs = got.length; if(defs>9) defs = 9;
                for(int slot=0;slot<defs;slot++) {
                    if(names.containsKey(got[slot])) buildSets[set][slot] = (Integer)(names.get(got[slot]));
                    else {
                        int id = parseIdInfo(got[slot]);
                        if(id==-1) err("error: config.txt @ optBuild"+(set>9?"B":"A")+((set%9)+1)+" - unknown item name or invalid code: \""+got[slot]+"\"");
                        else buildSets[set][slot] = id;
                    }
                }
            }
            if(checkClassBuild()) mods++; else modBuildEnabled = false;
        }
        // compass mod
        if((modCompassEnabled = getBool("modCompassEnabled", false))==true) {
            log("info: loading config for \"compass\"");
            keyCompassSet = getBind("keyCompassSet",              Keyboard.KEY_INSERT);
            keyCompassToggle = getBind("keyCompassToggle",        Keyboard.KEY_HOME);
            tagCompassAlternate = getString("tagCompassAlternate", "altSpawn");
            optCompassShowPos = getBool("optCompassShowPos", true);
            mods++;
        }
        // sun mod
        if((modSunEnabled = getBool("modSunEnabled", false))==true) {
            log("info: loading config for \"sun\"");
            keySunTimeAdd = getBind("keySunTimeAdd",              Keyboard.KEY_ADD);
            keySunTimeSub = getBind("keySunTimeSub",              Keyboard.KEY_SUBTRACT);
            keySunStop = getBind("keySunStop",                    Keyboard.KEY_END);
            keySunTimeNormal = getBind("keySunTimeNormal",        Keyboard.KEY_EQUALS);
            keySunServer = getBind("keySunServer",                Keyboard.KEY_LSHIFT);
            optSunServerCmdPlus = getBool("optSunServerCmdPlus", false);
            optSunTimeStep = getInt("optSunTimeStep", 30, 1, 600) * 20;
            tagSunTime = getString("tagSunTime", "time");
            optSunServerCmd = getString("optSunServerCmd", "/time add");
            if(checkClassSun()) mods++; else modSunEnabled = false;
        }
        // craft mod
        if((modCraftEnabled = getBool("modCraftEnabled", false))==true) {
            log("info: loading config for \"craft\"");
            keyCraftAll = getBind("keyCraftAll",                  Keyboard.KEY_LSHIFT);
            if(checkClassCraft()) mods++; else modCraftEnabled = false;
        }
        // fly mod
        if((modFlyEnabled = getBool("modFlyEnabled", false))==true) {
            log("info: loading config for \"fly\"");
            keyFlyOn = getBind("keyFlyOn",                        Keyboard.KEY_NONE);
            keyFlyOff = getBind("keyFlyOff",                      Keyboard.KEY_NONE);
            keyFlyUp = getBind("keyFlyUp",                        Keyboard.KEY_E);
            keyFlyDown = getBind("keyFlyDown",                    Keyboard.KEY_Q);
            keyFlySpeed = getBind("keyFlySpeed",                  Keyboard.KEY_LSHIFT);
            keyFlyRun = getBind("keyFlyRun",                      Keyboard.KEY_LSHIFT);
            keyFlyToggle = getBind("keyFlyToggle",                Keyboard.KEY_F);
            keyFlyNoClip = getBind("keyFlyNoClip",                Keyboard.KEY_F6);
            optFlyRunSpeedIsToggle = getBool("optFlyRunSpeedIsToggle", false);
            optFlySpeedIsToggle = getBool("optFlySpeedIsToggle", false);
            flyNoClip = false;
            optFlyNoClip = getBool("optFlyNoClip", true);
            optFlySpeedVertical = getFloat("optFlySpeedVertical", 0.2f, 0.1f, 1.0f);
            optFlySpeedMulNormal = getFloat("optFlySpeedMulNormal", 1.0f, 0.1f, 10.0f);
            optFlySpeedMulModifier = getFloat("optFlySpeedMulModifier", 2.0f, 1.0f, 10.0f);
            optFlyRunSpeedMul = getFloat("optFlyRunSpeedMul", 1.5f, 0.1f, 10f);
            tagFly = getString("tagFly", "flying");
            tagFlyNoClip = getString("tagFlyNoClip", "noclip");
            if(checkClassFly()) mods++; else modFlyEnabled = false;
        }
        // path mod
        if((modPathEnabled = getBool("modPathEnabled", false))==true) {
            log("info: loading config for \"path\"");
            keyPathShow = getBind("keyPathShow",                  Keyboard.KEY_BACK);
            keyPathDelete = getBind("keyPathDelete",              Keyboard.KEY_DELETE);
            optPathPoints = getInt("optPathPoints", 8192, 256, 32768); pathf = new float[3 * optPathPoints];
            optPathSpacing = getInt("optPathSpacing", 6, 0, 32) + 2;
            optPathMin = getFloat("optPathMin", 0.25f, 0.1f, 4f); optPathMin *= optPathMin;
            optPathAnimSpeed = getFloat("optPathAnimSpeed", 8f, 0f, 32f);
            optPathShow = getBool("optPathShow", false);
            optPathColor = getColor("optPathColor", 0xff0000);
            mods++;
        }
        // recipe mod
        if((modRecipeEnabled = getBool("modRecipeEnabled", false))==true) {
            log("info: loading config for \"recipe\" - deferred");
            optRecipeShowId = getBool("optRecipeShowId", true);
            optRecipeDump = getBool("optRecipeDump", false);
            recipesMP = (List)((ArrayList)getValue(fCMRecipes, getCManager())).clone();
            mods++;
        }
        // safe mod
        if((modSafeEnabled = getBool("modSafeEnabled", false))==true) {
            safeMark = new Mark[safeMax];
            log("info: loading config for \"safe\"");
            keySafeShow = getBind("keySafeShow",                  Keyboard.KEY_L);
            optSafeDangerColor = getColor("optSafeDangerColor", 0xff0000);
            optSafeDangerColorSun = getColor("optSafeDangerColorSun", 0xdddd00);
            optSafeShowWithSun = getBool("optSafeShowWithSun", true);
            tagSafe = getString("tagSafe", "safe");
            mods++;
        }
        // boom mod
        if((modBoomEnabled = getBool("modBoomEnabled", false))==true) {
            log("info: loading config for \"boom\"");
            optBoomDropChance = (float)getInt("optBoomDropChance", 30, 0, 100) / 100f;
            optBoomDropOreChance = (float)getInt("optBoomDropOreChance", 100, 0, 100) / 100f;
            optBoomScaleTNT = getFloat("optBoomScaleTNT", 1f, 0.1f, 10f);
            optBoomScaleCreeper = getFloat("optBoomScaleCreeper", 1f, 0.1f, 10f);
            optBoomSafeRange  = getInt("optBoomSafeRange", 16, -1, 32);
            if(checkClassBoom()) mods++; else modBoomEnabled = false;
        }
        // spawn mod
        if((modSpawnEnabled = getBool("modSpawnEnabled", false))==true) {
            log("info: loading config for \"spawn\"");
            optSpawnSupportMods = getBool("optSpawnSupportMods", true);
            optSpawnAllowInNonAir = getBool("optSpawnAllowInNonAir", false);
            optSpawnAllowOnNonNatural = getBool("optSpawnAllowOnNonNatural", false);
            optSpawnAllowOnGrass = getBool("optSpawnAllowOnGrass", true);
            optSpawnAllowOnCobble = getBool("optSpawnAllowOnCobble", false);
            optSpawnAllowOnSand = getBool("optSpawnAllowOnSand", true);
            optSpawnAllowOnGravel = getBool("optSpawnAllowOnGravel", true);
            optSpawnAllowOnTree = getBool("optSpawnAllowOnTree", false);
            optSpawnAllowOnSandstone = getBool("optSpawnAllowOnSandstone", false);

            optSpawnPigReduction = getInt("optSpawnPigReduction", 75, 0, 100);
            optSpawnChickenReduction = getInt("optSpawnChickenReduction", 0, 0, 100);
            optSpawnCowReduction = getInt("optSpawnCowReduction", 0, 0, 100);
            optSpawnSheepReduction = getInt("optSpawnSheepReduction", 0, 0, 100);
            optSpawnSquidReduction = getInt("optSpawnSquidReduction", 0, 0, 100);
            optSpawnWolfReduction = getInt("optSpawnWolfReduction", 0, 0, 100);

            optSpawnSpiderReduction = getInt("optSpawnSpiderReduction", 0, 0, 100);
            optSpawnSkeletonReduction = getInt("optSpawnSkeletonReduction", 0, 0, 100);
            optSpawnCreeperReduction = getInt("optSpawnCreeperReduction", 0, 0, 100);
            optSpawnZombieReduction = getInt("optSpawnZombieReduction", 0, 0, 100);
            optSpawnSlimeReduction = getInt("optSpawnSlimeReduction", 0, 0, 100);

            optSpawnGhastReduction = getInt("optSpawnGhastReduction", 0, 0, 100);
            optSpawnPigZombieReduction = getInt("optSpawnPigZombieReduction", 0, 0, 100);
            mods++;
        }
        // ore mod
        if((modOreEnabled = getBool("modOreEnabled", false))==true) {
            log("info: loading config for \"ore\"");
            optOreLavaFloor   = getBool("optOreLavaFloor", true);
            // chance_for_chunk / max_height / min_height / attempts / size / what_must_be_above
            optOreCoalRule    = parseRule(getString("optOreCoalRule"   , "75/80/48/8/16/1  10/120/32/128/4/1 5/120/64/1/128/1"));
            optOreIronRule    = parseRule(getString("optOreIronRule"   , "100/80/16/8/16/1 100/96/8/16/8/1   5/120/64/128/1/1"));
            optOreGoldRule    = parseRule(getString("optOreGoldRule"   , "50/32/4/4/16/1   5/96/8/8/64/1"));
            optOreBlueRule    = parseRule(getString("optOreBlueRule"   , "100/32/8/2/8/1   5/56/48/64/2/1    5/96/48/1/32/1/1"));
            optOreRedRule     = parseRule(getString("optOreRedRule"    , "100/32/8/2/8/1   10/120/96/64/1/1"));
            optOreDiamondRule = parseRule(getString("optOreDiamondRule", "75/16/4/2/8/1    100/32/2/128/2/11 10/120/16/2/8/1"));
            mods++;
        }
        // teleport mod
        if((modTeleportEnabled = getBool("modTeleportEnabled", false))==true) {
            log("info: loading config for \"teleport\"");
            optTeleportItem = getBlockId("optTeleportItem", 42); // iron block
            optTeleportPlayer = getBlockId("optTeleportPlayer", 41); // gold block
            optTeleportCritter = getBlockId("optTeleportCritter", 57); // diamond block
            keyTeleportUp = getBind("keyTeleportUp",              Keyboard.KEY_PRIOR);
            keyTeleportDown = getBind("keyTeleportDown",          Keyboard.KEY_NEXT);
            keyTeleportCursor = getBind("keyTeleportCursor",      Keyboard.KEY_RIGHT);
            optTeleportIsSelected = getBool("optTeleportIsSelected", true);
            optTeleportUseItem = getItemId("optTeleportUseItem", 331); // redstone dust
            mods++;
        }
        // cheat mod
        if((modCheatEnabled = getBool("modCheatEnabled", false))==true) {
            cheatMobs = new Mark[MAXTYPE]; cheatOres = new Mark[256]; cheatMark = new Mark[cheatMax]; cheatDamage = new boolean[cheatItems];
            cheatAmbItems = makeBuffer(new float[] {4f, 4f, 4f, 1f});
            cheatAmbGeom  = makeBuffer(new float[] {0f, 0f, 0f, 1f});
            log("info: loading config for \"cheat\"");
            keyCheat = getBind("keyCheat",                        Keyboard.KEY_Y);
            keyCheatShowMobs = getBind("keyCheatShowMobs",        Keyboard.KEY_M);
            keyCheatShowOres = getBind("keyCheatShowOres",        Keyboard.KEY_O);
            keyCheatSee = getBind("keyCheatSee",                  Keyboard.KEY_I);
            keyCheatHighlight = getBind("keyCheatHighlight",      Keyboard.KEY_H);
            keyCheatRemoveFire = getBind("keyCheatRemoveFire",    Keyboard.KEY_N);
            keyCheatView = getBind("keyCheatView",                Keyboard.KEY_NUMPAD5);
            keyCheatHealth = getBind("keyCheatHealth",            Keyboard.KEY_NONE);
            optCheatFallDamage = getBool("optCheatFallDamage", true);
            if(!optCheatFallDamage) checkClassCheat();
            optCheatRestoreHealth = getBool("optCheatRestoreHealth", false);
            optCheatSeeIsToggle = getBool("optCheatSeeIsToggle", false);
            optCheatShowMobsSize = getBool("optCheatShowMobsSize", false);
            optCheatInfArrows = getBool("optCheatInfArrows", false);
            optCheatInfArmor = getBool("optCheatInfArmor", false);
            optCheatInfSword = getBool("optCheatInfSword", false);
            optCheatInfTools = getBool("optCheatInfTools", false);
            optCheatFireImmune = getBool("optCheatFireImmune", false);
            optCheatShowHealth = getBool("optCheatShowHealth", true);
            optCheatHighlightMode = getInt("optCheatHighlightMode", 2, 1, 3);
            optCheatSeeDist = getFloat("optCheatSeeDist", 4.0f, 1.0f, 32.0f);
            if(optCheatInfArmor) for(int i=298;i<=317;i++) cheatDamage[i] = true;
            if(optCheatInfSword) cheatDamage[267] = cheatDamage[268] = cheatDamage[272] = cheatDamage[276] = cheatDamage[283] = true;
            if(optCheatInfTools) cheatDamage[256] = cheatDamage[257] = cheatDamage[258] = cheatDamage[259] = cheatDamage[269] =
                cheatDamage[270] = cheatDamage[271] = cheatDamage[273] = cheatDamage[274] = cheatDamage[275] =
                cheatDamage[277] = cheatDamage[278] = cheatDamage[279] = cheatDamage[284] = cheatDamage[285] =
                cheatDamage[286] = cheatDamage[290] = cheatDamage[291] = cheatDamage[292] = cheatDamage[293] =
                cheatDamage[294] = cheatDamage[346] = true;
            String val[];
            val = getString("optCheatShowOres", "15/0x008888, 82/0x00ffff, 14/0xffee00, 56/0xeeffff, 48/0x00ff00, 21/0x0000ff, 73/0xff0000, 52/0xff00ff, 16/0x444444").split("[\\t ]*,[\\t ]*");
            for(int i=0;i<val.length;i++) {
                String got[] = val[i].split("/");
                if(got.length == 2) {
                    Mark color = new Mark();
                    int id = names.containsKey(got[0]) ? (Integer)(names.get(got[0])) : parseUnsigned(got[0]);
                    if(id>0 && id<256 && color.loadColor(got[1])) { cheatOres[id] = color; continue; }
                }
                err("error: config.txt @ optCheatOres - invalid ore/color pair \""+val[i]+"\"");
            }
            val = getString("optCheatShowMobs", "1/0x000088, 3/0x880000, 5/0x888888, 6/0x008800, 7/0x888800, 8/0x880088, 12/0x008888, 11/0x000044, 2/0x444400, 4/0x444444, 9/0x440000, 10/0x004444, 14/0x004400, 15/0xffffff").split("[\\t ]*,[\\t ]*");
            for(int i=0;i<val.length;i++) {
                String got[] = val[i].split("/");
                if(got.length == 2) {
                    Mark color = new Mark();
                    int id = names.containsKey(got[0]) ? (Integer)(names.get(got[0])) : parseUnsigned(got[0]);
                    if(id>0 && id<MAXTYPE && color.loadColor(got[1])) { cheatMobs[id] = color; continue; }
                }
                err("error: config.txt @ optCheatMobs - invalid mob/color pair \""+val[i]+"\"");
            }
            tagCheater = getString("tagCheater", "cheater");
            getDeprecated("optCheatSpecialOre");
            mods++;
        }
        // resize mod
        if((modResizeEnabled = getBool("modResizeEnabled", false))==true) {
            resizeChanceBig = new int[MAXTYPE]; resizeChanceSmall = new int[MAXTYPE]; resizeSize = new float[MAXTYPE];
            log("info: loading config for \"resize\"");
            for(int i=0;i<MAXTYPE;i++) resizeChanceBig[i] = 100;
            // big
            resizeChanceBig[COW]    = 100 - getInt("optResizeCowBig"   , 10, 0, 100);
            resizeChanceBig[SPIDER] = 100 - getInt("optResizeSpiderBig", 10, 0, 100);
            resizeChanceBig[SHEEP]  = 100 - getInt("optResizeSheepBig" , 10, 0, 100);
            resizeChanceBig[SKELLY] = 100 - getInt("optResizeSkellyBig", 20, 0, 100);
            resizeChanceBig[ZOMBIE] = 100 - getInt("optResizeZombieBig", 20, 0, 100);
            resizeChanceBig[PIG]    = 100 - getInt("optResizePigBig"   , 10, 0, 100);
            // small
            resizeChanceSmall[COW]    = getInt("optResizeCowSmall"   , 30, 0, 100);
            resizeChanceSmall[SPIDER] = getInt("optResizeSpiderSmall", 50, 0, 100);
            resizeChanceSmall[SHEEP]  = getInt("optResizeSheepSmall" , 30, 0, 100);
            resizeChanceSmall[SKELLY] = getInt("optResizeSkellySmall", 10, 0, 100);
            resizeChanceSmall[ZOMBIE] = getInt("optResizeZombieSmall", 30, 0, 100);
            resizeChanceSmall[PIG]    = getInt("optResizePigSmall"   , 50, 0, 100);
            if(checkClassResize()) mods++; else modResizeEnabled = false;
        }
        // furnace mod
        if((modFurnaceEnabled = getBool("modFurnaceEnabled", false))==true) {
            pFuel = furnaceFuel = new HashMap<Integer,Integer>();
            pSmelt = furnaceSmelting = new HashMap<Integer,Object>();
            log("info: loading config for \"furnace\"");
            optFurnaceWoodFuel = getInt("optFurnaceWoodFuel", 300, 1, 32767);
            optFurnaceInfiniteFuel = getInt("optFurnaceInfiniteFuel", 32767, 1, 32767);
            optFurnaceSmeltingTime = getInt("optFurnaceSmeltingTime", 200, 1, 1000);
            optFurnaceFuelWaste = getBool("optFurnaceFuelWaste", true);
            optFurnaceReturnBucket = getBool("optFurnaceReturnBucket", false);
            parse(null, "fuel.txt", FUEL);
            parse(null, "smelting.txt", SMELTING);
            if(checkClassFurnace()) mods++; else modFurnaceEnabled = false;
        }
        // dig mod
        if((modDigEnabled = getBool("modDigEnabled", false))==true) {
            log("info: loading config for \"dig\"");
            optDigSpeed = getFloat("optDigSpeed", 2.0f, 0.1f, 10.0f);
            optDigHarvestAlways = getBool("optDigHarvestAlways", false);
            if(checkClassDig()) mods++; else modDigEnabled = false;
        }
        // weather mod
        if((modWeatherEnabled = getBool("modWeatherEnabled", false))==true) {
            log("info: loading config for \"weather\"");
            keyWeatherRain = getBind("keyWeatherRain",            Keyboard.KEY_J);
            keyWeatherThunderstorm = getBind("keyWeatherThunderstorm", Keyboard.KEY_K);
            keyWeatherMayhem = getBind("keyWeatherMayhem",        Keyboard.KEY_LSHIFT);
            keyWeatherLightning = getBind("keyWeatherLightning",  Keyboard.KEY_U);
            optWeatherThunderChance = getInt("optWeatherThunderChance", 100000, 1, 500000);
            optWeatherThunderMayhemChance = getInt("optWeatherThunderMayhemChance", 2000, 1, 10000);
            optWeatherRainTime = getIntRange("optWeatherRainTime", 180, 600, 10, 3600);
            optWeatherRainTime.min *= 20; optWeatherRainTime.max *= 20; optWeatherRainTime.max -= optWeatherRainTime.min - 1; // -1 to prevent the case of Random.nextInt(0)
            optWeatherNoRainTime = getIntRange("optWeatherNoRainTime", 600, 8400, 10, 14400);
            optWeatherNoRainTime.min *= 20; optWeatherNoRainTime.max *= 20; optWeatherNoRainTime.max -= optWeatherNoRainTime.min - 1;
            optWeatherThunderTime = getIntRange("optWeatherThunderTime", 180, 600, 10, 3600);
            optWeatherThunderTime.min *= 20; optWeatherThunderTime.max *= 20; optWeatherThunderTime.max -= optWeatherThunderTime.min - 1;
            optWeatherNoThunderTime = getIntRange("optWeatherNoThunderTime", 600, 8400, 10, 14400);
            optWeatherNoThunderTime.min *= 20; optWeatherNoThunderTime.max *= 20; optWeatherNoThunderTime.max -= optWeatherNoThunderTime.min - 1;
            tagWeatherRaining = getString("tagWeatherRaining", "raining");
            tagWeatherThundering = getString("tagWeatherThundering", "thunder");
            tagWeatherMayhem = getString("tagWeatherMayhem", "mayhem");
            optWeatherLocked = getBool("optWeatherLocked", false);
            optWeatherNoDraw = getBool("optWeatherNoDraw", false);
            mods++;
        }
        // growth mod
        if((modGrowthEnabled = getBool("modGrowthEnabled", false))==true) {
            log("info: loading config for \"growth\"");
            optGrowthRooting = getBool("optGrowthRooting", true);
            optGrowthPlanting = getBool("optGrowthPlanting", true);
            optGrowthFlower = getInt("optGrowthFlower", 25, 1, 1000);
            optGrowthShroom = getInt("optGrowthShroom", 100, 1, 1000);
            optGrowthPumpkin = getInt("optGrowthPumpkin", 50, 1, 1000);
            optGrowthSappling = getInt("optGrowthSappling", 25, 1, 1000);
            optGrowthReed = getInt("optGrowthReed", 10, 1, 1000);
            optGrowthRootingSpace = getInt("optGrowthRootingSpace", 3, 1, 5);
            optGrowthRootingTime = getInt("optGrowthRootingTime", 10, 1, 300) * 20;
            growthSqrRadius = (0.5f + optGrowthRootingSpace) * (0.5f + optGrowthRootingSpace);
            mods++;
        }
        // done
        if(mods==0) err("warning: no mods are enabled! Read the readme.txt!");
        log("info: configuration loaded");
        // total fuckup log
        } catch(Exception error) {
            err("error: initialization failed", error);
        }
        log("*** done ***");
    }

    // ################################################################################################################ OVERRIDES - FIXME
    public static void initOverrides() {
        try {
        log("info: init render"); overloadRenderGlobal();
        
        mc.t = new ZER(mc, mc.t);
        
        // total fuckup log
        } catch(Exception error) {
            err("error: overrides failed", error);
        }
    }

    // ################################################################################################################ AFTER RESPAWNING
    public static void pingRespawnHandle(boolean first) {
        try {
            if(!isMultiplayer && modDeathEnabled && !optDeathDropInv && deathInv != null && !first) setInventory(getPlayer(), deathInv);
        } catch(Exception error) {
            err("error: respawn failed", error);
        }
    }

    // ################################################################################################################ PRE ENT
    private static boolean playerClassActive;
    public static void pingPreEntHandle() {
        if(playerClassActive && player != null && (!modFlyEnabled || !fly)) {
            setEntityOnGround(player, moveOnGround);
        }
    }

    // ################################################################################################################ UPDATE
    private static Object prevPC, PC;
    public static void pingUpdateHandle() {
        int i;
        if(!deferredInit) try {
            deferredInit = true;
            if(modItemEnabled && itemOrig == null) {
                log("info: continuing to load \"item\"");
                itemOrig = new Mark[32000]; itemMine = new Mark[32000];
                for(i=0;i<itemOrig.length;i++) if(getItem(i) != null) {
                    itemOrig[i] = Mark.makeItem(i);
                    itemMine[i] = Mark.makeItem(i);
                }
                parse(null, "items.txt", ITEMS);
            }
            if(modRecipeEnabled && recipesSP == null) {
                log("info: continuing to load \"recipes\"");
                recipesSP = (List)getValue(fCMRecipes, getCManager());
                log("info: "+recipesSP.size()+" SP recipes before loading mod");
                parse(recipesSP, "recipes.txt",    RECIPES); sortRecipes(recipesSP);
                log("info: "+recipesSP.size()+" SP recipes after loading mod");
                if(optRecipeDump) {
                    log("==== recipe dump ====");
                    String res;
                    Object obj, items;
                    for(i=0;i<recipesSP.size();i++) {
                        obj = recipesSP.get(i);
                        if(isRecipeNormal(obj)) {
                            items = getValue(fRResA, obj);
                            Object arr[] = (Object[])getValue(fRMap, obj);
                            res = "type normal    : " + getItemsId(items)+"/"+getItemsInfo(items) + " " + getValue(fRWidth, obj) + " " + getValue(fRHeight, obj);
                            for(int m=0;m<arr.length;m++) res += arr[m]==null ? " 0" : (" "+getItemsId(arr[m])+"/"+getItemsInfo(arr[m]));
                        } else if(isRecipeShapeless(obj)) {
                            items = getValue(fRResB, obj);
                            List arr = (List)getValue(fRList, obj);
                            res = "type shapeless : " + getItemsId(items)+"/"+getItemsInfo(items) + " " + arr.size() + " 0";
                            for(int m=0;m<arr.size();m++) res += " "+getItemsId(arr.get(m))+"/"+getItemsInfo(arr.get(m));
                        } else {
                            res = "type: KST " + obj;
                        }
                        log(res);
                    }
                }
            }
        } catch(Exception error) {
            err("error: deferredInit failed", error);
        }
        try {
        // update state
        if((player = getPlayer()) == null) return;
        isMapChange = map != getMap();
        if((map = getMap()) == null) return;
        if((renderer = getRenderer()) == null) return;
        posX = getEntityPosX(player); posY = getEntityPosY(player); posZ = getEntityPosZ(player);
        motionX = getEntityMotionX(player); motionY = getEntityMotionY(player); motionZ = getEntityMotionZ(player);
        isMenu = getIsMenu(); isMultiplayer = getIsMultiplayer(); isHell = getIsHell();
        inWhat = getOnEntity(player);
        inv = getInventory(player); invItems = getInvItems(inv); invArmors = getInvArmors(inv);
        world = getWorld();
        PC = getPlayerController();
        if(isWorldChange = PC != prevPC) {
            modFlyAllowed = modCheatAllowed = true;
            chatWelcomed = false;
        }
        prevPC = PC;
        List chat = getChat();
        if(!chatWelcomed) for(int line=0;line<chat.size();line++) {
            String msg = getChatLine(chat, line);
            if(msg == chatLast) break;
            if(msg.contains("joined the game")) { chatWelcomed = true; continue; }
            if(msg.contains("�f �f �1 �0 �2 �4")) modFlyAllowed = false;
            if(msg.contains("�f �f �2 �0 �4 �8")) modCheatAllowed = false;
            if(msg.matches(".*(\\W|^)no-z-fly(\\W|$).*")) modFlyAllowed = false;
            if(msg.matches(".*(\\W|^)no-z-cheat(\\W|$).*")) modCheatAllowed = false;
        }
        if(chat.size()>0) chatLast = getChatLine(chat, 0);
        delMsg(1);
        // update logging
        if(showError != null && !isMenu && keyPress(clearDisplayedError)) {
            showError = null;
            delMsg(3);
        }
        // update "item"
        if(modItemEnabled) {
            if(isMultiplayer && itemModified) {
                itemModified = false;
                for(i=0;i<itemOrig.length;i++) if(itemOrig[i]!=null) itemOrig[i].activate(i);
                if(optItemChangeFence) setBlock(85, itemFenceO);
                if(optItemChangeGlass) setBlock(20, itemGlassO);
                if(optItemChangeIce) setBlock(79, itemIceO);
                if(optItemChangeLeaves) setBlock(18, itemLeavesO);
                if(optItemChangeTorch) setBlock(50, itemTorchO);
                if(optItemChangeFarmland) setBlock(60, itemFarmlandO);
            }
            if(!isMultiplayer && !itemModified) {
                itemModified = true;
                for(i=0;i<itemMine.length;i++) if(itemMine[i]!=null) itemMine[i].activate(i);
                if(optItemChangeFence) setBlock(85, itemFenceM);
                if(optItemChangeGlass) setBlock(20, itemGlassM);
                if(optItemChangeIce) setBlock(79, itemIceM);
                if(optItemChangeLeaves) setBlock(18, itemLeavesM);
                if(optItemChangeTorch) setBlock(50, itemTorchM);
                if(optItemChangeFarmland) setBlock(60, itemFarmlandM);
            }
        }
        // update "death"
        if(modDeathEnabled && !optDeathDropInv) {
            if(isMultiplayer || isWorldChange) deathInv = null;
            if(!isMultiplayer && deathInv == null) {
                deathInv = new ZI(null);
                copy(getInventory(player), deathInv);
                setInventory(player, deathInv);
            }
        }
        // update "info"
        if(modInfoEnabled) {
            if(!isMenu && keyPress(keyInfoToggle)) infoShow = !infoShow;
            delMsg(2);
            String info = "";
            if(infoShow && !isMenu) {
                int x = fix(posX), y = fix(posY), z = fix(posZ), mx, my, mz, id, meta, cap, cnt;
                long time = getTime(), timeRT = time;
                float val;
                Object at;
                if(modSunEnabled && sunTimeOffset != 0) time += sunTimeOffset;
                // your location
                info += "Your position:   �9" + x + "�f , �9" + y + "�f , �9" + z; // player position
                if(y >= 0) info += "\n  Light level:   �9" + getLightLevel(x,y,z) + "�f   (   min: �8"+getLightLevel(x,y,z,16)+"�f   max: �e"+getLightLevel(x,y,z,0)+"�f   )"; // current light level, min, max
                info += "\n  Biome:   �9" + getBiomeName(x,z); // biome
                val = getTemp(); if(!Float.isNaN(val)) info += "�f   temp = �9" + (int)(val * 40) + "�f C";
                val = getHumid(); if(!Float.isNaN(val)) info += "�f   humid = �9" + (int)(val * 100) + "� %";
                // the world
                info += "\nCompasspoint:   �9" + (mx = (Integer)getValue(fSpawnX, world)) + "�f , �9" + (my = (Integer)getValue(fSpawnY, world)) + "�f , �9" + (mz = (Integer)getValue(fSpawnZ, world));
                mx -= x; mz -= z; info += "�f (�9" + (int)Math.sqrt(mx*mx + mz*mz) + "�fm)";
                if(modCompassEnabled && compassHaveMine) {
                    if(compassShowOrig) info += "\n  Alt: �9" + (mx = compassMX) + "�f , �9" + (my = compassMY) + "�f , �9" + (mz = compassMZ);
                    else info += "\n  Orig: �9" + (mx = compassOX) + "�f , �9" + (my = compassOY) + "�f , �9" + (mz = compassOZ);
                    mx -= x; mz -= z; info += "�f (�9" + (int)Math.sqrt(mx*mx + mz*mz) + "�fm)";
                }
                at = getSpawn(player);
                if(at != null) {
                    info += "\nSpawnpoint:   �9" + (mx = getX(at)) + "�f , �9" + (my = getY(at)) + "�f , �9" + (mz = getZ(at)); // spawnpoint
                    mx -= x; mz -= z; info += "�f (�9" + (int)Math.sqrt(mx*mx + mz*mz) + "�fm)";
                    if(isMultiplayer && getBed(player)==null) info += "  �4Bed-override?";
                }
                at = getBed(player);
                if(at != null) {
                    info += "\nYour bed:   �9" + (mx = getX(at)) + "�f , �9" + (my = getY(at)) + "�f , �9" + (mz = getZ(at)); // bedpoint
                    mx -= x; mz -= z; info += "�f (�9" + (int)Math.sqrt(mx*mx + mz*mz) + "�fm)";
                }
                if(!isMultiplayer) info += "\nWorld Name:   �9" + getName(); // world name
                info += "\nWorld Seed:   �9" + getSeed(); // world seed
                info += "\nWorld Age (real time):   �9" + getRealTime(timeRT);
                // state of world
                info += "\nTime:   �9" + getTime(time);
                if(time != timeRT) info += "�f   (actual time: �9" + getTime(timeRT)+"�f )";
                if(!isMultiplayer) {
                    info += "\nRain:   �9" + (getRain() ? "raining" : "not raining");
                    if((!modWeatherEnabled || !optWeatherLocked) && !isHell) info += "�f the next �9" + (getRainTime() / 20) + "�f seconds"; // rain
                    info += "\nThunder:   �9" + (getThunder() ? "thundering" : "not thundering");
                    if((!modWeatherEnabled || !optWeatherLocked) && !isHell) info += "�f the next �9" + (getThunderTime() / 20) + "�f seconds"; // thunder
                }
                // item in hand
                at = invItems[getInvCur()];
                if(at != null) {
                    id = getItemsId(at);
                    meta = getItemsInfo(at);
                    cnt = getItemsCount(at);
                    at = getItem(id);
                    info += "\nSelected item:   �9" + getItemName(at) + "�f  id: �9" + id + (getItemHasSubTypes(at) ? "�f/�9" + meta : "") + "�f  stack: �9" + cnt + "�f/�9" + getItemMax(at);
                    if((cap = getItemDmgCap(at)) != 0) info += "�f  damage: �9" + meta + "�f/�9" + cap;
                    info += "�f  type: �9" + (id < 256 ? "Block" : "Item");
                    if(id < 256) {
                        at = getBlock(id);
                        info += "\n  Properties:   strength = �9" + getBlockStrength(at) + "�f  resistance = �9" + getBlockResist(at) + "�f  slipperiness = �9" + getBlockSlip(at);
                        info += "\n  Light:   emission = �9" + getBlockLight(id) + "�f  reduction = �9" + (getBlockIsOpaque(id) ? "opaque" : getBlockOpacity(id) );
                        info += "\n  Fire:   spread = �9" + getFireSpread(id) + "�f  burn = �9" + getFireBurn(id);
                        at = getBlockMaterial(at);
                        info += "\n  Material:   �9"; i = 0;
                        if(getIsSolid(at)) { info += " solid"; i++; }
                        if(getIsBurnable(at)) { info += " burnable"; i++; }
                        if(getIsReplaceable(at)) { info += " replaceable"; i++; }
                        if(getIsLiquid(at)) { info += " liquid"; i++; }
                        if(getIsCover(at)) { info += " cover"; i++; }
                        if(i==0) info += "-";
                    }
                }
                // players
                if(isMultiplayer) {
                    int width = getScrWidthS(), cur, len; cnt = 0; i = 0;
                    String tmp = "", add;
                    cur = showTextLength("Players nearby (00):  ");
                    List list = getEntities();
                    Iterator it = list.iterator();
                    while(it.hasNext()) {
                        Object ent = it.next();
                        if(!getEntityIsPlayer(ent) || ent==player) continue;
                        tmp += (cnt==0?" �9":", �9"); cur += showTextLength(cnt==0?" �9":", �9");
                        add = getPlayerName(ent);
                        mx = fix(getEntityPosX(ent)) - x;
                        my = fix(getEntityPosY(ent)) - y;
                        mz = fix(getEntityPosZ(ent)) - z;
                        add += "�f (�9" + (int)Math.sqrt(mx*mx + my*my + mz*mz) + "�fm)";
                        len = showTextLength(add); i++;
                        if(width < cur + len || i > 4) { i = 0; tmp += "\n   �9" + add; cur = len + showTextLength("   "); } else { tmp += add; cur += len; }
                        cnt++;
                    }
                    if(cnt==0) tmp += "�4none";
                    info += "\nPlayers nearby (�9" + cnt + "�f):  " + tmp;
                }
                setMsg(MINFO, info);
            }
        }
        // update "chest"
        if(modChestEnabled && !isMultiplayer && (optChestStore || optChestStoreRadius>0)) try {
            List list = getEntities();
            Iterator it = list.iterator();
            while(it.hasNext()) {
                Object ent = it.next(), items[] = null, tent = null;
                if(!getEntityIsItemStack(ent)) continue;
                if(getEntityAge(ent) < 0) continue;
                Object sub = getEntityItemStack(ent);
                int findId = getItemsId(sub), findMeta = getItemsInfo(sub), count;
                int x = fix(getEntityPosX(ent)), y = fix(getEntityPosY(ent)) - 1, z = fix(getEntityPosZ(ent)), id = mapGetId(x,y,z), slot = 0, score = 0, space = 0, maxspace = getItemMax(getItem(findId)), empty = -1;
                boolean hadMatch;
                // score: 0-cannot, 1=free-space, 2=free-space-and-same-items, 3=found-nonfull-matching-stack
                int radius = -1;
                if(id == optChestStoreBlock && optChestStoreRadius > 0) radius = optChestStoreRadius;
                else if(optChestStore && id == 54) radius = 0;
                if(radius >= 0) {
                    // find a nice chest
                    Search: for(int dx=-radius;dx<=radius;dx++) for(int dy=-radius;dy<=radius;dy++) for(int dz=-radius;dz<=radius;dz++) if(mapGetId(x+dx, y+dy, z+dz) == 54) {
                        Object foundtent = getTileEntity(x+dx, y+dy, z+dz), found[] = getChestItems(foundtent); empty = -1; hadMatch = false;
                        for(i=0;i<27;i++)
                            if(found[i]==null) {
                                if(empty == -1) empty = i;
                                if(score<2 && hadMatch) { items = found; tent = foundtent; slot = i; score = 2; space = maxspace; }
                                else if(score==0) { items = found; tent = foundtent; slot = i; score = 1; space = maxspace; }
                            } else if(getItemsId(found[i])==findId && getItemsInfo(found[i])==findMeta) {
                                hadMatch = true;
                                if(empty != -1 && score == 1) { items = found; tent = foundtent; slot = empty; score = 2; space = maxspace; }
                                if((count = getItemsCount(found[i])) < maxspace) { items = found; tent = foundtent; slot = i; score = 3; space = maxspace - count; break Search; }
                            }
                    }
                    // found one?
                    if(tent != null) {
                        // squeeze it in ...
                        count = getItemsCount(sub);
                        if(items[slot]==null) items[slot] = newItems(findId, count > space ? space : count, findMeta);
                        else {
                            if(count > space) setItemsCount(items[slot], maxspace);
                            else setItemsCount(items[slot], getItemsCount(items[slot]) + count);
                        }
                        count -= space;
                        if(count <= 0) dieEntity(ent);
                        setChanged(tent);
                        if(count > 0) { setItemsCount(sub, count); continue; }
                    }
                    // skip testing it for 5 seconds
                    setEntityAge(ent, -100);
                }
            }
        } catch(Exception error) { err("error: \"chest\" update failed", error); }
        // update "growth"
        if(modGrowthEnabled && !isMultiplayer) try {
            // grow plants
            int px = fix(posX) >> 4, pz = fix(posZ) >> 4;
            for(int cx=-15;cx<=15;cx++) for(int cz=-15;cz<=15;cz++) if(mapGetChunkExists(px + cx, pz + cz)) {
                byte arr[] = mapGetChunkData(px + cx, pz + cz);
                int pos = (rnd.nextInt(256) << 7) + 1, x = (pos >> 11) + ((px + cx) << 4), y, z = ((pos >> 7) & 15) + ((pz + cz) << 4), id, meta;
                for(y = 1;y<128;y++,pos++) if((block[id = ((int)arr[pos] & 255)] & GROW)!=0 && arr[pos - 1]==3) {
                    int chance = Integer.MAX_VALUE;
                    switch(id) {
                        case 6:           chance = optGrowthSappling; break; // sappling
                        case 37: case 38: chance = optGrowthFlower;   break; // flower
                        case 39: case 40: chance = optGrowthShroom;   break; // shroom
                        case 83:          chance = optGrowthReed;     break; // reed
                        case 86:          chance = optGrowthPumpkin;  break; // pumpkin
                    }
                    if(chance >= 1000 || rnd.nextInt(chance) != 0) continue;
                    int rx = rnd.nextInt(3) - 1, rz = rnd.nextInt(3) - 1;
                    if(mapGetId(x + rx, y - 1, z + rz)!=3 || mapGetId(x + rx, y, z + rz)!=0) continue;
                    int light = getLightLevel(x + rx, y, z + rz, 0);
                    if(id == 39 || id == 40) { if(light > 13) continue; } else if(light < 8) continue; // light check
                    mapSetIdMeta(x + rx, y, z + rz, id, mapGetMeta(x,y,z));
                }
            }
            // root sapplings
            if(optGrowthRooting || optGrowthPlanting) {
                List list = getEntities();
                ArrayList die = new ArrayList();
                Iterator it = list.iterator();
                GrowthList: while(it.hasNext()) {
                    Object ent = it.next();
                    if(!getEntityIsItemStack(ent)) continue;
                    int age = getEntityAge(ent);
                    if(age != optGrowthRootingTime && age != 5980) continue; // configurable     (items die at: 6000)
                    Object items = getEntityItemStack(ent);
                    int stack = getItemsId(items);
                    if(getItemsCount(items) != 1 || (!(stack == 6 && optGrowthRooting) && !(stack == 295 && optGrowthPlanting)) ) continue;
                    int x = fix(getEntityPosX(ent)), y = fix(getEntityPosY(ent)), z = fix(getEntityPosZ(ent));
                    if(y < 0 || mapGetId(x, y, z) != 0) continue; // need empty space
                    if(getLightLevel(x, y, z, 0) < 8) continue; // need light (using day setting)
                    int id = mapGetId(x, y - 1, z);
                    if(stack == 295) {
                        if(id != 60) continue; // need farmland to grow
                        // rooting
                        mapSetIdMeta(x, y, z, 59, 0);
                    } else {
                        if(id != 2 && id != 3) continue; // need grass or dirt to grow
                        for(int ax=-optGrowthRootingSpace;ax<=optGrowthRootingSpace;ax++) for(int az=-optGrowthRootingSpace;az<=optGrowthRootingSpace;az++) {
                            if(ax * ax + az * az > growthSqrRadius) continue;
                            for(int ay=-optGrowthRootingSpace;ay<=optGrowthRootingSpace;ay++) {
                                id = mapGetId(x + ax, y + ay, z + az);
                                if(id == 17 || id == 6) continue GrowthList;
                            }
                        }
                        // rooting
                        mapSetIdMeta(x, y, z, 6, getItemsInfo(items));
                    }
                    die.add(ent);
                }
                for(int deathrow=0;deathrow<die.size();deathrow++)  dieEntity(die.get(deathrow));
            }
        } catch(Exception error) { err("error: \"growth\" update failed", error); }
        // update "weather"
        if(modWeatherEnabled && !isMultiplayer) try {
            // spawn lightning
            if(!isMenu && keyPress(keyWeatherLightning) && rayTrace(256d, 0f)) {
                int x = rayHitX(),y = rayHitY(),z = rayHitZ(), s = rayHitSide();
                if(s==2) z--; if(s==3) z++; if(s==4) x--; if(s==5) x++;
                while((block[mapGetId(x,y,z)] & SOLID) == 0) y--;
                while((block[mapGetId(x,y,z)] & SOLID) != 0) y++;
                spawnLightning(x, y, z);
            }
            // weather control
            overloadMapRandom();
            int wrt = getRainTime(), wtt = getThunderTime();
            boolean wr = getRain(), wt = getThunder(), boost, raining, thundering;
            if(!isMenu && keyPress(keyWeatherRain)) { wrt = 1; }
            else if(!isMenu && keyPress(keyWeatherThunderstorm)) {
                // intended behaviour: 0/1 initial state (key down in "boost" case). state change: "+" start, "-" end, "." no-change, "!" flip.
                // raining     0+ 1. 0+ 1. 0+ 1. 0+ 1.
                // thundering  0+ 0+ 1+ 1- 0+ 0+ 1+ 1.
                // boost       0. 0. 0. 0. 1+ 1+ 1+ 1!
                boost = keyDown(keyWeatherMayhem); raining = wr; thundering = wt;
                if(!raining) { wrt = 1; wr = false; } // adjust raining
                if(!(raining && thundering)) { wtt = 1; wt = false; } else if (!boost) { wtt = 1; wt = true; } // adjust thundering
                if(boost) weatherMayhem = !(raining && thundering) || !weatherMayhem; // adjust weather mayhem
            }
            if(wrt == 0) { wr = true; } // minecraft seems to reset all weather whenever one sleeps causing it to never rain in the morning - it seems :/ ... WHY!?
            if(wrt <= 1) {
                wr = !wr;
                if(wr) wrt = rnd.nextInt(optWeatherRainTime.max) + optWeatherRainTime.min;
                else { wrt = rnd.nextInt(optWeatherNoRainTime.max) + optWeatherNoRainTime.min; weatherMayhem = false; }
            }
            if(wtt <= 1) {
                wt = !wt;
                if(wt) wtt = rnd.nextInt(optWeatherThunderTime.max) + optWeatherThunderTime.min;
                else { wtt = rnd.nextInt(optWeatherNoThunderTime.max) + optWeatherNoThunderTime.min; weatherMayhem = false; }
            }
            if(!isHell && optWeatherLocked) { wrt++; wtt++; } // weather timers are stopped in hell
            setRain(wr); setThunder(wt); setRainTime(wrt); setThunderTime(wtt);
        } catch(Exception error) { err("error: \"weather\" update failed", error); }
        // update "cloud"
        if(modCloudEnabled && !isMenu) try {
            if(keyPress(keyCloudVanilla)) optCloudVanilla = !optCloudVanilla;
            if(keyPress(keyCloudToggle)) { if(optCloudVanilla) optCloudVanilla = false; else optCloudShow = !optCloudShow; }
            if(keyPress(keyCloudUp))     { if(optCloudVanilla) optCloudVanilla = false; else optCloudOffset += 1f; }
            if(keyPress(keyCloudDown))   { if(optCloudVanilla) optCloudVanilla = false; else optCloudOffset -= 1f; }
        } catch(Exception error) { err("error: \"cloud\" update failed", error); }
        // update "cart"
        if(!isMultiplayer && modCartEnabled && getEntityIsCart(inWhat)) try {
            double mx = getEntityMotionX(inWhat) + motionX * optCartAcceleration, mz = getEntityMotionZ(inWhat) + motionZ * optCartAcceleration;
            double speed = Math.sqrt(mx*mx+mz*mz), rate;
            if(!isMenu && keyPress(keyCartPerpetual)) {
                optCartPerpetual = !optCartPerpetual;
                if(optCartPerpetual) cartSpeed = speed;
            }
            if((speed > optCartSpeedAccumCap) || (optCartPerpetual && speed > 0.001d )) {
                rate = optCartPerpetual ? (cartSpeed / speed) : (optCartSpeedAccumCap / speed);
                mz *= rate; mz *= rate;
            }
            if(!isMenu && keyDown(keyCartStop)) { mx = mz = 0.0d; optCartPerpetual = false; }
            setEntityMotionX(inWhat, mx); setEntityMotionZ(inWhat, mz);
            // handle powered minecarts
            if(optCartInfiniteFuel) {
                List list = getEntities();
                Iterator it = list.iterator();
                while(it.hasNext()) {
                    Object ent = it.next();
                    if(!getEntityIsCart(ent)) continue;
                    if(getCartType(ent) != 2) continue;
                    if(getCartFuel(ent) > 0) setCartFuel(ent, 1200);
                }
            }
        } catch(Exception error) { err("error: \"cart\" update failed", error); }
        // update "wield"
        if(modWieldEnabled) try {
            int bow = -1, swd = -1, cur = getInvCur();
            int arrows = 0;
            boolean haveBow = false;
            for(i=0;i<invItems.length;i++) {
                int id = invItems[i]==null ? 0 : getItemsId(invItems[i]);
                if(id==262) arrows += getItemsCount(invItems[i]);
                if(i<9) { if(id==261) { bow = i; haveBow = true; } else if(id==268 || id==272 || id==267 || id==276) swd = i; }
            }
            if(arrows==0) bow = -1;
            if(bow == -1) bow = swd; else if(swd == -1) swd = bow;
            int set = optWieldBowFirst ? bow : swd;
            if(cur == set) set = set==bow ? swd : bow;
            if(!isMenu && keyPress(keyWield) && set != -1) setInvCur(set);
            if(optWieldShowAmmo && haveBow) setMsg(MTAG2, tagWieldAmmo + arrows, arrows > 8 ? (arrows > 32 ? (arrows > 64 ? 0xbbffbb : 0x22dd22) : 0xeeee11) : 0xdd3333);
        } catch(Exception error) { err("error: \"wield\" update failed", error); }
        // update "build"
        if(!isMultiplayer && modBuildEnabled) try {
            if(!isMenu) {
                if(keyPress(keyBuildToggle)) optBuild = !optBuild;
                if(isMapChange) optBuild = false;
                if(optBuild) {
                    // sets
                    int set = -1;
                    if(keyDown(keyBuildA)) for(i=Keyboard.KEY_1;i<=Keyboard.KEY_9;i++) if(keyPress(i)) set = i - Keyboard.KEY_1;
                    if(keyDown(keyBuildB)) for(i=Keyboard.KEY_1;i<=Keyboard.KEY_9;i++) if(keyPress(i)) set = 9 + i - Keyboard.KEY_1;
                    if(set!=-1) for(int slot=0;slot<9;slot++) if(buildSets[set][slot]!=0) invItems[slot] = newItemsE(buildSets[set][slot], 32);
                    // map edit part of mod follows
                    int x = fix(posX),y = fix(posY),z = fix(posZ);
                    if(keyPress(keyBuildDeselect)) buildMark = 0; // deselect
                    if(optBuildExtension && keyPress(keyBuildMark)) {
                        if(buildMark==1) { buildEX = x; buildEY = keyDown(keyBuildDown) ? y - 1 : y; buildEZ = z; buildMark = 2; }
                        else { buildSX = x; buildSY = keyDown(keyBuildDown) ? y - 1 : y; buildSZ = z; buildMark = 1; }
                    } else if(buildMark==2) {
                        // fix coords
                        int tmp;
                        if(buildSX > buildEX) { tmp = buildSX; buildSX = buildEX; buildEX = tmp; }
                        if(buildSY > buildEY) { tmp = buildSY; buildSY = buildEY; buildEY = tmp; }
                        if(buildSZ > buildEZ) { tmp = buildSZ; buildSZ = buildEZ; buildEZ = tmp; }
                        // ready
                        if(keyPress(keyBuildSet)) {
                            int id = 0, got, meta = 0;
                            if(invItems[getInvCur()] != null) {
                                id = getItemsId(invItems[getInvCur()]);
                                meta = getItemsInfo(invItems[getInvCur()]);
                                if(id >= 255) id = meta = 0;
                            }
                            if(keyDown(keyBuildFill)) {
                                for(x=buildSX;x<=buildEX;x++) for(y=buildSY;y<=buildEY;y++) for(z=buildSZ;z<=buildEZ;z++) if(mapGetId(x,y,z)==0) mapSetIdMetaNoUpdate(x,y,z,id,meta);
                            } else if(keyDown(keyBuildRemove)) {
                                for(x=buildSX;x<=buildEX;x++) for(y=buildSY;y<=buildEY;y++) for(z=buildSZ;z<=buildEZ;z++) if((got=mapGetId(x,y,z))==id || (id==8 && got==9) || (id==10 && got==11)) mapSetIdMetaNoUpdate(x,y,z,0,0);
                            } else {
                                for(x=buildSX;x<=buildEX;x++) for(y=buildSY;y<=buildEY;y++) for(z=buildSZ;z<=buildEZ;z++) mapSetIdMetaNoUpdate(x,y,z,id,meta);
                            }
                            mapNeedsUpdate(buildSX,buildSY,buildSZ,buildEX,buildEY,buildEZ);
                        } else if(keyPress(keyBuildCopy)) {
                            buildMark = 0;
                            buildSizeX = 1 + buildEX - buildSX;
                            buildSizeY = 1 + buildEY - buildSY;
                            buildSizeZ = 1 + buildEZ - buildSZ;
                            int size = buildSizeX * buildSizeY * buildSizeZ, at = 0;
                            buildBufBlock = new int[size];
                            buildBufExtra = new int[size];
                            for(x=buildSX;x<=buildEX;x++) for(y=buildSY;y<=buildEY;y++) for(z=buildSZ;z<=buildEZ;z++) {
                                buildBufBlock[at] = mapGetId(x,y,z);
                                buildBufExtra[at] = mapGetMeta(x,y,z);
                                at++;
                            }
                        } else if(keyPress(keyBuildPaste) && buildBufBlock!=null) {
                            int sx = 1 + buildEX - buildSX; sx = sx > buildSizeX ? sx % buildSizeX : 0;
                            int sy = 1 + buildEY - buildSY; sy = sy > buildSizeY ? sy % buildSizeY : 0;
                            int sz = 1 + buildEZ - buildSZ; sz = sz > buildSizeZ ? sz % buildSizeZ : 0;
                            if(sx!=0 || sy!=0 || sz!=0) { // adjust selection (try to avoid partial copy)
                                buildEX -= sx; buildEY -= sy; buildEZ -= sz;
                            } else if(keyDown(keyBuildFill)) { // fill space
                                for(x=buildSX;x<=buildEX;x++) for(y=buildSY;y<=buildEY;y++) for(z=buildSZ;z<=buildEZ;z++) if(mapGetId(x,y,z)==0) {
                                    int cx = (x-buildSX) % buildSizeX, cy = (y-buildSY) % buildSizeY, cz = (z-buildSZ) % buildSizeZ;
                                    int at = (cx*buildSizeY + cy)*buildSizeZ + cz;
                                    mapSetIdMetaNoUpdate(x,y,z,buildBufBlock[at],buildBufExtra[at]);
                                }
                            } else if(keyDown(keyBuildRemove)) { // remove matching
                                for(x=buildSX;x<=buildEX;x++) for(y=buildSY;y<=buildEY;y++) for(z=buildSZ;z<=buildEZ;z++) {
                                    int cx = (x-buildSX) % buildSizeX, cy = (y-buildSY) % buildSizeY, cz = (z-buildSZ) % buildSizeZ;
                                    int at = (cx*buildSizeY + cy)*buildSizeZ + cz;
                                    int id = buildBufBlock[at], got = mapGetId(x,y,z);
                                    if(id == got || (id==8 && got==9) || (id==10 && got==11)) mapSetIdMetaNoUpdate(x,y,z,0,0);
                                }
                            } else { // replace
                                for(x=buildSX;x<=buildEX;x++) for(y=buildSY;y<=buildEY;y++) for(z=buildSZ;z<=buildEZ;z++) {
                                    int cx = (x-buildSX) % buildSizeX, cy = (y-buildSY) % buildSizeY, cz = (z-buildSZ) % buildSizeZ;
                                    int at = (cx*buildSizeY + cy)*buildSizeZ + cz;
                                    mapSetIdMetaNoUpdate(x,y,z,buildBufBlock[at],buildBufExtra[at]);
                                }
                            }
                            mapNeedsUpdate(buildSX,buildSY,buildSZ,buildEX,buildEY,buildEZ);
                        }
                    } else if(buildMark==1 && keyPress(keyBuildPaste)) {
                        buildEX = buildSX + buildSizeX - 1; buildEY = buildSY + buildSizeY - 1; buildEZ = buildSZ + buildSizeZ - 1; buildMark = 2;
                    }
                } else {
                    buildMark = 0; // deselect if build mode is not active
                }
            }
            // lock items in hand
            if(optBuild && !isMenu && optBuildLockQuantity) {
                if(optBuildLockQuantityToNr != 0) {
                    for(int slot=0;slot<invItems.length;slot++) if(invItems[slot] != null) setItemsCount(invItems[slot], optBuildLockQuantityToNr);
                } else {
                    int cur = getInvCur();
                    if(cur != buildHandSlot || (invItems[cur] != null && invItems[cur] != buildHand)) {
                        buildHandSlot = cur;
                        buildHand = invItems[cur];
                        buildHandCount = buildHand != null ? getItemsCount(buildHand) : 0;
                    } else if(buildHand != null && (invItems[cur] == null || invItems[cur] == buildHand)) {
                        setItemsCount(buildHand, buildHandCount);
                        setInvItems(cur, buildHand);
                    }
                }
            } else {
                buildHandSlot = -1;
            }
        } catch(Exception error) { err("error: \"build\" update failed", error); }
        // update "compass"
        if(modCompassEnabled && !isHell) try {
            if(isWorldChange) { compassHaveMine = false; compassShowOrig = true; }
            int cX = (Integer)getValue(fSpawnX, world);
            int cY = (Integer)getValue(fSpawnY, world);
            int cZ = (Integer)getValue(fSpawnZ, world);
            int pX = fix(posX), pY = fix(posY), pZ = fix(posZ);
            if(!compassHaveOrig || ((cX!=compassOX || cY!=compassOY || cZ!=compassOZ) && (cX!=compassMX || cY!=compassMY || cZ!=compassMZ))) {
                compassOX = cX; compassOY = cY; compassOZ = cZ; compassHaveOrig = true;
            }
            if(!isMenu) {
                if(keyPress(keyCompassToggle)) compassShowOrig = !compassShowOrig;
                if(keyPress(keyCompassSet)) {
                    compassMX = pX; compassMY = pY; compassMZ = pZ;
                    compassHaveMine = true;
                    compassShowOrig = false;
                }
            }
            if(compassShowOrig) { cX = compassOX; cY = compassOY; cZ = compassOZ; } else { cX = compassMX; cY = compassMY; cZ = compassMZ; }
            setValue(fSpawnX, world, cX);
            setValue(fSpawnY, world, cY);
            setValue(fSpawnZ, world, cZ);
        } catch(Exception error) { err("error: \"compass\" update failed", error); }
        // update "sun"
        if(modSunEnabled) try {
            long time = (Long)getValue(fTime, world);
            if(getIsSleeping(player)) sunSleeping = true;
            else if(sunSleeping) { sunSleeping = false; sunTimeOffset = 0; }
            if(!isMenu) {
                if(keyDown(keySunServer)) {
                    if(keyPress(keySunTimeAdd)) sendChat(optSunServerCmd+(optSunServerCmdPlus ? " +" : " ")+optSunTimeStep);
                    else if(keyPress(keySunTimeSub)) sendChat(optSunServerCmd+" -"+optSunTimeStep);
                } else {
                    if(keyPress(keySunTimeAdd)) { if(sunTimeStop) sunTimeMoment += optSunTimeStep; sunTimeOffset += optSunTimeStep; }
                    else if(keyPress(keySunTimeSub)) { if(sunTimeStop) sunTimeMoment -= optSunTimeStep; sunTimeOffset -= optSunTimeStep; }
                }
                if(keyPress(keySunStop)) { sunTimeStop = !sunTimeStop; if(sunTimeStop) sunTimeMoment = time; }
                if(keyPress(keySunTimeNormal)) { sunTimeStop = false; sunTimeOffset = 0; }
            }
            if(sunTimeStop) { sunTimeOffset -= time - sunTimeMoment; sunTimeMoment = time; }
        } catch(Exception error) { err("error: \"sun\" update failed", error); }
        // update "fly"
        if(isWorldChange) flyNoClip = optFlyNoClip && !isMultiplayer;
        if(modFlyEnabled && !isMenu) try {
            if(keyPress(keyFlyToggle)) fly = !fly;
            else if(keyDown(keyFlyOn)) fly = true;
            else if(keyDown(keyFlyOff)) fly = false;
            if(!modFlyAllowed && fly) {
                fly = false;
                chatClient("�4zombe's �2fly�4-mod is not allowed on this server.");
            }
            if(!isMultiplayer && fly && keyPress(keyFlyNoClip)) flyNoClip = !flyNoClip;
            setNoClip(fly && flyNoClip);
            if(optFlySpeedIsToggle && keyPress(keyFlySpeed)) flySpeed = !flySpeed;
            if(optFlyRunSpeedIsToggle && keyPress(keyFlyRun)) flyRun = !flyRun;
        } catch(Exception error) { err("error: \"fly\" update failed", error); }
        // update "path"
        if(modPathEnabled && !isMenu) try {
            if(keyPress(keyPathShow)) optPathShow = !optPathShow;
            if(keyPress(keyPathDelete)) pathCount = 0;
        } catch(Exception error) { err("error: \"path\" update failed", error); }
        // update "recipe"
        if(modRecipeEnabled) try {
            setValue(fCMRecipes, getCManager(), isMultiplayer ? recipesMP : recipesSP);
        } catch(Exception error) { err("error: \"recipe\" update failed", error); }
        // update "safe"
        if(modSafeEnabled && !isMenu && keyPress(keySafeShow)) try {
            safeShow = !safeShow;
        } catch(Exception error) { err("error: \"safe\" update failed", error); }
        // update "spawn"
        if(modSpawnEnabled && !isMultiplayer) try {
            List list = getEntities();
            Iterator it = list.iterator();
            int mask = 0;
            if(!optSpawnAllowOnGrass) mask |= GRASS;
            if(!optSpawnAllowOnCobble) mask |= COBBLE;
            if(!optSpawnAllowOnSand) mask |= SAND;
            if(!optSpawnAllowOnGravel) mask |= GRAVEL;
            if(!optSpawnAllowOnTree) mask |= TREE;
            if(!optSpawnAllowOnNonNatural) mask |= CRAFT;
            if(!optSpawnAllowOnSandstone) mask |= SANDSTONE;
            while(it.hasNext()) {
                Object ent = it.next();
                if(getEntityAge(ent)!=1) continue; // 1st beat
                boolean kill = false;
                switch(getEntityType(ent)) {
                    case GHAST:     if(optSpawnGhastReduction     != 0 && rnd.nextInt(100)<optSpawnGhastReduction    ) kill = true; break;
                    case COW:       if(optSpawnCowReduction       != 0 && rnd.nextInt(100)<optSpawnCowReduction      ) kill = true; break;
                    case SPIDER:    if(optSpawnSpiderReduction    != 0 && rnd.nextInt(100)<optSpawnSpiderReduction   ) kill = true; break;
                    case SHEEP:     if(optSpawnSheepReduction     != 0 && rnd.nextInt(100)<optSpawnSheepReduction    ) kill = true; break;
                    case SKELLY:    if(optSpawnSkeletonReduction  != 0 && rnd.nextInt(100)<optSpawnSkeletonReduction ) kill = true; break;
                    case CREEPER:   if(optSpawnCreeperReduction   != 0 && rnd.nextInt(100)<optSpawnCreeperReduction  ) kill = true; break;
                    case ZOMBIE:    if(optSpawnZombieReduction    != 0 && rnd.nextInt(100)<optSpawnZombieReduction   ) kill = true; break;
                    case SLIME:     if(optSpawnSlimeReduction     != 0 && rnd.nextInt(100)<optSpawnSlimeReduction    ) kill = true; break;
                    case PIG:       if(optSpawnPigReduction       != 0 && rnd.nextInt(100)<optSpawnPigReduction      ) kill = true; break;
                    case CHICKEN:   if(optSpawnChickenReduction   != 0 && rnd.nextInt(100)<optSpawnChickenReduction  ) kill = true; break;
                    case SQUID:     if(optSpawnSquidReduction     != 0 && rnd.nextInt(100)<optSpawnSquidReduction    ) kill = true; break;
                    case PIGZOMBIE: if(optSpawnPigZombieReduction != 0 && rnd.nextInt(100)<optSpawnPigZombieReduction) kill = true; break;
                    case WOLF:      if(optSpawnWolfReduction      != 0 && rnd.nextInt(100)<optSpawnWolfReduction     ) kill = true; break;
                    case LIVING:    if(!optSpawnSupportMods) continue; break;
                    default: continue;
                }
                if(!kill) {
                    int x = fix(getEntityPosX(ent)), y = fix(getEntityPosY(ent)), z = fix(getEntityPosZ(ent));
                    if(!optSpawnAllowInNonAir && (block[mapGetId(x,y,z)] & DECAL)!=0) kill = true;
                    if(mask!=0 && (block[mapGetId(x,y-1,z)] & mask)!=0) kill = true;
                }
                if(kill) dieEntity(ent);
            }
        } catch(Exception error) { err("error: \"spawn\" update failed", error); }
        // update "ore"
        if(modOreEnabled && !isMultiplayer && !isHell) try {
            int cx = fix(posX) >> 4, cz = fix(posZ) >> 4, tx, ty, tz, id;
            for(int cxi=cx-3;cxi<=cx+3;cxi++) for(int czi=cz-3;czi<=cz+3;czi++) {
                tx = (cxi<<4)+3; ty = (czi<<4)+3;
                byte data[] = mapGetChunkData(cxi, czi);
                if(data[1024] != 7) continue; // already done
                data[1024] = 0; data[1025] = 7; // mark the chunk done
                for(i=0;i<data.length;i++) {
                    id = (int)data[i] & 255; // fucking Java with his lack of unsigned types x_x.
                    if((block[id] & ORE) != 0) data[i] = 1;
                    else if(id == 7 && (i & 127) > 1) data[i] = optOreLavaFloor ? (byte)11 : (byte)1;
                    else if((i & 127) == 1) data[i] = 7;
                }
                oreDistribute(data, optOreCoalRule   , (byte)16);
                oreDistribute(data, optOreIronRule   , (byte)15);
                oreDistribute(data, optOreGoldRule   , (byte)14);
                oreDistribute(data, optOreBlueRule   , (byte)21);
                oreDistribute(data, optOreRedRule    , (byte)73);
                oreDistribute(data, optOreDiamondRule, (byte)56);
                chunkNeedsUpdate(cxi, czi); // request update
            }
        } catch(Exception error) { err("error: \"ore\" update failed", error); }
        // update "teleport"
        if(modTeleportEnabled && !isMultiplayer) try { // blocking buggy MP support
            List list = getEntities();
            Iterator it = list.iterator();
            int type, x, y, z, id, ofs;
            Object entTpSound = null;
            while(it.hasNext()) {
                Object ent = it.next();
                type = getEntityType(ent);
                if(isMultiplayer && ent!=player) continue;
                x = fix(getEntityPosX(ent)); y = fix(getEntityPosY(ent)) - 1; z = fix(getEntityPosZ(ent)); ofs=0;
                // find solid ground / teleportation pad
                id = mapGetId(x,y,z);
                if((block[id] & SOLID) == 0) { id = mapGetId(x,--y,z); ofs++; }
                // check pad type vs entity type
                if(type == 0 && (id != optTeleportItem || !getEntityIsItemStack(ent))) continue;
                if(type != 0 && type != PLAYER && id != optTeleportCritter) continue;
                if(type == PLAYER && id != optTeleportPlayer) continue;
                // get sign text
                String sign[] = null;
                id = mapGetId(x, y+1, z); if(id == 63 || id == 68) sign = getSignText(x, y+1, z);
                id = mapGetId(x, y+2, z); if(id == 63 || id == 68) sign = getSignText(x, y+2, z);
                id = mapGetId(x, y-1, z); if(id == 63 || id == 68) sign = getSignText(x, y-1, z);
                if(sign == null) continue;
                // read teleportation info from sign and TP
                try {
                    x = 0; y = -1; z = 0;
                    boolean allow = false, needAllow = false;
                    for(i=0;i<sign.length;i++) if(sign[i]!=null && sign[i].length()>1) {
                        if(sign[i].charAt(0)=='!') {
                            String part[] = sign[i].substring(1).split(",");
                            if(part.length != 3) break;
                            x = new Integer(part[0]);
                            y = new Integer(part[1]);
                            z = new Integer(part[2]);
                        } else if(sign[i].charAt(0)=='?') {
                            if(sign[i].charAt(1)=='!') {
                                String filter = sign[i].substring(2);
                                id = ( names.containsKey(filter) ? (Integer)names.get(filter) : parseIdInfo(filter) ) & 0xffff; // strip "damage" / info
                                if(type != 0 && type != PLAYER && id == type) { y=-1; break; } // mob filter match
                                if(type == 0 && getItemsId(getEntityItemStack(ent)) == id) { y=-1; break; } // item filter match
                            } else {
                                needAllow = true;
                                String filter = sign[i].substring(1);
                                id = ( names.containsKey(filter) ? (Integer)names.get(filter) : parseIdInfo(filter) ) & 0xffff; // strip "damage" / info
                                if(type != 0 && type != PLAYER && id == type) { allow = true; continue; } // mob filter match
                                if(type == 0 && getItemsId(getEntityItemStack(ent)) == id) { allow = true; continue; } // item filter match
                            }
                        }
                    }
                    if(y==-1 || (needAllow && !allow)) continue;
                    // check target coordinates - multiplayer only
                    if(isMultiplayer) {
                        // is target chunk missing?
                        if(mapGetId(x,0,z)!=7) { noiseTP(ent); break; }
                        // is target area clear?
                        if((block[mapGetId(x,y+1,z)] & SOLID)!=0 || (block[mapGetId(x,y+0,z)] & SOLID)!=0 || (block[mapGetId(x,y-1,z)] & SOLID)!=0) { noiseTP(ent); break; }
                    }
                    // teleport
                    Object entBound = getOnEntity(ent);
                    if(entBound != null) {
                        // should be correct coordinates - but are not :(
                        setEntityPos(entBound, 0.5+x, 0.0+(y+ofs), 0.5+z);
                        setEntityPos(ent, 0.5+x, getMountOffset(entBound)+(y+ofs), 0.5+z);
                    } else setEntityPos(ent, 0.5+x, 0.5+(y+ofs), 0.5+z);
                    //if(isMultiplayer) ((pg)player).bI.a(new x(0.5+x, player.aS.b, 0.5+(y+ofs), 0.5+z, player.aT)); // player search: -999D * the other stuff (new x...) you will also find there
                    if(type==PLAYER) entTpSound = ent;
                } catch(Exception whatever) {} // failsafe
            }
            // handle non-pad teleporting
            if(!isMenu && inWhat == null) {
                int dir = 0, s;
                boolean teleport = false;
                if(keyPress(keyTeleportUp)) dir = 1;
                else if(keyPress(keyTeleportDown)) dir = -1;
                x = fix(getEntityPosX(player)); y = fix(getEntityPosY(player)); z = fix(getEntityPosZ(player));
                if(dir != 0) { // teleport up and down
                    boolean safe[] = new boolean[131], ok = false;
                    while(y > 1 && (block[mapGetId(x,y-1,z)] & SOLID) == 0) y--; // land player
                    for(i=0;i<131;i++) { // find all acceptable locations
                        id = mapGetId(x,i,z);
                        if((block[id] & SOLID) != 0 && id != 81) ok = true; // above ground ...
                        else if(id == 10 || id == 11 || id == 51 || id == 81 || i==y) ok = false; // ... above lava, fire, cactus or current location
                        safe[i] = ok && (block[id] & SPACE)!=0;
                        if(i>2 && !safe[i] && safe[i-1] && !safe[i-3]) safe[i-1] = safe[i-2] = false; // not enough room
                    }
                    for(i=130;i>0;i--) if(safe[i] && safe[i-1]) safe[i] = false; // remove locations in air
                    while(y>0 && y<129) if(safe[y += dir]) {
                        if(y < 1 || (isHell && y>127)) break; // extra sanitizing
                        teleport = true; y++; break; // found the place
                    }
                } else if(keyPress(keyTeleportCursor) && rayTrace(256d, 0f)) { // teleport to cursor
                    x = rayHitX(); y = rayHitY(); z = rayHitZ(); s = rayHitSide();
                    if(s==0) y--; if(s==1) y++; if(s==2) z--; if(s==3) z++; if(s==4) x--; if(s==5) x++; // move to side
                    i = y; id = 0; if(!fly) while(i>0 && (block[id = mapGetId(x,i-1,z)] & SOLID) == 0) i--; // what is down there?
                    if(mapGetId(x,i-1,z)!=81 && id != 10 && id != 11 && id != 51) { // ... nothing bad.
                        if((block[mapGetId(x,y+1,z)] & SOLID)!=0) y--; else if((block[mapGetId(x,y-1,z)] & SOLID)!=0) y++;
                        if((y-i < 4) && (block[mapGetId(x,y-1,z)] & SPACE)!=0 && (block[mapGetId(x,y,z)] & SPACE)!=0 && (block[mapGetId(x,y+1,z)] & SPACE)!=0) teleport = true; // plenty of space
                    }
                }
                if(teleport && optTeleportUseItem != 0) { // use the item
                    int cur = getInvCur(), use = -1, cnt;
                    for(i=0;i<36;i++) if(invItems[i]!=null && isItemsMatch(invItems[i], optTeleportUseItem) && (!optTeleportIsSelected || i==cur)) { use = i; break; }
                    if(use == -1) teleport = false; // nothing to use
                    else {
                        cnt = getItemsCount(invItems[use]) - 1;
                        if(cnt == 0) invItems[use] = null; else setItemsCount(invItems[use], cnt);
                    }
                }
                if(teleport) { // do the deed
                    setEntityPos(player, 0.5+x, 0.75+y, 0.5+z);
                    entTpSound = player;
                }
            }
            // teleport effect when player teleported
            if(entTpSound != null) noiseTP(entTpSound);
        } catch(Exception error) { err("error: \"teleport\" update failed", error); }
        // update "cheat"
        if(modCheatEnabled) try {
            if(!isMenu && keyPress(keyCheat)) {
                cheating = !cheating;
                if(!modCheatAllowed && cheating) {
                    cheating = false;
                    chatClient("�4zombe's �2cheat�4-mod is not allowed on this server.");
                }
            }
            if(!isMultiplayer) {
                if((!cheating || !optCheatRestoreHealth) && getHealth(player)>200) setHealth(player, 20);
                setEntityFireImmune(player, cheating && optCheatFireImmune);
            }
            if(cheatView != null) {
                if(isWorldChange || !cheating || !getEntities().contains(cheatView) || getView()==player) cheatView = null;
                if(cheatView == null) setView(player);
            }
            if(cheatView != null) setMsg(MTAG2, "View: �9" + getEntityName(cheatView));
            if(cheating) {
                if(!isMenu) {
                    if(keyPress(keyCheatView)) {
                        if(cheatView != null) {
                            cheatView = null;
                            setView(player);
                        } else {
                            // hold on to your hats - math follows
                            float x1, x2, x3, xt, y1, y2, y3, yt, z1, z2, z3, zt, yaw, pitch, u, distS, factor;
                            x1 = (float)posX; y1 = (float)posY; z1 = (float)posZ;
                            yaw = getEntityYaw(player) * (float)(Math.PI / 180.0);
                            pitch = getEntityPitch(player) * (float)(Math.PI / 180.0);
                            x2 = x1 + 100f * ( -(float)Math.sin(yaw) * (float)Math.abs(Math.cos(pitch)) );
                            y2 = y1 + 100f * ( -(float)Math.sin(pitch) );
                            z2 = z1 + 100f * ( (float)Math.cos(yaw) * (float)Math.abs(Math.cos(pitch)) );
                            Object best = null;
                            float bestDS = 1000000000f;
                            List list = getEntities();
                            Iterator it = list.iterator();
                            while(it.hasNext()) {
                                Object ent = it.next();
                                if(!getEntityIsLiving(ent) || ent == player) continue;
                                x3 = (float)getEntityPosX(ent);  y3 = (float)getEntityPosY(ent);  z3 = (float)getEntityPosZ(ent);
                                if((x2-x1)*(x3-x1) + (y2-y1)*(y3-y1) + (z2-z1)*(z3-z1) < 0f) continue;
                                factor = 1f / ( (x1-x3)*(x1-x3) + (y1-y3)*(y1-y3) + (z1-z3)*(z1-z3) );
                                xt = x2 - x1; yt = y2 - y1; zt = z2 - z1;  u = xt*xt + yt*yt + zt*zt;
                                u = ( (x3-x1)*(x2-x1) + (y3-y1)*(y2-y1) + (z3-z1)*(z2-z1) ) / u;
                                xt = x1 + u*(x2-x1) - x3; yt = y1 + u*(y2-y1) - y3; zt = z1 + u*(z2-z1) - z3;
                                distS = ( xt*xt + yt*yt + zt*zt ) * factor;
                                if(distS < bestDS) { best = ent; bestDS = distS; }
                            }
                            if(best != null) setView(cheatView = best);
                        }
                    }
                    if(keyPress(keyCheatShowMobs)) cheatShowMobs = !cheatShowMobs;
                    if(keyPress(keyCheatShowOres)) cheatShowOres = !cheatShowOres;
                    if(keyPress(keyCheatHighlight)) cheatHighlight = !cheatHighlight;
                    if(keyPress(keyCheatHealth)) optCheatRestoreHealth = !optCheatRestoreHealth;
                    if(optCheatSeeIsToggle) { if(keyPress(keyCheatSee)) cheatSee = !cheatSee; } else cheatSee = keyDown(keyCheatSee);
                    if(!isMultiplayer && keyPress(keyCheatRemoveFire)) {
                        int x = fix(posX), y = fix(posY), z = fix(posZ);
                        for(int dx=-16;dx<=16;dx++) for(int dy=-16;dy<=16;dy++) for(int dz=-16;dz<=16;dz++) if(mapGetId(x+dx,y+dy,z+dz)==51) mapSetIdMeta(x+dx,y+dy,z+dz,0,0);
                    }
                }
                if(!isMultiplayer) {
                    if(!optCheatFallDamage) setFall(player, 0f);
                    if(optCheatRestoreHealth) { setHealth(player, 2000); setFire(player, 0); setAir(player, 300); }
                    if(optCheatInfArrows || optCheatInfArmor || optCheatInfSword || optCheatInfTools) for(int slot=0;slot<invItems.length;slot++) if(invItems[slot] != null) {
                        Object items = invItems[slot];
                        int id = getItemsId(items);
                        if(id < 256 || id >= cheatItems) continue;
                        if(optCheatInfArrows && id==262) setItemsCount(items, 32);
                        else if(cheatDamage[id]) setItemsInfo(items, 0);
                    }
                    if(optCheatInfArmor) for(int slot=0;slot<invArmors.length;slot++) if(invArmors[slot] != null) {
                        int id = getItemsId(invArmors[slot]);
                        if(id < 256 || id >= cheatItems) continue;
                        if(cheatDamage[id]) setItemsInfo(invArmors[slot], 0);
                    }
                }
            }
        } catch(Exception error) { err("error: \"cheat\" update failed", error); }
        // update "resize"
        if(modResizeEnabled && !isMultiplayer) try {
            List list = getEntities();
            Iterator it = list.iterator();
            int chance;
            while(it.hasNext()) {
                Object ent = it.next();
                if(getEntityAge(ent)!=1) continue;
                int type = getEntityType(ent);
                if(type==0 || type==LIVING) continue;
                chance = rnd.nextInt(100);
                resizeSize[type] = getEntityHeight(ent); // store original size
                if(resizeChanceSmall[type]>chance) setEntitySize(ent, false);
                else if(resizeChanceBig[type]<chance) setEntitySize(ent, true);
            }
        } catch(Exception error) { err("error: \"resize\" update failed", error); }
        // store final movement
        movX = getEntityMotionX(player);
        movZ = getEntityMotionZ(player);
        // total fuckup log
        } catch(Exception error) {
            err("error: update-handle failed", error);
        }
    }
    
    // ################################################################################################################ START
    public static void pingStartHandle() {
        try {
        // update "cheat"
        if(modCheatAllowed && cheating && cheatSee) obliqueNearPlaneClip(0.0f, 0.0f, -1.0f, -optCheatSeeDist);
        // total fuckup log
        } catch(Exception error) {
            err("error: start-handle failed", error);
        }
    }
    
    // ################################################################################################################ ITEMS
    public static void pingItemsHandle() {
        if(cheating && cheatHighlight && (optCheatHighlightMode&1)!=0) {
            GL11.glLight(GL11.GL_LIGHT0, GL11.GL_AMBIENT, cheatAmbItems);
        }
    }
    
    // ################################################################################################################ GEOM
    public static void pingGeomHandle() {
        if(cheating && cheatHighlight && (optCheatHighlightMode&2)!=0) {
            GL11.glEnable(GL11.GL_LIGHTING);
            GL11.glLight(GL11.GL_LIGHT0, GL11.GL_AMBIENT, cheatAmbGeom);
        }
    }

    // ################################################################################################################ DRAW
    private static long prevTick, curTick;
    private static float seconds; // current frame delta time
    public static void pingDrawHandle(float delta) {
        try {
        if(player == null || map == null || renderer == null || cheatView != null) return;
        // update player position
        posX = getEntityPosX(player); posY = getEntityPosY(player); posZ = getEntityPosZ(player);
        // update time
        curTick = System.nanoTime();
        float seconds = ((float)(curTick - prevTick)) * 0.000000001f;
        if(seconds > 1f) seconds = 0f;
        prevTick = curTick;
        // draw in 3d
        float px = (float)posX, py = (float)posY, pz = (float)posZ;
        float mx = (float)getEntityPrevPosX(player), my = (float)getEntityPrevPosY(player) ,mz = (float)getEntityPrevPosZ(player);
        float x = mx + ( px - mx ) * delta, y = my + ( py - my ) * delta, z = mz + ( pz - mz ) * delta;
        // draw "chest"
        if(!isMultiplayer && modIconEnabled) try {
            //float halfTexel = 0.5f / GL11.glGetTexLevelParameterf(GL11.GL_TEXTURE_2D, 0, GL11.GL_TEXTURE_WIDTH);
            int ix = fix(posX), iy = fix(posY), iz = fix(posZ), range = 16, blockId;
            textureBlock = getTexture("/terrain.png"); textureItems = getTexture("/gui/items.png"); texture = -1;
            GL11.glBegin(GL11.GL_QUADS);
            for(int dx=-range;dx<=range;dx++) for(int dy=-range;dy<=range;dy++) for(int dz=-range;dz<=range;dz++) if((block[blockId = mapGetId(ix+dx, iy+dy, iz+dz)] & STORAGE) != 0) {
                int icon = -1, side, i, xx = ix+dx, yy = iy+dy, zz = iz+dz;
                Object tent = getTileEntity(xx, yy, zz);
                float vx, vy, vz, tx, ty;
                if(blockId == 54) { // chest
                    if(!optIconShowChest) continue;
                    Object items[] = getChestItems(tent);
                    for(i=0;i<27;i++) if(items[i] != null) { icon = bindAndGetIcon(items[i]); break; }
                    if(icon < 0) continue;
                    vx = 0.5f + xx - x; vy = 0.5f + yy - y; vz = 0.5f + zz - z; tx = 0.0625f * (icon % 16); ty = 0.0625f * (icon / 16);
                    if((block[mapGetId(xx-1, yy, zz)] & SPACE) != 0) chestDrawIcon(4, getLight(xx-1, yy, zz), tx, ty, vx, vy, vz, -0.4f, 0.4f, -0.4f, 0.4f);
                    if((block[mapGetId(xx+1, yy, zz)] & SPACE) != 0) chestDrawIcon(5, getLight(xx+1, yy, zz), tx, ty, vx, vy, vz, -0.4f, 0.4f, -0.4f, 0.4f);
                    if((block[mapGetId(xx, yy, zz-1)] & SPACE) != 0) chestDrawIcon(2, getLight(xx, yy, zz-1), tx, ty, vx, vy, vz, -0.4f, 0.4f, -0.4f, 0.4f);
                    if((block[mapGetId(xx, yy, zz+1)] & SPACE) != 0) chestDrawIcon(3, getLight(xx, yy, zz+1), tx, ty, vx, vy, vz, -0.4f, 0.4f, -0.4f, 0.4f);
                } else if(blockId == 23) { // dispenser
                    if(!optIconShowDispenser) continue;
                    Object items[] = getDispItems(tent);
                    for(i=0;i<9;i++) if(items[i] != null) { icon = bindAndGetIcon(items[i]); break; }
                    if(icon < 0) continue;
                    vx = 0.5f + xx - x; vy = 0.5f + yy - y; vz = 0.5f + zz - z; tx = 0.0625f * (icon % 16); ty = 0.0625f * (icon / 16);
                    side = mapGetMeta(xx, yy, zz); if(side < 4) zz += side == 2 ? -1 : 1; else xx += side == 4 ? -1 : 1;
                    if((block[mapGetId(xx, yy, zz)] & SPACE) != 0) chestDrawIcon(side, getLight(xx, yy, zz), tx, ty, vx, vy, vz, -0.1f, 0.1f, -0.1f, 0.1f);
                } else { // furnace
                    if(!optIconShowFurnace) continue;
                    Object items[] = getFurnaceItems(tent);
                    vx = 0.5f + xx - x; vy = 0.5f + yy - y; vz = 0.5f + zz - z;
                    side = mapGetMeta(xx, yy, zz); if(side < 4) zz += side == 2 ? -1 : 1; else xx += side == 4 ? -1 : 1;
                    if((block[mapGetId(xx, yy, zz)] & SPACE) != 0) {
                        float light = getLight(xx, yy, zz);
                        if(items[0] != null) { // input
                            icon = bindAndGetIcon(items[0]); tx = 0.0625f * (icon % 16); ty = 0.0625f * (icon / 16);
                            chestDrawIcon(side, light, tx, ty, vx, vy, vz, -0.4f, -0.2f,  0.2f,  0.4f);
                        }
                        if(items[1] != null) { // fuel
                            icon = bindAndGetIcon(items[1]); tx = 0.0625f * (icon % 16); ty = 0.0625f * (icon / 16);
                            chestDrawIcon(side, light, tx, ty, vx, vy, vz, -0.1f,  0.1f, -0.4f, -0.2f);
                        }
                        if(items[2] != null) { // output
                            icon = bindAndGetIcon(items[2]); tx = 0.0625f * (icon % 16); ty = 0.0625f * (icon / 16);
                            chestDrawIcon(side, light, tx, ty, vx, vy, vz,  0.2f,  0.4f,  0.2f,  0.4f);
                        }
                    }
                }
            }
            GL11.glEnd();
        } catch(Exception error) { err("error: \"chest\" draw failed", error); }
        // draw "cheat"
        if(cheatShowMobs || cheatShowOres || optCheatShowHealth || optInfoShowHealth) try {
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            if(!isMultiplayer && ((cheating && optCheatShowHealth) || optInfoShowHealth)) {
                GL11.glColor3ub((byte)0, (byte)128, (byte)0);
                GL11.glBegin(GL11.GL_QUADS);
                List list = getEntities();
                Iterator it=list.iterator();
                while(it.hasNext()) {
                    Object ent = it.next();
                    if(!getEntityIsLiving(ent) || ent == player) continue;
                    int health = getHealth(ent);
                    mx = (float)getEntityPrevPosX(ent); my = (float)getEntityPrevPosY(ent) + 0.4f; mz = (float)getEntityPrevPosZ(ent);
                    my += getEntityHeight(ent);
                    float dx = mz - pz, dz = -(mx - px), d = (float)Math.sqrt(dx*dx + dz*dz), pos = 0.25f * health;
                    mx -= x; my -= y; mz -= z;
                    if(d < 0.1f || d > 64f) continue;
                    dx /= d; dz /= d;
                    while(health>0) {
                        float ax1, ax2, az1, az2;
                        pos -= 0.3f;
                        ax1 = pos * dx * 0.1f; az1 = pos * dz * 0.1f;
                        pos -= 0.7f;
                        ax2 = pos * dx * 0.1f; az2 = pos * dz * 0.1f;
                        GL11.glVertex3f(mx+ax1, my-0.1f, mz+az1);
                        GL11.glVertex3f(mx+ax2, my-0.1f, mz+az2);
                        GL11.glVertex3f(mx+ax2, my+(health == 1 ? 0f : 0.1f), mz+az2);
                        GL11.glVertex3f(mx+ax1, my+(health == 1 ? 0f : 0.1f), mz+az1);
                        health -= 2;
                    }
                }
                GL11.glEnd();
            }
            GL11.glDisable(GL11.GL_DEPTH_TEST);
            GL11.glDisable(GL11.GL_FOG);
            GL11.glBegin(GL11.GL_LINES);
            if(modCheatAllowed && cheating && cheatShowMobs) {
                List list = getEntities();
                Iterator it=list.iterator();
                while(it.hasNext()) {
                    Object ent = it.next();
                    int type = getEntityType(ent);
                    if(cheatMobs[type] == null || ent == player) continue;
                    GL11.glColor3ub(cheatMobs[type].r, cheatMobs[type].g, cheatMobs[type].b);
                    mx = (float)getEntityPosX(ent) - x; my = (float)getEntityPosY(ent) - y; mz = (float)getEntityPosZ(ent) - z;
                    GL11.glVertex3f(mx,my+(optCheatShowMobsSize ? getEntityHeight(ent) : 2.0f),mz); GL11.glVertex3f(mx,my,mz);
                }
            }
            if(modCheatAllowed && cheating && cheatShowOres) {
                cheatRefresh += seconds;
                if(cheatRefresh > 0.3f) {
                    cheatReCheck(fix(posX), fix(posY), fix(posZ));
                    cheatRefresh -= 0.3f;
                }
                for(int i=0;i<cheatCur;i++) {
                    Mark got = cheatMark[i];
                    GL11.glColor3ub(got.r,got.g,got.b);
                    mx = got.x - x; my = got.y - y; mz = got.z - z;
                    GL11.glVertex3f(mx+0.25f,my+0.25f,mz+0.25f); GL11.glVertex3f(mx-0.25f,my-0.25f,mz-0.25f);
                    GL11.glVertex3f(mx+0.25f,my+0.25f,mz-0.25f); GL11.glVertex3f(mx-0.25f,my-0.25f,mz+0.25f);
                    GL11.glVertex3f(mx+0.25f,my-0.25f,mz+0.25f); GL11.glVertex3f(mx-0.25f,my+0.25f,mz-0.25f);
                    GL11.glVertex3f(mx+0.25f,my-0.25f,mz-0.25f); GL11.glVertex3f(mx-0.25f,my+0.25f,mz+0.25f);
                }
            }
            GL11.glEnd();
            GL11.glEnable(GL11.GL_FOG);
            GL11.glEnable(GL11.GL_DEPTH_TEST);
            GL11.glEnable(GL11.GL_TEXTURE_2D);
        } catch(Exception error) { err("error: \"cheat\" draw failed", error); }
        // draw "path"
        if(modPathEnabled) try {
            // get previous location
            float tx = pathf[pathLast] - px, ty = pathf[pathLast+1] - (py - 1.25f), tz = pathf[pathLast+2] - pz;
            float dist = tx*tx + ty*ty + tz*tz;
            // do we have a new pathpoint
            if(dist > optPathMin) {
                pathLast += 3; if(pathLast >= pathf.length) pathLast = 0;
                if(pathCount < optPathPoints) pathCount++;
                pathf[pathLast] = px;
                pathf[pathLast+1] = py - 1.25f;
                pathf[pathLast+2] = pz;
            }
            // draw the path?
            if(optPathShow && pathCount>3) {
                pathAnimCur += seconds * optPathAnimSpeed;
                if(pathAnimCur > optPathSpacing) pathAnimCur -= optPathSpacing;
                float x1 = pathf[pathLast] - x, y1 = pathf[pathLast+1] - y, z1 = pathf[pathLast+2] - z, x2, y2, z2;
                int cnt = pathCount-1, at = pathLast, anim = ((pathf.length - pathLast) / 3 + (int)pathAnimCur) % optPathSpacing;
                int skip = 4;
                GL11.glDisable(GL11.GL_TEXTURE_2D);
                GL11.glColor3ub(optPathColor.r,optPathColor.g,optPathColor.b);
                GL11.glBegin(GL11.GL_LINES);
                    do {
                        x2 = x1; y2 = y1; z2 = z1;
                        at -= 3; if(at<0) at = pathf.length - 3;
                        x1 = pathf[at] - x; y1 = pathf[at+1] - y; z1 = pathf[at+2] - z;
                        if(optPathSpacing > 2) {
                            if(++anim == optPathSpacing) anim = 0;
                            if(anim <= 1 && skip < 0) { GL11.glVertex3f(x1,y1,z1); GL11.glVertex3f(x2,y2,z2); }
                        } else if(skip < 0) { GL11.glVertex3f(x1,y1,z1); GL11.glVertex3f(x2,y2,z2); }
                        skip--;
                    } while((--cnt) != 0);
                GL11.glEnd();
                GL11.glEnable(GL11.GL_TEXTURE_2D);
            }
        } catch(Exception error) { err("error: \"path\" draw failed", error); }
        // draw "safe"
        if(modSafeEnabled && safeShow) try {
            if(--safeUpdate<0) {
                safeUpdate = 16;
                reCheckSafe(fix(posX), fix(posY), fix(posZ));
            }
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glBegin(GL11.GL_LINES);
            for(int i=0;i<safeCur;i++) {
                Mark got = safeMark[i];
                if(got.r==1) GL11.glColor3ub(optSafeDangerColorSun.r,optSafeDangerColorSun.g,optSafeDangerColorSun.b);
                else GL11.glColor3ub(optSafeDangerColor.r,optSafeDangerColor.g,optSafeDangerColor.b);
                mx = got.x - x; my = got.y - y; mz = got.z - z;
                GL11.glVertex3f(mx+0.5f,my,mz+0.5f); GL11.glVertex3f(mx-0.5f,my,mz-0.5f);
                GL11.glVertex3f(mx+0.5f,my,mz-0.5f); GL11.glVertex3f(mx-0.5f,my,mz+0.5f);
            }
            GL11.glEnd();
            GL11.glEnable(GL11.GL_TEXTURE_2D);
        } catch(Exception error) { err("error: \"safe\" draw failed", error); }
        // draw "build"
        if(modBuildEnabled && !isMultiplayer && buildMark > 0) try {
            // calculate selection box
            float sx = (float)buildSX - x - 0.1f, ex = (float)(buildMark==2 ? buildEX : buildSX) - x + 1.1f;
            float sy = (float)buildSY - y - 0.1f, ey = (float)(buildMark==2 ? buildEY : buildSY) - y + 1.1f;
            float sz = (float)buildSZ - z - 0.1f, ez = (float)(buildMark==2 ? buildEZ : buildSZ) - z + 1.1f;
            // change state
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glDepthMask(false);
            GL11.glDisable(GL11.GL_CULL_FACE);
            // draw selection box sides
            if(buildMark == 2) {
                GL11.glEnable(GL11.GL_BLEND); GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
                GL11.glColor4ub((byte)255,(byte)64,(byte)32,(byte)32);
                GL11.glBegin(GL11.GL_QUADS);
                    GL11.glVertex3f(sx,sy,sz); GL11.glVertex3f(sx,sy,ez); GL11.glVertex3f(sx,ey,ez); GL11.glVertex3f(sx,ey,sz);
                    GL11.glVertex3f(ex,sy,sz); GL11.glVertex3f(ex,sy,ez); GL11.glVertex3f(ex,ey,ez); GL11.glVertex3f(ex,ey,sz);
                    GL11.glVertex3f(sx,sy,sz); GL11.glVertex3f(sx,sy,ez); GL11.glVertex3f(ex,sy,ez); GL11.glVertex3f(ex,sy,sz);
                    GL11.glVertex3f(sx,ey,sz); GL11.glVertex3f(sx,ey,ez); GL11.glVertex3f(ex,ey,ez); GL11.glVertex3f(ex,ey,sz);
                    GL11.glVertex3f(sx,sy,sz); GL11.glVertex3f(sx,ey,sz); GL11.glVertex3f(ex,ey,sz); GL11.glVertex3f(ex,sy,sz);
                    GL11.glVertex3f(sx,sy,ez); GL11.glVertex3f(sx,ey,ez); GL11.glVertex3f(ex,ey,ez); GL11.glVertex3f(ex,sy,ez);
                GL11.glEnd();
                GL11.glDisable(GL11.GL_BLEND);
            }
            // draw selection box
            GL11.glColor3ub((byte)32,(byte)64,(byte)255);
            GL11.glBegin(GL11.GL_LINES);
                GL11.glVertex3f(sx,sy,sz); GL11.glVertex3f(sx,sy,ez);
                GL11.glVertex3f(sx,sy,ez); GL11.glVertex3f(sx,ey,ez);
                GL11.glVertex3f(sx,ey,ez); GL11.glVertex3f(sx,ey,sz);
                GL11.glVertex3f(sx,ey,sz); GL11.glVertex3f(sx,sy,sz);
                    
                GL11.glVertex3f(ex,sy,sz); GL11.glVertex3f(ex,sy,ez);
                GL11.glVertex3f(ex,sy,ez); GL11.glVertex3f(ex,ey,ez);
                GL11.glVertex3f(ex,ey,ez); GL11.glVertex3f(ex,ey,sz);
                GL11.glVertex3f(ex,ey,sz); GL11.glVertex3f(ex,sy,sz);

                GL11.glVertex3f(sx,sy,sz); GL11.glVertex3f(ex,sy,sz);
                GL11.glVertex3f(sx,sy,ez); GL11.glVertex3f(ex,sy,ez);
                GL11.glVertex3f(sx,ey,ez); GL11.glVertex3f(ex,ey,ez);
                GL11.glVertex3f(sx,ey,sz); GL11.glVertex3f(ex,ey,sz);
            GL11.glEnd();
            // restore state
            GL11.glEnable(GL11.GL_CULL_FACE);
            GL11.glDepthMask(true);
            GL11.glEnable(GL11.GL_TEXTURE_2D);
        } catch(Exception error) { err("error: \"build\" draw failed", error); }
        // draw "cloud"
        if(modCloudEnabled && !optCloudVanilla) {
            if(optCloudShow) {
                double mov = getEntityPrevPosY(player);
                setEntityPrevPosY(player, mov + (getEntityPosY(player) - mov) * delta - optCloudOffset);
                render.callSuper(0F);
                setEntityPrevPosY(player, mov);
            }
        } else {
            render.callSuper(delta);
        }
        // done
        // total fuckup log
        } catch(Exception error) {
            err("error: draw-handle failed", error);
        }
    }

    // ################################################################################################################ GUI
    private static boolean ML_loaded;
    private static Method ML_OnTick;
    public static void pingDrawGUIHandle() {
        // draw GUI?
        if(!isHideGUI()) {
            // set state
            GL11.glMatrixMode(GL11.GL_PROJECTION); GL11.glPushMatrix(); GL11.glLoadIdentity(); setOrtho();
            GL11.glMatrixMode(GL11.GL_MODELVIEW); GL11.glPushMatrix(); GL11.glLoadIdentity();
            GL11.glTranslatef(0.0F, 0.0F, -2000F);
            GL11.glDisable(GL11.GL_LIGHTING);
                // draw text
            if(isShowDebug()) {
                setMsg(MDEBUG, pingDebugHandle(), 0xffffff, 2, 90);
                Text tmp = texts[MDEBUG];
                String lines[] = tmp.msg.split("\n");
                int x = tmp.x, y = tmp.y, c = tmp.color;
                for(int line=0;line<lines.length;line++,y+=10) showText(lines[line], x, y, c);
            } else {
                setMsg(MTAG1, pingTextHandle());
                for(int i=0;i<texts.length;i++) {
                    Text tmp = texts[i];
                    if(tmp == null || (isMenu && i != MTAG1) || i == MDEBUG) continue;
                    String lines[] = tmp.msg.split("\n");
                    int x = tmp.x, y = tmp.y, c = tmp.color;
                    for(int line=0;line<lines.length;line++,y+=10) showText(lines[line], x, y, c);
                }
            }
            // restore state
            GL11.glPopMatrix();
            GL11.glMatrixMode(GL11.GL_PROJECTION); GL11.glPopMatrix();
            GL11.glMatrixMode(GL11.GL_MODELVIEW);
        }
        // modLoader compatibility
        if(!ML_loaded) try {
            ML_loaded = true;
            ML_OnTick = Class.forName("ModLoader").getDeclaredMethod("OnTick", new Class[]{ Minecraft.class });
        } catch(Exception whatever) { ML_OnTick = null; }
        if(ML_OnTick != null) getResult(ML_OnTick, null, mc);
    }

    // ################################################################################################################ TEXT
    public static String pingTextHandle() {
        if(player == null || map == null || renderer == null) return "";
        String infoLine = "";
        try {
        // text for sun
        if(modSunEnabled && sunTimeOffset!=0) infoLine += tagSunTime + (sunTimeOffset<0 ? "" : "+") + (sunTimeOffset/20) + " ";
        // text for info : time
        if(modInfoEnabled && optInfoShowTime) infoLine += "[" + getTime(getTime() + sunTimeOffset) + "] ";
        // text for compass : pos
        if((modCompassEnabled && optCompassShowPos) || (modInfoEnabled && optInfoShowPos)) infoLine += "(" + fix(posX) + "," + fix(posY) + "," + fix(posZ) + ") ";
        // text for compass : alternate
        if(modCompassEnabled && !compassShowOrig && tagCompassAlternate.length()>0) infoLine += tagCompassAlternate + " ";
        // text for fly
        if(modFlyEnabled && fly && tagFly.length()>0) infoLine += tagFly + " ";
        // text for fly/noclip
        if(modFlyEnabled && fly && flyNoClip && tagFlyNoClip.length()>0) infoLine += tagFlyNoClip + " ";
        // text for safe
        if(modSafeEnabled && safeShow && tagSafe.length()>0) infoLine += tagSafe + " ";
        // text for cheat
        if(modCheatAllowed && modCheatEnabled && cheating && tagCheater.length()>0) infoLine += tagCheater + " ";
        // text for build
        if(!isMultiplayer && modBuildEnabled && optBuild && tagBuildEnabled.length()>0) infoLine += tagBuildEnabled + " ";
        // text for recipe
        if(modRecipeEnabled && optRecipeShowId) { Object items = invItems[getInvCur()]; if(items != null) { int id = getItemsId(items); infoLine += "id:" + (getItemHasSubTypes(getItem(id)) ? id + "/" + getItemsInfo(items) : id ) + " "; } }
        // text for cloud
        if(modCloudEnabled && optCloudVanilla && tagCloudVanilla.length()>0) infoLine += tagCloudVanilla + " ";
        // text for cart
        if(!isMultiplayer && modCartEnabled && optCartPerpetual && tagCartPerpetual.length()>0) infoLine += tagCartPerpetual + " ";
        // text for weather
        if(modWeatherEnabled && !isMultiplayer && getRain()) infoLine += (getThunder() ? (weatherMayhem ? tagWeatherMayhem : tagWeatherThundering) : tagWeatherRaining) + " ";
        // text for info : biome
        if(modInfoEnabled && optInfoShowBiome) infoLine += getBiomeName(fix(posX),fix(posZ)) + " ";
        // total fuckup log
        } catch(Exception error) {
            err("error: text-handle failed", error);
        }
        // done
        return infoLine;
    }

    // ################################################################################################################ DEBUG
    public static String pingDebugHandle() {
        if(player == null || map == null || renderer == null) return "";
        String infoLine = "";
        try {
        // text for minecart
        if(modCartEnabled && getEntityIsCart(inWhat)) {
            double mx = getEntityMotionX(inWhat), mz = getEntityMotionZ(inWhat);
            infoLine += "\nMinecart speed (acm): " + Math.sqrt(mx*mx + mz*mz);
        }
        // total fuckup log
        } catch(Exception error) {
            err("error: text-handle failed", error);
        }
        // done
        return infoLine;
    }


    // ################################################################################################################

    // ---------------------------------------------------------------------------------------------------------------- rainHandle
    public static boolean drawRainHandle() {
        return !optWeatherNoDraw;
    }

    // ---------------------------------------------------------------------------------------------------------------- leavesHandle
    public static int leavesDropHandle() {
        return rnd.nextInt(optItemLeavesDrop) == 0 ? 1 : 0;
    }

    // ---------------------------------------------------------------------------------------------------------------- leavesHandle
    public static int leavesHandle(int meta) {
        int chance = rnd.nextInt(100);
        if(meta==0 && chance < optItemOakChance) return optItemOakSpecial;
        if(meta==1 && chance < optItemPineChance) return optItemPineSpecial;
        if(meta==2 && chance < optItemBirchChance) return optItemBirchSpecial;
        return 6 | (meta << 16);
    }

    // ---------------------------------------------------------------------------------------------------------------- flyDickmoveCancel
    public static void itemGraphicsLevelHandle(boolean flag) {
        if(!optItemChangeLeaves) return;
        setBlockGraphicsLevel(itemLeavesO, flag);
        setBlockGraphicsLevel(itemLeavesM, flag);
    }

    // ---------------------------------------------------------------------------------------------------------------- flyDickmoveCancel
    private static double movX, movZ;
    public static void flyDickmoveCancel() {
        if(!flyNoClip || !fly || isMultiplayer) return;
        setEntityMotionX(player, movX);
        setEntityMotionZ(player, movZ);
    }

    // ---------------------------------------------------------------------------------------------------------------- dropAll
    public static boolean dropAllHandle() {
        return isMultiplayer || !modDeathEnabled || optDeathDropInv;
    }

    // ---------------------------------------------------------------------------------------------------------------- icon / textures
    private static int textureBlock, textureItems, texture;
    private static final float iconSize = 1f / 16f;
    private static void chestDrawIcon(int side, float color, float tx, float ty, float x, float y, float z, float xs, float xe, float ys, float ye) {
        GL11.glColor3f(color, color, color);
        float txe = tx + iconSize, tye = ty + iconSize;
        if(side == 4) { // -x
            GL11.glTexCoord2f(txe,tye); GL11.glVertex3f(x-0.52f, y+ys, z+xe);
            GL11.glTexCoord2f(txe,ty ); GL11.glVertex3f(x-0.52f, y+ye, z+xe);
            GL11.glTexCoord2f(tx ,ty ); GL11.glVertex3f(x-0.52f, y+ye, z+xs);
            GL11.glTexCoord2f(tx ,tye); GL11.glVertex3f(x-0.52f, y+ys, z+xs);
        } else if(side == 5) { // +x
            GL11.glTexCoord2f(txe,tye); GL11.glVertex3f(x+0.52f, y+ys, z-xe);
            GL11.glTexCoord2f(txe,ty ); GL11.glVertex3f(x+0.52f, y+ye, z-xe);
            GL11.glTexCoord2f(tx ,ty ); GL11.glVertex3f(x+0.52f, y+ye, z-xs);
            GL11.glTexCoord2f(tx ,tye); GL11.glVertex3f(x+0.52f, y+ys, z-xs);
        } else if(side == 2) { // -z
            GL11.glTexCoord2f(txe,tye); GL11.glVertex3f(x-xe, y+ys, z-0.52f);
            GL11.glTexCoord2f(txe,ty ); GL11.glVertex3f(x-xe, y+ye, z-0.52f);
            GL11.glTexCoord2f(tx ,ty ); GL11.glVertex3f(x-xs, y+ye, z-0.52f);
            GL11.glTexCoord2f(tx ,tye); GL11.glVertex3f(x-xs, y+ys, z-0.52f);
        } else if(side == 3) { // +z
            GL11.glTexCoord2f(txe,tye); GL11.glVertex3f(x+xe, y+ys, z+0.52f);
            GL11.glTexCoord2f(txe,ty ); GL11.glVertex3f(x+xe, y+ye, z+0.52f);
            GL11.glTexCoord2f(tx ,ty ); GL11.glVertex3f(x+xs, y+ye, z+0.52f);
            GL11.glTexCoord2f(tx ,tye); GL11.glVertex3f(x+xs, y+ys, z+0.52f);
        }
    }

    private static int bindAndGetIcon(Object items) {
        int id = getItemsId(items);
        if(getItem(id) == null) return -1; // chest contains unknown stuff
        if(id == 35) setItemsInfo(items, 15 - getItemsInfo(items)); // wool icon fix (why the hell is this messed up !?)
        int tex = id < 256 ? textureBlock : textureItems, icon = getItemsIcon(items);
        if(id == 35) setItemsInfo(items, 15 - getItemsInfo(items)); // wool icon fix
        if(tex == texture) return icon;
        GL11.glEnd();
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, texture = tex);
        GL11.glBegin(GL11.GL_QUADS);
        return icon;
    }

    // ---------------------------------------------------------------------------------------------------------------- timeToString
    private static String getTime(long time) {
        time += optInfoTimeOffset; // time counting offset as 0:00 is beginning of day normally
        int daytime = (int)(time % 24000), h = daytime / 1000, m = (int)((daytime % 1000) * 0.06f);
        return (h<10 ? "0" : "") + h + (m<10 ? " : 0" : " : ") + m;
    }

    private static String getRealTime(long time) {
        long d = time / 1728000; time %= 1728000;
        long h = time / 72000; time %= 72000;
        long m = time / 1200; time %= 1200;
        long s = time / 20; time %= 20;
        long u = time / 2;
        return ""+d+(h<10?"�f : �90":"�f : �9")+h+(m<10?"�f : �90":"�f : �9")+m+(s<10?"�f : �90":"�f : �9")+s+"�f . �9"+u;
    }

    // ---------------------------------------------------------------------------------------------------------------- sunOffset
    public static long sunOffsetHandle() { return modSunEnabled && sunTimeOffset!=0 ? sunTimeOffset : 0; }

    // ---------------------------------------------------------------------------------------------------------------- furnace
    public static boolean furnaceWasteHandle() { return isMultiplayer || !modFurnaceEnabled || optFurnaceFuelWaste; }
    public static int furnaceSmeltTimeHandle() { return isMultiplayer || !modFurnaceEnabled ? 200 : optFurnaceSmeltingTime; }
    public static boolean furnaceUseFuelHandle(int fuel, boolean canSmelt) { return isMultiplayer || !modFurnaceEnabled || (optFurnaceInfiniteFuel > fuel && (optFurnaceFuelWaste || canSmelt)); }
    public static Object furnaceSmeltingHandle(Integer id) { if(modFurnaceEnabled && !isMultiplayer && furnaceSmelting!=null) return furnaceSmelting.get(id); return null; }
    public static int furnaceWoodFuelHandle() { return !isMultiplayer && modFurnaceEnabled ? optFurnaceWoodFuel : 300; }
    public static int furnaceFuelHandle(Integer id) { return !isMultiplayer && modFurnaceEnabled && furnaceFuel!=null && furnaceFuel.containsKey(id) ? furnaceFuel.get(id) : 0; }
    public static boolean furnaceWorldUpdateHandle(int fuel, int x, int y, int z) { return fuel==0 && !isMultiplayer && modFurnaceEnabled && !optFurnaceFuelWaste && mapGetId(x,y,z)==62; }
    public static Object furnaceDecFuelHandle(Object items) {
        int count = getItemsCount(items);
        if(modFurnaceEnabled && !isMultiplayer && optFurnaceReturnBucket && getItemsId(items) == 327) return newItems(325, count);
        if(count == 1) return null;
        setItemsCount(items, count-1);
        return items;
    }

    // ---------------------------------------------------------------------------------------------------------------- boomDrop
    public static float boomDropHandle(int blockId) {
        if(modBoomEnabled && !isMultiplayer) {
            if((block[blockId] & ORE) != 0) return optBoomDropOreChance;
            else return optBoomDropChance;
        }
        return 0.3f;
    }

    // ---------------------------------------------------------------------------------------------------------------- boomDamage
    public static boolean boomDamageHandle(int eX, int eY, int eZ, boolean creeper) {
        boolean damage = true;
        if(creeper) {
            if(optBoomSafeRange == -1) damage = false;
            else if(optBoomSafeRange > 0) {
                int x1=eX-optBoomSafeRange,x2=eX+optBoomSafeRange,y1=eY-optBoomSafeRange,y2=eY+optBoomSafeRange,z1=eZ-optBoomSafeRange,z2=eZ+optBoomSafeRange;
                Search: for(int x=x1;x<=x2;x++) for(int y=y1;y<=y2;y++) for(int z=z1;z<=z2;z++) if((block[mapGetId(x,y,z)] & CRAFT)!=0) { damage = false; break Search; }
            }
        }
        return damage;
    }

    // ---------------------------------------------------------------------------------------------------------------- boomScale
    public static float boomScaleHandle(float boom, boolean creeper) {
        return modBoomEnabled && !isMultiplayer ? boom * (creeper ? optBoomScaleCreeper : optBoomScaleTNT) : boom;
    }

    // ---------------------------------------------------------------------------------------------------------------- crafting
    public static int craftingHandle() {
        return modCraftEnabled && keyDown(keyCraftAll) ? 64 : 1;
    }

    // ---------------------------------------------------------------------------------------------------------------- resize
    public static void resizeHandle(Object ent) {
        if(!modResizeEnabled || isMultiplayer || resizeSize==null) return;
        float resize = resizeSize[getEntityType(ent)];
        if(resize<=0.000001f) return;
        float scale = getEntityHeight(ent) / resize;
        GL11.glScalef(scale, scale, scale);
    }

    // ---------------------------------------------------------------------------------------------------------------- harvestable
    public static boolean harvestableHandle(boolean harvest) {
        if(modDigEnabled && optDigHarvestAlways) harvest = true;
        if(modBuildEnabled && optBuild) {
            if(optBuildHarvestRule == -1) harvest = false;
            else if(optBuildHarvestRule == 1) harvest = true;
        }
        return harvest;
    }
    
    // ---------------------------------------------------------------------------------------------------------------- digProgress
    public static float digProgressHandle(float progress, int blockId) {
        if(modBuildEnabled && optBuild) return (block[blockId] & TOUCH) != 0 ? 0.1f : optBuildDigSpeed;
        else if(ZMod.modDigEnabled) return progress * optDigSpeed;
        return progress;
    }

    // ---------------------------------------------------------------------------------------------------------------- ore
    private static void oreDistribute(byte data[], int rule[], byte result) {
        int i, chunk, max, min, attempt, size, above, x, y, z, at, cnt;
        for(i=0;i<rule.length;i+=6) {
            chunk = rule[i + 0];
            max = rule[i + 1];
            min = rule[i + 2];
            attempt = rule[i + 3];
            size = rule[i + 4];
            above = rule[i + 5];
            if(chunk<100 && rnd.nextInt(100)>=chunk) continue;
            while(attempt-->0) {
                x = rnd.nextInt(14)+1; y = rnd.nextInt(1+max-min) + min; z = rnd.nextInt(14)+1;
                at = x<<11 | z<<7 | y;
                if(data[at]!=1 || data[at-1]!=1 || data[at+1]!=above || data[at+128]!=1 || data[at-128]!=1 || data[at+2048]!=1 || data[at-2048]!=1) continue;
                cnt = size - 1;
                data[at] = result;
                while(cnt-->0) {
                    switch(rnd.nextInt(7)) {
                        case 0: continue;
                        case 1: at += 1; break;
                        case 2: at -= 1; break;
                        case 3: at += 128; break;
                        case 4: at -= 128; break;
                        case 5: at += 2048; break;
                        case 6: at -= 2048; break;
                    }
                    if(at<0) at += 32768; else if(at>=32768) at -= 32768;
                    if(data[at]==1) data[at] = result;
                }
            }
        }
    }

    // ---------------------------------------------------------------------------------------------------------------- cheat
    private static void cheatReCheck(int pX, int pY, int pZ) {
        cheatCur = 0;
        for(int x=pX-16;x<pX+16;x++) for(int y=pY-64;y<pY+64;y++) for(int z=pZ-16;z<pZ+16;z++) {
            Mark color = cheatOres[mapGetId(x,y,z)];
            if(color == null) continue;
            cheatMark[cheatCur++] = new Mark(x,y,z,color);
            if(cheatCur == cheatMax) return;
        }
    }

    // ---------------------------------------------------------------------------------------------------------------- safe
    private static void reCheckSafe(int pX, int pY, int pZ) {
        safeCur = 0;
        int id, maskA = SPAWN, maskB = SPAWN | LIQUID | SOLID, maskC = SPAWN, maskL = 0;
        if(modSpawnEnabled && !isMultiplayer) {
            if(!optSpawnAllowInNonAir) maskB |= DECAL;
            if(!optSpawnAllowOnNonNatural) maskL |= CRAFT;
            if(!optSpawnAllowOnGrass) maskL |= GRASS;
            if(!optSpawnAllowOnCobble) maskL |= COBBLE;
            if(!optSpawnAllowOnSand) maskL |= SAND;
            if(!optSpawnAllowOnGravel) maskL |= GRAVEL;
            if(!optSpawnAllowOnTree) maskL |= TREE;
            if(!optSpawnAllowOnSandstone) maskL |= SANDSTONE;
        }
        for(int x=pX-16;x<pX+16;x++) for(int y=pY-16;y<pY+16;y++) for(int z=pZ-16;z<pZ+16;z++) {
            int onWhat;
            // UPDATE: ensure the spawn check has not changed - search: completed * find the can-spawn function there
            if(((onWhat = block[mapGetId(x,y,z)]) & maskA) == 0) continue; // !eb1.g(i, j - 1, k)
            if((onWhat & maskL) != 0) continue; // spawn limitations from "spawn" mod
            if((block[mapGetId(x,y+1,z)] & maskB) != 0) continue; // eb1.g(i, j, k) || eb1.f(i, j, k).d()
            if((block[mapGetId(x,y+2,z)] & maskC) != 0) continue; // eb1.g(i, j + 1, k)
            // light level check
            if(getLightLevel(x, y+1, z, 16) > 7) continue;
            safeMark[safeCur++] = new Mark(x,y+1,z, optSafeShowWithSun && (getLightLevel(x, y+1, z, 0) > 7));
            if(safeCur == safeMax) return;
        }
    }
    
    // ---------------------------------------------------------------------------------------------------------------- fly
    private static boolean flew = false, moveOnGround;
    private static float flyTmp;
    public static void flyHandle(Object ent, double mx, double my, double mz) {
        if(ent == player) {
            if(modFlyEnabled) {
                flyTmp = getEntitySteps(ent);
                if(fly) {
                    my = 0d;
                    if(!isMenu) {
                        if(keyDown(keyFlyUp)) my += optFlySpeedVertical;
                        if(keyDown(keyFlyDown)) my -= optFlySpeedVertical;
                        double mul = ( optFlySpeedIsToggle ? flySpeed : keyDown(keyFlySpeed) ) ? optFlySpeedMulModifier : optFlySpeedMulNormal;
                        mx*=mul; my*=mul; mz*=mul;
                        setFall(ent, 0f); setEntityMotionY(ent, 0f); flew = true;
                    }
                } else if(optFlyRunSpeedIsToggle ? flyRun : keyDown(keyFlyRun)) {
                    mx *= optFlyRunSpeedMul;
                    mz *= optFlyRunSpeedMul;
                }
            }
        }
        flyCallSuper(ent, mx, my, mz);
        if(ent == player) {
            moveOnGround = getEntityOnGround(ent);
            playerClassActive = true;

            if(modFlyEnabled && ent == player) {
                if(fly) { setFall(ent, 0f); setEntityOnGround(ent, true); setEntitySteps(ent, flyTmp); }
                else if(flew && !getEntityOnGround(ent)) { setFall(ent, 0f); setEntityOnGround(ent, true); }
                else flew = false;
            }

            if(cheating && !optCheatFallDamage) { setFall(ent, 0f); setEntityOnGround(ent, true); }
        }
    }

    // ----------------------------------------------------------------------------------------------------------------
    public static int mapRandomHandle(int n) {
        if(n==0x186a0 && modWeatherEnabled && !isMultiplayer) {
            if(weatherMayhem) return rnd.nextInt(optWeatherThunderMayhemChance);
            return rnd.nextInt(optWeatherThunderChance);
        }
        return rnd.nextInt(n);
    }
    
    // ----------------------------------------------------------------------------------------------------------------
    private static String getEntityName(Object ent) {
        if(!getEntityIsLiving(ent)) return "inanimate object";
        if(getEntityIsPlayer(ent)) return getPlayerName(ent);
        return typeName[getEntityType(ent)];
    }
    
    // ----------------------------------------------------------------------------------------------------------------
    private static String getNameForId(int id, int meta) { return getNameForId(id | ((meta==-1 ? 9999 : meta) << 16)); }
    private static String getNameForId(int id) {
        Set set = names.entrySet();
        Iterator it = set.iterator();
        String found = null, key;
        while(it.hasNext()) {
            Map.Entry ent = (Map.Entry)it.next();
            if((Integer)ent.getValue() != id) continue;
            key = (String)ent.getKey();
            if(found == null || found.length() < key.length()) found = key;
        }
        if(found == null && id < 65536) {
            found = getNameForId(id, -1);
            if(found.charAt(0)=='6' && found.length()>6) found = null;
        }
        return found == null ? ""+id : found;
    }

    // ----------------------------------------------------------------------------------------------------------------
    public static Minecraft getMinecraft() { return mc; }

    // ================================================================================================================ helpers
    private static boolean isMenu, isMultiplayer, isHell, isMapChange, isWorldChange;
    private static double posX, posY, posZ, motionX, motionY, motionZ;
    private static String chatLast;
    // ---------------------------------------------------------------------------------------------------------------- WorldProvider       - xa : wr
    private static boolean checkClassSun()     { return checkClass(xa.class, "sun");     } // update - search: 24000F
    // ---------------------------------------------------------------------------------------------------------------- PlayerControllerSP  - os : oo
    private static boolean checkClassDig()     { return checkClass(os.class, "dig");     } // update - search: = -180F * the one that does not create new packets
    private static boolean checkClassBuild()   { return checkClass(os.class, "build");   }
    // ---------------------------------------------------------------------------------------------------------------- RenderLiving        - gv : gt
    private static boolean checkClassResize()  { return checkClass(gv.class, "resize");  } // update - search: "deadmau5" * the one with simpler IF
    // ---------------------------------------------------------------------------------------------------------------- Explosion           - qx : qs
    private static boolean checkClassBoom()    { return checkClass(qx.class, "boom");    } // update - search: "random.explode"
    // ---------------------------------------------------------------------------------------------------------------- Entity              - sn : si
    private static sn inWhat;                             // update
    private static Field fFireImmune = getField(sn.class, "bC"); // immune to fire, search: = 600;
    private static void setNoClip(boolean val) { ((sn)player).bq = val; } // at the beginning of the fn - search: \*= 0\.05000000074505806D
    private static float getEntityWidth(Object ent) { return ((sn)ent).bg; } // update  default in const: ?? = 0.6F;
    private static float getEntityHeight(Object ent) { return ((sn)ent).bh; } // update  default in const: ?? = 1.8F;
    private static float getEntityYaw(Object ent) { return ((sn)ent).aS; } // % 360F;
    private static float getEntityPitch(Object ent) { return ((sn)ent).aT; }
    private static sn getOnEntity(Object ent) { return ((sn)ent).aH; } // first or second Entity field in Entity ("Motion") ... dangit
    private static double getMountOffset(Object ent) { return ((sn)ent).m(); } // search: \* 0\.75D; * it is in that fucntion
    private static boolean getEntityOnGround(Object ent) {    return ((sn)ent).aX; } // search: "OnGround"
    private static void setEntityOnGround(Object ent, boolean val) { ((sn)ent).aX = val; }
    private static float getEntitySteps(Object ent) {    return ((sn)ent).bj; } // search: 59999999999999998D * Entity class: stepCounter += (double)??.?(? * ? + ? + ?)*0.59999999999999998D;
    private static void setEntitySteps(Object ent, float val) { ((sn)ent).bj = val; }
    private static void dieEntity(Object ent) { ((sn)ent).K(); } // UPDATE: search: = 600; * next function calls setEntityDead
    private static double getEntityMotionX(Object ent) {    return ((sn)ent).aP; } // search: "Motion" * aP, aQ, aR
    private static void setEntityMotionX(Object ent, double val) { ((sn)ent).aP = val; }
    private static double getEntityMotionY(Object ent) {    return ((sn)ent).aQ; }
    private static void setEntityMotionY(Object ent, double val) { ((sn)ent).aQ = val; }
    private static double getEntityMotionZ(Object ent) {    return ((sn)ent).aR; }
    private static void setEntityMotionZ(Object ent, double val) { ((sn)ent).aR = val; }
    private static double getEntityPrevPosX(Object ent) {    return ((sn)ent).bl; } // update - search "Pos" ... next function has ? = prevPosX = posX
    private static double getEntityPrevPosY(Object ent) {    return ((sn)ent).bm; }
    private static void setEntityPrevPosY(Object ent, double val) { ((sn)ent).bm = val; }
    private static double getEntityPrevPosZ(Object ent) {    return ((sn)ent).bn; }
    private static double getEntityPosX(Object ent) { return ((sn)ent).aM; } // UPDATE
    private static double getEntityPosY(Object ent) { return ((sn)ent).aN; } // UPDATE
    private static double getEntityPosZ(Object ent) { return ((sn)ent).aO; } // UPDATE
    private static void setFire(Object ent, int val) { ((sn)ent).bv = val; } // update: "Fire"
    private static void setAir(Object ent, int val) { ((sn)ent).bz = val; } // update: "Air"
    private static void setFall(Object ent, float val) { ((sn)ent).bk = val; } // update: "FallDistance"
    private static int getEntityAge(Object ent) { return ((sn)ent).bt; } // search: [a-z]+ % 20\) \* 12 == 0
    private static void setEntityAge(Object ent, int val) { ((sn)ent).bt = val; }
    private static void setEntityFireImmune(Object ent, boolean immune) { setValue(fFireImmune, ent, immune); }
    private static int getEntityType(Object ent) {
        if(ent instanceof gs) return PLAYER; // char - ensure it is player
        if(ent instanceof bp) return GHAST;
        if(ent instanceof bx) return COW;
        if(ent instanceof cn) return SPIDER;
        if(ent instanceof dl) return SHEEP;
        if(ent instanceof fr) return SKELLY;
        if(ent instanceof gb) return CREEPER;
        if(ent instanceof gi) return WOLF;
        if(ent instanceof ya) return PIGZOMBIE;
        if(ent instanceof nt || ent instanceof uz) return ZOMBIE;
        if(ent instanceof uw) return SLIME;
        if(ent instanceof wh) return PIG;
        if(ent instanceof ww) return CHICKEN;
        if(ent instanceof xt) return SQUID;
        if(ent instanceof ls) return LIVING; // char - ensure it is not player
        return 0;
    }
    private static void setEntityPos(Object obj, double x, double y, double z) { // search: "Pos"
        sn ent = (sn)obj;
        ent.d(0.0D, 0.0D, 0.0D);
        ent.aJ = ent.bl = ent.aM = x;
        ent.aK = ent.bm = ent.aN = y;
        ent.aL = ent.bn = ent.aO = z;
        ent.d(x, y, z);
    }
    // ---------------------------------------------------------------------------------------------------------------- GuiContainer        - id : ia
    private static boolean checkClassCraft()   { return checkClass(id.class, "craft");   } // update - search: = -999;
    // ---------------------------------------------------------------------------------------------------------------- EntityLiving        - ls : lo
    private static Object getView() { return mc.i; } // search: \.[a-zA-Z]+\..*33000001311302185D * begins with what you seek
    private static void setView(Object ent) { mc.i = (ls)ent; } // update type: entityLiving
    private static void setHealth(Object ent, int val) { ((ls)ent).Y = val; } // update: "Health"
    private static int getHealth(Object ent) { return ((ls)ent).Y; }
    private static boolean getEntityIsLiving(Object ent) { return ent instanceof ls; }
    private static void setEntitySize(Object obj, boolean big) {
        ls ent = (ls)obj; // class that gives "Health"
        ent.bg *= big ? 1.5 : 0.5;      // update        width
        ent.bh *= big ? 1.5 : 0.5;      // update        height
        if(big) ent.Y <<= 1; else ent.Y >>= 1;// update  health
        ent.d(ent.aM, ent.aN, ent.aO);  // update        ... search: mob/slime
    }
    // ---------------------------------------------------------------------------------------------------------------- EntityPlayer        - gs : gq
    private static boolean checkClassFly()     { return checkClass(gs.class, "fly");     } // update - search: "humanoid"
    private static boolean checkClassCheat()   { return checkClass(gs.class, "cheat", "fall damage is not disabled in MP"); }
    private static Field fBed = getField(gs.class, "v"); // search: return [a-zA-Z]+.[a-zA-Z]+\([a-zA-Z]+\.[a-z], [a-zA-Z]+\.[a-z], [a-zA-Z]+\.[a-z]\) ==  * ?.a, ?.b ...
    private static void flyCallSuper(Object ent, double mx, double my, double mz) { ((gs)ent).callSuper(mx,my,mz); }
    private static boolean getIsSleeping(Object ent) { return ((gs)player).N(); } // search: "Sleeping"
    private static boolean getEntityIsPlayer(Object ent) { return ent instanceof gs; }
    private static String getPlayerName(Object ent) { return ((gs)ent).l; } // update: "deadmau5"
    private static Object getSpawn(Object ent) { return ((gs)ent).Q(); } // search: [a-zA-Z]+ = new [a-zA-Z]+\([a-zA-Z0-9]+\.[a-z]+\("SpawnX" * then search for the function that returns it.
    private static Object getBed(Object ent) { return getValue(fBed, ent); }
    // ---------------------------------------------------------------------------------------------------------------- EntityPlayerSP      - dc : da
    private static dc player;              // update
    private static dc getPlayer() { return mc.h; } // Minecraft.player      : g    ? only field of that ("portal.trigger") type in mc
    private static void sendChat(String msg) { ((dc)player).a(msg); } // Packet3Chat: \.substring\(0, 119\); * it is used in send chat
    // ---------------------------------------------------------------------------------------------------------------- EntityMinecart      - yl : yc
    private static boolean getEntityIsCart(Object ent) { return ent instanceof yl; } // EntityMinecart ? search: "Fuel"
    private static int getCartType(Object ent) { return ((yl)ent).d; } // update - d = "Type"
    private static int getCartFuel(Object ent) { return ((yl)ent).e; } // update - e = "Fuel"
    private static void setCartFuel(Object ent, int val) { ((yl)ent).e = val; }
    // ---------------------------------------------------------------------------------------------------------------- EntityItem          - hl : hj
    private static boolean getEntityIsItemStack(Object ent) { return ent instanceof hl; } // UPDATE: ? "Age" ("Age" exists only for entity of type itemstack)
    private static Object getEntityItemStack(Object ent) { return ((hl)ent).a; } // UPDATE: ? "Age" * only itemstack type field there
    // ---------------------------------------------------------------------------------------------------------------- TileEntity          - ow : os
    private static void setChanged(Object tent) { ((ow)tent).y_(); } // class is the other one that matches "Chest" (ie. not the one that IS returning "Chest")
    // ---------------------------------------------------------------------------------------------------------------- TileEntityFurnace   - sk : sf
    private static boolean checkClassFurnace() { return checkClass(sk.class, "furnace"); } // update - search: "CookTime"
    private static Field fFurnaceItems = getField(sk.class, "i"); // search: [^a-z][a-z] = new [a-z]+\[3\];
    private static Object[] getFurnaceItems(Object tent) { return (Object[])getValue(fFurnaceItems, tent); }
    // ---------------------------------------------------------------------------------------------------------------- TileEntityChest     - js : jo
    private static Field fChestItems = getField(js.class, "a"); // search: [^a-z][a-z] = new [a-z]+\[36\];
    private static Object[] getChestItems(Object tent) { return (Object[])getValue(fChestItems, tent); }
    // ---------------------------------------------------------------------------------------------------------------- TileEntityDispenser - az : ay
    private static Field fDispItems = getField(az.class, "a"); // search: [^a-z][a-z] = new [a-z]+\[9\];
    private static Object[] getDispItems(Object tent) { return (Object[])getValue(fDispItems, tent); }
    // ---------------------------------------------------------------------------------------------------------------- TileEntitySign      - yk : yb
    private static String[] getSignText(int x, int y, int z) { return ((yk)getTileEntity(x,y,z)).a; } // search: "Text
    // ---------------------------------------------------------------------------------------------------------------- ItemStack           - iz : iw
    private static Field fDamage = getField(iz.class, "d"); // search: "Damage"
    private static int getItemsIcon(Object items) { return ((iz)items).b(); } // search: % 16\) \* 16\) \+ 0.0F\) / 256F;  * line before thous gets the icon nr  ... now it goes through item - living :/
    private static iz[] newIngredients(int cnt) { return new iz[cnt]; }
    private static iz newItemsE(int id, int count) { return newItems(id & 0xffff, count, id >> 16); }
    private static iz newItems(int id, int count, int param) { return new iz(id, count, param == 9999 ? -1 : param); } // ItemStack     : iw ? search: "Damage"
    private static iz newItems(int id, int count) { return newItems(id, count, 0); }
    private static int getItemsId(Object items) { return ((iz)items).c; } // ItemStack.itemID      : c    ? search: "id" * has ItemId = ??.?("id"); in it
    private static int getItemsCount(Object items) { return ((iz)items).a; } // search: "Count"
    private static void setItemsCount(Object items, int cnt) { ((iz)items).a = cnt; }
    private static int getItemsInfo(Object items) { return ((iz)items).i(); } // returns d / "Damage"
    private static void setItemsInfo(Object items, int val) { setValue(fDamage, items, val); }
    private static boolean isItemsMatch(Object items, int val) { return ( getItemsId(items) | ((val >> 16) == 9999 ? 0x270f0000 : (getItemsInfo(items) << 16)) ) == val; }
    // ---------------------------------------------------------------------------------------------------------------- CraftingManager     - hk : hi
    private static Field fCMRecipes = getField(hk.class, "b"); // update - only List in CraftingManager (###)
    private static hk getCManager() { return hk.a(); } // update - search: ### * only function that returns CraftingManager
    // ---------------------------------------------------------------------------------------------------------------- ShapedRecipes       - is : ip
    private static boolean isRecipeNormal(Object recipe) { return recipe instanceof is; } // for\(int i = 0; i <= 3
    private static Field fRWidth = getField(is.class, "b"), fRHeight = getField(is.class, "c"), fRMap = getField(is.class, "d"), fRResA = getField(is.class, "e"); // UPDATE
    private static Object newRecipeNormal(int id, int count, int width, int height, Object ingredients[]) { return new is(width, height, (iz[])ingredients, newItemsE(id, count)); }
    // ---------------------------------------------------------------------------------------------------------------- ShapelessRecipes    - tt : to
    private static boolean isRecipeShapeless(Object recipe) { return recipe instanceof tt; } // if\(i >= 3\)
    private static Field fRList = getField(tt.class, "b"), fRResB = getField(tt.class, "a");
    private static Object newRecipeShapeless(int id, int count, List ingredients) { return new tt(newItemsE(id, count), ingredients); }
    // ---------------------------------------------------------------------------------------------------------------- RecipeSorter        - ky : ku
    private static void sortRecipes(List recipes) { Collections.sort(recipes, new ky(getCManager())); } // return [a-z0-9]+\.[a-z]\(\) <= [a-z0-9]+\.[a-z]\(\) \? 0 : 1;
    // ---------------------------------------------------------------------------------------------------------------- InventoryCrafting   - mq : mm
    private static Field fCBTable = getField(mq.class, "a"); // return "Crafting" * itemstack there
    private static mq newCraftingGrid(int width, int height, Object search[]) { mq grid = new mq(null, width, height); setValue(fCBTable, grid, search); return grid; }
    private static boolean isRecipeMatch(int i, Object grid) { return ((dt)pList.get(i)).a((mq)grid); } // function in (###) that deals with this type
    // ---------------------------------------------------------------------------------------------------------------- WorldInfo           - ei : eg
    private static Field fSpawnX = getField(ei.class, "b"); // update - search: "Spawn  * is in class ("RandomSeed")
    private static Field fSpawnY = getField(ei.class, "c"); // ...
    private static Field fSpawnZ = getField(ei.class, "d"); // ...
    private static Field fTime = getField(ei.class, "e"); // ...
    private static Field fRainTime = getField(ei.class, "m"); // ...
    private static Field fRaining = getField(ei.class, "l"); // ...
    private static Field fThunderTime = getField(ei.class, "o"); // ...
    private static Field fThundering = getField(ei.class, "n"); // ...
    private static ei world;                   // update
    private static ei getWorld() { return getMap().x(); } // only function in map (0x3c6ef35f) that returns this type : public ?? .+\(\)
    private static boolean getRain() { return (Boolean)getValue(fRaining, world); }
    private static boolean getThunder() { return (Boolean)getValue(fThundering, world); }
    private static void setRain(boolean val) { setValue(fRaining, world, val); }
    private static void setThunder(boolean val) { setValue(fThundering, world, val); }
    private static int getRainTime() { return (Integer)getValue(fRainTime, world); }
    private static int getThunderTime() { return (Integer)getValue(fThunderTime, world); }
    private static void setRainTime(int val) { setValue(fRainTime, world, val); }
    private static void setThunderTime(int val) { setValue(fThunderTime, world, val); }
    private static long getTime() { return world.f(); } // update
    private static long getSeed() { return world.b(); } // update
    private static String getName() { return world.j(); } // update
    // ---------------------------------------------------------------------------------------------------------------- World               - fd : fb
    private static fd map;                              // update
    private static fd getMap() { return mc.f; } // Minecraft.map : e ? only field of that (0x3c6ef35f) type
    private static void spawnLightning(int x, int y, int z) { map.a(new c(map, x, y, z)); }      // 0x186a0
    private static int getLightLevel(int x, int y, int z, int kst) { return map.c(x >> 4, z >> 4).c(x & 0xf, y, z & 0xf, kst); } // update ... ugh ... where do i find it? FIXME
    private static float getLight(int x, int y, int z) { return map.c(x, y, z); } // search: return [a-zA-Z]+\.[a-zA-Z]+\[[a-zA-Z]+\([a-z0-9]+, [a-z0-9]+, [a-z0-9]+\)\]; * is in function
    private static int getLightLevel(int x,int y,int z) { return map.n(x, y, z); } // update (is in the previous search)
    // UPDATE search: public int [a-z]+\(int [a-z0-9]+, int [a-z0-9]+, int [a-z0-9]+\)
    private static int mapGetId(int x, int y, int z) { return map.a(x,y,z); } // first result - returns X(...).Y(...)
    private static int mapGetMeta(int x, int y, int z) { return map.e(x,y,z); } // second result - has "&= 0xf;" in it
    // UPDATE search: public boolean [a-z]+\(int [a-z0-9]+, int [a-z0-9]+, int [a-z0-9]+, int [a-z0-9]+, int [a-z0-9]+\)
    private static void mapSetIdMetaNoUpdate(int x, int y, int z, int id, int meta) { map.a(x,y,z,id,meta); } // first match - the one with bounds check
    private static void mapSetIdMeta(int x, int y, int z, int id, int meta) { map.b(x,y,z,id,meta); } // second match - the one without bounds checks
    private static void mapSetId(int x, int y, int z, int id) { map.c(x,y,z,id); } // search: [a-zA-Z]+\([a-zA-Z0-9]+ \+ [a-zA-Z0-9]+, [a-zA-Z0-9]+ \+ [a-zA-Z0-9]+, [a-zA-Z0-9]+ \+ [a-zA-Z0-9]+, [a-zA-Z0-9]+ < 4 \? [a-zA-Z0-9_]+ : 0\);
    private static byte[] mapGetChunkData(int cx, int cz) { return map.c(cx, cz).b; } // search: return [a-zA-Z]+\([a-z0-9]+ >> 4, [a-z0-9]+ >> 4\)\.[a-zA-Z]+\([a-z0-9]+ & 0xf, [a-z0-9]+, [a-z0-9]+ & 0xf\);      * FIXME
    private static boolean mapGetChunkExists(int cx, int cy) { return map.w().a(cx, cy); } // search: public abstract boolean [a-z]+\(int [^,)]+, int [^,)]+\); * chunk provider, find in map that gives it
    private static void chunkNeedsUpdate(int cx, int cz) { cx <<= 4; cz <<= 4; map.b(cx, 0, cz, cx+15, 127, cz+15); } // update: in map ? search: public void [a-z]+\(int[^,]+, int[^,]+, int[^,]+, int[^,]+, int[^,]+, int[^,]+\)
    private static void mapNeedsUpdate(int sx, int sy, int sz, int ex, int ey, int ez) { map.b(sx, sy, sz, ex, ey, ez); } // public void [a-z]+\(int [^,]+, int [^,]+, int [^,]+, int [^,]+, int [^,]+, int [^,)]+\)
    private static List getEntities() { return (List)((ArrayList)map.b).clone(); } // seacrh-in-class: / 16D * ?.add after the branch that has instanceof check
    private static void noiseTP(Object ent) { map.a((sn)ent, "mob.slime", 0.4f,( (rnd.nextFloat() - rnd.nextFloat())*0.2f + 1.0f )*0.8f); } // UPDATE "mob.slime"
    private static void overloadMapRandom() { if(!(map.r instanceof ZR)) map.r = new ZR(); } // update - only Random field in map
    private static Object getTileEntity(int x, int y, int z) { return map.b(x,y,z); } // search: public <TileEntity)>
    // ---------------------------------------------------------------------------------------------------------------- BiomeGenBase        - kd : ??
    private static String getBiomeName(int x, int z) { return map.a().a(x,z).n; } // = [a-z]+\(\)\.[a-z]+\([a-z0-9]+, [a-z0-9]+\);
    private static float getTemp() { return map.a().a == null || map.a().a.length <= 0 ? Float.NaN : (float)(map.a().a[0] * 2.0 - 1.0); }
    private static float getHumid() { return map.a().b == null || map.a().b.length <= 0 ? Float.NaN : (float)map.a().b[0]; }
    // ---------------------------------------------------------------------------------------------------------------- GuiIngame           - uq : uk
    private static Field fChat = getField(uq.class, "e"); // search: / 200D; * (double)((ChatLine)ChatLines.get(??)).notMessage / 200D;
    // ---------------------------------------------------------------------------------------------------------------- Minecraft           - MC
    private static String getPath() { String res = ""; try { res = Minecraft.b().getCanonicalPath(); } catch(Exception whatever) { res = ""; } return res; } // get path - getPath : b  ? search: public static File * only static function that returns File and takes no parameters
    private static int getTexture(String name) { return mc.p.b(name); } // search: GL11[^"]+"/gui/items\.png" * the one with longer selector for texture name
    private static List getChat() { return (List)getValue(fChat, mc.v); } // search for quiingame class name (/ 200D;)
    private static boolean getIsMenu() { return mc.r != null; } // Minecraft.gui ? search: if\([a-z]+ instanceof * take the one which has no matches in higher steps
    private static boolean getIsMultiplayer() { return mc.l(); } // Minecraft.isMultiplayer ? search: public boolean [a-z]+\(\) * only match in Minecraft
    private static Object getPlayerController() { return mc.c; } // search: if\([a-z0-9]+ == 0 && !\([a-zA-Z]+ instanceof * left side of instanceof
    private static boolean rayTrace(double dist, float f) { return (rayHit = mc.i.a(dist, f)) != null; } // search: = 32D; * gives: "d? = d? = 32D;" a few lines above it is: mc.? = mc.i.a(d?, f?);
    private static void overloadRenderGlobal() { mc.g = render = new ZRG(mc, mc.p); } // "Post startup" * f = new ?(this, o); just before viewport
    // ---------------------------------------------------------------------------------------------------------------- ChatLine            - sw : sr
    private static String getChatLine(List chat, int i) { return ((sw)chat.get(i)).a; } // search: / 200D; * (double)((ChatLine)ChatLines.get(??)).notMessage / 200D;
    private static void chatClient(String msg) { getChat().add(0,new sw(msg)); }
    // ---------------------------------------------------------------------------------------------------------------- EntityRenderer      - px : pt
    private static px renderer;                      // update
    private static px getRenderer() { return mc.t; } // Minecraft.renderer ? only EntityRenderer (?glu) type field - only one is in Minecraft
    // ---------------------------------------------------------------------------------------------------------------- MovingObjectPosition- vf : ux
    private static vf rayHit; // search: public [a-z]+\(int [^,]+, int [^,]+, int [^,]+, int [^,]+, * last param is some class - the class itself is trivial
    private static int rayHitX() { return rayHit.b; } // update
    private static int rayHitY() { return rayHit.c; } // update
    private static int rayHitZ() { return rayHit.d; } // update
    private static int rayHitSide() { return rayHit.e; } // update
    // ---------------------------------------------------------------------------------------------------------------- InventoryPlayer     - ix : iu
    private static ix inv;                                // update
    private static ix getInventory(Object ent) { return ((gs)ent).c; } // search: . = new ..\(this\); * the one in constructor of ("humanoid") class
    private static void setInventory(Object ent, Object val) {
        ((gs)ent).c = (ix)val;
        ((gs)ent).e = ((gs)ent).d = new aa((ix)val, !isMultiplayer); // This stuff is in constructor of ("humanoid") class
    }
    private static iz invItems[], invArmors[];            // update
    private static iz[] getInvItems(ix inv) { return inv.a; } // search: \[36\] * the one with 2 matches - found line assigns it
    private static iz[] getInvArmors(ix inv) { return inv.b; } // ... next line
    private static void setInvItems(int loc, Object items) { invItems[loc] = (iz)items; }
    private static int getInvCur() { return inv.c; } // .currentItem only int field in class
    private static void setInvCur(int cur) { inv.c = cur; }
    // ---------------------------------------------------------------------------------------------------------------- ChunkCoordinates    - br : bp
    private static int getX(Object pos) { return ((br)pos).a; } // "SpawnX" * the class after "new"
    private static int getY(Object pos) { return ((br)pos).b; }
    private static int getZ(Object pos) { return ((br)pos).c; }
    // ---------------------------------------------------------------------------------------------------------------- Block               - uu : un
    private static Object getBlock(int id) { return uu.m[id]; }
    private static void setBlock(int id, Object val) { uu.m[id] = (uu)val; }
    private static boolean getBlockIsSpawn(int id) { return uu.m[id] != null && uu.m[id].bA.h() && uu.m[id].d(); } // search: completed
    private static void setBlockGraphicsLevel(Object block, boolean flag) { ((bk)block).a(flag); } // type: "leaves",  first thing in function: int [a-z0-9]+ = 64 << 3 -
    private static Field fBlockStrength = getField(uu.class, "bo"); // search: 1.0F / [a-z]+ / 100F; * field is in the middle
    private static float getBlockStrength(Object block) { return (Float)getValue(fBlockStrength, block); }
    private static void setBlockStrength(Object block, float val) { setValue(fBlockStrength, block, val); }
    private static Field fBlockResist = getField(uu.class, "bp"); // search: return [a-z]+ / 5F;
    private static float getBlockResist(Object block) { return (Float)getValue(fBlockResist, block); }
    private static void setBlockResist(Object block, float val) { setValue(fBlockResist, block, val); }
    private static float getBlockSlip(Object block) { return ((uu)block).bB; } // [a-zA-Z]+ = 0\.6F;
    private static void setBlockSlip(Object block, float val) { ((uu)block).bB = val; }
    private static Object getBlockMaterial(Object block) { return ((uu)block).bA; } // return [a-zA-Z]+ != [a-zA-Z]+\.[a-zA-Z]+ \? 0 : 30;  * return ? != ...
    private static boolean getBlockIsOpaque(int id) { return uu.o[id]; } // line before x() ? 255 : 0 in constructor      * can not change this as most of the code bypasses the array and recalculates it needlessly all the fucking time - NOTCH!
    private static int getBlockOpacity(int id) { return uu.q[id]; } // line x() ? 255 : 0 in constructor
    private static void setBlockOpacity(int id, int val) { uu.q[id] = val; }
    private static int getBlockLight(int id) { return uu.s[id]; } // search: [a-z]+\[[a-z0-9]+\] = \(int\)\(15F \* [a-z0-9]+\);
    private static void setBlockLight(int id, int val) { uu.s[id] = val; }
    // ---------------------------------------------------------------------------------------------------------------- Material            - ln : lj
    private static boolean getIsLiquid(Object mat) { return ((ln)mat).d(); } // if\([a-zA-Z0-9]+ >= 4 && [a-zA-Z0-9]+\.[a-zA-Z]+\(\)\)
    private static boolean getIsCover(Object mat) { return ((ln)mat).b(); } // [a-z]+\[[a-z0-9]+\] = ![a-z0-9]+\.[a-z]+\(\);
    private static boolean getIsSolid(Object mat) { return ((ln)mat).c(); } // < 128 && [^)]+\)[^)]+\)\.[a-z]+\(\) &&
    private static boolean getIsBurnable(Object mat) { return ((ln)mat).e(); } // return [a-z0-9]+\.[a-z]+\([a-z0-9]+, [a-z0-9]+, [a-z0-9]+\)\.[a-z]+\(\);
    private static boolean getIsReplaceable(Object mat) { return ((ln)mat).g(); } // return [a-z0-9]+ == 0 \|\| [a-zA-Z]+\[[a-z0-9]+\]\.[a-zA-Z]+\.[a-zA-Z]+\(\);
    // ---------------------------------------------------------------------------------------------------------------- Items               - gm : gk
    private static Object getItem(int id) { return gm.c[id]; }
    private static int getItemMax(Object item) { return item == null ? 0 : ((gm)item).d(); } // �"Max stack size� - find the getters / setters
    private static void setItemMax(Object item, int val) { if(item != null) ((gm)item).d(val); }
    private static int getItemDmgCap(Object item) { return ((gm)item).f(); } // search: \[[a-z]+\]\.[a-z]+\(\) > 0;  * last function name
    private static void setItemDmgCap(Object item, int val) { ((gm)item).e(val); } // search:  3 << [a-z0-9]+\);
    private static String getItemName(Object item) { return ((gm)item).a(); } // search: [a-z]\(\)\)\.append\("\.name"  * match from correct class
    private static boolean getItemHasSubTypes(Object item) { return ((gm)item).e(); } // search: return [a-z0-9]+\.[a-z]+\[[a-z0-9]+\]\.[a-z]+\(\); * returns boolean (ie. not getItemDmgCap).
    // ---------------------------------------------------------------------------------------------------------------- GameSettings        - ?? : ??
    //private static Object getSettings() { return mc.z; } // search: "/font/default.png"  * the parameter before that
    private static void setOrtho() { // search: glOrtho
        qq qq1 = new qq(mc.z, mc.d, mc.e);
        GL11.glOrtho(0.0D, qq1.a, qq1.b, 0.0D, 1000D, 3000D);
    }
    private static int getScrWidthS() { return new qq(mc.z, mc.d, mc.e).a(); } // used at the beginning of the function where showText was found
    private static boolean isHideGUI() { return mc.z.z; } // search: glViewport * the one with 2 matches has "if(!mc.gameSettings.hideGUI || mc.? != null) \n mc.?.?(?, mc.? != null, ?, ?);
    private static boolean isShowDebug() { return mc.z.B; } // search: Minecraft Beta * the one with "(" after version number
    private static int getKeyGo() { return mc.z.m.b; } // "key.forward" * probably never need to check the last var as the other is of type string
    private static int getKeyBack() { return mc.z.o.b; } // "key.back"
    // ---------------------------------------------------------------------------------------------------------------- BlockFire           - yq : yh
    private static Field fBlockFireSpread = getField(yq.class, "a"); // search: fire
    private static int getFireSpread(int id) { return Array.getInt(getValue(fBlockFireSpread, getBlock(51)), id); }
    private static void setFireSpread(int id, int val) { Array.setInt(getValue(fBlockFireSpread, getBlock(51)), id, val); }
    private static Field fBlockFireBurn = getField(yq.class, "b");
    private static int getFireBurn(int id) { return Array.getInt(getValue(fBlockFireBurn, getBlock(51)), id); }
    private static void setFireBurn(int id, int val) { Array.setInt(getValue(fBlockFireBurn, getBlock(51)), id, val); }

    // #############################
    // ----------------------------------------------------------------------------------------------------------------
    private static boolean getIsHell() { return mapGetId(fix(posX),127,fix(posZ))==7; } // hackish, there is certainly a better way - but the hell with it.
    private static void showText(String str, int x, int y, int color) { mc.q.a(str,x,y,color); } // / 2, [a-z]+ / 2 - 4 - 16, 0xffffff\); * mc.?.show( ... mc.?.length ...
    private static int showTextLength(String str) { return mc.q.a(str); } // update

    // ================================================================================================================ log
    private static void initLogAndPath() {
        path = getPath();
        path += File.separatorChar + "mods" + File.separatorChar + "zombe" + File.separatorChar;
        try { File make = new File(path); make.mkdirs(); } catch(Exception whatever) { path = ""; }
        try { File tmp = new File(path + "log.txt"); out = new PrintStream(tmp); logPath = tmp.getCanonicalPath(); } catch(Exception whatever) { logPath = "failed to create one :("; out = System.out; }
        log("=========== logging ===========");
        log("ZModPack: version "+version);
        log("Log started at: "+(new Timestamp((new Date()).getTime())));
    }

    private static void log(String text) {
        if(out == null) initLogAndPath();
        out.println(text);
    }

    private static void err(String text) {
        if(logErrors <= 0) return;
        log(text);
        if(showError == null) {
            showError = text;
            setMsg(MERR, "ZMod: errors detected - one or more mods affected\n"+(logErrors==8 ? "First " : "Next ")+showError+"\nLog: "+logPath, 0xff8888);
        }
        if(logErrors-- == 0) log("info: stopping error logging.");
    }

    private static void err(String text, Exception e) {
        err(text);
        if(logErrors <= 0) return;
        log("### Exception: " + e.toString());
        e.printStackTrace(out);
    }
    
    public static void logc(String text) {
        log(text);
        chatClient(text);
    }
    
    // ================================================================================================================ config
    private static int getBind(String name, int init) {
        String val = conf.getProperty(name);
        if(val == null) return init;
        val = val.replaceAll("[\t\r\n]+", " ").trim();
        if(val.equals("")) return Keyboard.KEY_NONE;
        int i = Keyboard.getKeyIndex(val.toUpperCase());
        if(i == Keyboard.KEY_NONE) { err("error: config.txt @ "+name+" - invalid key name \""+val+"\""); return init; }
        return i;
    }

    private static float getFloat(String name, float init, float min, float max) {
        String val = conf.getProperty(name);
        if(val == null) return init;
        val = val.replaceAll("[\t\r\n]+", " ").trim();
        float f = parseFloat(val, Float.NaN);
        if(Float.isNaN(f)) { err("error: config.txt @ "+name+" - float expected but garbage found \""+val+"\""); return init; }
        else if(f<min || f>max) { err("error: config.txt @ "+name+" - must be between "+min+" and "+max+" \""+val+"\""); return init; }
        return f;
    }

    private static int getInt(String name, int init, int min, int max) {
        String val = conf.getProperty(name);
        if(val == null) return init;
        val = val.replaceAll("[\t\r\n]+", " ").trim();
        int i = parseInteger(val, Integer.MIN_VALUE);
        if(i==Integer.MIN_VALUE) { err("error: config.txt @ "+name+" - integer expected but garbage found \""+val+"\""); return init; }
        else if(i<min || i>max) { err("error: config.txt @ "+name+" - must be between "+min+" and "+max+" \""+val+"\""); return init; }
        return i;
    }

    private static String getString(String name, String init) {
        String val = conf.getProperty(name);
        if(val == null) return init;
        val = val.replaceAll("[\t\r\n]+", " ").trim();
        return val;
    }

    private static boolean getBool(String name, boolean init) {
        String val = conf.getProperty(name);
        if(val == null) return init;
        val = val.replaceAll("[\t\r\n]+", " ").trim();
        if(val.equals("1") || val.equals("yes") || val.equals("true") || val.equals("on")) return true;
        if(val.equals("0") || val.equals("no") || val.equals("false") || val.equals("off")) return false;
        err("error: config.txt @ "+name+" - must be one of (1, yes, true, on, 0, no, false, off) \""+val+"\"");
        return init;
    }
    
    private static Mark getColor(String name, int color) {
        Mark res = new Mark(color);
        String val = conf.getProperty(name);
        if(val == null) return res;
        val = val.replaceAll("[\t\r\n]+", " ").trim();
        if(!res.loadColor(val)) err("error: config.txt @ "+name+" - undefined or invalid color \""+val+"\"");
        return res;
    }
    
    private static Mark getIntRange(String name, int initMin, int initMax, int min, int max) {
        Mark res = new Mark(min, max);
        String val = conf.getProperty(name);
        if(val == null) return res;
        val = val.replaceAll("[\t\r\n]+", " ").trim();
        String part[] = val.split(" *\\.\\. *");
        int a = initMin, b = initMax;
        if(part.length == 2) { a = parseInteger(part[0], Integer.MIN_VALUE); b = parseInteger(part[1], Integer.MIN_VALUE); }
        if(part.length != 2) err("error: config.txt @ "+name+" - invalid range specification \""+val+"\"");
        else if(a == Integer.MIN_VALUE) err("error: config.txt @ "+name+" - integer expected but garbage found \""+part[0]+"\" in \""+val+"\"");
        else if(b == Integer.MIN_VALUE) err("error: config.txt @ "+name+" - integer expected but garbage found \""+part[1]+"\" in \""+val+"\"");
        else if(a > b) err("error: config.txt @ "+name+" - range begins after end \""+val+"\"");
        else if(a < min || b > max) err("error: config.txt @ "+name+" - range \""+val+"\" is out of bounds ("+min+" .. "+max+")");
        else { res.min = a; res.max = b; }
        return res;
    }
    
    private static int getBlockId(String name, int init) {
        String val = conf.getProperty(name);
        if(val == null) return init;
        val = val.replaceAll("[\t\r\n]+", " ").trim();
        int id = parseUnsigned(val);
        if(names.containsKey(val)) id = (Integer)names.get(val);
        if((id & 65535) > 255) err("error: config.txt @ "+name+" - non-block name or id out of block id range \""+val+"\"");
        else if((id>>16) != 9999 && (id>>16) != 0) err("error: config.txt @ "+name+" - block has metadata (ex: colored wool) \""+val+"\".");
        else return id & 255;
        return init;
    }
    
    private static int getItemId(String name, int init) {
        String val = conf.getProperty(name);
        if(val == null) return init;
        val = val.replaceAll("[\t\r\n]+", " ").trim();
        int id = parseIdInfo(val);
        if(names.containsKey(val)) id = (Integer)names.get(val);
        if(id == -1) err("error: config.txt @ "+name+" - invalid name or id \""+val+"\"");
        else return id;
        return init;
    }

    private static boolean getDeprecated(String name) {
        if(conf.getProperty(name) == null) return false;
        log("notice: config.txt @ "+name+" - this option is deprecated");
        return true;
    }
    
    // ================================================================================================================ reflect
    private static void reportException(Exception error) {
        if(exceptionReported) return;
        exceptionReported = true;
        err("exception in reflection code encountered !", error);
    }
    private static Field getField(Class c, String name) { try { Field field = c.getDeclaredField(name); field.setAccessible(true); return field; } catch(Exception error) { reportException(error); } return null; }
    private static Object getValue(Field field, Object obj) { try { return field.get(obj); } catch(Exception error) { reportException(error); } return null; }
    private static void setValue(Field field, Object obj, Object val) { try { field.set(obj, val); } catch(Exception error) { reportException(error); } }
    private static Class getClass(String name) { try { return Class.forName(name); } catch(Exception error) { reportException(error); } return null; }
    private static Constructor getConstructor(Class c, Class param[]) { try { return c.getConstructor(param); } catch(Exception error) { reportException(error); } return null; }
    private static Method getMethod(Class c, String name, Class param[]) { try { Method method = c.getDeclaredMethod(name, param); method.setAccessible(true); return method; } catch(Exception error) { reportException(error); } return null; }
    private static Method getMethod(Class c, String name) { return getMethod(c,name,new Class[]{}); }
    private static Method getMethod(Class c, String name, Class p1) { return getMethod(c,name,new Class[]{p1}); }
    private static Method getMethod(Class c, String name, Class p1, Class p2) { return getMethod(c,name,new Class[]{p1,p2}); }
    private static Method getMethod(Class c, String name, Class p1, Class p2, Class p3) { return getMethod(c,name,new Class[]{p1,p2,p3}); }
    private static Method getMethod(Class c, String name, Class p1, Class p2, Class p3, Class p4) { return getMethod(c,name,new Class[]{p1,p2,p3,p4}); }
    private static Object getNew(Constructor cc, Object param[]) { try { return cc.newInstance(param); } catch(Exception error) { reportException(error); } return null; }
    private static Object getNew(Constructor cc, Object p1) { return getNew(cc, new Object[]{p1}); }
    private static Object getNew(Constructor cc, Object p1, Object p2) { return getNew(cc, new Object[]{p1,p2}); }
    private static Object getNew(Constructor cc, Object p1, Object p2, Object p3) { return getNew(cc, new Object[]{p1,p2,p3}); }
    private static Object getNew(Constructor cc, Object p1, Object p2, Object p3, Object p4) { return getNew(cc, new Object[]{p1,p2,p3,p4}); }
    private static Object getNew(Class c) { try { return c.newInstance(); } catch(Exception error) { reportException(error); } return null; }
    private static Object getResult(Method m, Object obj, Object param[]) { try { return m.invoke(obj, param); } catch(Exception error) { reportException(error); } return null; }
    private static Object getResult(Method m) { return getResult(m, null, new Object[]{}); }
    private static Object getResult(Method m, Object obj) { return getResult(m, obj, new Object[]{}); }
    private static Object getResult(Method m, Object obj, Object p1) { return getResult(m, obj, new Object[]{p1}); }
    private static Object getResult(Method m, Object obj, Object p1, Object p2) { return getResult(m, obj, new Object[]{p1,p2}); }
    private static Object getResult(Method m, Object obj, Object p1, Object p2, Object p3) { return getResult(m, obj, new Object[]{p1,p2,p3}); }
    private static Object getResult(Method m, Object obj, Object p1, Object p2, Object p3, Object p4) { return getResult(m, obj, new Object[]{p1,p2,p3,p4}); }
    private static boolean checkClass(Class c, String mod) { return checkClass(c, mod, null); }
    private static boolean checkClass(Class c, String mod, String warning) {
        try { Field field = c.getDeclaredField("zmodmarker"); if(field != null) return true; } catch(Exception whatever) { }
        if(warning == null) err("error: "+c.getName()+".class has not been installed - "+mod+" mod disabled");
        else log("warning: "+c.getName()+".class has not been installed - "+mod+" mod: "+warning);
        return false;
    }
    // NB! does not copy private members from subclasses
    private static void copy(Object s, Object d) { copy(s,d,s.getClass()); }
    private static void copy(Object s, Object d, Class c) {
        try {
            Field fields[] = c.getDeclaredFields();
            for(int i=0;i<fields.length;i++) if((fields[i].getModifiers() & (Modifier.FINAL | Modifier.STATIC)) == 0) {
                fields[i].setAccessible(true);
                setValue(fields[i], d, getValue(fields[i], s));
            }
        } catch(Exception error) { reportException(error); }
    }
    

    // ================================================================================================================ util
    private static int fix(double d) { return (int)Math.floor(d); } // returns correct integer coordinate
    private static void delMsg(int rank) { texts[rank] = null; }
    private static void setMsg(String msg) { setMsg(2, msg); }
    private static void setMsg(int rank, String msg) { setMsg(rank, msg, 0xffffff, 2+rank*2, 2+rank*12); }
    private static void setMsg(int rank, String msg, int color) { texts[rank] = new Text(msg, 2+rank*2, 2+rank*12, color); }
    private static void setMsg(int rank, String msg, int color, int x, int y) { texts[rank] = new Text(msg, x, y, color); }
    private static boolean keyPress(int key) { boolean res = !keys[key]; return (keys[key] = keyDown(key)) && res; }
    private static boolean keyDown(int key) { return key != 0 && Keyboard.isKeyDown(key); }
    private static float sgn(float f) { return f<0f ? -1f : (f>0f ? 1f : 0f); }
    private static FloatBuffer makeBuffer(int length) { return ByteBuffer.allocateDirect(length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer(); }
    private static FloatBuffer makeBuffer(float[] array) { return (FloatBuffer)ByteBuffer.allocateDirect(array.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(array).flip(); }
    private static void obliqueNearPlaneClip(float a, float b, float c, float d) {
        float matrix[] = new float[16];
        float x, y, z, w, dot;
        FloatBuffer buf = makeBuffer(16);
        GL11.glGetFloat(GL11.GL_PROJECTION_MATRIX, buf);
        buf.get(matrix).rewind();
        x = (sgn(a) + matrix[8]) / matrix[0];
        y = (sgn(b) + matrix[9]) / matrix[5];
        z = -1.0F;
        w = (1.0F + matrix[10]) / matrix[14];
        dot = a*x + b*y + c*z + d*w;
        matrix[2] = a * (2f / dot);
        matrix[6] = b * (2f / dot);
        matrix[10] = c * (2f / dot) + 1.0F;
        matrix[14] = d * (2f / dot);
        buf.put(matrix).rewind();
        GL11.glMatrixMode(GL11.GL_PROJECTION);
        GL11.glLoadMatrix(buf);
        GL11.glMatrixMode(GL11.GL_MODELVIEW);
    }

    // ================================================================================================================ parser
    private static HashMap pNames;
    private static HashSet<String> pFiles;
    private static HashMap<Integer, Integer> pFuel;
    private static HashMap<Integer, Object> pSmelt;
    private static List pList;

    private static void parse(List list, String file, int section) {
        pList = list;
        pNames = names==null ? new HashMap() : (HashMap)(((HashMap)names).clone());
        pFiles = new HashSet<String>();
        parseFile(file, section);
    }
    
    private static void parseFile(String file, int section) {
        if(!pFiles.add(file)) {
            err("error: recursion detected - \""+file+"\" is already included");
            return;
        }
        String data = "", fn = path + file;
        try {
            byte[] buffer = new byte[(int) new File(fn).length()];
            BufferedInputStream stream = new BufferedInputStream(new FileInputStream(fn));
            stream.read(buffer);
            stream.close();
            data = new String(buffer);
            log("info: parsing \""+file+"\"");
        } catch(Exception error) {
            err("error: failed to load \""+file+"\"", error);
            data = "";
        }
        String lines[] = data.split("\\r?\\n");
        int at;
        for(int line=0;line<lines.length;line++) {
            if(lines[line].startsWith("[IGNORE]")) section = IGNORE;
            else if(lines[line].startsWith("[NAMEMAP]")) section = NAMEMAP;
            else if(lines[line].startsWith("[RECIPES]")) section = RECIPES;
            else if(lines[line].startsWith("[FUEL]")) section = FUEL;
            else if(lines[line].startsWith("[SMELTING]")) section = SMELTING;
            else if(lines[line].startsWith("[ITEMS]")) section = ITEMS;
            else if(lines[line].startsWith("[NAMEMAP=")) parseFile(lines[line].substring(9).replaceAll("\\].*\\z",""), NAMEMAP);
            else if(lines[line].startsWith("[RECIPES=")) parseFile(lines[line].substring(9).replaceAll("\\].*\\z",""), RECIPES);
            else if(lines[line].startsWith("[FUEL=")) parseFile(lines[line].substring(6).replaceAll("\\].*\\z",""), FUEL);
            else if(lines[line].startsWith("[SMELTING=")) parseFile(lines[line].substring(10).replaceAll("\\].*\\z",""), SMELTING);
            else if(lines[line].startsWith("[ITEMS=")) parseFile(lines[line].substring(7).replaceAll("\\].*\\z",""), ITEMS);
            else if(section == NAMEMAP) parseNames(lines[line], file, line + 1);
            else if(section == RECIPES) parseRecipe(lines[line], file, line + 1);
            else if(section == FUEL) parseFuel(lines[line], file, line + 1);
            else if(section == SMELTING) parseSmelting(lines[line], file, line + 1);
            else if(section == ITEMS) parseItems(lines[line], file, line + 1);
        }
    }
    
    private static int parseUnsigned(String str) { return parseInteger(str, -1); }

    private static int parseInteger(String str, int fail) {
        try {
            return Integer.decode(str);
        } catch(Exception whatever) {
            return fail;
        }
    }

    private static float parseFloat(String str, float fail) {
        try {
            return Float.parseFloat(str);
        } catch(Exception whatever) {
            return fail;
        }
    }

    private static int parseIdInfo(String text) {
        try {
            String part[] = text.split("/");
            if(part.length>2) return -1;
            int id = Integer.decode(part[0]);
            if(part.length==2) {
                int info = Integer.decode(part[1]);
                if(info<0) info = 9999;
                id += info << 16;
            }
            return id;
        } catch(Exception error) {
            return -1;
        }
    }
    
    private static void parseFuel(String src, String file, int line) {
        String got[] = src.replaceAll("\\A[\\t ]*","").replaceAll("[\\t ]*(|//.*)\\z","").split("[ \\t]+");
        if(got.length != 2) {
            if(got.length == 1 && !got[0].equals("")) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid fuel definition");
        } else {
            int fuel = pNames.containsKey(got[0]) ? (Integer)pNames.get(got[0]) : parseUnsigned(got[0]);
            if(fuel > 0) fuel &= 0xffff;
            int time = parseUnsigned(got[1]);
            if(fuel<=0) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid fuel definition (\""+got[0]+"\" is unknown or invalid)");
            else if(time<=0) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid fuel definition (\""+got[1]+"\" is invalid time)");
            else pFuel.put(fuel, time);
        }
    }
    
    private static void parseSmelting(String src, String file, int line) {
        String got[] = src.replaceAll("\\A[\\t ]*","").replaceAll("[\\t ]*(|//.*)\\z","").split("[ \\t]+");
        if(got.length != 2) {
            if(got.length == 1 && !got[0].equals("")) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid smelt definition");
        } else {
            int itemId = pNames.containsKey(got[0]) ? (Integer)pNames.get(got[0]) : parseIdInfo(got[0]);
            int id = pNames.containsKey(got[1]) ? (Integer)pNames.get(got[1]) : parseUnsigned(got[1]);
            if(id > 0) id &= 0xffff;
            Object item = itemId>0 ? newItemsE(itemId, 1) : null;
            if(id<=0) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid smelting definition (\""+got[0]+"\" is unknown or invalid)");
            else if(item==null) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid smelting definition (\""+got[1]+"\" is unknown or invalid)");
            else pSmelt.put(id, item);
        }
    }

    private static void parseNames(String src, String file, int line) {
        String got[] = src.replaceAll("\\A[\\t ]*","").replaceAll("[\\t ]*(|//.*)\\z","").split("[ \\t]+");
        if((got.length & 1) != 0) {
            if(got.length != 1 && !got[0].equals("")) err("error: "+file+" @ line#" + line + " \"" + src + "\" - incomplete name definition");
        } else for(int at=0;at<got.length;at+=2) {
            int id = parseIdInfo(got[at+1]);
            if(id==-1) err("error: "+file+" @ line#" + line + " \"" + src + "\" - non numbers in name definition");
            else pNames.put(got[at], id);
        }
    }

    private static void addRecipe(int width, int height, Object recipeMap[], int id, int count) {
        boolean normal = height > 0;
        Object search[] = recipeMap;
        List list = null;
        if(!normal) {
            search = newIngredients(9);
            list = new ArrayList();
            for(int i=0;i<recipeMap.length;i++) list.add(search[i] = recipeMap[i]);
            width = height = 3;
        }
        Object grid = newCraftingGrid(width, height, search);
        // find and remove match
        for(int i=0;i<pList.size();i++) if(isRecipeMatch(i, grid)) { pList.remove(i); break; }
        // add new
        if(id!=0) pList.add( normal ? newRecipeNormal(id, count, width, height, recipeMap) : newRecipeShapeless(id, count, list) );
    }

    private static void parseRecipe(String src, String file, int line) {
        String trouble = ""; // parsing trouble - will contain the offending substring
        String got[] = src.replaceAll("\\A[\\t ]*","").replaceAll("[\\t ]*(|//.*)\\z","").split("[ \\t]+");
        if(got.length < 5) {
            if(got.length != 1 && !got[0].equals("")) log("error: "+file+" @ line#" + line + " \"" + src + "\" - incomplete recipe definition");
            return;
        }
        try {
            trouble = got[0];
            int width = Integer.decode(got[2]), height = Integer.decode(got[3]), count = Integer.decode(got[1]);
            int itemnr = pNames.containsKey(got[0]) ? (Integer)pNames.get(got[0]) : parseIdInfo(got[0]);
            if(itemnr<0 || count<0 || (itemnr>0 && count<=0)) {
                err("error: "+file+" @ line#" + line + " \"" + src + "\" - bad recipe result");
                return;
            }
            if(itemnr != 0 && getItem(itemnr & 0xffff) == null) {
                log("warning: "+file+" @ line#" + line + " \"" + src + "\" - resulting item does not exist, recipe ignored");
                return;
            }
            if(height != 0 && (width*height+4 != got.length || width <= 0 || height <= 0 || width > 3 || height > 3)) {
                err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid recipe size (" + width + "," + height + ")");
                return;
            } else if(height == 0 && (width+4 != got.length || width <= 0)) {
                err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid recipe size (" + width + ")");
                return;
            }
            Object recipeMap[] = newIngredients(width*(height==0?1:height));
            for(int at=4;at<got.length;at++) {
                trouble = got[at];
                int value = pNames.containsKey(got[at]) ? (Integer)pNames.get(got[at]) : parseIdInfo(got[at]);
                if(value == -1 || (height==0 && value==0)) throw new Exception("("+value+" "+got[at]+" "+(pNames.containsKey(got[at])?"+":"-")+")");
                recipeMap[at - 4] = value<=0 ? null : newItemsE(value, 1);
            }
            addRecipe(width, height, recipeMap, itemnr, count);
        } catch(Exception whatever) {
            err("error: "+file+" @ line#" + line + " \"" + src + "\" - \"" + trouble + "\" is unknown or malformed");
            err("???",whatever);
        }
    }

    private static void parseItems(String src, String file, int line) {
        String got[] = src.replaceAll("\\A[\\t ]*","").replaceAll("[\\t ]*(|//.*)\\z","").split("[ \\t]+");
        if(got.length < 2) {
            if(got.length == 1 && !got[0].equals("")) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid items definition");
        } else {
            int id, stack = 0, damage = 0, emit = 0, absorb = 0, load = 0, spread = 0, burn = 0;
            float strength = 0f, resist = 0f, slip = 0f;
            Object obj;
            id = ( pNames.containsKey(got[0]) ? (Integer)pNames.get(got[0]) : parseUnsigned(got[0]) ) & 0xffff;
            if(id > 32000 || (obj = getItem(id))==null) log("warning: "+file+" @ line#" + line + " \"" + src + "\" - item/block does not exist, definition ignored");
            else {
                if(!got[1].equals("?")) { load |= 1; stack = parseUnsigned(got[1]); }
                if(id >= 256) {
                    if(got.length > 2 && !got[2].equals("?") && !getItemHasSubTypes(obj) && getItemDmgCap(obj)>0) { load |= 2; damage = parseUnsigned(got[2]); }
                } else {
                    if(got.length > 2 && !got[2].equals("?")) { load |= 4; emit = parseUnsigned(got[2]); }
                    if(got.length > 3 && !got[3].equals("?")) { load |= 8; absorb = parseUnsigned(got[3]); }
                    if(got.length > 4 && !got[4].equals("?")) { load |= 16; strength = parseFloat(got[4], Float.NaN); }
                    if(got.length > 5 && !got[5].equals("?")) { load |= 32; resist = parseFloat(got[5], Float.NaN); }
                    if(got.length > 6 && !got[6].equals("?")) { load |= 64; slip = parseFloat(got[6], Float.NaN); }
                    if(got.length > 7 && !got[7].equals("?")) { load |= 128; spread = parseUnsigned(got[7]); }
                    if(got.length > 8 && !got[8].equals("?")) { load |= 256; burn = parseUnsigned(got[8]); }
                }
                
                if((load & 1) != 0 && (stack < 1 || stack > 64)) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid max stack size (\""+got[1]+"\")");
                else if((load & 2) != 0 && damage < 1) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid max damage (\""+got[2]+"\")");
                else if((load & 4) != 0 && (emit < 0 || emit > 15)) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid light emission (\""+got[2]+"\")");
                else if((load & 8) != 0 && (absorb < 0 || absorb > 255)) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid light reduction (\""+got[3]+"\")");
                else if((load & 16) != 0 && (Float.isNaN(strength) || strength < -1f || strength > 100f)) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid strength (\""+got[4]+"\")");
                else if((load & 32) != 0 && (Float.isNaN(resist) || resist < 0f || resist > 18000000f)) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid resistance (\""+got[5]+"\")");
                else if((load & 64) != 0 && (Float.isNaN(slip) || slip < 0.5f || slip > 1f)) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid slipperiness (\""+got[6]+"\")");
                else if((load & 128) != 0 && (spread < 0 || spread > 100)) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid fire spread value (\""+got[7]+"\")");
                else if((load & 256) != 0 && (burn < 0 || burn > 100)) err("error: "+file+" @ line#" + line + " \"" + src + "\" - invalid burn speed value (\""+got[8]+"\")");
                else {
                    Mark item = itemMine[id];
                    if((load & 1) != 0) item.setMaxStack(stack);
                    if((load & 2) != 0) item.setMaxDamage(damage);
                    if((load & 4) != 0) item.setLightEmission(emit);
                    if((load & 8) != 0) item.setLightReduction(absorb);
                    if((load & 16) != 0) item.setStrength(strength);
                    if((load & 32) != 0) item.setResistance(resist);
                    if((load & 64) != 0) item.setSlipperiness(slip);
                    if((load & 128) != 0) item.setFireSpread(spread);
                    if((load & 256) != 0) item.setFireBurn(burn);
                }
            }
        }
    }

    private static int[] parseRule(String rule) {
        String got[] = rule.split("[\t ]+"), part[];
        int res[] = new int[got.length * 6];
        for(int i=0;i<got.length;i++) {
            part = got[i].split("/");
            if(part.length != 6) { modOreEnabled = false; err("error : ore-mod disabled - invalid ore rule found \""+rule+"\""); continue; }
            res[i*6 + 0] = new Integer(part[0]);
            res[i*6 + 1] = new Integer(part[1]);
            res[i*6 + 2] = new Integer(part[2]);
            res[i*6 + 3] = new Integer(part[3]);
            res[i*6 + 4] = new Integer(part[4]);
            res[i*6 + 5] = new Integer(part[5]);
        }
        return res;
    }

}
