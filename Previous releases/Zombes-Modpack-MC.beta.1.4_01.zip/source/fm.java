// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.util.*;
import java.lang.reflect.*;

// EntityPlayer ? search: "humanoid"
public abstract class fm extends jm {

    // ============================================================================================================
    protected static boolean zmodmarker = true;
    private static Method flyHandle;
    // moveEntity   : b   ? search: double d9 = 0\.050000000000000003D; - it is in the function
    public final void callSuper(double mx, double my, double mz) { super.b(mx,my,mz); }
    public void b(double mx, double my, double mz) { // ZMod.flyHandle(this,mx,my,mz);
      if(zmodmarker && flyHandle==null) {
          try { flyHandle = Class.forName("ZMod").getDeclaredMethod("flyHandle", new Class[]{Object.class, Double.TYPE, Double.TYPE, Double.TYPE}); }
          catch(Exception whatever) { zmodmarker=false; flyHandle = null; }
      }
      if(flyHandle!=null) try { flyHandle.invoke(null, new Object[]{this, mx, my, mz}); } catch(Exception whatever) { flyHandle = null; callSuper(mx,my,mz); }
      else callSuper(mx,my,mz);
    }
    // ============================================================================================================


    public fm(eb eb1) {
        super(eb1);
        f = new hh(this);
        i = 0;
        j = 0;
        m = false;
        n = 0;
        e = 0;
        A = null;
        g = new u(f, !eb1.t);
        h = g;
        bb = 1.62F;
        ay ay1 = eb1.t();
        c((double)ay1.a + 0.5D, ay1.b + 1, (double)ay1.c + 0.5D, 0.0F, 0.0F);
        V = 20;
        O = "humanoid";
        N = 180F;
        br = 20;
        L = "/mob/char.png";
    }

    protected void b() {
        super.b();
        bA.a(16, Byte.valueOf((byte)0));
    }

    public void w_() {
        if(M()) {
            c++;
            if(c > 100)
                c = 100;
            if(!ah())
                a(true, true, false);
            else
            if(!aF.t && aF.f())
                a(false, true, true);
        } else
        if(c > 0) {
            c++;
            if(c >= 110)
                c = 0;
        }
        super.w_();
        if(!aF.t && h != null && !h.b(this)) {
            q();
            h = g;
        }
        r = u;
        s = v;
        t = w;
        double d1 = aJ - u;
        double d2 = aK - v;
        double d3 = aL - w;
        double d4 = 10D;
        if(d1 > d4)
            r = u = aJ;
        if(d3 > d4)
            t = w = aL;
        if(d2 > d4)
            s = v = aK;
        if(d1 < -d4)
            r = u = aJ;
        if(d3 < -d4)
            t = w = aL;
        if(d2 < -d4)
            s = v = aK;
        u += d1 * 0.25D;
        w += d3 * 0.25D;
        v += d2 * 0.25D;
        a(hs.j, 1);
    }

    protected boolean y() {
        return V <= 0 || M();
    }

    protected void q() {
        h = g;
    }

    public void v_() {
        q = (new StringBuilder()).append("http://s3.amazonaws.com/MinecraftCloaks/").append(o).append(".png").toString();
        by = q;
    }

    public void t_() {
        super.t_();
        k = l;
        l = 0.0F;
    }

    public void u_() {
        bb = 1.62F;
        b(0.6F, 1.8F);
        super.u_();
        V = 20;
        aa = 0;
    }

    protected void e_() {
        if(m) {
            n++;
            if(n == 8) {
                n = 0;
                m = false;
            }
        } else {
            n = 0;
        }
        U = (float)n / 8F;
    }

    public void n() {
        if(aF.j == 0 && V < 20 && (bq % 20) * 12 == 0)
            c(1);
        f.e();
        k = l;
        super.n();
        float f1 = gz.a(aM * aM + aO * aO);
        float f2 = (float)Math.atan(-aN * 0.20000000298023224D) * 15F;
        if(f1 > 0.1F)
            f1 = 0.1F;
        if(!aU || V <= 0)
            f1 = 0.0F;
        if(aU || V <= 0)
            f2 = 0.0F;
        l += (f1 - l) * 0.4F;
        ad += (f2 - ad) * 0.8F;
        if(V > 0) {
            List list = aF.b(this, aT.b(1.0D, 0.0D, 1.0D));
            if(list != null) {
                for(int i1 = 0; i1 < list.size(); i1++) {
                    pb pb1 = (pb)list.get(i1);
                    if(!pb1.ba)
                        j(pb1);
                }

            }
        }
    }

    private void j(pb pb1) {
        pb1.b(this);
    }

    public int C() {
        return j;
    }

    public void b(pb pb1) {
        super.b(pb1);
        b(0.2F, 0.2F);
        c(aJ, aK, aL);
        aN = 0.10000000149011612D;
        if(o.equals("Notch"))
            a(new hi(fg.h, 1), true);
        f.g();
        if(pb1 != null) {
            aM = -gz.b(((Z + aP) * 3.141593F) / 180F) * 0.1F;
            aO = -gz.a(((Z + aP) * 3.141593F) / 180F) * 0.1F;
        } else {
            aM = aO = 0.0D;
        }
        bb = 0.1F;
        a(hs.u, 1);
    }

    public void c(pb pb1, int i1) {
        j += i1;
        if(pb1 instanceof fm)
            a(hs.w, 1);
        else
            a(hs.v, 1);
    }

    public void D() {
        a(f.a(f.c, 1), false);
    }

    public void a(hi hi1) {
        a(hi1, false);
    }

    public void a(hi hi1, boolean flag) {
        if(hi1 == null)
            return;
        gb gb1 = new gb(aF, aJ, (aK - 0.30000001192092896D) + (double)w(), aL, hi1);
        gb1.c = 40;
        float f1 = 0.1F;
        if(flag) {
            float f3 = bp.nextFloat() * 0.5F;
            float f5 = bp.nextFloat() * 3.141593F * 2.0F;
            gb1.aM = -gz.a(f5) * f3;
            gb1.aO = gz.b(f5) * f3;
            gb1.aN = 0.20000000298023224D;
        } else {
            float f2 = 0.3F;
            gb1.aM = -gz.a((aP / 180F) * 3.141593F) * gz.b((aQ / 180F) * 3.141593F) * f2;
            gb1.aO = gz.b((aP / 180F) * 3.141593F) * gz.b((aQ / 180F) * 3.141593F) * f2;
            gb1.aN = -gz.a((aQ / 180F) * 3.141593F) * f2 + 0.1F;
            f2 = 0.02F;
            float f4 = bp.nextFloat() * 3.141593F * 2.0F;
            f2 *= bp.nextFloat();
            gb1.aM += Math.cos(f4) * (double)f2;
            gb1.aN += (bp.nextFloat() - bp.nextFloat()) * 0.1F;
            gb1.aO += Math.sin(f4) * (double)f2;
        }
        a(gb1);
        a(hs.r, 1);
    }

    protected void a(gb gb1) {
        aF.a(gb1);
    }

    public float a(ra ra1) {
        float f1 = f.a(ra1);
        if(a(jh.f))
            f1 /= 5F;
        if(!aU)
            f1 /= 5F;
        return f1;
    }

    public boolean b(ra ra1) {
        return f.b(ra1);
    }

    public void b(lg lg1) {
        super.b(lg1);
        pd pd1 = lg1.l("Inventory");
        f.b(pd1);
        p = lg1.e("Dimension");
        a = lg1.m("Sleeping");
        c = lg1.d("SleepTimer");
        if(a) {
            b = new ay(gz.b(aJ), gz.b(aK), gz.b(aL));
            a(true, true, false);
        }
        if(lg1.b("SpawnX") && lg1.b("SpawnY") && lg1.b("SpawnZ"))
            d = new ay(lg1.e("SpawnX"), lg1.e("SpawnY"), lg1.e("SpawnZ"));
    }

    public void a(lg lg1) {
        super.a(lg1);
        lg1.a("Inventory", f.a(new pd()));
        lg1.a("Dimension", p);
        lg1.a("Sleeping", a);
        lg1.a("SleepTimer", (short)c);
        if(d != null) {
            lg1.a("SpawnX", d.a);
            lg1.a("SpawnY", d.b);
            lg1.a("SpawnZ", d.c);
        }
    }

    public void a(jp jp) {
    }

    public void a(int i1, int j1, int k1) {
    }

    public void b(pb pb1, int i1) {
    }

    public float w() {
        return 0.12F;
    }

    protected void E() {
        bb = 1.62F;
    }

    public boolean a(pb pb1, int i1) {
        as = 0;
        if(V <= 0)
            return false;
        if(M())
            a(true, true, false);
        if((pb1 instanceof fr) || (pb1 instanceof oz)) {
            if(aF.j == 0)
                i1 = 0;
            if(aF.j == 1)
                i1 = i1 / 3 + 1;
            if(aF.j == 3)
                i1 = (i1 * 3) / 2;
        }
        if(i1 == 0)
            return false;
        Object obj = pb1;
        if((obj instanceof oz) && ((oz)obj).b != null)
            obj = ((oz)obj).b;
        if(obj instanceof jm)
            a((jm)obj, false);
        a(hs.t, i1);
        return super.a(pb1, i1);
    }

    protected void a(jm jm1, boolean flag) {
        if((jm1 instanceof ex) || (jm1 instanceof az))
            return;
        if(jm1 instanceof fd) {
            fd fd1 = (fd)jm1;
            if(fd1.D() && o.equals(fd1.A()))
                return;
        }
        List list = aF.a(fd.class, dq.b(aJ, aK, aL, aJ + 1.0D, aK + 1.0D, aL + 1.0D).b(16D, 4D, 16D)); // UPDATE
        Iterator iterator = list.iterator();
        do {
            if(!iterator.hasNext())
                break;
            pb pb1 = (pb)iterator.next();
            fd fd2 = (fd)pb1;
            if(fd2.D() && fd2.F() == null && o.equals(fd2.A()) && (!flag || !fd2.B())) {
                fd2.b(false);
                fd2.c(jm1);
            }
        } while(true);
    }

    protected void b(int i1) {
        int j1 = 25 - f.f();
        int k1 = i1 * j1 + e;
        f.e(i1);
        i1 = k1 / 25;
        e = k1 % 25;
        super.b(i1);
    }

    public void a(oy oy) {
    }

    public void a(al al) {
    }

    public void a(uf uf) {
    }

    public void c(pb pb1) {
        if(pb1.a(this))
            return;
        hi hi1 = F();
        if(hi1 != null && (pb1 instanceof jm)) {
            hi1.a((jm)pb1);
            if(hi1.a <= 0) {
                hi1.a(this);
                G();
            }
        }
    }

    public hi F() {
        return f.b();
    }

    public void G() {
        f.a(f.c, null);
    }

    public double H() {
        return (double)(bb - 0.5F);
    }

    public void I() {
        n = -1;
        m = true;
    }

    public void d(pb pb1) {
        int i1 = f.a(pb1);
        if(i1 > 0) {
            pb1.a(this, i1);
            hi hi1 = F();
            if(hi1 != null && (pb1 instanceof jm)) {
                hi1.a((jm)pb1, this);
                if(hi1.a <= 0) {
                    hi1.a(this);
                    G();
                }
            }
            if(pb1 instanceof jm) {
                if(pb1.U())
                    a((jm)pb1, true);
                a(hs.s, i1);
            }
        }
    }

    public void p_() {
    }

    public abstract void v();

    public void b(hi hi1) {
    }

    public void J() {
        super.J();
        g.a(this);
        if(h != null)
            h.a(this);
    }

    public boolean K() {
        return !a && super.K();
    }

    public cb b(int i1, int j1, int k1) {
        if(M() || !U())
            return cb.e;
        if(aF.m.c)
            return cb.b;
        if(aF.f())
            return cb.c;
        if(Math.abs(aJ - (double)i1) > 3D || Math.abs(aK - (double)j1) > 2D || Math.abs(aL - (double)k1) > 3D)
            return cb.d;
        b(0.2F, 0.2F);
        bb = 0.2F;
        if(aF.h(i1, j1, k1)) {
            int l1 = aF.e(i1, j1, k1);
            int i2 = rj.c(l1);
            float f1 = 0.5F;
            float f2 = 0.5F;
            switch(i2) {
            case 0: // '\0'
                f2 = 0.9F;
                break;

            case 2: // '\002'
                f2 = 0.1F;
                break;

            case 1: // '\001'
                f1 = 0.1F;
                break;

            case 3: // '\003'
                f1 = 0.9F;
                break;
            }
            e(i2);
            c((float)i1 + f1, (float)j1 + 0.9375F, (float)k1 + f2);
        } else {
            c((float)i1 + 0.5F, (float)j1 + 0.9375F, (float)k1 + 0.5F);
        }
        a = true;
        c = 0;
        b = new ay(i1, j1, k1);
        aM = aO = aN = 0.0D;
        if(!aF.t)
            aF.x();
        return cb.a;
    }

    private void e(int i1) {
        x = 0.0F;
        z = 0.0F;
        switch(i1) {
        case 0: // '\0'
            z = -1.8F;
            break;

        case 2: // '\002'
            z = 1.8F;
            break;

        case 1: // '\001'
            x = 1.8F;
            break;

        case 3: // '\003'
            x = -1.8F;
            break;
        }
    }

    public void a(boolean flag, boolean flag1, boolean flag2) {
        b(0.6F, 1.8F);
        E();
        ay ay1 = b;
        ay ay2 = b;
        if(ay1 != null && aF.a(ay1.a, ay1.b, ay1.c) == ra.S.bl) {
            rj.a(aF, ay1.a, ay1.b, ay1.c, false);
            ay ay3 = rj.f(aF, ay1.a, ay1.b, ay1.c, 0);
            if(ay3 == null)
                ay3 = new ay(ay1.a, ay1.b + 1, ay1.c);
            c((float)ay3.a + 0.5F, (float)ay3.b + bb + 0.1F, (float)ay3.c + 0.5F);
        }
        a = false;
        if(!aF.t && flag1)
            aF.x();
        if(flag)
            c = 0;
        else
            c = 100;
        if(flag2)
            a(b);
    }

    private boolean ah() {
        return aF.a(b.a, b.b, b.c) == ra.S.bl;
    }

    public static ay a(eb eb1, ay ay1) {
        bs bs1 = eb1.v();
        bs1.c(ay1.a - 3 >> 4, ay1.c - 3 >> 4);
        bs1.c(ay1.a + 3 >> 4, ay1.c - 3 >> 4);
        bs1.c(ay1.a - 3 >> 4, ay1.c + 3 >> 4);
        bs1.c(ay1.a + 3 >> 4, ay1.c + 3 >> 4);
        if(eb1.a(ay1.a, ay1.b, ay1.c) != ra.S.bl) {
            return null;
        } else {
            ay ay2 = rj.f(eb1, ay1.a, ay1.b, ay1.c, 0);
            return ay2;
        }
    }

    public float L() {
        if(b != null) {
            int i1 = aF.e(b.a, b.b, b.c);
            int j1 = rj.c(i1);
            switch(j1) {
            case 0: // '\0'
                return 90F;

            case 1: // '\001'
                return 0.0F;

            case 2: // '\002'
                return 270F;

            case 3: // '\003'
                return 180F;
            }
        }
        return 0.0F;
    }

    public boolean M() {
        return a;
    }

    public boolean N() {
        return a && c >= 100;
    }

    public int O() {
        return c;
    }

    public void b(String s1) {
    }

    public ay P() {
        return d;
    }

    public void a(ay ay1) {
        if(ay1 != null)
            d = new ay(ay1);
        else
            d = null;
    }

    public void a(ru ru, int i1) {
    }

    protected void Q() {
        super.Q();
        a(hs.q, 1);
    }

    public void a_(float f1, float f2) {
        double d1 = aJ;
        double d2 = aK;
        double d3 = aL;
        super.a_(f1, f2);
        h(aJ - d1, aK - d2, aL - d3);
    }

    private void h(double d1, double d2, double d3) {
        if(a(jh.f)) {
            int i1 = Math.round(gz.a(d1 * d1 + d2 * d2 + d3 * d3) * 100F);
            if(i1 > 0)
                a(hs.p, i1);
        } else
        if(k_()) {
            int j1 = Math.round(gz.a(d1 * d1 + d3 * d3) * 100F);
            if(j1 > 0)
                a(hs.l, j1);
        } else
        if(o()) {
            if(d2 > 0.0D)
                a(hs.n, (int)Math.round(d2 * 100D));
        } else
        if(aU) {
            int k1 = Math.round(gz.a(d1 * d1 + d3 * d3) * 100F);
            if(k1 > 0)
                a(hs.k, k1);
        } else {
            int l1 = Math.round(gz.a(d1 * d1 + d3 * d3) * 100F);
            if(l1 > 25)
                a(hs.o, l1);
        }
    }

    protected void b(float f1) {
        if(f1 >= 2.0F)
            a(hs.m, (int)Math.round((double)f1 * 100D));
        super.b(f1);
    }

    public hh f;
    public da g, h;
    public byte i;
    public int j, n, p;
    public float k, l, x, y, z;
    public boolean m;
    public String o, q;
    public double r, s, t, u, v;
    public double w;
    private boolean a;
    private ay b, d;
    private int c, e;
    public jq A;
}
