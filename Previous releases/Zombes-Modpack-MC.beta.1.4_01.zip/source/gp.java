// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.util.List;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;

// search: = -999;
public abstract class gp extends cf {

    protected static final boolean zmodmarker = true;

    public gp(da da1) {
        a = 176;
        i = 166;
        j = da1;
    }

    public void a() {
        super.a();
        b.g.h = j;
    }

    public void a(int k, int i1, float f) {
        i();
        int j1 = (c - a) / 2;
        int k1 = (d - i) / 2;
        a(f);
        GL11.glPushMatrix();
        GL11.glRotatef(180F, 1.0F, 0.0F, 0.0F);
        q.b();
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(j1, k1, 0.0F);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glEnable(32826);
        fi fi1 = null;
        for(int l1 = 0; l1 < j.e.size(); l1++) {
            fi fi2 = (fi)j.e.get(l1);
            a(fi2);
            if(a(fi2, k, i1)) {
                fi1 = fi2;
                GL11.glDisable(2896);
                GL11.glDisable(2929);
                int i2 = fi2.b;
                int k2 = fi2.c;
                a(i2, k2, i2 + 16, k2 + 16, 0x80ffffff, 0x80ffffff);
                GL11.glEnable(2896);
                GL11.glEnable(2929);
            }
        }

        hh hh1 = b.g.f;
        if(hh1.i() != null) {
            GL11.glTranslatef(0.0F, 0.0F, 32F);
            l.a(g, b.o, hh1.i(), k - j1 - 8, i1 - k1 - 8);
            l.b(g, b.o, hh1.i(), k - j1 - 8, i1 - k1 - 8);
        }
        GL11.glDisable(32826);
        q.a();
        GL11.glDisable(2896);
        GL11.glDisable(2929);
        j();
        if(hh1.i() == null && fi1 != null && fi1.b()) {
            String s = (new StringBuilder()).append("").append(kt.a().b(fi1.a().l())).toString().trim();
            if(s.length() > 0) {
                int j2 = (k - j1) + 12;
                int l2 = i1 - k1 - 12;
                int i3 = g.a(s);
                a(j2 - 3, l2 - 3, j2 + i3 + 3, l2 + 8 + 3, 0xc0000000, 0xc0000000);
                g.a(s, j2, l2, -1);
            }
        }
        GL11.glPopMatrix();
        super.a(k, i1, f);
        GL11.glEnable(2896);
        GL11.glEnable(2929);
    }

    protected void j() {
    }

    protected abstract void a(float f);

    private void a(fi fi1) {
        int k = fi1.b;
        int i1 = fi1.c;
        hi hi1 = fi1.a();
        if(hi1 == null) {
            int j1 = fi1.e();
            if(j1 >= 0) {
                GL11.glDisable(2896);
                b.o.b(b.o.a("/gui/items.png"));
                b(k, i1, (j1 % 16) * 16, (j1 / 16) * 16, 16, 16);
                GL11.glEnable(2896);
                return;
            }
        }
        l.a(g, b.o, hi1, k, i1);
        l.b(g, b.o, hi1, k, i1);
    }

    private fi a(int k, int i1) {
        for(int j1 = 0; j1 < j.e.size(); j1++) {
            fi fi1 = (fi)j.e.get(j1);
            if(a(fi1, k, i1))
                return fi1;
        }

        return null;
    }

    private boolean a(fi fi1, int k, int i1) {
        int j1 = (c - a) / 2;
        int k1 = (d - i) / 2;
        k -= j1;
        i1 -= k1;
        return k >= fi1.b - 1 && k < fi1.b + 16 + 1 && i1 >= fi1.c - 1 && i1 < fi1.c + 16 + 1;
    }

    protected void a(int k, int i1, int j1) {
        super.a(k, i1, j1);
        if(j1 == 0 || j1 == 1) {
            fi fi1 = a(k, i1);
            int k1 = (c - a) / 2;
            int l1 = (d - i) / 2;
            boolean flag = k < k1 || i1 < l1 || k >= k1 + a || i1 >= l1 + i;
            int i2 = -1;
            if(fi1 != null)
                i2 = fi1.a;
            if(flag)
                i2 = -999;
            if(i2 != -1)
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                { int infinite = 1; // yes ... this is horrible hack - sue me
                if(i2==0 && fi1!=null && fi1.getClass()!=fi.class) infinite = ZMod.craftingHandle();
                while(   b.b.a(j.f, i2, j1, b.g)   != null && --infinite > 0); }
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        }
    }

    protected void b(int k, int i1, int j1) {
        if(j1 != 0);
    }

    protected void a(char c, int k) {
        if(k == 1 || k == b.y.q.b)
            b.g.q();
    }

    public void h() {
        if(b.g == null) {
            return;
        } else {
            b.b.a(j.f, b.g);
            return;
        }
    }

    public boolean b() {
        return false;
    }

    private static am l = new am();
    protected int a, i;
    public da j;

}
