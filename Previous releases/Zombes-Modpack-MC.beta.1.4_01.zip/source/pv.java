// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb safe
// Source File Name:   SourceFile

import net.minecraft.client.Minecraft;

// Search: -999D * need to decompile separately
public class pv extends ch {

    public pv(Minecraft minecraft, eb eb1, fk fk, ko ko1) {
        super(minecraft, eb1, fk, 0);
        bJ = 0;
        bK = false;
        bR = false;
        bS = false;
        bT = 0;
        bI = ko1;
    }

    public boolean a(pb pb, int i) {
        return false;
    }

    public void c(int i) {
    }

    public void w_() {
        //if(ZMod.keyPress(88)) ZMod.modFlyAllowed = ZMod.modCheatAllowed = true; // F8 search: -999D
        if(!aF.h(gz.b(aJ), 64, gz.b(aL))) {
            return;
        } else {
            super.w_();
            ah();
            return;
        }
    }

    public void ah() {
        if(bJ++ == 20) {
            ai();
            bJ = 0;
        }
        boolean flag = s();
        if(flag != bS) {
            if(flag)
                bI.a(((ik) (new qd(((pb) (this)), 1))));
            else
                bI.a(((ik) (new qd(((pb) (this)), 2))));
            bS = flag;
        }
        double d = aJ - bL;
        double d1 = aT.b - bM;
        double d2 = aK - bN;
        double d3 = aL - bO;
        double d4 = aP - bP;
        double d5 = aQ - bQ;
        boolean flag1 = d1 != 0.0D || d2 != 0.0D || d != 0.0D || d3 != 0.0D;
        boolean flag2 = d4 != 0.0D || d5 != 0.0D;
        if(aE != null) {
            if(flag2)
                bI.a(((ik) (new y(aM, -999D, -999D, aO, aU))));
            else
                bI.a(((ik) (new du(aM, -999D, -999D, aO, aP, aQ, aU))));
            flag1 = false;
        } else
        if(flag1 && flag2) {
            bI.a(((ik) (new du(aJ, aT.b, aK, aL, aP, aQ, aU))));
            bT = 0;
        } else
        if(flag1) {
            bI.a(((ik) (new y(aJ, aT.b, aK, aL, aU))));
            bT = 0;
        } else
        if(flag2) {
            bI.a(((ik) (new rm(aP, aQ, aU))));
            bT = 0;
        } else {
            bI.a(((ik) (new gs(aU))));
            if(bR != aU || bT > 200)
                bT = 0;
            else
                bT++;
        }
        bR = aU;
        if(flag1) {
            bL = aJ;
            bM = aT.b;
            bN = aK;
            bO = aL;
        }
        if(flag2) {
            bP = aP;
            bQ = aQ;
        }
    }

    public void D() {
        bI.a(((ik) (new hz(4, 0, 0, 0, 0))));
    }

    private void ai() {
    }

    protected void a(gb gb) {
    }

    public void a(String s) {
        bI.a(((ik) (new mi(s))));
    }

    public void I() {
        super.I();
        bI.a(((ik) (new ky(((pb) (this)), 1))));
    }

    public void p_() {
        ai();
        bI.a(((ik) (new mc())));
    }

    protected void b(int i) {
        V -= i;
    }

    public void q() {
        bI.a(((ik) (new kg(h.f))));
        f.b(((hi) (null)));
        super.q();
    }

    public void a_(int i) {
        if(bK) {
            super.a_(i);
        } else {
            V = i;
            bK = true;
        }
    }

    public ko bI;
    private int bJ, bT;
    private boolean bK, bR, bS;
    private double bL, bM, bN, bO;
    private float bP, bQ;
}
