// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

import java.awt.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MinecraftApplet;

public final class ij extends Minecraft {

    public ij(Component component, Canvas canvas, MinecraftApplet minecraftapplet, int i, int j, boolean flag, Frame frame) {
        super(component, canvas, minecraftapplet, i, j, flag);
        a = frame;
        ZMod.initialize(this); // initialization
    }

    public void a(jz jz) {
        a.removeAll();
        a.add(new bj(jz), "Center");
        a.validate();
    }

    // xxxfunc : a ? search: "/font/default.png" * function contains it
    public void a() {
        super.a();
        ZMod.initOverrides();
    }

    // called before "Pre render" just before continue command
    public void j() {
        ZMod.pingUpdateHandle();
        super.j();
    }

    final Frame a;
}
