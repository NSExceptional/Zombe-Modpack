package net.minecraft.src;

final class ZMod$Text
{
    public String msg;
    public int x;
    public int y;
    public int color;

    public ZMod$Text(String var1, int var2, int var3, int var4)
    {
        this.msg = var1;
        this.x = var2;
        this.y = var3;
        this.color = var4;
    }
}
