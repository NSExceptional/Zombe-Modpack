package net.minecraft.src;

final class ZMod$Mark
{
    public float x;
    public float y;
    public float z;
    public int min;
    public int max;
    public byte r;
    public byte g;
    public byte b;
    public byte a;

    public ZMod$Mark() {}

    public ZMod$Mark(int var1, int var2, int var3, boolean var4)
    {
        this.x = 0.5F + (float)var1;
        this.y = (float)var2 + 0.13F;
        this.z = 0.5F + (float)var3;
        this.r = (byte)(var4 ? 1 : 0);
    }

    public ZMod$Mark(int var1, int var2, int var3, ZMod$Mark var4)
    {
        this.x = 0.5F + (float)var1;
        this.y = 0.5F + (float)var2;
        this.z = 0.5F + (float)var3;
        this.r = var4.r;
        this.g = var4.g;
        this.b = var4.b;
    }

    public ZMod$Mark(int var1, int var2)
    {
        this.min = var1;
        this.max = var2;
    }

    public ZMod$Mark(int var1)
    {
        this.loadColor(var1);
    }

    public void loadColor(int var1)
    {
        this.b = (byte)(var1 & 255);
        this.g = (byte)(var1 >> 8 & 255);
        this.r = (byte)(var1 >> 16 & 255);
    }

    public boolean loadColor(String var1)
    {
        int var2 = ZMod.access$000().containsKey(var1) ? ((Integer)((Integer)ZMod.access$000().get(var1))).intValue() : ZMod.access$100(var1);

        if (var2 < 0)
        {
            return false;
        }
        else
        {
            this.loadColor(var2);
            return true;
        }
    }

    public static ZMod$Mark makeItem(int var0)
    {
        ZMod$Mark var1 = new ZMod$Mark();
        Item var2 = ZMod.access$200(var0);
        var1.setMaxStack(ZMod.access$300(var2));
        var1.setMaxDamage(ZMod.access$400(var2));

        if (var0 >= 256)
        {
            return var1;
        }
        else
        {
            var1.setLightEmission(ZMod.access$500(var0));
            var1.setLightReduction(ZMod.access$600(var0));
            Block var3 = ZMod.access$700(var0);
            var1.setStrength(ZMod.access$800(var3));
            var1.setResistance(ZMod.access$900(var3));
            var1.setSlipperiness(ZMod.access$1000(var3));
            var1.setFireBurn(ZMod.access$1100(var0));
            var1.setFireSpread(ZMod.access$1200(var0));
            return var1;
        }
    }

    public void setMaxStack(int var1)
    {
        this.r = (byte)var1;
    }

    public void setMaxDamage(int var1)
    {
        this.max = var1;
    }

    public void setLightEmission(int var1)
    {
        this.g = (byte)var1;
    }

    public void setLightReduction(int var1)
    {
        this.min = var1;
    }

    public void setStrength(float var1)
    {
        this.x = var1;
    }

    public void setResistance(float var1)
    {
        this.y = var1;
    }

    public void setSlipperiness(float var1)
    {
        this.z = var1;
    }

    public void setFireBurn(int var1)
    {
        this.b = (byte)var1;
    }

    public void setFireSpread(int var1)
    {
        this.a = (byte)var1;
    }

    public void activate(int var1)
    {
        Item var2 = ZMod.access$200(var1);
        ZMod.access$1300(var2, this.r);
        ZMod.access$1400(var2, this.max);

        if (var1 < 256)
        {
            ZMod.access$1500(var1, this.g);
            ZMod.access$1600(var1, this.min);
            Block var3 = ZMod.access$700(var1);
            ZMod.access$1700(var3, this.x);
            ZMod.access$1800(var3, this.y);
            ZMod.access$1900(var3, this.z);
            ZMod.access$2000(var1, this.a);
            ZMod.access$2100(var1, this.b);
        }
    }
}
