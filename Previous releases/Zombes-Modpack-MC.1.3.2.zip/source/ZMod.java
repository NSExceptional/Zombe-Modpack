package net.minecraft.src;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintStream;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.client.Minecraft;
import net.minecraft.src.ZMod$Mark;
import net.minecraft.src.ZMod$Options;
import net.minecraft.src.ZMod$Text;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;

public final class ZMod
{
    public static final String version = "6.3";
    private static final String[] MCPnames = new String[] {"ga_theAchievement", "theAchievement", "f", "gnc_ChatLines", "ChatLines", "c", "e_isImmuneToFire", "isImmuneToFire", "ae", "el_health", "health", "aK", "eps_sprintToggleTimer", "sprintToggleTimer", "d", "ep_flyToggleTimer", "flyToggleTimer", "bC", "em_fuel", "fuel", "e", "ee_canCarryBlocks", "carriableBlocks", "d", "tef_furnaceItemStacks", "furnaceItemStacks", "d", "tec_chestContents", "chestContents", "i", "ted_dispenserContents", "dispenserContents", "a", "cm_recipes", "recipes", "b", "sr_recipeWidth", "recipeWidth", "b", "sr_recipeHeight", "recipeHeight", "c", "sr_recipeItems", "recipeItems", "b", "sr_recipeOutput", "recipeOutput", "a", "lr_recipeOutput", "recipeOutput", "a", "lr_recipeItems", "recipeItems", "b", "ic_stackList", "stackList", "a", "b_blockHardness", "blockHardness", "cb", "b_blockResistance", "blockResistance", "cc", "bf_chanceToEncourageFire", "chanceToEncourageFire", "a", "bf_abilityToCatchFire", "abilityToCatchFire", "b"};
    private static final int KNOWN = 1;
    private static final int SOLID = 2;
    private static final int LIQUID = 4;
    private static final int CRAFT = 8;
    private static final int BASIC = 16;
    private static final int SPACE = 32;
    private static final int TREE = 64;
    private static final int GRASS = 128;
    private static final int COBBLE = 256;
    private static final int DECAL = 512;
    private static final int SAND = 1024;
    private static final int GRAVEL = 2048;
    private static final int ORE = 4096;
    private static final int OBSIDIAN = 8192;
    private static final int SPAWN = 16384;
    private static final int TOUCH = 32768;
    private static final int SANDSTONE = 65536;
    private static final int GROW = 131072;
    private static final int STORAGE = 262144;
    private static final int EMPTY = 524288;
    private static final int GHAST = 1;
    private static final int COW = 2;
    private static final int SPIDER = 3;
    private static final int SHEEP = 4;
    private static final int SKELLY = 5;
    private static final int CREEPER = 6;
    private static final int ZOMBIE = 7;
    private static final int SLIME = 8;
    private static final int PIG = 9;
    private static final int CHICKEN = 10;
    private static final int SQUID = 11;
    private static final int PIGZOMBIE = 12;
    private static final int PLAYER = 13;
    private static final int LIVING = 14;
    private static final int WOLF = 15;
    private static final int CAVESPIDER = 16;
    private static final int ENDERMAN = 17;
    private static final int SILVERFISH = 18;
    private static final int LAVASLIME = 19;
    private static final int REDCOW = 20;
    private static final int VILLAGER = 21;
    private static final int SNOWMAN = 22;
    private static final int BLAZE = 23;
    private static final int DRAGON = 24;
    private static final int GOLEM = 25;
    private static final int OCELOT = 26;
    private static final int MAXTYPE = 27;
    private static final String[] typeName = new String[] {"???", "Ghast", "Cow", "Spider", "Sheep", "Skeleton", "Creeper", "Zombie", "Slime", "Pig", "Chicken", "Squid", "PigZombie", "Player", "UnknownCreature", "Wolf", "CaveSpider", "Enderman", "Silverfish", "LavaSlime", "MushroomCow", "Villager", "SnowMan", "Blaze", "EnderDragon", "VillagerGolem", "Ozelot"};
    private static final int IGNORE = 0;
    private static final int NAMEMAP = 1;
    private static final int RECIPES = 2;
    private static final int FUEL = 3;
    private static final int SMELTING = 4;
    private static final int ITEMS = 5;
    private static final int MTAG1 = 0;
    private static final int MTAG2 = 1;
    private static final int MINFO = 2;
    private static final int MERR = 3;
    private static final int MDEBUG = 4;
    private static final int MTAGR = 5;
    private static final int MAXMSG = 6;
    private static int[] block = new int[256];
    private static Minecraft minecraft;
    private static Random rnd = new Random();
    private static String path;
    private static PrintStream out;
    private static String logPath;
    private static String showError;
    private static ZRG render;
    private static Properties conf;
    private static boolean exceptionReported;
    private static boolean[] keys = new boolean[256];
    private static boolean[] keysM = new boolean[3];
    private static HashMap names;
    private static boolean chatWelcomed;
    private static boolean initialized;
    private static int logErrors = 8;
    private static ZMod$Text[] texts = new ZMod$Text[6];
    private static int clearDisplayedError;
    private static int showOptions;
    private static ZMod$Options opt;
    private static int optionsSelMod = -1;
    private static int optionSel = -1;
    private static int optionNr;
    private static int optionModNr;
    private static int optionOfs = 0;
    private static int optionsPage = 20;
    private static boolean optionsModEnabled;
    private static Object prevPC;
    private static Object PC;
    private static boolean deferredInit;
    private static boolean isMenu;
    private static boolean isMultiplayer;
    private static boolean isHell;
    private static boolean isMapChange;
    private static boolean isWorldChange;
    private static double posX;
    private static double posY;
    private static double posZ;
    private static double motionX;
    private static double motionY;
    private static double motionZ;
    private static String chatLast;
    private static int mouseX;
    private static int mouseY;
    private static Entity inWhat;
    private static EntityPlayerSP player;
    private static WorldInfo world;
    private static World map;
    private static InventoryPlayer inv;
    private static long prevTick;
    private static long curTick;
    private static float seconds;
    private static boolean origClouds;
    private static int origFog;
    private static boolean ML_loaded;
    private static Method ML_OnTick;
    private static boolean modItemEnabled;
    private static boolean optItemChangeFence;
    private static boolean optItemChangeGlass;
    private static boolean optItemChangeIce;
    private static boolean optItemChangeLeaves;
    private static boolean optItemChangeTorch;
    private static boolean optItemChangeFarmland;
    private static boolean optItemChangeSponge;
    private static boolean optItemChangeWater;
    private static boolean optItemChangeSpawner;
    private static boolean optItemChangeShelf;
    private static boolean optItemChangeStairs;
    private static boolean optItemDump;
    private static boolean optItemChangeLava;
    private static Block itemFenceO;
    private static Block itemGlassO;
    private static Block itemIceO;
    private static Block itemLeavesO;
    private static Block itemTorchO;
    private static Block itemFarmlandO;
    private static Block itemSpongeO;
    private static Block itemWaterO;
    private static Block itemSpawnerO;
    private static Block itemShelfO;
    private static Block itemStairsO;
    private static Block itemLavaO;
    private static Block itemGlassPO;
    private static Block itemFenceM;
    private static Block itemGlassM;
    private static Block itemIceM;
    private static Block itemLeavesM;
    private static Block itemTorchM;
    private static Block itemFarmlandM;
    private static Block itemSpongeM;
    private static Block itemWaterM;
    private static Block itemSpawnerM;
    private static Block itemShelfM;
    private static Block itemStairsM;
    private static Block itemLavaM;
    private static Block itemGlassPM;
    private static int optItemLeavesDrop;
    private static int optItemOakChance;
    private static int optItemOakSpecial;
    private static int optItemBirchChance;
    private static int optItemBirchSpecial;
    private static int optItemPineChance;
    private static int optItemPineSpecial;
    private static boolean itemModified;
    private static ZMod$Mark[] itemOrig;
    private static ZMod$Mark[] itemMine;
    private static boolean modDeathEnabled;
    private static boolean optDeathDropInv;
    private static boolean optDeathLoseExp;
    private static int optDeathHPPenalty;
    private static boolean deathHaveInv;
    private static boolean deathHaveExp;
    private static ItemStack[] deathInv;
    private static ItemStack[] deathArmor;
    private static int deathXpLevel;
    private static int deathXpTotal;
    private static float deathXpP;
    private static boolean modInfoEnabled;
    private static int keyInfoToggle;
    private static int keyInfoPlayersToggle;
    private static String optInfoPrefixNear;
    private static String optInfoPrefixFar;
    private static boolean optInfoShowPos;
    private static boolean optInfoShowTime;
    private static boolean optInfoShowBiome;
    private static boolean optInfoShowHealth;
    private static boolean optInfoHideAchievement;
    private static boolean optInfoShowItem;
    private static boolean optInfoShowFPS;
    private static float optInfoRangeMax;
    private static float optInfoRangeNear;
    private static int optInfoTimeOffset;
    private static boolean infoShow;
    private static boolean infoPlayerShow;
    private static int infoDeathX;
    private static int infoDeathY;
    private static int infoDeathZ;
    private static int infoFrames = 0;
    private static long infoTime = 0L;
    private static String infoFps = "";
    private static boolean modIconEnabled;
    private static boolean optIconShowChest;
    private static boolean optIconShowDispenser;
    private static boolean optIconShowFurnace;
    private static boolean optIconMP;
    private static boolean iconMPSupport;
    private static int textureBlock;
    private static int textureItems;
    private static int texture;
    private static final float iconSize = 0.0625F;
    private static boolean modChestEnabled;
    private static boolean optChestStore;
    private static int optChestStoreRadius;
    private static int optChestStoreBlock;
    private static boolean modCloudEnabled;
    private static String tagCloudVanilla;
    private static int keyCloudToggle;
    private static int keyCloudUp;
    private static int keyCloudDown;
    private static int keyCloudVanilla;
    private static boolean optCloudShow;
    private static boolean optCloudVanilla;
    private static float optCloudOffset;
    private static boolean modCartEnabled;
    private static String tagCartPerpetual;
    private static int keyCartStop;
    private static int keyCartPerpetual;
    private static boolean optCartPerpetual;
    private static boolean optCartInfiniteFuel;
    private static float optCartSpeedAccumCap;
    private static float optCartAcceleration;
    private static double cartSpeed;
    public static boolean modWieldEnabled;
    public static String tagWieldAmmo;
    public static int keyWield;
    public static boolean optWieldBowFirst;
    public static boolean optWieldShowAmmo;
    private static boolean modBuildEnabled;
    private static String tagBuildEnabled;
    private static int keyBuildToggle;
    private static int keyBuildA;
    private static int keyBuildB;
    private static int keyBuildMark;
    private static int keyBuildCopy;
    private static int keyBuildPaste;
    private static int keyBuildSet;
    private static int keyBuildFill;
    private static int keyBuildRemove;
    private static int keyBuildDown;
    private static int keyBuildDeselect;
    private static int optBuildLockQuantityToNr;
    private static int optBuildHarvestRule;
    private static float optBuildDigSpeed;
    private static float optBuildReach;
    private static boolean optBuild;
    private static boolean optBuildExtension;
    private static boolean optBuildLockQuantity;
    private static int[][] buildSets;
    private static int[] buildBufBlock;
    private static int[] buildBufExtra;
    private static int buildSX;
    private static int buildEX;
    private static int buildSY;
    private static int buildEY;
    private static int buildSZ;
    private static int buildEZ;
    private static int buildMark = 0;
    private static int buildSizeX = 0;
    private static int buildSizeY = 0;
    private static int buildSizeZ = 0;
    private static int buildHandSlot;
    private static int buildHandCount;
    private static NBTTagCompound[] buildBufNBT;
    private static ItemStack buildHand;
    private static boolean modCompassEnabled;
    private static String tagCompassAlternate;
    private static int keyCompassSet;
    private static int keyCompassToggle;
    private static boolean optCompassShowPos;
    private static boolean compassHaveOrig;
    private static boolean compassHaveMine;
    private static boolean compassShowOrig = true;
    private static int compassOX;
    private static int compassOY;
    private static int compassOZ;
    private static int compassMX;
    private static int compassMY;
    private static int compassMZ;
    private static boolean modSunEnabled;
    private static String tagSunTime;
    private static String optSunServerCmd;
    private static int keySunTimeAdd;
    private static int keySunTimeSub;
    private static int keySunStop;
    private static int keySunTimeNormal;
    private static int keySunServer;
    private static int optSunTimeStep;
    private static boolean optSunServerCmdPlus;
    private static boolean sunTimeStop;
    private static boolean sunSleeping;
    private static long sunTimeOffset;
    private static long sunTimeMoment;
    private static Field fSprintTT = getField(EntityPlayerSP.class, "eps_sprintToggleTimer");
    private static Field fFlyTT = getField(EntityPlayer.class, "ep_flyToggleTimer");
    private static boolean modFlyEnabled;
    private static boolean modFlyAllowed;
    private static boolean modNoClipAllowed;
    private static String tagFly;
    private static String tagFlyNoClip;
    private static int keyFlyOn;
    private static int keyFlyOff;
    private static int keyFlyUp;
    private static int keyFlyDown;
    private static int keyFlySpeed;
    private static int keyFlyToggle;
    private static int keyFlyRun;
    private static int keyFlyNoClip;
    private static double optFlySpeedVertical;
    private static double optFlySpeedMulNormal;
    private static double optFlySpeedMulModifier;
    private static double optFlyRunSpeedMul;
    private static double optFlyRunSpeedVMul;
    private static double optFlyJump;
    private static double optFlyJumpHigh;
    private static boolean optFlySpeedIsToggle;
    private static boolean optFlyRunSpeedIsToggle;
    private static boolean optFlyNoClip;
    private static boolean optFlyVanillaFly;
    private static boolean optFlyVanillaSprint;
    static boolean fly;
    private static boolean flySpeed;
    private static boolean flyRun;
    private static boolean flyNoClip;
    private static boolean playerClassActive;
    private static double movX;
    private static double movZ;
    private static boolean flew = false;
    private static boolean moveOnGround;
    private static float flyTmp;
    private static boolean modCraftEnabled;
    private static int keyCraftAll;
    private static boolean modPathEnabled;
    private static int keyPathShow;
    private static int keyPathDelete;
    private static boolean optPathShow;
    private static int optPathPoints;
    private static int optPathSpacing;
    private static float optPathMin;
    private static float optPathAnimSpeed;
    private static ZMod$Mark optPathColor;
    private static int pathCount;
    private static int pathLast;
    private static float pathAnimCur;
    private static float[] pathf;
    private static boolean modRecipeEnabled;
    private static boolean optRecipeShowId;
    private static boolean optRecipeDump;
    private static boolean optRecipeVanillaMP;
    private static boolean optRecipeShowHelp;
    private static List recipesSP;
    private static List recipesMP;
    private static int recipesMobType;
    private static IRecipe selRecipe;
    private static boolean modSafeEnabled;
    private static String tagSafe;
    private static int keySafeShow;
    private static ZMod$Mark optSafeDangerColor;
    private static ZMod$Mark optSafeDangerColorSun;
    private static boolean optSafeShowWithSun;
    private static final int safeMax = 2048;
    private static ZMod$Mark[] safeMark;
    private static boolean safeShow;
    private static int safeCur;
    private static int safeUpdate;
    private static boolean modBoomEnabled;
    private static int optBoomSafeRange;
    private static float optBoomDropOreChance;
    private static float optBoomDropChance;
    private static float optBoomScaleTNT;
    private static float optBoomScaleCreeper;
    private static float optBoomScaleFireball;
    private static boolean modSpawnEnabled;
    private static boolean optSpawnSupportMods;
    private static boolean optSpawnAllowInNonAir;
    private static boolean optSpawnAllowOnNonNatural;
    private static boolean optSpawnAllowOnGrass;
    private static boolean optSpawnAllowOnCobble;
    private static boolean optSpawnAllowOnSand;
    private static boolean optSpawnAllowOnGravel;
    private static boolean optSpawnAllowOnTree;
    private static boolean optSpawnAllowOnSandstone;
    private static int optSpawnPigReduction;
    private static int optSpawnChickenReduction;
    private static int optSpawnCowReduction;
    private static int optSpawnSheepReduction;
    private static int optSpawnSquidReduction;
    private static int optSpawnGhastReduction;
    private static int optSpawnWolfReduction;
    private static int optSpawnSpiderReduction;
    private static int optSpawnSkeletonReduction;
    private static int optSpawnCreeperReduction;
    private static int optSpawnZombieReduction;
    private static int optSpawnSlimeReduction;
    private static int optSpawnPigZombieReduction;
    private static int optSpawnCaveSpiderReduction;
    private static int optSpawnEndermanReduction;
    private static int optSpawnSilverfishReduction;
    private static boolean modOreEnabled;
    private static boolean optOreLavaFloor;
    private static int[] optOreCoalRule;
    private static int[] optOreIronRule;
    private static int[] optOreGoldRule;
    private static int[] optOreBlueRule;
    private static int[] optOreRedRule;
    private static int[] optOreDiamondRule;
    private static boolean modTeleportEnabled;
    private static int keyTeleportUp;
    private static int keyTeleportDown;
    private static int keyTeleportCursor;
    private static boolean optTeleportIsSelected;
    private static int optTeleportUseItem;
    private static int optTeleportItem;
    private static int optTeleportPlayer;
    private static int optTeleportCritter;
    private static boolean modCheatEnabled;
    private static boolean modCheatAllowed;
    private static String tagCheater;
    private static int keyCheatShowMobs;
    private static int keyCheatShowOres;
    private static int keyCheat;
    private static int keyCheatSee;
    private static int keyCheatHighlight;
    private static int keyCheatRemoveFire;
    private static int keyCheatView;
    private static int keyCheatHealth;
    private static boolean optCheatFallDamage;
    private static boolean optCheatRestoreHealth;
    private static boolean optCheatShowDangerous;
    private static boolean optCheatShowNeutral;
    private static boolean optCheat;
    private static boolean optCheatSeeIsToggle;
    private static boolean optCheatShowMobsSize;
    private static boolean optCheatInfArrows;
    private static boolean optCheatInfArmor;
    private static boolean optCheatInfSword;
    private static boolean optCheatInfTools;
    private static boolean optCheatFireImmune;
    private static boolean optCheatShowHealth;
    private static boolean optCheatNoAir;
    private static boolean optCheatNerfEnderman;
    private static int optCheatHighlightMode;
    private static int optCheatShowOresRangeH;
    private static int optCheatShowOresRangeV;
    private static int optCheatShowMobsRange;
    private static float optCheatSeeDist;
    private static final int cheatMax = 16384;
    private static final int cheatItems = 400;
    private static ZMod$Mark[] cheatMobs;
    private static ZMod$Mark[] cheatOres;
    private static ZMod$Mark[] cheatMark;
    private static boolean cheating = false;
    private static boolean cheatShowMobs = false;
    private static boolean cheatShowOres = false;
    private static boolean cheatSee;
    private static boolean[] cheatDamage;
    private static boolean cheatHighlight;
    private static int cheatCur = 0;
    private static float cheatRefresh;
    private static FloatBuffer cheatAmbItems;
    private static FloatBuffer cheatAmbGeom;
    private static EntityLiving cheatView;
    private static float cheatGamma;
    private static boolean[] cheatCarryBlocks;
    private static boolean cheatCarryOverride;
    private static Field fCarryBlocks = getField(EntityEnderman.class, "ee_canCarryBlocks");
    private static int cheatArrowCount;
    private static boolean modResizeEnabled;
    private static int[] resizeChanceBig;
    private static int[] resizeChanceSmall;
    private static float[] resizeSize;
    private static boolean modFurnaceEnabled;
    private static boolean optFurnaceFuelWaste;
    private static boolean optFurnaceReturnBucket;
    private static int optFurnaceWoodFuel;
    private static int optFurnaceInfiniteFuel;
    private static int optFurnaceSmeltingTime;
    private static HashMap furnaceFuel;
    private static HashMap furnaceSmelting;
    private static boolean modDigEnabled;
    private static boolean optDigHarvestAlways;
    private static float optDigSpeed;
    private static float optDigReach;
    private static boolean modWeatherEnabled;
    private static int keyWeatherRain;
    private static int keyWeatherThunderstorm;
    private static int keyWeatherMayhem;
    private static int keyWeatherLightning;
    private static boolean optWeatherLocked;
    private static boolean optWeatherNoDraw;
    private static int optWeatherThunderChance;
    private static int optWeatherThunderMayhemChance;
    private static ZMod$Mark optWeatherRainTime;
    private static ZMod$Mark optWeatherNoRainTime;
    private static ZMod$Mark optWeatherThunderTime;
    private static ZMod$Mark optWeatherNoThunderTime;
    private static String tagWeatherRaining;
    private static String tagWeatherThundering;
    private static String tagWeatherMayhem;
    private static boolean weatherMayhem;
    private static boolean modGrowthEnabled;
    private static boolean optGrowthRooting;
    private static boolean optGrowthPlanting;
    private static int optGrowthFlower;
    private static int optGrowthShroom;
    private static int optGrowthPumpkin;
    private static int optGrowthSappling;
    private static int optGrowthReed;
    private static int optGrowthRootingSpace;
    private static int optGrowthRootingTime;
    private static float growthSqrRadius;
    private static boolean TMI_initialized;
    private static Method mTMI_isEnabled;
    private static Method mTMI_getInstance;
    private static Field fChat = getField(GuiNewChat.class, "gnc_ChatLines");
    private static Field fAchivement = getField(GuiAchievement.class, "ga_theAchievement");
    private static RenderItem itemRenderer;
    private static Field fFireImmune = getField(Entity.class, "e_isImmuneToFire");
    private static Field fHealth = getField(EntityLiving.class, "el_health");
    private static Field fCartFuel = getField(EntityMinecart.class, "em_fuel");
    private static Field fFurnaceItems = getField(TileEntityFurnace.class, "tef_furnaceItemStacks");
    private static Field fChestItems = getField(TileEntityChest.class, "tec_chestContents");
    private static Field fDispItems = getField(TileEntityDispenser.class, "ted_dispenserContents");
    private static Field fCMRecipes = getField(CraftingManager.class, "cm_recipes");
    private static Field fRWidth = getField(ShapedRecipes.class, "sr_recipeWidth");
    private static Field fRHeight = getField(ShapedRecipes.class, "sr_recipeHeight");
    private static Field fRMap = getField(ShapedRecipes.class, "sr_recipeItems");
    private static Field fRResA = getField(ShapedRecipes.class, "sr_recipeOutput");
    private static Field fRList = getField(ShapelessRecipes.class, "lr_recipeItems");
    private static Field fRResB = getField(ShapelessRecipes.class, "lr_recipeOutput");
    private static Field fCBTable = getField(InventoryCrafting.class, "ic_stackList");
    private static MovingObjectPosition rayHit;
    private static ItemStack[] invItemsArr;
    private static ItemStack[] invArmorsArr;
    private static Field fBlockStrength = getField(Block.class, "b_blockHardness");
    private static Field fBlockResist = getField(Block.class, "b_blockResistance");
    private static Field fBlockFireSpread = getField(BlockFire.class, "bf_chanceToEncourageFire");
    private static Field fBlockFireBurn = getField(BlockFire.class, "bf_abilityToCatchFire");
    private static HashMap pNames;
    private static HashSet pFiles;
    private static HashMap pFuel;
    private static HashMap pSmelt;
    private static List pList;

    private static void initBlockLookupArray()
    {
        block[0] = 524337;
        block[1] = 19;
        block[2] = 131;
        block[3] = 19;
        block[4] = 259;
        block[5] = 11;
        block[6] = 131617;
        block[7] = 19;
        block[8] = 37;
        block[9] = 37;
        block[10] = 5;
        block[11] = 5;
        block[12] = 1027;
        block[13] = 2051;
        block[14] = 4115;
        block[15] = 4115;
        block[16] = 4115;
        block[17] = 67;
        block[18] = 67;
        block[19] = 11;
        block[20] = 11;
        block[21] = 4115;
        block[22] = 11;
        block[23] = 262155;
        block[24] = 65539;
        block[25] = 32779;
        block[26] = 11;
        block[27] = 545;
        block[28] = 545;
        block[30] = 545;
        block[31] = 545;
        block[32] = 545;
        block[33] = 11;
        block[34] = 11;
        block[35] = 11;
        block[36] = 3;
        block[37] = 131617;
        block[38] = 131617;
        block[39] = 131617;
        block[40] = 131617;
        block[41] = 11;
        block[42] = 11;
        block[43] = 11;
        block[44] = 11;
        block[45] = 11;
        block[46] = 11;
        block[47] = 11;
        block[48] = 19;
        block[49] = 8195;
        block[50] = 545;
        block[51] = 545;
        block[52] = 19;
        block[53] = 11;
        block[54] = 262155;
        block[55] = 545;
        block[56] = 4115;
        block[57] = 11;
        block[58] = 11;
        block[59] = 545;
        block[60] = 11;
        block[61] = 262155;
        block[62] = 262155;
        block[63] = 33313;
        block[64] = 33313;
        block[65] = 545;
        block[66] = 545;
        block[67] = 11;
        block[68] = 33313;
        block[69] = 33313;
        block[70] = 545;
        block[71] = 33313;
        block[72] = 545;
        block[73] = 4115;
        block[74] = 4115;
        block[75] = 545;
        block[76] = 545;
        block[77] = 33313;
        block[78] = 33;
        block[79] = 19;
        block[80] = 11;
        block[81] = 19;
        block[82] = 19;
        block[83] = 131617;
        block[84] = 11;
        block[85] = 11;
        block[86] = 131091;
        block[87] = 19;
        block[88] = 19;
        block[89] = 4115;
        block[90] = 33;
        block[91] = 11;
        block[92] = 32779;
        block[93] = 32779;
        block[94] = 32779;
        block[95] = 11;
        block[96] = 11;
        block[97] = 19;
        block[98] = 19;
        block[99] = 19;
        block[100] = 19;
        block[101] = 19;
        block[102] = 11;
        block[103] = 19;
        block[104] = 545;
        block[105] = 545;
        block[106] = 545;
        block[107] = 11;
        block[108] = 11;
        block[109] = 11;
        block[110] = 19;
        block[111] = 49;
        block[112] = 19;
        block[113] = 11;
        block[114] = 11;
        block[115] = 49;
        block[116] = 11;
        block[117] = 11;
        block[118] = 11;
        block[119] = 33;
        block[120] = 11;
        block[121] = 19;
        block[122] = 19;
        block[123] = 11;
        block[124] = 11;

        for (int var0 = 0; var0 < 256; ++var0)
        {
            if (getBlockIsSpawn(var0))
            {
                block[var0] |= 16384;
            }
        }
    }

    public static void initialize(Minecraft var0)
    {
        log("*** initialization ***");
        minecraft = var0;
        conf = new Properties();

        try
        {
            Properties var1;
            (var1 = new Properties()).load(new FileInputStream(path + "config.txt"));
            conf = var1;
            log("info: processing configuration");
        }
        catch (Exception var2)
        {
            err("error: failed to load configuration from config.txt", var2);
        }

        try
        {
            if (getBool("disableAllMods", false))
            {
                log("info: all mods disabled");
                return;
            }

            optionsModModpack();
            parse((List)null, "names.txt", 1);
            names = pNames;
            initBlockLookupArray();
            int var4 = 0;

            if (modItemEnabled = getBool("modItemEnabled", false) && initModItem())
            {
                ++var4;
            }

            if (modDeathEnabled = getBool("modDeathEnabled", false) && initModDeath())
            {
                ++var4;
            }

            if (modInfoEnabled = getBool("modInfoEnabled", false) && initModInfo())
            {
                ++var4;
            }

            if (modIconEnabled = getBool("modIconEnabled", false) && initModIcon())
            {
                ++var4;
            }

            ZP250.init();

            if (modChestEnabled = getBool("modChestEnabled", false) && initModChest())
            {
                ++var4;
            }

            if (modCloudEnabled = getBool("modCloudEnabled", false) && initModCloud())
            {
                ++var4;
            }

            if (modCartEnabled = getBool("modCartEnabled", false) && initModCart())
            {
                ++var4;
            }

            if (modWieldEnabled = getBool("modWieldEnabled", false) && initModWield())
            {
                ++var4;
            }

            if (modBuildEnabled = getBool("modBuildEnabled", false) && initModBuild())
            {
                ++var4;
            }

            if (modCompassEnabled = getBool("modCompassEnabled", false) && initModCompass())
            {
                ++var4;
            }

            if (modSunEnabled = getBool("modSunEnabled", false) && initModSun())
            {
                ++var4;
            }

            if (modCraftEnabled = getBool("modCraftEnabled", false) && initModCraft())
            {
                ++var4;
            }

            if (modFlyEnabled = getBool("modFlyEnabled", false) && initModFly())
            {
                ++var4;
            }

            if (modPathEnabled = getBool("modPathEnabled", false) && initModPath())
            {
                ++var4;
            }

            if (modRecipeEnabled = getBool("modRecipeEnabled", false) && initModRecipe())
            {
                ++var4;
            }

            if (modSafeEnabled = getBool("modSafeEnabled", false) && initModSafe())
            {
                ++var4;
            }

            if (modBoomEnabled = getBool("modBoomEnabled", false) && initModBoom())
            {
                ++var4;
            }

            if (modSpawnEnabled = getBool("modSpawnEnabled", false) && initModSpawn())
            {
                ++var4;
            }

            if (modOreEnabled = getBool("modOreEnabled", false) && initModOre())
            {
                ++var4;
            }

            if (modTeleportEnabled = getBool("modTeleportEnabled", false) && initModTeleport())
            {
                ++var4;
            }

            if (modCheatEnabled = getBool("modCheatEnabled", false) && initModCheat())
            {
                ++var4;
            }

            if (modResizeEnabled = getBool("modResizeEnabled", false) && initModResize())
            {
                ++var4;
            }

            if (modFurnaceEnabled = getBool("modFurnaceEnabled", false) && initModFurnace())
            {
                ++var4;
            }

            if (modDigEnabled = getBool("modDigEnabled", false) && initModDig())
            {
                ++var4;
            }

            if (modWeatherEnabled = getBool("modWeatherEnabled", false) && initModWeather())
            {
                ++var4;
            }

            if (modGrowthEnabled = getBool("modGrowthEnabled", false) && initModGrowth())
            {
                ++var4;
            }

            if (optItemChangeSpawner || modRecipeEnabled || modBuildEnabled)
            {
                initModItemShared();
            }

            if (var4 == 0)
            {
                err("warning: no mods are enabled! Read the readme.html!");
            }

            log("info: configuration loaded");
        }
        catch (Exception var3)
        {
            err("error: initialization failed", var3);
        }

        initialized = true;
        log("*** done ***");
    }

    private static void optionsModModpack()
    {
        showOptions = getSetBind(showOptions, "showOptions", 65, "Show options screen");
        clearDisplayedError = getSetBind(clearDisplayedError, "clearDisplayedError", 67, "Clear displayed error");
    }

    private static boolean optionsMod(String var0, boolean var1)
    {
        byte var2 = 14;
        int var3 = optionModNr / var2 * 10 + 2;
        int var4 = optionModNr % var2 + 1;
        optionsModEnabled = true;

        if (drawBtn(var3, var4, 9, var0, (String)null, optionsSelMod == optionModNr, var1, false, false))
        {
            optionsSelMod = optionModNr;
            optionSel = -1;
            optionNr = -100;
            optionOfs = 0;
        }

        optionsModEnabled = var1;
        return optionsSelMod == optionModNr++;
    }

    private static void optionsMods(ZMod$Options var0)
    {
        if (modInfoEnabled && optInfoHideAchievement)
        {
            killAchievement();
        }

        opt = var0;
        optionModNr = 0;
        optionNr = 0;
        ZMod$Options var10000 = opt;
        ZMod$Options.drawRect(0, 0, opt.width, opt.height, -1073741824);
        showText("Zombe\'s modpack v6.3:", 2, 2, 13421772);

        if (optionOfs > 0)
        {
            if (drawBtn(22, 1, 20, "^^^", (String)null, false, false, true, true))
            {
                optionOfs -= optionsPage;
                return;
            }

            ++optionNr;
        }

        if (optionsMod("\u00a7emodpack", true))
        {
            optionsModModpack();
        }

        if (optionsMod("Boom", modBoomEnabled))
        {
            optionsModBoom();
        }

        if (optionsMod("Build", modBuildEnabled))
        {
            optionsModBuild();
        }

        if (optionsMod("Cart", modCartEnabled))
        {
            optionsModCart();
        }

        if (optionsMod("Cheat", modCheatEnabled))
        {
            optionsModCheat();
        }

        if (optionsMod("Chest", modChestEnabled))
        {
            optionsModChest();
        }

        if (optionsMod("Cloud", modCloudEnabled))
        {
            optionsModCloud();
        }

        if (optionsMod("Compass", modCompassEnabled))
        {
            optionsModCompass();
        }

        if (optionsMod("Craft", modCraftEnabled))
        {
            optionsModCraft();
        }

        if (optionsMod("Death", modDeathEnabled))
        {
            optionsModDeath();
        }

        if (optionsMod("Dig", modDigEnabled))
        {
            optionsModDig();
        }

        if (optionsMod("Fly", modFlyEnabled))
        {
            optionsModFly();
        }

        if (optionsMod("Furnace", modFurnaceEnabled))
        {
            optionsModFurnace();
        }

        if (optionsMod("Growth", modGrowthEnabled))
        {
            optionsModGrowth();
        }

        if (optionsMod("Icon", modIconEnabled))
        {
            optionsModIcon();
        }

        if (optionsMod("Info", modInfoEnabled))
        {
            optionsModInfo();
        }

        if (optionsMod("Ite\u00a7fm", modItemEnabled))
        {
            optionsModItem();
        }

        if (optionsMod("Ore", modOreEnabled))
        {
            optionsModOre();
        }

        if (optionsMod("Path", modPathEnabled))
        {
            optionsModPath();
        }

        if (optionsMod("Recipe", modRecipeEnabled))
        {
            optionsModRecipe();
        }

        if (optionsMod("Resize", modResizeEnabled))
        {
            optionsModResize();
        }

        if (optionsMod("Safe", modSafeEnabled))
        {
            optionsModSafe();
        }

        if (optionsMod("Spawn", modSpawnEnabled))
        {
            optionsModSpawn();
        }

        if (optionsMod("Sun", modSunEnabled))
        {
            optionsModSun();
        }

        if (optionsMod("Teleport", modTeleportEnabled))
        {
            optionsModTeleport();
        }

        if (optionsMod("Weather", modWeatherEnabled))
        {
            optionsModWeather();
        }

        if (optionsMod("Wield", modWieldEnabled))
        {
            optionsModWield();
        }

        if (optionOfs + optionsPage < optionNr)
        {
            optionNr = optionOfs + optionsPage + 1;

            if (drawBtn(22, optionNr - optionOfs, 20, "vvv", (String)null, false, false, true, true))
            {
                optionOfs += optionsPage;
            }
        }
    }

    public static Minecraft getMinecraft()
    {
        return minecraft;
    }

    public static void pingRespawnHandle(boolean var0)
    {
        try
        {
            if (!isMultiplayer && modDeathEnabled && !var0)
            {
                respawnDeathMod();
            }

            if (modInfoEnabled && !var0)
            {
                respawnInfoMod();
            }
        }
        catch (Exception var2)
        {
            err("error: respawn failed", var2);
        }
    }

    public static void initOverrides()
    {
        try
        {
            log("info: init render");
            overloadRenderGlobal();
            overloadEntityRender();
        }
        catch (Exception var1)
        {
            err("error: overrides failed", var1);
        }
    }

    public static void pingOnDeathHandle()
    {
        onDeathModDeath();
    }

    public static void pingPreEntHandle()
    {
        preEntModFly();
    }

    public static void pingUpdateHandle()
    {
        if (!deferredInit)
        {
            try
            {
                deferredInit = true;
                deferredModItem();
                deferredModRecipe();
            }
            catch (Exception var26)
            {
                err("error: deferredInit failed", var26);
            }
        }

        try
        {
            if ((player = getPlayer()) == null)
            {
                deathHaveExp = false;
                deathHaveInv = false;
                return;
            }

            isMapChange = map != getMap();

            if ((map = getMap()) == null)
            {
                return;
            }

            if (getRenderer() == null)
            {
                return;
            }

            List var0 = getEntities();
            posX = getEntityPosX(player);
            posY = getEntityPosY(player);
            posZ = getEntityPosZ(player);
            motionX = getEntityMotionX(player);
            motionY = getEntityMotionY(player);
            motionZ = getEntityMotionZ(player);
            isMenu = getIsMenu();
            isMultiplayer = getIsMultiplayer();
            isHell = getIsHell();
            inWhat = getOnEntity(player);
            inv = getInventory(player);
            invItemsArr = getInvItems(inv);
            invArmorsArr = getInvArmors(inv);
            world = getWorld();
            PC = getPlayerController();

            if (isMenu)
            {
                updateMousePos();
            }

            if (isWorldChange = PC != prevPC)
            {
                modFlyAllowed = modFlyEnabled;
                modCheatAllowed = modCheatEnabled;
                modNoClipAllowed = modFlyEnabled && !isMultiplayer;
                chatWelcomed = false;
                iconMPSupport = false;
                infoDeathY = 1024;

                if (isMultiplayer && optIconMP)
                {
                    sendChat("/zombe-icon");
                }
            }

            prevPC = PC;
            List var1 = getChat();

            if (!chatWelcomed)
            {
                for (int var2 = 0; var2 < var1.size(); ++var2)
                {
                    String var3 = getChatLine(var1, var2);

                    if (var3 == chatLast)
                    {
                        break;
                    }

                    if (var3.contains("joined the game"))
                    {
                        chatWelcomed = true;
                    }
                    else
                    {
                        if (var3.contains("\u00a7f \u00a7f \u00a71 \u00a70 \u00a72 \u00a74"))
                        {
                            modFlyAllowed = false;
                        }

                        if (var3.contains("\u00a7f \u00a7f \u00a72 \u00a70 \u00a74 \u00a78"))
                        {
                            modCheatAllowed = false;
                        }

                        if (var3.contains("\u00a7f \u00a7f \u00a74 \u00a70 \u00a79 \u00a76"))
                        {
                            modNoClipAllowed = modFlyAllowed;
                        }

                        if (var3.matches(".*(\\W|^)no-z-fly(\\W|$).*"))
                        {
                            modFlyAllowed = false;
                        }

                        if (var3.matches(".*(\\W|^)no-z-cheat(\\W|$).*"))
                        {
                            modCheatAllowed = false;
                        }

                        if (var3.matches(".*(\\W|^)z-cheat(\\W|$).*"))
                        {
                            modNoClipAllowed = modFlyAllowed;
                        }
                    }
                }
            }

            if (var1.size() > 0)
            {
                chatLast = getChatLine(var1, 0);
            }

            delMsg(1);

            if (showError != null && !isMenu && keyPress(clearDisplayedError))
            {
                showError = null;
                delMsg(3);
            }

            if (keyPress(showOptions))
            {
                minecraft.displayGuiScreen(minecraft.currentScreen instanceof ZMod$Options ? null : new ZMod$Options());
            }

            try
            {
                updateModRecipeShared();
            }
            catch (Exception var25)
            {
                err("error: \"recipe\" update failed", var25);
            }

            try
            {
                updateModItem();
            }
            catch (Exception var24)
            {
                err("error: \"item\" update failed", var24);
            }

            try
            {
                updateModDeath();
            }
            catch (Exception var23)
            {
                err("error: \"death\" update failed", var23);
            }

            try
            {
                updateModInfo(var0);
            }
            catch (Exception var22)
            {
                err("error: \"info\" update failed", var22);
            }

            try
            {
                updateModChest(var0);
            }
            catch (Exception var21)
            {
                err("error: \"chest\" update failed", var21);
            }

            try
            {
                updateModGrowth(var0);
            }
            catch (Exception var20)
            {
                err("error: \"growth\" update failed", var20);
            }

            try
            {
                updateModWeather();
            }
            catch (Exception var19)
            {
                err("error: \"weather\" update failed", var19);
            }

            try
            {
                updateModCloud();
            }
            catch (Exception var18)
            {
                err("error: \"cloud\" update failed", var18);
            }

            try
            {
                updateModCart(var0);
            }
            catch (Exception var17)
            {
                err("error: \"cart\" update failed", var17);
            }

            try
            {
                updateModWield();
            }
            catch (Exception var16)
            {
                err("error: \"wield\" update failed", var16);
            }

            try
            {
                updateModBuild();
            }
            catch (Exception var15)
            {
                err("error: \"build\" update failed", var15);
            }

            try
            {
                updateModCompass();
            }
            catch (Exception var14)
            {
                err("error: \"compass\" update failed", var14);
            }

            try
            {
                updateModSun();
            }
            catch (Exception var13)
            {
                err("error: \"sun\" update failed", var13);
            }

            try
            {
                updateModFly();
            }
            catch (Exception var12)
            {
                err("error: \"fly\" update failed", var12);
            }

            try
            {
                updateModPath();
            }
            catch (Exception var11)
            {
                err("error: \"\" update failed", var11);
            }

            try
            {
                updateModRecipe();
            }
            catch (Exception var10)
            {
                err("error: \"recipe\" update failed", var10);
            }

            try
            {
                updateModSafe();
            }
            catch (Exception var9)
            {
                err("error: \"safe\" update failed", var9);
            }

            try
            {
                updateModSpawn(var0);
            }
            catch (Exception var8)
            {
                err("error: \"spawn\" update failed", var8);
            }

            try
            {
                updateModOre();
            }
            catch (Exception var7)
            {
                err("error: \"ore\" update failed", var7);
            }

            try
            {
                updateModTeleport(var0);
            }
            catch (Exception var6)
            {
                err("error: \"teleport\" update failed", var6);
            }

            try
            {
                updateModCheat(var0);
            }
            catch (Exception var5)
            {
                err("error: \"cheat\" update failed", var5);
            }

            try
            {
                updateResizeMod(var0);
            }
            catch (Exception var4)
            {
                err("error: \"resize\" update failed", var4);
            }

            movX = getEntityMotionX(player);
            movZ = getEntityMotionZ(player);
        }
        catch (Exception var27)
        {
            err("error: update-handle failed", var27);
        }
    }

    public static void pingStartHandle()
    {
        try
        {
            startModCheat();
        }
        catch (Exception var1)
        {
            err("error: start-handle failed", var1);
        }
    }

    public static void pingDrawHandle(float var0)
    {
        minecraft.gameSettings.clouds = origClouds;
        minecraft.gameSettings.renderDistance = origFog;

        if (player != null && map != null && getRenderer() != null && cheatView == null)
        {
            try
            {
                List var1 = getEntities();
                posX = getEntityPosX(player);
                posY = getEntityPosY(player);
                posZ = getEntityPosZ(player);
                curTick = System.nanoTime();
                seconds = (float)(curTick - prevTick) * 1.0E-9F;

                if (seconds > 1.0F)
                {
                    seconds = 0.0F;
                }

                prevTick = curTick;
                float var2 = (float)posX;
                float var3 = (float)posY;
                float var4 = (float)posZ;
                float var5 = (float)getEntityPrevPosX(player);
                float var6 = (float)getEntityPrevPosY(player);
                float var7 = (float)getEntityPrevPosZ(player);
                float var8 = var5 + (var2 - var5) * var0;
                float var9 = var6 + (var3 - var6) * var0;
                float var10 = var7 + (var4 - var7) * var0;

                try
                {
                    drawModIcon(var8, var9, var10);
                }
                catch (Exception var16)
                {
                    err("error: \"icon\" draw failed", var16);
                }

                try
                {
                    drawModCheat(var8, var9, var10, var1);
                }
                catch (Exception var15)
                {
                    err("error: \"cheat\" draw failed", var15);
                }

                try
                {
                    drawModPath(var8, var9, var10);
                }
                catch (Exception var14)
                {
                    err("error: \"path\" draw failed", var14);
                }

                try
                {
                    drawModSafe(var8, var9, var10);
                }
                catch (Exception var13)
                {
                    err("error: \"safe\" draw failed", var13);
                }

                try
                {
                    drawModBuild(var8, var9, var10);
                }
                catch (Exception var12)
                {
                    err("error: \"build\" draw failed", var12);
                }

                if (origFog < 2 && origClouds)
                {
                    drawModCloud(var0);
                }
            }
            catch (Exception var17)
            {
                err("error: draw-handle failed", var17);
            }
        }
    }

    public static void spoofCloudFogConfig()
    {
        origClouds = minecraft.gameSettings.clouds;
        minecraft.gameSettings.clouds = true;
        origFog = minecraft.gameSettings.renderDistance;
        minecraft.gameSettings.renderDistance = 0;
    }

    public static void pingDrawGUIHandle(float var0)
    {
        if (!isHideGUI() && !getIsOptions())
        {
            GL11.glMatrixMode(GL11.GL_PROJECTION);
            GL11.glPushMatrix();
            GL11.glLoadIdentity();
            setOrtho();
            GL11.glMatrixMode(GL11.GL_MODELVIEW);
            GL11.glPushMatrix();
            GL11.glLoadIdentity();
            GL11.glTranslatef(0.0F, 0.0F, -2000.0F);
            GL11.glDisable(GL11.GL_LIGHTING);
            byte var1 = 0;
            int var5;
            int var6;
            int var7;

            if (isShowDebug())
            {
                setMsg(4, pingDebugHandle(), 16777215, 2, 90);
                ZMod$Text var2 = texts[4];
                String[] var3 = var2.msg.split("\n");
                int var4 = var2.x;
                var5 = var2.y + var1;
                var6 = var2.color;

                for (var7 = 0; var7 < var3.length; var5 += 10)
                {
                    showText(var3[var7], var4, var5, var6);
                    ++var7;
                }
            }
            else if (!isMenu)
            {
                setMsg(0, pingTextHandle());

                for (int var11 = 0; var11 < texts.length; ++var11)
                {
                    ZMod$Text var12 = texts[var11];

                    if (var12 != null && (!isMenu || var11 == 0) && var11 != 4)
                    {
                        String[] var13 = var12.msg.split("\n");
                        var5 = var12.x;
                        var6 = var12.y + var1;
                        var7 = var12.color;
                        int var8 = getScrWidthS() - 2;

                        if (var11 == 5)
                        {
                            var6 = 2;
                        }

                        for (int var9 = 0; var9 < var13.length; var6 += 10)
                        {
                            if (var11 == 5)
                            {
                                var5 = var8 - showTextLength(var13[var9]);
                            }

                            showText(var13[var9], var5, var6, var7);
                            ++var9;
                        }
                    }
                }
            }

            drawGuiModInfo();
            drawGuiModRecipe();
            GL11.glPopMatrix();
            GL11.glMatrixMode(GL11.GL_PROJECTION);
            GL11.glPopMatrix();
            GL11.glMatrixMode(GL11.GL_MODELVIEW);
        }

        if (!ML_loaded)
        {
            try
            {
                ML_loaded = true;
                ML_OnTick = Class.forName("ModLoader").getDeclaredMethod("onTick", new Class[] {Float.TYPE, Minecraft.class});
            }
            catch (Exception var10)
            {
                ML_OnTick = null;
            }
        }

        if (ML_OnTick != null)
        {
            getResult(ML_OnTick, (Object)null, Float.valueOf(var0), minecraft);
        }
    }

    public static String pingTextHandle()
    {
        if (player != null && map != null)
        {
            String var0 = "";
            var0 = textModSun(var0);
            var0 = textModInfo(var0);
            var0 = textModCompassShared(var0);
            var0 = textModFly(var0);
            var0 = textModSafe(var0);
            var0 = textModCheat(var0);
            var0 = textModBuild(var0);
            var0 = textModRecipe(var0);
            var0 = textModCloud(var0);
            var0 = textModCart(var0);
            var0 = textModWeather(var0);
            var0 = textModInfoBiome(var0);
            return var0;
        }
        else
        {
            return "";
        }
    }

    public static String pingDebugHandle()
    {
        return "";
    }

    private static boolean initModItem()
    {
        log("info: loading config for \"item\" - deferred");
        optItemDump = getBool("optItemDump", false);

        if (optItemChangeFence = getBool("optItemChangeFence", true))
        {
            itemFenceO = getBlock(85);
            setBlock(85, (Block)null);
            itemFenceM = new ZBF();
            setBlock(85, itemFenceO);
        }

        if (optItemChangeGlass = getBool("optItemChangeGlass", true))
        {
            itemGlassO = getBlock(20);
            setBlock(20, (Block)null);
            itemGlassM = new ZBG();
            setBlock(20, itemGlassO);
            itemGlassPO = getBlock(102);
            setBlock(102, (Block)null);
            itemGlassPM = new ZBGP();
            setBlock(102, itemGlassPO);
        }

        if (optItemChangeIce = getBool("optItemChangeIce", true))
        {
            itemIceO = getBlock(79);
            setBlock(79, (Block)null);
            itemIceM = new ZBI();
            setBlock(79, itemIceO);
        }

        if (optItemChangeLeaves = getBool("optItemChangeLeaves", true))
        {
            itemLeavesO = getBlock(18);
            setBlock(18, (Block)null);
            itemLeavesM = new ZBL();
            setBlock(18, itemLeavesO);
        }

        if (optItemChangeSponge = getBool("optItemChangeSponge", false))
        {
            itemSpongeO = getBlock(19);
            setBlock(19, (Block)null);
            itemSpongeM = new ZBS();
            setBlock(19, itemSpongeO);
        }

        if (optItemChangeShelf = getBool("optItemChangeShelf", true))
        {
            itemShelfO = getBlock(47);
            setBlock(47, (Block)null);
            itemShelfM = new ZBB();
            setBlock(47, itemShelfO);
        }

        if (optItemChangeWater = getBool("optItemChangeWater", false))
        {
            itemWaterO = getBlock(8);
            setBlock(8, (Block)null);
            itemWaterM = new ZBW(true);
            setBlock(8, itemWaterO);
        }

        if (optItemChangeLava = getBool("optItemChangeLava", false))
        {
            itemLavaO = getBlock(10);
            setBlock(10, (Block)null);
            itemLavaM = new ZBW(false);
            setBlock(10, itemLavaO);
        }

        getDeprecated("optItemChangeStairs");
        optItemChangeSpawner = getBool("optItemChangeSpawner", true);
        getDeprecated("optItemChangeTorch");

        if (optItemChangeFarmland = getBool("optItemChangeFarmland", true))
        {
            itemFarmlandO = getBlock(60);
            setBlock(60, (Block)null);
            itemFarmlandM = new ZBFL();
            setBlock(60, itemFarmlandO);
        }

        if (optItemChangeLeaves)
        {
            optItemLeavesDrop = getInt("optItemLeavesDrop", 20, 1, 100);
            optItemOakChance = getInt("optItemOakChance", 3, 0, 100);
            optItemOakSpecial = getItemId("optItemOakSpecial", 260);
            optItemBirchChance = getInt("optItemBirchChance", 1, 0, 100);
            optItemBirchSpecial = getItemId("optItemBirchSpecial", 196959);
            optItemPineChance = getInt("optItemPineChance", 5, 0, 100);
            optItemPineSpecial = getItemId("optItemPineSpecial", 344);
        }

        return true;
    }

    private static void optionsModItem() {}

    private static void deferredModItem()
    {
        if (modItemEnabled)
        {
            int var0;

            if (itemOrig == null)
            {
                log("info: continuing to load \"item\"");
                itemOrig = new ZMod$Mark[Item.itemsList.length];
                itemMine = new ZMod$Mark[Item.itemsList.length];

                for (var0 = 0; var0 < itemOrig.length; ++var0)
                {
                    if (getItem(var0) != null)
                    {
                        itemOrig[var0] = ZMod$Mark.makeItem(var0);
                        itemMine[var0] = ZMod$Mark.makeItem(var0);
                    }
                }

                parse((List)null, "items.txt", 5);
            }

            if (optItemDump)
            {
                log("==== item dump ====\n");

                for (var0 = 0; var0 < Item.itemsList.length; ++var0)
                {
                    if (var0 == 0)
                    {
                        log("// blocks");
                    }
                    else if (var0 == 256)
                    {
                        log("\n// items");
                    }

                    if (var0 < 256)
                    {
                        Block var1 = getBlock(var0);

                        if (var1 != null)
                        {
                            log(String.format(Locale.ENGLISH, "%-14s %4d %2d %3d %5.1f %5.1f %4.1f %2d %3d", new Object[] {getNameForId(var0), Integer.valueOf(getItemMax(getItem(var0))), Integer.valueOf(getBlockLight(var0)), Integer.valueOf(getBlockOpacity(var0)), Float.valueOf(getBlockStrength(var1)), Float.valueOf(getBlockResist(var1)), Float.valueOf(getBlockSlip(var1)), Integer.valueOf(getFireSpread(var0)), Integer.valueOf(getFireBurn(var0))}));
                        }
                    }
                    else
                    {
                        Item var2 = getItem(var0);

                        if (var2 != null)
                        {
                            if (!getItemHasSubTypes(var2) && getItemDmgCap(var2) != 0)
                            {
                                log(String.format(Locale.ENGLISH, "%-14s %4d %2d", new Object[] {getNameForId(var0), Integer.valueOf(getItemMax(var2)), Integer.valueOf(getItemDmgCap(var2))}));
                            }
                            else
                            {
                                log(String.format(Locale.ENGLISH, "%-14s %4d", new Object[] {getNameForId(var0), Integer.valueOf(getItemMax(var2))}));
                            }
                        }
                    }
                }
            }
        }
    }

    private static void updateModItem()
    {
        if (modItemEnabled)
        {
            int var0;

            if (isMultiplayer && itemModified)
            {
                itemModified = false;

                for (var0 = 0; var0 < itemOrig.length; ++var0)
                {
                    if (itemOrig[var0] != null)
                    {
                        itemOrig[var0].activate(var0);
                    }
                }

                if (optItemChangeFence)
                {
                    setBlock(85, itemFenceO);
                }

                if (optItemChangeGlass)
                {
                    setBlock(20, itemGlassO);
                    setBlock(102, itemGlassPO);
                }

                if (optItemChangeIce)
                {
                    setBlock(79, itemIceO);
                }

                if (optItemChangeLeaves)
                {
                    setBlock(18, itemLeavesO);
                }

                if (optItemChangeTorch)
                {
                    setBlock(50, itemTorchO);
                }

                if (optItemChangeFarmland)
                {
                    setBlock(60, itemFarmlandO);
                }

                if (optItemChangeSponge)
                {
                    setBlock(19, itemSpongeO);
                }

                if (optItemChangeWater)
                {
                    setBlock(8, itemWaterO);
                }

                if (optItemChangeLava)
                {
                    setBlock(10, itemLavaO);
                }

                if (optItemChangeSpawner)
                {
                    setBlock(52, itemSpawnerO);
                }

                if (optItemChangeShelf)
                {
                    setBlock(47, itemShelfO);
                }
            }

            if (!isMultiplayer && !itemModified)
            {
                itemModified = true;

                for (var0 = 0; var0 < itemMine.length; ++var0)
                {
                    if (itemMine[var0] != null)
                    {
                        itemMine[var0].activate(var0);
                    }
                }

                if (optItemChangeFence)
                {
                    setBlock(85, itemFenceM);
                }

                if (optItemChangeGlass)
                {
                    setBlock(20, itemGlassM);
                    setBlock(102, itemGlassPM);
                }

                if (optItemChangeIce)
                {
                    setBlock(79, itemIceM);
                }

                if (optItemChangeLeaves)
                {
                    setBlock(18, itemLeavesM);
                }

                if (optItemChangeTorch)
                {
                    setBlock(50, itemTorchM);
                }

                if (optItemChangeFarmland)
                {
                    setBlock(60, itemFarmlandM);
                }

                if (optItemChangeSponge)
                {
                    setBlock(19, itemSpongeM);
                }

                if (optItemChangeWater)
                {
                    setBlock(8, itemWaterM);
                }

                if (optItemChangeLava)
                {
                    setBlock(10, itemLavaM);
                }

                if (optItemChangeSpawner)
                {
                    setBlock(52, itemSpawnerM);
                }

                if (optItemChangeShelf)
                {
                    setBlock(47, itemShelfM);
                }
            }
        }
    }

    private static void initModItemShared()
    {
        itemSpawnerO = getBlock(52);
        setBlock(52, (Block)null);
        itemSpawnerM = new ZBM();
        setBlock(52, itemSpawnerO);
    }

    public static String mobTypeHandle()
    {
        return recipesMobType != 0 ? typeName[recipesMobType] : null;
    }

    public static boolean spawnderDropHandle()
    {
        return !isMultiplayer && optItemChangeSpawner;
    }

    public static int leavesDropHandle()
    {
        return rnd.nextInt(optItemLeavesDrop) == 0 ? 1 : 0;
    }

    public static int leavesHandle(int var0)
    {
        int var1 = rnd.nextInt(100);
        return var0 == 0 && var1 < optItemOakChance ? optItemOakSpecial : (var0 == 1 && var1 < optItemPineChance ? optItemPineSpecial : (var0 == 2 && var1 < optItemBirchChance ? optItemBirchSpecial : 6 | var0 << 16));
    }

    public static void itemGraphicsLevelHandle(boolean var0)
    {
        if (optItemChangeLeaves)
        {
            setBlockGraphicsLevel(itemLeavesO, var0);
            setBlockGraphicsLevel(itemLeavesM, var0);
        }
    }

    private static boolean initModDeath()
    {
        log("info: loading config for \"death\"");
        optionsModDeath();
        return true;
    }

    private static void optionsModDeath()
    {
        optDeathDropInv = getSetBool(optDeathDropInv, "optDeathDropInv", false, "Drop inventory on death");
        optDeathLoseExp = getSetBool(optDeathLoseExp, "optDeathLoseExp", false, "Lose experience on death");
        optDeathHPPenalty = getSetInt(optDeathHPPenalty, "optDeathHPPenalty", 0, 0, 100, "Respawn HP penalty");
    }

    private static void onDeathModDeath()
    {
        if (modDeathEnabled && !isMultiplayer)
        {
            if (!optDeathDropInv)
            {
                deathHaveInv = true;
                InventoryPlayer var0 = player.inventory;
                deathInv = new ItemStack[var0.mainInventory.length];
                deathArmor = new ItemStack[var0.armorInventory.length];
                int var1;

                for (var1 = 0; var1 < deathInv.length; ++var1)
                {
                    deathInv[var1] = var0.mainInventory[var1];
                    var0.mainInventory[var1] = null;
                }

                for (var1 = 0; var1 < deathArmor.length; ++var1)
                {
                    deathArmor[var1] = var0.armorInventory[var1];
                    var0.armorInventory[var1] = null;
                }
            }

            if (!optDeathLoseExp)
            {
                deathHaveExp = true;
                deathXpTotal = player.experienceTotal;
                deathXpP = player.experience;
                deathXpLevel = player.experienceLevel;
            }
        }
    }

    private static void updateModDeath()
    {
        if (modDeathEnabled && !isMultiplayer)
        {
            if (!optDeathDropInv && deathHaveInv && getHealth(player) > 0)
            {
                deathHaveInv = false;
                InventoryPlayer var0 = player.inventory;
                int var1;

                for (var1 = 0; var1 < deathInv.length; ++var1)
                {
                    var0.mainInventory[var1] = var0.mainInventory[var1] == null ? deathInv[var1] : var0.mainInventory[var1];
                }

                for (var1 = 0; var1 < deathArmor.length; ++var1)
                {
                    var0.armorInventory[var1] = var0.armorInventory[var1] == null ? deathArmor[var1] : var0.armorInventory[var1];
                }
            }

            if (!optDeathLoseExp && deathHaveExp && getHealth(player) > 0)
            {
                deathHaveExp = false;

                if (player.experienceTotal == 0)
                {
                    player.experienceTotal = deathXpTotal;
                    player.experience = deathXpP;
                    player.experienceLevel = deathXpLevel;
                }
            }
        }
    }

    private static void respawnDeathMod()
    {
        EntityPlayerSP var0 = getPlayer();

        if (optDeathHPPenalty != 0)
        {
            int var1 = getHealth(var0) - optDeathHPPenalty;

            if (var1 < 1)
            {
                var1 = 1;
            }

            setHealth(var0, var1);
        }
    }

    private static boolean initModInfo()
    {
        log("info: loading config for \"info\"");
        optInfoTimeOffset = getInt("optInfoTimeOffset", 300, 0, 1199) * 20;
        optInfoPrefixNear = getString("optInfoPrefixNear", "\u00a7b");
        optInfoPrefixFar = getString("optInfoPrefixFar", "\u00a79");
        infoDeathY = 1024;
        optionsModInfo();
        return true;
    }

    private static void optionsModInfo()
    {
        keyInfoToggle = getSetBind(keyInfoToggle, "keyInfoToggle", 88, "Toggle info screen");
        optInfoShowPos = getSetBool(optInfoShowPos, "optInfoShowPos", true, "Show your coordinates");
        optInfoShowTime = getSetBool(optInfoShowTime, "optInfoShowTime", true, "Show time");
        optInfoShowBiome = getSetBool(optInfoShowBiome, "optInfoShowBiome", false, "Show biome name");
        optInfoShowItem = getSetBool(optInfoShowItem, "optInfoShowItem", true, "Show selected item information");
        optInfoShowHealth = getSetBool(optInfoShowHealth, "optInfoShowHealth", false, "Show critter health at all times");
        optInfoHideAchievement = getSetBool(optInfoHideAchievement, "optInfoHideAchievement", false, "Hide the obnoxious achievements");
        keyInfoPlayersToggle = getSetBind(keyInfoPlayersToggle, "keyInfoPlayersToggle", 62, "Toggle player list");
        optInfoRangeMax = getSetFloat(optInfoRangeMax, "optInfoRangeMax", 1000.0F, 10.0F, 1000.0F, "Player \'far\' range");
        optInfoRangeNear = getSetFloat(optInfoRangeNear, "optInfoRangeNear", 50.0F, 1.0F, 1000.0F, "Player \'near\' range");
        optInfoShowFPS = getSetBool(optInfoShowFPS, "optInfoShowFPS", false, "Show FPS counter on info bar");
    }

    private static void updateModInfo(List var0)
    {
        if (modInfoEnabled)
        {
            if (!isMenu && keyPress(keyInfoToggle))
            {
                infoShow = !infoShow;
            }

            if (!isMenu && keyPress(keyInfoPlayersToggle))
            {
                infoPlayerShow = !infoPlayerShow;
            }

            delMsg(2);
            String var1 = "";
            int var2 = fix(posX);
            int var3 = fix(posY);
            int var4 = fix(posZ);

            if (getHealth(player) <= 0)
            {
                infoDeathX = var2;
                infoDeathY = var3;
                infoDeathZ = var4;
            }

            int var5;
            int var6;
            int var7;
            int var8;

            if (!infoShow && infoPlayerShow && !isMenu)
            {
                String var9 = "";
                Iterator var10 = var0.iterator();

                while (var10.hasNext())
                {
                    Object var11 = var10.next();

                    if (var11 instanceof EntityPlayer && var11 != player)
                    {
                        EntityPlayer var12 = (EntityPlayer)var11;
                        var5 = fix(getEntityPosX(var12)) - var2;
                        var6 = fix(getEntityPosY(var12)) - var3;
                        var7 = fix(getEntityPosZ(var12)) - var4;
                        var8 = (int)Math.sqrt((double)(var5 * var5 + var6 * var6 + var7 * var7));

                        if ((float)var8 <= optInfoRangeMax)
                        {
                            String var13 = getAngleName((float)Math.atan2((double)var5, (double)var7) * -(180F / (float)Math.PI));
                            var9 = var9 + ((float)var8 < optInfoRangeNear ? optInfoPrefixNear : optInfoPrefixFar) + getEntityName(var12) + "\u00a7f (\u00a79" + var8 + "\u00a7fm \u00a79" + var13 + "\u00a7f)\n";
                        }
                    }
                }

                setMsg(5, var9);
            }
            else
            {
                delMsg(5);
            }

            if (infoShow && !isMenu)
            {
                int var35 = var2 >> 4;
                int var36 = var4 >> 4;
                long var14 = getTime();
                long var16 = var14;

                if (modSunEnabled && sunTimeOffset != 0L)
                {
                    var14 += sunTimeOffset;
                }

                var1 = var1 + "Your position:   \u00a79" + var2 + "\u00a7f , \u00a79" + var3 + "\u00a7f , \u00a79" + var4 + "\u00a7f    Fog: \u00a79" + getViewDistance() + "\u00a7f    Exp-orbs: \u00a79" + player.experienceTotal;

                if (var3 >= 0)
                {
                    var1 = var1 + "\n  Light level:   \u00a79" + getLightLevel(var2, var3, var4) + "\u00a7f   (   min: \u00a78" + getLightLevel(var2, var3, var4, 16) + "\u00a7f   max: \u00a7e" + getLightLevel(var2, var3, var4, 0) + "\u00a7f   )";
                }

                var1 = var1 + "\n  Biome:   \u00a79" + getBiomeName(var2, var4);
                Random var20 = new Random(getSeed() + (long)(var35 * var35 * 4987142) + (long)(var35 * 5947611) + (long)(var36 * var36) * 4392871L + (long)(var36 * 389711) ^ 987234911L);
                var1 = var1 + "\n  Slime spawns:   \u00a79" + (var20.nextInt(10) == 0 ? "yes " : "no  ") + "\u00a7f  chunk: \u00a79" + var35 + "\u00a7f , \u00a79" + var36;
                ChunkPosition var21 = map.findClosestStructure("Stronghold", var2, var3, var4);
                StringBuilder var10000;

                if (var21 != null)
                {
                    var10000 = (new StringBuilder()).append(var1).append("\n  Stronghold:    \u00a79");
                    var5 = var21.x;
                    var10000 = var10000.append(var21.x).append("\u00a7f , \u00a79").append(var21.y).append("\u00a7f , \u00a79");
                    var7 = var21.z;
                    var1 = var10000.append(var21.z).toString();
                    var5 -= var2;
                    var7 -= var4;
                    var1 = var1 + "\u00a7f (\u00a79" + (int)Math.sqrt((double)(var5 * var5 + var7 * var7)) + "\u00a7fm)";
                }

                var1 = var1 + "\nCompasspoint:   \u00a79" + (var5 = world.getSpawnX()) + "\u00a7f , \u00a79" + world.getSpawnY() + "\u00a7f , \u00a79" + (var7 = world.getSpawnZ());
                var5 -= var2;
                var7 -= var4;
                var1 = var1 + "\u00a7f (\u00a79" + (int)Math.sqrt((double)(var5 * var5 + var7 * var7)) + "\u00a7fm)";

                if (modCompassEnabled && compassHaveMine)
                {
                    if (compassShowOrig)
                    {
                        var10000 = (new StringBuilder()).append(var1).append("\n  Alt: \u00a79");
                        var5 = compassMX;
                        var10000 = var10000.append(compassMX).append("\u00a7f , \u00a79");
                        var6 = compassMY;
                        var10000 = var10000.append(compassMY).append("\u00a7f , \u00a79");
                        var7 = compassMZ;
                        var1 = var10000.append(compassMZ).toString();
                    }
                    else
                    {
                        var10000 = (new StringBuilder()).append(var1).append("\n  Orig: \u00a79");
                        var5 = compassOX;
                        var10000 = var10000.append(compassOX).append("\u00a7f , \u00a79");
                        var6 = compassOY;
                        var10000 = var10000.append(compassOY).append("\u00a7f , \u00a79");
                        var7 = compassOZ;
                        var1 = var10000.append(compassOZ).toString();
                    }

                    var5 -= var2;
                    var7 -= var4;
                    var1 = var1 + "\u00a7f (\u00a79" + (int)Math.sqrt((double)(var5 * var5 + var7 * var7)) + "\u00a7fm)";
                }

                ChunkCoordinates var19 = getSpawn(player);

                if (var19 != null)
                {
                    var1 = var1 + "\nSpawnpoint:   \u00a79" + (var5 = getX(var19)) + "\u00a7f , \u00a79" + getY(var19) + "\u00a7f , \u00a79" + (var7 = getZ(var19));
                    var5 -= var2;
                    var7 -= var4;
                    var1 = var1 + "\u00a7f (\u00a79" + (int)Math.sqrt((double)(var5 * var5 + var7 * var7)) + "\u00a7fm)";

                    if (isMultiplayer && getBed(player) == null)
                    {
                        var1 = var1 + "  \u00a74Bed-override?";
                    }
                }

                var19 = getBed(player);

                if (var19 != null)
                {
                    var1 = var1 + "\nYour bed:   \u00a79" + (var5 = getX(var19)) + "\u00a7f , \u00a79" + getY(var19) + "\u00a7f , \u00a79" + (var7 = getZ(var19));
                    var5 -= var2;
                    var7 -= var4;
                    var1 = var1 + "\u00a7f (\u00a79" + (int)Math.sqrt((double)(var5 * var5 + var7 * var7)) + "\u00a7fm)";
                }

                if (infoDeathY != 1024)
                {
                    var10000 = (new StringBuilder()).append(var1).append("\nYou died:   \u00a79");
                    var5 = infoDeathX;
                    var10000 = var10000.append(infoDeathX).append("\u00a7f , \u00a79");
                    var6 = infoDeathY;
                    var10000 = var10000.append(infoDeathY).append("\u00a7f , \u00a79");
                    var7 = infoDeathZ;
                    var1 = var10000.append(infoDeathZ).toString();
                    var5 -= var2;
                    var7 -= var4;
                    var1 = var1 + "\u00a7f (\u00a79" + (int)Math.sqrt((double)(var5 * var5 + var7 * var7)) + "\u00a7fm)";
                }

                if (!isMultiplayer)
                {
                    var1 = var1 + "\nWorld Name:   \u00a79" + getName();
                }

                var1 = var1 + "\nWorld Seed:   \u00a79" + getSeed();
                var1 = var1 + "\nWorld Age (real time):   \u00a79" + getRealTime(var14);
                var1 = var1 + "\nTime:   \u00a79" + getTime(var14);

                if (var14 != var16)
                {
                    var1 = var1 + "\u00a7f   (actual time: \u00a79" + getTime(var16) + "\u00a7f )";
                }

                if (!isMultiplayer)
                {
                    var1 = var1 + "\nRain:   \u00a79" + (getRain() ? "raining" : "not raining");

                    if ((!modWeatherEnabled || !optWeatherLocked) && !isHell)
                    {
                        var1 = var1 + "\u00a7f the next \u00a79" + getRainTime() / 20 + "\u00a7f seconds";
                    }

                    var1 = var1 + "\nThunder:   \u00a79" + (getThunder() ? "thundering" : "not thundering");

                    if ((!modWeatherEnabled || !optWeatherLocked) && !isHell)
                    {
                        var1 = var1 + "\u00a7f the next \u00a79" + getThunderTime() / 20 + "\u00a7f seconds";
                    }
                }

                ItemStack var22 = invItemsArr[getInvCur()];
                int var26;
                int var33;

                if (optInfoShowItem && var22 != null)
                {
                    var8 = getItemsId(var22);
                    int var32 = getItemsInfo(var22);
                    var33 = getItemsCount(var22);
                    Item var23 = getItem(var8);
                    var1 = var1 + "\nSelected item:   \u00a79" + getItemName(var23) + "\u00a7f  id: \u00a79" + var8 + (getItemHasSubTypes(var23) ? "\u00a7f/\u00a79" + var32 : "") + "\u00a7f  stack: \u00a79" + var33 + "\u00a7f/\u00a79" + getItemMax(var23);
                    int var34;

                    if ((var34 = getItemDmgCap(var23)) != 0)
                    {
                        var1 = var1 + "\u00a7f  damage: \u00a79" + var32 + "\u00a7f/\u00a79" + var34;
                    }

                    var1 = var1 + "\u00a7f  type: \u00a79" + (var8 < 256 ? "Block" : "Item");

                    if (var8 < 256)
                    {
                        Block var24 = getBlock(var8);
                        var1 = var1 + "\n  Properties:   strength = \u00a79" + getBlockStrength(var24) + "\u00a7f  resistance = \u00a79" + getBlockResist(var24) + "\u00a7f  slipperiness = \u00a79" + getBlockSlip(var24);
                        var1 = var1 + "\n  Light:   emission = \u00a79" + getBlockLight(var8) + "\u00a7f  reduction = \u00a79" + (getBlockIsOpaque(var8) ? "opaque" : Integer.valueOf(getBlockOpacity(var8)));
                        var1 = var1 + "\n  Fire:   spread = \u00a79" + getFireSpread(var8) + "\u00a7f  burn = \u00a79" + getFireBurn(var8);
                        Material var25 = getBlockMaterial(var24);
                        var1 = var1 + "\n  Mater\u00a7fial:   \u00a79";
                        var26 = 0;

                        if (getIsSolid(var25))
                        {
                            var1 = var1 + " solid";
                            ++var26;
                        }

                        if (getIsBurnable(var25))
                        {
                            var1 = var1 + " burnable";
                            ++var26;
                        }

                        if (getIsReplaceable(var25))
                        {
                            var1 = var1 + " replaceable";
                            ++var26;
                        }

                        if (getIsLiquid(var25))
                        {
                            var1 = var1 + " liquid";
                            ++var26;
                        }

                        if (getIsCover(var25))
                        {
                            var1 = var1 + " cover";
                            ++var26;
                        }

                        if (var26 == 0)
                        {
                            var1 = var1 + "-";
                        }
                    }
                }

                if (isMultiplayer)
                {
                    int var37 = getScrWidthS();
                    var33 = 0;
                    var26 = 0;
                    String var27 = "";
                    int var39 = showTextLength("Players nearby (00):  ");
                    Iterator var29 = var0.iterator();

                    while (var29.hasNext())
                    {
                        Object var30 = var29.next();

                        if (var30 instanceof EntityPlayer && var30 != player)
                        {
                            EntityPlayer var31 = (EntityPlayer)var30;
                            var27 = var27 + (var33 == 0 ? " \u00a79" : ", \u00a79");
                            var39 += showTextLength(var33 == 0 ? " \u00a79" : ", \u00a79");
                            String var28 = getPlayerName(var31);
                            var5 = fix(getEntityPosX(var31)) - var2;
                            var6 = fix(getEntityPosY(var31)) - var3;
                            var7 = fix(getEntityPosZ(var31)) - var4;
                            var28 = var28 + "\u00a7f (\u00a79" + (int)Math.sqrt((double)(var5 * var5 + var6 * var6 + var7 * var7)) + "\u00a7fm)";
                            int var38 = showTextLength(var28);
                            ++var26;

                            if (var37 >= var39 + var38 && var26 <= 4)
                            {
                                var27 = var27 + var28;
                                var39 += var38;
                            }
                            else
                            {
                                var26 = 0;
                                var27 = var27 + "\n   \u00a79" + var28;
                                var39 = var38 + showTextLength("   ");
                            }

                            ++var33;
                        }
                    }

                    if (var33 == 0)
                    {
                        var27 = var27 + "\u00a74none";
                    }

                    var1 = var1 + "\nPlayers nearby (\u00a79" + var33 + "\u00a7f):  " + var27;
                }

                setMsg(2, var1);
            }
        }
    }

    private static void respawnInfoMod()
    {
        infoDeathX = fix(posX);
        infoDeathY = fix(posY);
        infoDeathZ = fix(posZ);
    }

    private static void drawGuiModInfo()
    {
        if (modInfoEnabled && optInfoHideAchievement)
        {
            killAchievement();
        }
    }

    private static String textModInfo(String var0)
    {
        if (optInfoShowFPS)
        {
            long var1 = System.currentTimeMillis();
            ++infoFrames;

            if (var1 > infoTime + 1000L)
            {
                infoFps = "" + infoFrames + "FPS ";
                infoTime = var1;
                infoFrames = 0;
            }

            var0 = var0 + infoFps;
        }

        return modInfoEnabled && optInfoShowTime ? var0 + "[" + getTime(getTime() + sunTimeOffset) + "] " : var0;
    }

    private static String textModInfoBiome(String var0)
    {
        return modInfoEnabled && optInfoShowBiome ? var0 + getBiomeName(fix(posX), fix(posZ)) + " " : var0;
    }

    private static boolean initModIcon()
    {
        log("info: loading config for \"icon\"");
        optIconMP = getBool("optIconMP", false);
        iconMPSupport = false;
        optionsModIcon();
        return true;
    }

    private static void optionsModIcon()
    {
        optIconShowChest = getSetBool(optIconShowChest, "optIconShowChest", true, "Show chest contents (first item)");
        optIconShowDispenser = getSetBool(optIconShowDispenser, "optIconShowDispenser", true, "Show dispenser contents (first item)");
        optIconShowFurnace = getSetBool(optIconShowFurnace, "optIconShowFurnace", true, "Show furnace contents");
    }

    public static void drawModIcon(float var0, float var1, float var2)
    {
        if ((!isMultiplayer || iconMPSupport) && modIconEnabled)
        {
            int var3 = fix(posX);
            int var4 = fix(posY);
            int var5 = fix(posZ);
            byte var6 = 16;
            textureBlock = getTexture("/terrain.png");
            textureItems = getTexture("/gui/items.png");
            texture = -1;
            GL11.glBegin(GL11.GL_QUADS);

            for (int var8 = -var6; var8 <= var6; ++var8)
            {
                for (int var9 = -var6; var9 <= var6; ++var9)
                {
                    for (int var10 = -var6; var10 <= var6; ++var10)
                    {
                        int var7;

                        if ((block[var7 = mapXGetId(var3 + var8, var4 + var9, var5 + var10)] & 262144) != 0)
                        {
                            int var11 = -1;
                            int var14 = var3 + var8;
                            int var15 = var4 + var9;
                            int var16 = var5 + var10;
                            TileEntity var17 = getTileEntity(var14, var15, var16);

                            if (var17 != null)
                            {
                                int var13;
                                float var19;
                                float var18;
                                float var21;
                                float var20;
                                ItemStack[] var23;
                                float var22;

                                if (var7 == 54)
                                {
                                    if (optIconShowChest)
                                    {
                                        var23 = getChestItems(var17);

                                        for (var13 = 0; var13 < 27; ++var13)
                                        {
                                            if (var23[var13] != null)
                                            {
                                                var11 = bindAndGetIcon(var23[var13]);
                                                break;
                                            }
                                        }

                                        if (var11 >= 0)
                                        {
                                            var18 = 0.5F + (float)var14 - var0;
                                            var19 = 0.5F + (float)var15 - var1;
                                            var20 = 0.5F + (float)var16 - var2;
                                            var21 = 0.0625F * (float)(var11 % 16);
                                            var22 = 0.0625F * (float)(var11 / 16);

                                            if ((block[mapXGetId(var14 - 1, var15, var16)] & 32) != 0)
                                            {
                                                chestDrawIcon(4, getLight(var14 - 1, var15, var16), var21, var22, var18, var19, var20, -0.4F, -0.1F, -0.4F, -0.1F, -0.0625F);
                                            }

                                            if ((block[mapXGetId(var14 + 1, var15, var16)] & 32) != 0)
                                            {
                                                chestDrawIcon(5, getLight(var14 + 1, var15, var16), var21, var22, var18, var19, var20, -0.4F, -0.1F, -0.4F, -0.1F, -0.0625F);
                                            }

                                            if ((block[mapXGetId(var14, var15, var16 - 1)] & 32) != 0)
                                            {
                                                chestDrawIcon(2, getLight(var14, var15, var16 - 1), var21, var22, var18, var19, var20, -0.4F, -0.1F, -0.4F, -0.1F, -0.0625F);
                                            }

                                            if ((block[mapXGetId(var14, var15, var16 + 1)] & 32) != 0)
                                            {
                                                chestDrawIcon(3, getLight(var14, var15, var16 + 1), var21, var22, var18, var19, var20, -0.4F, -0.1F, -0.4F, -0.1F, -0.0625F);
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    int var12;

                                    if (var7 != 23)
                                    {
                                        if (optIconShowFurnace)
                                        {
                                            var23 = getFurnaceItems(var17);
                                            var18 = 0.5F + (float)var14 - var0;
                                            var19 = 0.5F + (float)var15 - var1;
                                            var20 = 0.5F + (float)var16 - var2;
                                            var12 = mapXGetMeta(var14, var15, var16);

                                            if (var12 < 4)
                                            {
                                                var16 += var12 == 2 ? -1 : 1;
                                            }
                                            else
                                            {
                                                var14 += var12 == 4 ? -1 : 1;
                                            }

                                            if ((block[mapXGetId(var14, var15, var16)] & 32) != 0)
                                            {
                                                float var24 = getLight(var14, var15, var16);

                                                if (var23[0] != null)
                                                {
                                                    var11 = bindAndGetIcon(var23[0]);
                                                    var21 = 0.0625F * (float)(var11 % 16);
                                                    var22 = 0.0625F * (float)(var11 / 16);
                                                    chestDrawIcon(var12, var24, var21, var22, var18, var19, var20, -0.4F, -0.2F, 0.2F, 0.4F, 0.0F);
                                                }

                                                if (var23[1] != null)
                                                {
                                                    var11 = bindAndGetIcon(var23[1]);
                                                    var21 = 0.0625F * (float)(var11 % 16);
                                                    var22 = 0.0625F * (float)(var11 / 16);
                                                    chestDrawIcon(var12, var24, var21, var22, var18, var19, var20, -0.1F, 0.1F, -0.4F, -0.2F, 0.0F);
                                                }

                                                if (var23[2] != null)
                                                {
                                                    var11 = bindAndGetIcon(var23[2]);
                                                    var21 = 0.0625F * (float)(var11 % 16);
                                                    var22 = 0.0625F * (float)(var11 / 16);
                                                    chestDrawIcon(var12, var24, var21, var22, var18, var19, var20, 0.2F, 0.4F, 0.2F, 0.4F, 0.0F);
                                                }
                                            }
                                        }
                                    }
                                    else if (optIconShowDispenser)
                                    {
                                        var23 = getDispItems(var17);

                                        for (var13 = 0; var13 < 9; ++var13)
                                        {
                                            if (var23[var13] != null)
                                            {
                                                var11 = bindAndGetIcon(var23[var13]);
                                                break;
                                            }
                                        }

                                        if (var11 >= 0)
                                        {
                                            var18 = 0.5F + (float)var14 - var0;
                                            var19 = 0.5F + (float)var15 - var1;
                                            var20 = 0.5F + (float)var16 - var2;
                                            var21 = 0.0625F * (float)(var11 % 16);
                                            var22 = 0.0625F * (float)(var11 / 16);
                                            var12 = mapXGetMeta(var14, var15, var16);

                                            if (var12 < 4)
                                            {
                                                var16 += var12 == 2 ? -1 : 1;
                                            }
                                            else
                                            {
                                                var14 += var12 == 4 ? -1 : 1;
                                            }

                                            if ((block[mapXGetId(var14, var15, var16)] & 32) != 0)
                                            {
                                                chestDrawIcon(var12, getLight(var14, var15, var16), var21, var22, var18, var19, var20, -0.1F, 0.1F, -0.1F, 0.1F, 0.0F);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            GL11.glEnd();
        }
    }

    public static void packet250Handle(ZP250 var0)
    {
        iconMPSupport = true;
        loadTileEntityFromNBT(var0);
    }

    private static void chestDrawIcon(int var0, float var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10, float var11)
    {
        var11 += 0.52F;
        GL11.glColor3f(var1, var1, var1);
        float var12 = var2 + 0.0625F;
        float var13 = var3 + 0.0625F;

        if (var0 == 4)
        {
            GL11.glTexCoord2f(var12, var13);
            GL11.glVertex3f(var4 - var11, var5 + var9, var6 + var8);
            GL11.glTexCoord2f(var12, var3);
            GL11.glVertex3f(var4 - var11, var5 + var10, var6 + var8);
            GL11.glTexCoord2f(var2, var3);
            GL11.glVertex3f(var4 - var11, var5 + var10, var6 + var7);
            GL11.glTexCoord2f(var2, var13);
            GL11.glVertex3f(var4 - var11, var5 + var9, var6 + var7);
        }
        else if (var0 == 5)
        {
            GL11.glTexCoord2f(var12, var13);
            GL11.glVertex3f(var4 + var11, var5 + var9, var6 - var8);
            GL11.glTexCoord2f(var12, var3);
            GL11.glVertex3f(var4 + var11, var5 + var10, var6 - var8);
            GL11.glTexCoord2f(var2, var3);
            GL11.glVertex3f(var4 + var11, var5 + var10, var6 - var7);
            GL11.glTexCoord2f(var2, var13);
            GL11.glVertex3f(var4 + var11, var5 + var9, var6 - var7);
        }
        else if (var0 == 2)
        {
            GL11.glTexCoord2f(var12, var13);
            GL11.glVertex3f(var4 - var8, var5 + var9, var6 - var11);
            GL11.glTexCoord2f(var12, var3);
            GL11.glVertex3f(var4 - var8, var5 + var10, var6 - var11);
            GL11.glTexCoord2f(var2, var3);
            GL11.glVertex3f(var4 - var7, var5 + var10, var6 - var11);
            GL11.glTexCoord2f(var2, var13);
            GL11.glVertex3f(var4 - var7, var5 + var9, var6 - var11);
        }
        else if (var0 == 3)
        {
            GL11.glTexCoord2f(var12, var13);
            GL11.glVertex3f(var4 + var8, var5 + var9, var6 + var11);
            GL11.glTexCoord2f(var12, var3);
            GL11.glVertex3f(var4 + var8, var5 + var10, var6 + var11);
            GL11.glTexCoord2f(var2, var3);
            GL11.glVertex3f(var4 + var7, var5 + var10, var6 + var11);
            GL11.glTexCoord2f(var2, var13);
            GL11.glVertex3f(var4 + var7, var5 + var9, var6 + var11);
        }
    }

    private static int bindAndGetIcon(ItemStack var0)
    {
        int var1 = getItemsId(var0);

        if (getItem(var1) == null)
        {
            return -1;
        }
        else
        {
            if (var1 == 35)
            {
                setItemsInfo(var0, 15 - getItemsInfo(var0));
            }

            int var2 = var1 < 256 ? textureBlock : textureItems;
            int var3 = getItemsIcon(var0);

            if (var1 == 35)
            {
                setItemsInfo(var0, 15 - getItemsInfo(var0));
            }

            if (var2 == texture)
            {
                return var3;
            }
            else
            {
                GL11.glEnd();
                texture = var2;
                GL11.glBindTexture(GL11.GL_TEXTURE_2D, var2);
                GL11.glBegin(GL11.GL_QUADS);
                return var3;
            }
        }
    }

    private static boolean initModChest()
    {
        log("info: loading config for \"chest\"");
        optChestStoreBlock = getBlockId("optChestStoreBlock", 58);
        optionsModChest();
        return true;
    }

    private static void optionsModChest()
    {
        optChestStore = getSetBool(optChestStore, "optChestStore", true, "Autostore items on top of chests");
        optChestStoreRadius = getSetInt(optChestStoreRadius, "optChestStoreRadius", 2, 0, 8, "Search radius for \'store\' block");
    }

    private static void updateModChest(List var0)
    {
        if (modChestEnabled && !isMultiplayer && (optChestStore || optChestStoreRadius > 0))
        {
            Iterator var1 = var0.iterator();

            while (var1.hasNext())
            {
                Object var2 = var1.next();

                if (var2 instanceof EntityItem)
                {
                    EntityItem var3 = (EntityItem)var2;

                    if (getEntityAge(var3) >= 0)
                    {
                        TileEntityChest var4 = null;
                        ItemStack[] var5 = null;
                        ItemStack var6 = getEntityItemStack(var3);
                        int var7 = getItemsId(var6);
                        int var8 = getItemsInfo(var6);
                        int var10 = fix(getEntityPosX(var3));
                        int var11 = fix(getEntityPosY(var3)) - 1;
                        int var12 = fix(getEntityPosZ(var3));
                        int var13 = mapXGetId(var10, var11, var12);
                        int var14 = 0;
                        byte var15 = 0;
                        int var16 = 0;
                        int var17 = getItemMax(getItem(var7));
                        boolean var18 = true;
                        int var20 = -1;

                        if (var13 == optChestStoreBlock && optChestStoreRadius > 0)
                        {
                            var20 = optChestStoreRadius;
                        }
                        else if (optChestStore && var13 == 54)
                        {
                            var20 = 0;
                        }

                        if (var20 >= 0)
                        {
                            int var9;
                            label116:

                            for (int var21 = -var20; var21 <= var20; ++var21)
                            {
                                for (int var22 = -var20; var22 <= var20; ++var22)
                                {
                                    for (int var23 = -var20; var23 <= var20; ++var23)
                                    {
                                        if (mapXGetId(var10 + var21, var11 + var22, var12 + var23) == 54)
                                        {
                                            TileEntityChest var24 = (TileEntityChest)getTileEntity(var10 + var21, var11 + var22, var12 + var23);
                                            ItemStack[] var25 = getChestItems(var24);
                                            int var28 = -1;
                                            boolean var19 = false;

                                            for (int var26 = 0; var26 < 27; ++var26)
                                            {
                                                if (var25[var26] == null)
                                                {
                                                    if (var28 == -1)
                                                    {
                                                        var28 = var26;
                                                    }

                                                    if (var15 < 2 && var19)
                                                    {
                                                        var5 = var25;
                                                        var4 = var24;
                                                        var14 = var26;
                                                        var15 = 2;
                                                        var16 = var17;
                                                    }
                                                    else if (var15 == 0)
                                                    {
                                                        var5 = var25;
                                                        var4 = var24;
                                                        var14 = var26;
                                                        var15 = 1;
                                                        var16 = var17;
                                                    }
                                                }
                                                else if (getItemsId(var25[var26]) == var7 && getItemsInfo(var25[var26]) == var8)
                                                {
                                                    var19 = true;

                                                    if (var28 != -1 && var15 == 1)
                                                    {
                                                        var5 = var25;
                                                        var4 = var24;
                                                        var14 = var28;
                                                        var15 = 2;
                                                        var16 = var17;
                                                    }

                                                    if ((var9 = getItemsCount(var25[var26])) < var17)
                                                    {
                                                        var5 = var25;
                                                        var4 = var24;
                                                        var14 = var26;
                                                        boolean var27 = true;
                                                        var16 = var17 - var9;
                                                        break label116;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            if (var4 != null)
                            {
                                var9 = getItemsCount(var6);

                                if (var5[var14] == null)
                                {
                                    var5[var14] = newItems(var7, var9 > var16 ? var16 : var9, var8);
                                }
                                else if (var9 > var16)
                                {
                                    setItemsCount(var5[var14], var17);
                                }
                                else
                                {
                                    setItemsCount(var5[var14], getItemsCount(var5[var14]) + var9);
                                }

                                var9 -= var16;

                                if (var9 <= 0)
                                {
                                    dieEntity(var3);
                                }

                                setChanged(var4);

                                if (var9 > 0)
                                {
                                    setItemsCount(var6, var9);
                                    continue;
                                }
                            }

                            setEntityAge(var3, -100);
                        }
                    }
                }
            }
        }
    }

    private static boolean initModCloud()
    {
        log("info: loading config for \"cloud\"");
        tagCloudVanilla = getString("tagCloudVanilla", "no-cloud-mod");
        optionsModCloud();
        return true;
    }

    private static void optionsModCloud()
    {
        keyCloudToggle = getSetBind(keyCloudToggle, "keyCloudToggle", 55, "Toggle clouds");
        optCloudShow = getSetBool(optCloudShow, "optCloudShow", true, "Show clouds by default");
        keyCloudVanilla = getSetBind(keyCloudVanilla, "keyCloudVanilla", 47, "Toggle vanilla clouds");
        keyCloudUp = getSetBind(keyCloudUp, "keyCloudUp", 0, "Move clouds up");
        keyCloudDown = getSetBind(keyCloudDown, "keyCloudDown", 0, "Move clouds down");
        optCloudOffset = getSetFloat(optCloudOffset, "optCloudOffset", 4.0F, -60.0F, 140.0F, "Cloud offset");
    }

    private static void updateModCloud()
    {
        if (modCloudEnabled && !isMenu)
        {
            if (keyPress(keyCloudVanilla))
            {
                optCloudVanilla = !optCloudVanilla;
            }

            if (keyPress(keyCloudToggle))
            {
                if (optCloudVanilla)
                {
                    optCloudVanilla = false;
                }
                else
                {
                    optCloudShow = !optCloudShow;
                }
            }

            if (keyPress(keyCloudUp))
            {
                if (optCloudVanilla)
                {
                    optCloudVanilla = false;
                }
                else
                {
                    ++optCloudOffset;
                }
            }

            if (keyPress(keyCloudDown))
            {
                if (optCloudVanilla)
                {
                    optCloudVanilla = false;
                }
                else
                {
                    --optCloudOffset;
                }
            }
        }
    }

    public static void drawModCloud(float var0)
    {
        if (modCloudEnabled && !optCloudVanilla)
        {
            if (optCloudShow)
            {
                double var1 = getEntityPrevPosY(player);
                setEntityPrevPosY(player, var1 + (getEntityPosY(player) - var1) * (double)var0 - (double)optCloudOffset);
                render.callSuper(0.0F);
                setEntityPrevPosY(player, var1);
            }
        }
        else
        {
            render.callSuper(var0);
        }
    }

    private static String textModCloud(String var0)
    {
        return modCloudEnabled && optCloudVanilla && tagCloudVanilla.length() != 0 ? var0 + tagCloudVanilla + " " : var0;
    }

    private static boolean initModCart()
    {
        log("info: loading config for \"cart\"");
        tagCartPerpetual = getString("tagCartPerpetual", "perpetual");
        optionsModCart();
        return true;
    }

    private static void optionsModCart()
    {
        keyCartStop = getSetBind(keyCartStop, "keyCartStop", 28, "Stop the minecart instantly");
        keyCartPerpetual = getSetBind(keyCartPerpetual, "keyCartPerpetual", 200, "Toggle perpetual motion mode");
        optCartSpeedAccumCap = getSetFloat(optCartSpeedAccumCap, "optCartSpeedAccumCap", 1.0F, 0.5F, 5.0F, "Speed accumulation cap");
        optCartAcceleration = getSetFloat(optCartAcceleration, "optCartAcceleration", 2.0F, 0.5F, 10.0F, "Acceleration");
        optCartInfiniteFuel = getSetBool(optCartInfiniteFuel, "optCartInfiniteFuel", true, "Infinite fuel for powered minecart");
    }

    private static void updateModCart(List var0)
    {
        if (!isMultiplayer && modCartEnabled && inWhat instanceof EntityMinecart)
        {
            double var1 = getEntityMotionX(inWhat) + motionX * (double)optCartAcceleration;
            double var3 = getEntityMotionZ(inWhat) + motionZ * (double)optCartAcceleration;
            double var5 = Math.sqrt(var1 * var1 + var3 * var3);

            if (!isMenu && keyPress(keyCartPerpetual))
            {
                optCartPerpetual = !optCartPerpetual;

                if (optCartPerpetual)
                {
                    cartSpeed = var5;
                }
            }

            if (var5 > (double)optCartSpeedAccumCap || optCartPerpetual && var5 > 0.001D)
            {
                double var7 = optCartPerpetual ? cartSpeed / var5 : (double)optCartSpeedAccumCap / var5;
                var3 *= var7;
                var3 *= var7;
            }

            if (!isMenu && keyDown(keyCartStop))
            {
                var3 = 0.0D;
                var1 = 0.0D;
                optCartPerpetual = false;
            }

            setEntityMotionX(inWhat, var1);
            setEntityMotionZ(inWhat, var3);

            if (optCartInfiniteFuel)
            {
                Iterator var9 = var0.iterator();

                while (var9.hasNext())
                {
                    Object var10 = var9.next();

                    if (var10 instanceof EntityMinecart)
                    {
                        EntityMinecart var11 = (EntityMinecart)var10;

                        if (getCartType(var11) == 2 && getCartFuel(var11) > 0)
                        {
                            setCartFuel(var11, 1200);
                        }
                    }
                }
            }
        }
    }

    private static String textModCart(String var0)
    {
        return !isMultiplayer && modCartEnabled && optCartPerpetual && tagCartPerpetual.length() != 0 ? var0 + tagCartPerpetual + " " : var0;
    }

    private static boolean initModWield()
    {
        log("info: loading config for \"wield\"");
        tagWieldAmmo = getString("tagWieldAmmo", "Arrows :") + " ";
        optionsModWield();
        return true;
    }

    private static void optionsModWield()
    {
        keyWield = getSetBind(keyWield, "keyWield", 19, "Wield key");
        optWieldBowFirst = getSetBool(optWieldBowFirst, "optWieldBowFirst", true, "Wield bow first");
        optWieldShowAmmo = getSetBool(optWieldShowAmmo, "optWieldShowAmmo", true, "Show arrow count");
    }

    private static void updateModWield()
    {
        if (modWieldEnabled)
        {
            int var0 = -1;
            int var1 = -1;
            int var2 = getInvCur();
            int var3 = 0;
            boolean var4 = false;
            int var5;

            for (var5 = 0; var5 < invItemsArr.length; ++var5)
            {
                int var6 = invItemsArr[var5] == null ? 0 : getItemsId(invItemsArr[var5]);

                if (var6 == 262)
                {
                    var3 += getItemsCount(invItemsArr[var5]);
                }

                if (var5 < 9)
                {
                    if (var6 == 261)
                    {
                        var0 = var5;
                        var4 = true;
                    }
                    else if (var6 == 268 || var6 == 272 || var6 == 267 || var6 == 276 || var6 == 283)
                    {
                        var1 = var5;
                    }
                }
            }

            if (var3 == 0)
            {
                var0 = -1;
            }

            if (var0 == -1)
            {
                var0 = var1;
            }
            else if (var1 == -1)
            {
                var1 = var0;
            }

            var5 = optWieldBowFirst ? var0 : var1;

            if (var2 == var5)
            {
                var5 = var5 == var0 ? var1 : var0;
            }

            if (!isMenu && keyPress(keyWield) && var5 != -1)
            {
                setInvCur(var5);
            }

            if (optWieldShowAmmo && var4)
            {
                setMsg(1, tagWieldAmmo + var3, var3 > 8 ? (var3 > 32 ? (var3 > 64 ? 12320699 : 2284834) : 15658513) : 14496563);
            }
        }
    }

    private static boolean initModBuild()
    {
        log("info: loading config for \"build\"");
        optionsModBuild();

        if (!optBuildExtension)
        {
            log("info: build extension is disabled");
        }

        tagBuildEnabled = getString("tagBuildEnabled", "builder");
        String[] var0 = new String[] {getString("optBuildA1", ""), getString("optBuildA2", ""), getString("optBuildA3", ""), getString("optBuildA4", ""), getString("optBuildA5", ""), getString("optBuildA6", ""), getString("optBuildA7", ""), getString("optBuildA8", ""), getString("optBuildA9", ""), getString("optBuildB1", ""), getString("optBuildB2", ""), getString("optBuildB3", ""), getString("optBuildB4", ""), getString("optBuildB5", ""), getString("optBuildB6", ""), getString("optBuildB7", ""), getString("optBuildB8", ""), getString("optBuildB9", "")};
        buildSets = new int[var0.length][9];

        for (int var1 = 0; var1 < var0.length; ++var1)
        {
            if (!var0[var1].equals(""))
            {
                String[] var2 = var0[var1].split("[\\t ]*,[\\t ]*");
                int var3 = var2.length;

                if (var3 > 9)
                {
                    var3 = 9;
                }

                for (int var4 = 0; var4 < var3; ++var4)
                {
                    if (names.containsKey(var2[var4]))
                    {
                        buildSets[var1][var4] = ((Integer)((Integer)names.get(var2[var4]))).intValue();
                    }
                    else
                    {
                        int var5 = parseIdInfo(var2[var4]);

                        if (var5 == -1)
                        {
                            err("error: config.txt @ optBuild" + (var1 > 9 ? "B" : "A") + (var1 % 9 + 1) + " - unknown item name or invalid code: \"" + var2[var4] + "\"");
                        }
                        else
                        {
                            buildSets[var1][var4] = var5;
                        }
                    }
                }
            }
        }

        return checkClass(PlayerControllerMP.class, "build");
    }

    private static void optionsModBuild()
    {
        keyBuildToggle = getSetBind(keyBuildToggle, "keyBuildToggle", 48, "Toggle builder mode");
        keyBuildA = getSetBind(keyBuildA, "keyBuildA", 42, "A item sets (this + number)");
        keyBuildB = getSetBind(keyBuildB, "keyBuildB", 29, "B item sets (this + number)");
        optBuild = getSetBool(optBuild, "optBuild", false, "Builder mode is enabled by default");
        optBuildLockQuantity = getSetBool(optBuildLockQuantity, "optBuildLockQuantity", true, "Lock item quantity");
        optBuildLockQuantityToNr = getSetInt(optBuildLockQuantityToNr, "optBuildLockQuantityToNr", 0, 0, 32, "Lock item quatity to nr (0 = don\'t)");
        optBuildDigSpeed = getSetFloat(optBuildDigSpeed, "optBuildDigSpeed", 1.0F, 0.1F, 6.0F, "Digging speed");
        optBuildHarvestRule = getSetInt(optBuildHarvestRule, "optBuildHarvestRule", -1, -1, 1, "Harvest rule (-1=never, 0=vanilla, 1=always)");
        optBuildReach = getSetFloat(optBuildReach, "optBuildReach", 16.0F, 2.0F, 128.0F, "Arm length");
        optBuildExtension = getSetBool(optBuildExtension, "optBuildExtension", false, "Build extension enabled");
        keyBuildMark = getSetBind(keyBuildMark, "keyBuildMark", 45, "Set marker");
        keyBuildCopy = getSetBind(keyBuildCopy, "keyBuildCopy", 46, "Copy selected area");
        keyBuildPaste = getSetBind(keyBuildPaste, "keyBuildPaste", 25, "Paste into selected area");
        keyBuildSet = getSetBind(keyBuildSet, "keyBuildSet", 44, "Set in selected area");
        keyBuildFill = getSetBind(keyBuildFill, "keyBuildFill", 42, "Modifier to fill only empty space");
        keyBuildRemove = getSetBind(keyBuildRemove, "keyBuildRemove", 54, "Modifier to remove matching");
        keyBuildDown = getSetBind(keyBuildDown, "keyBuildDown", 29, "Modifier to set marker at feet level");
        keyBuildDeselect = getSetBind(keyBuildDeselect, "keyBuildDeselect", 0, "Remove markers");
    }

    private static void updateModBuild()
    {
        if (modBuildEnabled)
        {
            if (!optBuild || isMenu || !optBuildLockQuantity || isMultiplayer)
            {
                buildHandSlot = -1;
            }

            if (!isMenu)
            {
                if (keyPress(keyBuildToggle))
                {
                    optBuild = !optBuild;
                }

                if (isMapChange)
                {
                    optBuild = false;
                }

                if (!optBuild)
                {
                    buildMark = 0;
                }
                else
                {
                    int var0 = -1;
                    int var1;

                    if (keyDown(keyBuildA))
                    {
                        for (var1 = 2; var1 <= 10; ++var1)
                        {
                            if (keyPress(var1))
                            {
                                var0 = var1 - 2;
                            }
                        }
                    }

                    if (keyDown(keyBuildB))
                    {
                        for (var1 = 2; var1 <= 10; ++var1)
                        {
                            if (keyPress(var1))
                            {
                                var0 = 9 + var1 - 2;
                            }
                        }
                    }

                    if (var0 != -1)
                    {
                        for (var1 = 0; var1 < 9; ++var1)
                        {
                            if (buildSets[var0][var1] != 0)
                            {
                                invItemsArr[var1] = newItemsE(buildSets[var0][var1], 32);
                            }
                        }
                    }

                    var1 = fix(posX);
                    int var2 = fix(posY);
                    int var3 = fix(posZ);

                    if (keyPress(keyBuildDeselect))
                    {
                        buildMark = 0;
                    }

                    int var4;

                    if (optBuildExtension && keyPress(keyBuildMark))
                    {
                        if (buildMark == 1)
                        {
                            buildEX = var1;
                            buildEY = keyDown(keyBuildDown) ? var2 - 1 : var2;
                            buildEZ = var3;
                            buildMark = 2;
                        }
                        else
                        {
                            buildSX = var1;
                            buildSY = keyDown(keyBuildDown) ? var2 - 1 : var2;
                            buildSZ = var3;
                            buildMark = 1;
                        }
                    }
                    else if (buildMark == 2)
                    {
                        if (buildSX > buildEX)
                        {
                            var4 = buildSX;
                            buildSX = buildEX;
                            buildEX = var4;
                        }

                        if (buildSY > buildEY)
                        {
                            var4 = buildSY;
                            buildSY = buildEY;
                            buildEY = var4;
                        }

                        if (buildSZ > buildEZ)
                        {
                            var4 = buildSZ;
                            buildSZ = buildEZ;
                            buildEZ = var4;
                        }

                        int var5;
                        int var6;
                        int var7;

                        if (keyPress(keyBuildSet) && !isMultiplayer)
                        {
                            var5 = 0;
                            var7 = 0;

                            if (invItemsArr[getInvCur()] != null)
                            {
                                var5 = getItemsId(invItemsArr[getInvCur()]);
                                var7 = getItemsInfo(invItemsArr[getInvCur()]);

                                if (var5 >= 255)
                                {
                                    var7 = 0;
                                    var5 = 0;
                                }
                            }

                            if (keyDown(keyBuildFill))
                            {
                                for (var1 = buildSX; var1 <= buildEX; ++var1)
                                {
                                    for (var2 = buildSY; var2 <= buildEY; ++var2)
                                    {
                                        for (var3 = buildSZ; var3 <= buildEZ; ++var3)
                                        {
                                            if (mapXGetId(var1, var2, var3) == 0)
                                            {
                                                mapXSetIdMetaNoUpdate(var1, var2, var3, var5, var7);
                                            }
                                        }
                                    }
                                }
                            }
                            else if (keyDown(keyBuildRemove))
                            {
                                for (var1 = buildSX; var1 <= buildEX; ++var1)
                                {
                                    for (var2 = buildSY; var2 <= buildEY; ++var2)
                                    {
                                        for (var3 = buildSZ; var3 <= buildEZ; ++var3)
                                        {
                                            if ((var6 = mapXGetId(var1, var2, var3)) == var5 || var5 == 8 && var6 == 9 || var5 == 10 && var6 == 11)
                                            {
                                                mapXSetIdMetaNoUpdate(var1, var2, var3, 0, 0);
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                for (var1 = buildSX; var1 <= buildEX; ++var1)
                                {
                                    for (var2 = buildSY; var2 <= buildEY; ++var2)
                                    {
                                        for (var3 = buildSZ; var3 <= buildEZ; ++var3)
                                        {
                                            mapXSetIdMetaNoUpdate(var1, var2, var3, var5, var7);
                                        }
                                    }
                                }
                            }

                            mapXNeedsUpdate(buildSX - 1, buildSY - 1, buildSZ - 1, buildEX + 1, buildEY + 1, buildEZ + 1);
                        }
                        else if (keyPress(keyBuildCopy))
                        {
                            buildMark = 0;
                            buildSizeX = 1 + buildEX - buildSX;
                            buildSizeY = 1 + buildEY - buildSY;
                            buildSizeZ = 1 + buildEZ - buildSZ;
                            var5 = buildSizeX * buildSizeY * buildSizeZ;
                            var6 = 0;
                            buildBufBlock = new int[var5];
                            buildBufExtra = new int[var5];
                            buildBufNBT = new NBTTagCompound[var5];

                            for (var1 = buildSX; var1 <= buildEX; ++var1)
                            {
                                for (var2 = buildSY; var2 <= buildEY; ++var2)
                                {
                                    for (var3 = buildSZ; var3 <= buildEZ; ++var3)
                                    {
                                        buildBufBlock[var6] = mapXGetId(var1, var2, var3);
                                        buildBufExtra[var6] = mapXGetMeta(var1, var2, var3);
                                        buildBufNBT[var6] = mapGetTileCopy(var1, var2, var3);
                                        ++var6;
                                    }
                                }
                            }
                        }
                        else if (keyPress(keyBuildPaste) && buildBufBlock != null && !isMultiplayer)
                        {
                            var5 = 1 + buildEX - buildSX;
                            var5 = var5 > buildSizeX ? var5 % buildSizeX : 0;
                            var6 = 1 + buildEY - buildSY;
                            var6 = var6 > buildSizeY ? var6 % buildSizeY : 0;
                            var7 = 1 + buildEZ - buildSZ;
                            var7 = var7 > buildSizeZ ? var7 % buildSizeZ : 0;

                            if (var5 == 0 && var6 == 0 && var7 == 0)
                            {
                                int var8;
                                int var9;
                                int var10;
                                int var11;

                                if (keyDown(keyBuildFill))
                                {
                                    for (var1 = buildSX; var1 <= buildEX; ++var1)
                                    {
                                        for (var2 = buildSY; var2 <= buildEY; ++var2)
                                        {
                                            for (var3 = buildSZ; var3 <= buildEZ; ++var3)
                                            {
                                                if (mapXGetId(var1, var2, var3) == 0)
                                                {
                                                    var8 = (var1 - buildSX) % buildSizeX;
                                                    var9 = (var2 - buildSY) % buildSizeY;
                                                    var10 = (var3 - buildSZ) % buildSizeZ;
                                                    var11 = (var8 * buildSizeY + var9) * buildSizeZ + var10;
                                                    mapXSetIdMetaNoUpdate(var1, var2, var3, buildBufBlock[var11], buildBufExtra[var11]);
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (keyDown(keyBuildRemove))
                                {
                                    for (var1 = buildSX; var1 <= buildEX; ++var1)
                                    {
                                        for (var2 = buildSY; var2 <= buildEY; ++var2)
                                        {
                                            for (var3 = buildSZ; var3 <= buildEZ; ++var3)
                                            {
                                                var8 = (var1 - buildSX) % buildSizeX;
                                                var9 = (var2 - buildSY) % buildSizeY;
                                                var10 = (var3 - buildSZ) % buildSizeZ;
                                                var11 = (var8 * buildSizeY + var9) * buildSizeZ + var10;
                                                int var12 = buildBufBlock[var11];
                                                int var13 = mapXGetId(var1, var2, var3);

                                                if (var12 == var13 || var12 == 8 && var13 == 9 || var12 == 10 && var13 == 11)
                                                {
                                                    mapXSetIdMetaNoUpdate(var1, var2, var3, 0, 0);
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    for (var1 = buildSX; var1 <= buildEX; ++var1)
                                    {
                                        for (var2 = buildSY; var2 <= buildEY; ++var2)
                                        {
                                            for (var3 = buildSZ; var3 <= buildEZ; ++var3)
                                            {
                                                var8 = (var1 - buildSX) % buildSizeX;
                                                var9 = (var2 - buildSY) % buildSizeY;
                                                var10 = (var3 - buildSZ) % buildSizeZ;
                                                var11 = (var8 * buildSizeY + var9) * buildSizeZ + var10;
                                                mapXSetIdMetaNoUpdate(var1, var2, var3, buildBufBlock[var11], buildBufExtra[var11]);

                                                if (buildBufNBT[var11] != null)
                                                {
                                                    mapSetTileCopy(buildBufNBT[var11], var1, var2, var3);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                buildEX -= var5;
                                buildEY -= var6;
                                buildEZ -= var7;
                            }

                            mapXNeedsUpdate(buildSX - 1, buildSY - 1, buildSZ - 1, buildEX + 1, buildEY + 1, buildEZ + 1);
                        }
                    }
                    else if (buildMark == 1 && keyPress(keyBuildPaste) && !isMultiplayer)
                    {
                        buildEX = buildSX + buildSizeX - 1;
                        buildEY = buildSY + buildSizeY - 1;
                        buildEZ = buildSZ + buildSizeZ - 1;
                        buildMark = 2;
                    }

                    if (optBuildLockQuantity && !isMultiplayer)
                    {
                        if (optBuildLockQuantityToNr != 0)
                        {
                            for (var4 = 0; var4 < invItemsArr.length; ++var4)
                            {
                                if (invItemsArr[var4] != null)
                                {
                                    setItemsCount(invItemsArr[var4], optBuildLockQuantityToNr);
                                }
                            }
                        }
                        else
                        {
                            var4 = getInvCur();

                            if (var4 == buildHandSlot && (invItemsArr[var4] == null || invItemsArr[var4] == buildHand))
                            {
                                if (buildHand != null && (invItemsArr[var4] == null || invItemsArr[var4] == buildHand))
                                {
                                    setItemsCount(buildHand, buildHandCount);
                                    setInvItems(var4, buildHand);
                                }
                            }
                            else
                            {
                                buildHandSlot = var4;
                                buildHand = invItemsArr[var4];
                                buildHandCount = buildHand != null ? getItemsCount(buildHand) : 0;
                            }
                        }
                    }
                }
            }
        }
    }

    public static void drawModBuild(float var0, float var1, float var2)
    {
        if (modBuildEnabled && buildMark > 0)
        {
            float var3 = (float)buildSX - var0 - 0.1F;
            float var4 = (float)(buildMark == 2 ? buildEX : buildSX) - var0 + 1.1F;
            float var5 = (float)buildSY - var1 - 0.1F;
            float var6 = (float)(buildMark == 2 ? buildEY : buildSY) - var1 + 1.1F;
            float var7 = (float)buildSZ - var2 - 0.1F;
            float var8 = (float)(buildMark == 2 ? buildEZ : buildSZ) - var2 + 1.1F;
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glDepthMask(false);
            GL11.glDisable(GL11.GL_CULL_FACE);

            if (buildMark == 2)
            {
                GL11.glEnable(GL11.GL_BLEND);
                GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
                GL11.glColor4ub((byte) - 1, (byte)64, (byte)32, (byte)32);
                GL11.glBegin(GL11.GL_QUADS);
                GL11.glVertex3f(var3, var5, var7);
                GL11.glVertex3f(var3, var5, var8);
                GL11.glVertex3f(var3, var6, var8);
                GL11.glVertex3f(var3, var6, var7);
                GL11.glVertex3f(var4, var5, var7);
                GL11.glVertex3f(var4, var5, var8);
                GL11.glVertex3f(var4, var6, var8);
                GL11.glVertex3f(var4, var6, var7);
                GL11.glVertex3f(var3, var5, var7);
                GL11.glVertex3f(var3, var5, var8);
                GL11.glVertex3f(var4, var5, var8);
                GL11.glVertex3f(var4, var5, var7);
                GL11.glVertex3f(var3, var6, var7);
                GL11.glVertex3f(var3, var6, var8);
                GL11.glVertex3f(var4, var6, var8);
                GL11.glVertex3f(var4, var6, var7);
                GL11.glVertex3f(var3, var5, var7);
                GL11.glVertex3f(var3, var6, var7);
                GL11.glVertex3f(var4, var6, var7);
                GL11.glVertex3f(var4, var5, var7);
                GL11.glVertex3f(var3, var5, var8);
                GL11.glVertex3f(var3, var6, var8);
                GL11.glVertex3f(var4, var6, var8);
                GL11.glVertex3f(var4, var5, var8);
                GL11.glEnd();
                GL11.glDisable(GL11.GL_BLEND);
            }

            GL11.glColor3ub((byte)32, (byte)64, (byte) - 1);
            GL11.glBegin(GL11.GL_LINES);
            GL11.glVertex3f(var3, var5, var7);
            GL11.glVertex3f(var3, var5, var8);
            GL11.glVertex3f(var3, var5, var8);
            GL11.glVertex3f(var3, var6, var8);
            GL11.glVertex3f(var3, var6, var8);
            GL11.glVertex3f(var3, var6, var7);
            GL11.glVertex3f(var3, var6, var7);
            GL11.glVertex3f(var3, var5, var7);
            GL11.glVertex3f(var4, var5, var7);
            GL11.glVertex3f(var4, var5, var8);
            GL11.glVertex3f(var4, var5, var8);
            GL11.glVertex3f(var4, var6, var8);
            GL11.glVertex3f(var4, var6, var8);
            GL11.glVertex3f(var4, var6, var7);
            GL11.glVertex3f(var4, var6, var7);
            GL11.glVertex3f(var4, var5, var7);
            GL11.glVertex3f(var3, var5, var7);
            GL11.glVertex3f(var4, var5, var7);
            GL11.glVertex3f(var3, var5, var8);
            GL11.glVertex3f(var4, var5, var8);
            GL11.glVertex3f(var3, var6, var8);
            GL11.glVertex3f(var4, var6, var8);
            GL11.glVertex3f(var3, var6, var7);
            GL11.glVertex3f(var4, var6, var7);
            GL11.glEnd();
            GL11.glEnable(GL11.GL_CULL_FACE);
            GL11.glDepthMask(true);
            GL11.glEnable(GL11.GL_TEXTURE_2D);
        }
    }

    private static String textModBuild(String var0)
    {
        return modBuildEnabled && optBuild && tagBuildEnabled.length() != 0 ? var0 + tagBuildEnabled + " " : var0;
    }

    private static boolean initModCompass()
    {
        log("info: loading config for \"compass\"");
        tagCompassAlternate = getString("tagCompassAlternate", "altSpawn");
        optionsModCompass();
        return true;
    }

    private static void optionsModCompass()
    {
        keyCompassSet = getSetBind(keyCompassSet, "keyCompassSet", 210, "Set alternate compasspoint");
        keyCompassToggle = getSetBind(keyCompassToggle, "keyCompassToggle", 199, "Toggle compasspont original/alternate");
        optCompassShowPos = getSetBool(optCompassShowPos, "optCompassShowPos", true, "Show coordinates");
    }

    private static void updateModCompass()
    {
        if (modCompassEnabled && !isHell)
        {
            if (isWorldChange)
            {
                compassHaveMine = false;
                compassShowOrig = true;
            }

            int var0 = world.getSpawnX();
            int var1 = world.getSpawnY();
            int var2 = world.getSpawnZ();
            int var3 = fix(posX);
            int var4 = fix(posY);
            int var5 = fix(posZ);

            if (!compassHaveOrig || (var0 != compassOX || var1 != compassOY || var2 != compassOZ) && (var0 != compassMX || var1 != compassMY || var2 != compassMZ))
            {
                compassOX = var0;
                compassOY = var1;
                compassOZ = var2;
                compassHaveOrig = true;
            }

            if (!isMenu)
            {
                if (keyPress(keyCompassToggle))
                {
                    compassShowOrig = !compassShowOrig;
                }

                if (keyPress(keyCompassSet))
                {
                    compassMX = var3;
                    compassMY = var4;
                    compassMZ = var5;
                    compassHaveMine = true;
                    compassShowOrig = false;
                }
            }

            if (compassShowOrig)
            {
                var0 = compassOX;
                var1 = compassOY;
                var2 = compassOZ;
            }
            else
            {
                var0 = compassMX;
                var1 = compassMY;
                var2 = compassMZ;
            }

            world.setSpawnPosition(var0, var1, var2);
        }
    }

    private static String getAngleName(float var0)
    {
        for (var0 -= 112.5F; var0 > 360.0F; var0 -= 360.0F)
        {
            ;
        }

        while (var0 < 0.0F)
        {
            var0 += 360.0F;
        }

        return var0 < 45.0F ? "NW" : (var0 < 90.0F ? "N" : (var0 < 135.0F ? "NE" : (var0 < 180.0F ? "E" : (var0 < 225.0F ? "SE" : (var0 < 270.0F ? "S" : (var0 < 315.0F ? "SW" : "W"))))));
    }

    private static String textModCompassShared(String var0)
    {
        if (modCompassEnabled && optCompassShowPos || modInfoEnabled && optInfoShowPos)
        {
            var0 = var0 + "(" + fix(posX) + "," + fix(posY) + "," + fix(posZ) + " \u00a77" + getAngleName(player.rotationYaw) + "\u00a7f) ";
        }

        if (modCompassEnabled && !compassShowOrig && tagCompassAlternate.length() > 0)
        {
            var0 = var0 + tagCompassAlternate + " ";
        }

        return var0;
    }

    private static boolean initModSun()
    {
        log("info: loading config for \"sun\"");
        tagSunTime = getString("tagSunTime", "time");
        optSunServerCmd = getString("optSunServerCmd", "/time add");
        optionsModSun();
        return checkClass(WorldProvider.class, "sun");
    }

    private static void optionsModSun()
    {
        keySunTimeAdd = getSetBind(keySunTimeAdd, "keySunTimeAdd", 78, "Add time");
        keySunTimeSub = getSetBind(keySunTimeSub, "keySunTimeSub", 74, "Subtract time");
        optSunTimeStep = getSetInt(optSunTimeStep / 20, "optSunTimeStep", 30, 1, 600, "Time step in seconds") * 20;
        keySunStop = getSetBind(keySunStop, "keySunStop", 207, "Stop / resume sun-time");
        keySunTimeNormal = getSetBind(keySunTimeNormal, "keySunTimeNormal", 13, "Restore time");
        keySunServer = getSetBind(keySunServer, "keySunServer", 42, "Modifier to change real time (SSP/SMP)");
        optSunServerCmdPlus = getSetBool(optSunServerCmdPlus, "optSunServerCmdPlus", false, "Use \'+\' for adding time in SMP");
    }

    private static void updateModSun()
    {
        if (modSunEnabled)
        {
            long var0 = getTime();

            if (getIsSleeping(player))
            {
                sunSleeping = true;
            }
            else if (sunSleeping)
            {
                sunSleeping = false;
                sunTimeOffset = 0L;
            }

            if (!isMenu)
            {
                if (keyDown(keySunServer))
                {
                    if (isMultiplayer)
                    {
                        if (keyPress(keySunTimeAdd))
                        {
                            sendChat(optSunServerCmd + (optSunServerCmdPlus ? " +" : " ") + optSunTimeStep);
                        }
                        else if (keyPress(keySunTimeSub))
                        {
                            sendChat(optSunServerCmd + " -" + optSunTimeStep);
                        }
                    }
                    else if (keyPress(keySunTimeAdd))
                    {
                        setTime(getTime() + (long)optSunTimeStep);
                    }
                    else if (keyPress(keySunTimeSub))
                    {
                        setTime(getTime() - (long)optSunTimeStep);
                    }
                }
                else if (keyPress(keySunTimeAdd))
                {
                    if (sunTimeStop)
                    {
                        sunTimeMoment += (long)optSunTimeStep;
                    }

                    sunTimeOffset += (long)optSunTimeStep;
                }
                else if (keyPress(keySunTimeSub))
                {
                    if (sunTimeStop)
                    {
                        sunTimeMoment -= (long)optSunTimeStep;
                    }

                    sunTimeOffset -= (long)optSunTimeStep;
                }

                if (keyPress(keySunStop))
                {
                    sunTimeStop = !sunTimeStop;

                    if (sunTimeStop)
                    {
                        sunTimeMoment = var0;
                    }
                }

                if (keyPress(keySunTimeNormal))
                {
                    sunTimeStop = false;
                    sunTimeOffset = 0L;
                }
            }

            if (sunTimeStop)
            {
                sunTimeOffset -= var0 - sunTimeMoment;
                sunTimeMoment = var0;
            }
        }
    }

    private static String textModSun(String var0)
    {
        return modSunEnabled && sunTimeOffset != 0L ? var0 + tagSunTime + (sunTimeOffset < 0L ? "" : "+") + sunTimeOffset / 20L + " " : var0;
    }

    public static long sunOffsetHandle()
    {
        return modSunEnabled && sunTimeOffset != 0L ? sunTimeOffset : 0L;
    }

    private static boolean initModFly()
    {
        log("info: loading config for \"fly\"");
        keyFlyOn = getBind("keyFlyOn", 0);
        keyFlyOff = getBind("keyFlyOff", 0);
        flyNoClip = false;
        tagFly = getString("tagFly", "flying");
        tagFlyNoClip = getString("tagFlyNoClip", "noclip");
        optionsModFly();
        return checkClass(EntityPlayer.class, "fly");
    }

    private static void optionsModFly()
    {
        keyFlyToggle = getSetBind(keyFlyToggle, "keyFlyToggle", 33, "Toggle fly mode");
        optFlySpeedMulNormal = (double)getSetFloat((float)optFlySpeedMulNormal, "optFlySpeedMulNormal", 1.0F, 0.1F, 10.0F, "Flying speed");
        keyFlyUp = getSetBind(keyFlyUp, "keyFlyUp", 18, "Fly up");
        keyFlyDown = getSetBind(keyFlyDown, "keyFlyDown", 16, "Fly down");
        optFlySpeedVertical = (double)getSetFloat((float)optFlySpeedVertical, "optFlySpeedVertical", 0.2F, 0.1F, 1.0F, "Vertical flying speed");
        keyFlySpeed = getSetBind(keyFlySpeed, "keyFlySpeed", 42, "Fly speed modifier");
        optFlySpeedIsToggle = getSetBool(optFlySpeedIsToggle, "optFlySpeedIsToggle", false, "Fly speed modifier is toggle");
        optFlySpeedMulModifier = (double)getSetFloat((float)optFlySpeedMulModifier, "optFlySpeedMulModifier", 2.0F, 1.0F, 10.0F, "Flying speed with speed modifier");
        keyFlyRun = getSetBind(keyFlyRun, "keyFlyRun", 42, "Running speed modifier");
        optFlyRunSpeedIsToggle = getSetBool(optFlyRunSpeedIsToggle, "optFlyRunSpeedIsToggle", false, "Run speed modifier is toggle");
        optFlyRunSpeedMul = (double)getSetFloat((float)optFlyRunSpeedMul, "optFlyRunSpeedMul", 1.5F, 0.1F, 10.0F, "Running speed");
        optFlyRunSpeedVMul = (double)getSetFloat((float)optFlyRunSpeedVMul, "optFlyRunSpeedVMul", 1.5F, 0.1F, 10.0F, "Vertical speed (ladders / water)");
        keyFlyNoClip = getSetBind(keyFlyNoClip, "keyFlyNoClip", 66, "Toggle no-clip mode");
        optFlyNoClip = getSetBool(optFlyNoClip, "optFlyNoClip", true, "No-clip is enabled by default");
        optFlyJump = (double)getSetFloat((float)optFlyJump, "optFlyJump", 1.0F, 1.0F, 10.0F, "Jump speed");
        optFlyJumpHigh = (double)getSetFloat((float)optFlyJumpHigh, "optFlyJumpHigh", 1.25F, 1.0F, 10.0F, "Jump speed with speed modifier (run)");
        optFlyVanillaFly = getSetBool(optFlyVanillaFly, "optFlyVanillaFly", true, "Allow vanilla MC fly toggle");
        optFlyVanillaSprint = getSetBool(optFlyVanillaSprint, "optFlyVanillaSprint", true, "Allow vanilla MC sprint toggle");
    }

    private static void updateModFly()
    {
        if (isWorldChange)
        {
            flyNoClip = optFlyNoClip && modNoClipAllowed;
            setNoClip(modFlyAllowed && flyNoClip && fly);
        }

        if (modFlyEnabled && !isMenu)
        {
            boolean var0 = fly;

            if (keyPress(keyFlyToggle))
            {
                fly = !fly;
            }
            else if (keyDown(keyFlyOn))
            {
                fly = true;
            }
            else if (keyDown(keyFlyOff))
            {
                fly = false;
            }

            if (!modFlyAllowed && fly)
            {
                fly = false;
                chatClient("\u00a74zombe\'s \u00a72fly\u00a74-mod is not allowed on this server.");
            }

            if (fly && keyPress(keyFlyNoClip))
            {
                setNoClip(flyNoClip = !flyNoClip);
            }
            else if (var0 != fly)
            {
                setNoClip(fly && flyNoClip);
            }

            if (optFlySpeedIsToggle && keyPress(keyFlySpeed))
            {
                flySpeed = !flySpeed;
            }

            if (optFlyRunSpeedIsToggle && keyPress(keyFlyRun))
            {
                flyRun = !flyRun;
            }
        }
    }

    private static void preEntModFly()
    {
        if (playerClassActive && player != null && (!modFlyEnabled || !fly))
        {
            setEntityOnGround(player, moveOnGround);
        }
    }

    private static String textModFly(String var0)
    {
        if (modFlyEnabled && fly)
        {
            if (tagFly.length() > 0)
            {
                var0 = var0 + tagFly + " ";
            }

            if (flyNoClip && tagFlyNoClip.length() > 0)
            {
                var0 = var0 + tagFlyNoClip + " ";
            }

            return var0;
        }
        else
        {
            return var0;
        }
    }

    public static void flyDickmoveCancel()
    {
        if (modFlyEnabled)
        {
            if (!optFlyVanillaFly && !fly)
            {
                setValue(fFlyTT, player, Integer.valueOf(0));
                player.capabilities.isFlying = false;
            }

            if (!optFlyVanillaSprint)
            {
                setValue(fSprintTT, player, Integer.valueOf(0));
            }

            if (flyNoClip && fly && modNoClipAllowed)
            {
                setEntityMotionX(player, movX);
                setEntityMotionZ(player, movZ);
            }
        }
    }

    public static void flyHandle(Object var0, double var1, double var3, double var5)
    {
        EntityPlayer var7 = (EntityPlayer)var0;

        if (var7 == player && modFlyAllowed)
        {
            flyTmp = getEntitySteps(var7);
            var7.capabilities.allowFlying = true;
            var7.sendPlayerAbilities();
            if (fly)
            {
                var3 = 0.0D;

                if (!isMenu)
                {
                    if (keyDown(keyFlyUp))
                    {
                        var3 += optFlySpeedVertical;
                    }

                    if (keyDown(keyFlyDown))
                    {
                        var3 -= optFlySpeedVertical;
                    }

                    double var10000;
                    label70:
                    {
                        label69:
                        {
                            if (optFlySpeedIsToggle)
                            {
                                if (flySpeed)
                                {
                                    break label69;
                                }
                            }
                            else if (keyDown(keyFlySpeed))
                            {
                                break label69;
                            }

                            var10000 = optFlySpeedMulNormal;
                            break label70;
                        }
                        var10000 = optFlySpeedMulModifier;
                    }
                    double var8 = var10000;
                    var1 *= var8;
                    var3 *= var8;
                    var5 *= var8;
                    setFall(var7, 0.0F);
                    setEntityMotionY(var7, 0.0D);
                    flew = true;
                }
            }
            else
            {
                label82:
                {
                    if (optFlyRunSpeedIsToggle)
                    {
                        if (!flyRun)
                        {
                            break label82;
                        }
                    }
                    else if (!keyDown(keyFlyRun))
                    {
                        break label82;
                    }

                    var1 *= optFlyRunSpeedMul;
                    var5 *= optFlyRunSpeedMul;
                    int var10 = mapXGetId(fix(getEntityPosX(var7)), fix(getEntityPosY(var7)), fix(getEntityPosZ(var7)));

                    if (var10 == 65 || var10 >= 8 && var10 <= 11)
                    {
                        var3 *= optFlyRunSpeedVMul;
                    }
                }
            }
        }

        flyCallSuper(var7, var1, var3, var5);

        if (var7 == player)
        {
            moveOnGround = getEntityOnGround(var7);
            playerClassActive = true;

            if (modFlyAllowed && var7 == player)
            {
                if (fly)
                {
                	var7.capabilities.isFlying = true;
                    var7.sendPlayerAbilities();
                    setFall(var7, 0.0F);
                    setEntityOnGround(var7, true);
                    setEntitySteps(var7, flyTmp);
                }
                else if (flew && !getEntityOnGround(var7))
                {
                    setFall(var7, 0.0F);
                    setEntityOnGround(var7, true);
                }
                else
                {
                    flew = false;
                }
            }

            if (cheating && !optCheatFallDamage)
            {
                setFall(var7, 0.0F);
                setEntityOnGround(var7, true);
            }
        }
    }

    public static double flyJumpHandle()
    {
        if (!modFlyAllowed)
        {
            return 1.0D;
        }
        else
        {
            if (optFlyRunSpeedIsToggle)
            {
                if (flyRun)
                {
                    return optFlyJumpHigh;
                }
            }
            else if (keyDown(keyFlyRun))
            {
                return optFlyJumpHigh;
            }

            return optFlyJump;
        }
    }

    private static boolean initModCraft()
    {
        log("info: loading config for \"craft\"");
        optionsModCraft();
        return checkClass(GuiContainer.class, "craft");
    }

    private static void optionsModCraft()
    {
        keyCraftAll = getSetBind(keyCraftAll, "keyCraftAll", 42, "Craft-all modifier key");
    }

    public static int craftingHandle()
    {
        return modCraftEnabled && keyDown(keyCraftAll) ? 64 : 1;
    }

    private static boolean initModPath()
    {
        log("info: loading config for \"path\"");
        optPathPoints = getInt("optPathPoints", 8192, 256, 32768);
        pathf = new float[3 * optPathPoints];
        optPathMin = getFloat("optPathMin", 0.25F, 0.1F, 4.0F);
        optPathMin *= optPathMin;
        optPathColor = getColor("optPathColor", 16711680);
        optionsModPath();
        return true;
    }

    private static void optionsModPath()
    {
        keyPathShow = getSetBind(keyPathShow, "keyPathShow", 14, "Show / hide path");
        optPathShow = getSetBool(optPathShow, "optPathShow", false, "Path is shown by default");
        optPathSpacing = getSetInt(optPathSpacing - 2, "optPathSpacing", 6, 0, 32, "Spacing") + 2;
        optPathAnimSpeed = getSetFloat(optPathAnimSpeed, "optPathAnimSpeed", 8.0F, 0.0F, 32.0F, "Animation speed");
        keyPathDelete = getSetBind(keyPathDelete, "keyPathDelete", 211, "Delete path");
    }

    private static void updateModPath()
    {
        if (modPathEnabled && !isMenu)
        {
            if (keyPress(keyPathShow))
            {
                optPathShow = !optPathShow;
            }

            if (keyPress(keyPathDelete))
            {
                pathCount = 0;
            }
        }
    }

    public static void drawModPath(float var0, float var1, float var2)
    {
        if (modPathEnabled)
        {
            float var3 = (float)posX;
            float var4 = (float)posY;
            float var5 = (float)posZ;
            float var6 = pathf[pathLast] - var3;
            float var7 = pathf[pathLast + 1] - (var4 - 1.25F);
            float var8 = pathf[pathLast + 2] - var5;
            float var9 = var6 * var6 + var7 * var7 + var8 * var8;

            if (var9 > optPathMin)
            {
                pathLast += 3;

                if (pathLast >= pathf.length)
                {
                    pathLast = 0;
                }

                if (pathCount < optPathPoints)
                {
                    ++pathCount;
                }

                pathf[pathLast] = var3;
                pathf[pathLast + 1] = var4 - 1.25F;
                pathf[pathLast + 2] = var5;
            }

            if (optPathShow && pathCount > 3)
            {
                pathAnimCur += seconds * optPathAnimSpeed;

                if (pathAnimCur > (float)optPathSpacing)
                {
                    pathAnimCur -= (float)optPathSpacing;
                }

                float var10 = pathf[pathLast] - var0;
                float var11 = pathf[pathLast + 1] - var1;
                float var12 = pathf[pathLast + 2] - var2;
                int var16 = pathCount - 1;
                int var17 = pathLast;
                int var18 = ((pathf.length - pathLast) / 3 + (int)pathAnimCur) % optPathSpacing;
                int var19 = 4;
                GL11.glDisable(GL11.GL_TEXTURE_2D);
                GL11.glColor3ub(optPathColor.r, optPathColor.g, optPathColor.b);
                GL11.glBegin(GL11.GL_LINES);

                do
                {
                    float var13 = var10;
                    float var14 = var11;
                    float var15 = var12;
                    var17 -= 3;

                    if (var17 < 0)
                    {
                        var17 = pathf.length - 3;
                    }

                    var10 = pathf[var17] - var0;
                    var11 = pathf[var17 + 1] - var1;
                    var12 = pathf[var17 + 2] - var2;

                    if (optPathSpacing > 2)
                    {
                        ++var18;

                        if (var18 == optPathSpacing)
                        {
                            var18 = 0;
                        }

                        if (var18 <= 1 && var19 < 0)
                        {
                            GL11.glVertex3f(var10, var11, var12);
                            GL11.glVertex3f(var13, var14, var15);
                        }
                    }
                    else if (var19 < 0)
                    {
                        GL11.glVertex3f(var10, var11, var12);
                        GL11.glVertex3f(var13, var14, var15);
                    }

                    --var19;
                    --var16;
                }
                while (var16 != 0);

                GL11.glEnd();
                GL11.glEnable(GL11.GL_TEXTURE_2D);
            }
        }
    }

    private static boolean initModRecipe()
    {
        log("info: loading config for \"recipe\" - deferred");
        optRecipeDump = getBool("optRecipeDump", false);
        optRecipeVanillaMP = getBool("optRecipeVanillaMP", false);
        optionsModRecipe();

        if (optRecipeVanillaMP)
        {
            recipesMP = (List)((ArrayList)getValue(fCMRecipes, getCManager())).clone();
        }
        else
        {
            recipesMP = (List)getValue(fCMRecipes, getCManager());
        }

        return true;
    }

    private static void optionsModRecipe()
    {
        optRecipeShowId = getSetBool(optRecipeShowId, "optRecipeShowId", true, "Show selected item id");
        optRecipeShowHelp = getSetBool(optRecipeShowHelp, "optRecipeShowHelp", true, "Show recipe helper");
    }

    private static void deferredModRecipe()
    {
        if (modRecipeEnabled && recipesSP == null)
        {
            log("info: continuing to load \"recipes\"");
            recipesSP = (List)getValue(fCMRecipes, getCManager());
            log("info: " + recipesSP.size() + " SP recipes before loading mod");
            parse(recipesSP, "recipes.txt", 2);
            sortRecipes(recipesSP);
            log("info: " + recipesSP.size() + " SP recipes after loading mod");

            if (optRecipeDump)
            {
                log("==== recipe dump ====");

                for (int var1 = 0; var1 < recipesSP.size(); ++var1)
                {
                    Object var2 = recipesSP.get(var1);
                    String var0;
                    ItemStack var3;
                    int var4;
                    int var5;
                    int var7;

                    if (var2 instanceof ShapedRecipes)
                    {
                        var3 = (ItemStack)getValue(fRResA, var2);
                        var4 = getItemsId(var3);
                        var5 = getItemsInfo(var3);
                        ItemStack[] var6 = (ItemStack[])((ItemStack[])getValue(fRMap, var2));
                        var0 = getNameForId(var4);

                        if (var4 > 0 || getItemHasSubTypes(getItem(var4)) || getItemDmgCap(getItem(var4)) > 0)
                        {
                            var0 = var0 + "/" + var5;
                        }

                        var0 = var0 + " " + getItemsCount(var3) + " " + getValue(fRWidth, var2) + " " + getValue(fRHeight, var2);

                        for (var7 = 0; var7 < var6.length; ++var7)
                        {
                            if (var6[var7] == null)
                            {
                                var0 = var0 + " 0";
                            }
                            else
                            {
                                var4 = getItemsId(var6[var7]);
                                var5 = getItemsInfo(var6[var7]);
                                var0 = var0 + " " + getNameForId(var4);

                                if (var4 > 0 || getItemHasSubTypes(getItem(var4)) || getItemDmgCap(getItem(var4)) > 0)
                                {
                                    var0 = var0 + "/" + var5;
                                }
                            }
                        }
                    }
                    else if (var2 instanceof ShapelessRecipes)
                    {
                        var3 = (ItemStack)getValue(fRResB, var2);
                        var4 = getItemsId(var3);
                        var5 = getItemsInfo(var3);
                        List var8 = (List)getValue(fRList, var2);
                        var0 = getNameForId(var4);

                        if (var4 > 0 || getItemHasSubTypes(getItem(var4)) || getItemDmgCap(getItem(var4)) > 0)
                        {
                            var0 = var0 + "/" + var5;
                        }

                        var0 = var0 + " " + getItemsCount(var3) + " " + var8.size() + " 0";

                        for (var7 = 0; var7 < var8.size(); ++var7)
                        {
                            var3 = (ItemStack)var8.get(var7);
                            var4 = getItemsId(var3);
                            var5 = getItemsInfo(var3);
                            var0 = var0 + " " + getNameForId(var4);

                            if (var4 > 0 || getItemHasSubTypes(getItem(var4)) || getItemDmgCap(getItem(var4)) > 0)
                            {
                                var0 = var0 + "/" + var5;
                            }
                        }
                    }
                    else
                    {
                        var0 = "Unknown type";
                    }

                    log(var0);
                }
            }
        }
    }

    private static void updateModRecipe()
    {
        if (modRecipeEnabled)
        {
            setValue(fCMRecipes, getCManager(), isMultiplayer ? recipesMP : recipesSP);
        }
    }

    private static void updateModRecipeShared()
    {
        recipesMobType = 0;

        if (!isMultiplayer && (modRecipeEnabled || modBuildEnabled))
        {
            ItemStack var0 = invItemsArr[getInvCur()];

            if (var0 != null && getItemsId(var0) == 52)
            {
                int var1 = getItemsInfo(var0);

                if (var1 >= 0 && var1 < 27 && var1 != 13 && var1 != 14)
                {
                    recipesMobType = var1;
                }
            }
        }
    }

    private static void drawGuiModRecipe()
    {
        if (modRecipeEnabled && optRecipeShowHelp && isMenu && !isTMIEnabled())
        {
            ArrayList var0 = new ArrayList();
            ArrayList var1 = new ArrayList();
            ItemStack[] var2 = new ItemStack[9];
            ItemStack[] var3 = new ItemStack[9];
            IRecipe var4 = null;
            IRecipe var5 = null;
            boolean[] var6 = new boolean[9];
            int var7 = 0;
            int var9 = 0;
            int var12;
            label279:

            for (int var10 = 0; var10 < 9; ++var10)
            {
                ItemStack var11 = getGridItem(var10);

                if (var11 != null)
                {
                    var2[var7++] = var11;

                    for (var12 = 0; var12 < var9; ++var12)
                    {
                        if (isItemsMatch(var2[var7 - 1], var3[var12]))
                        {
                            continue label279;
                        }
                    }

                    var3[var9++] = var11;
                }
            }

            if (var7 > 0)
            {
                short var32 = 176;
                short var31 = 166;
                var12 = getScrWidthS();
                int var13 = getScrHeightS();
                byte var14 = 2;
                int var15 = var14 + var32 + (var12 - var32) / 2;
                int var16 = 2 + (var13 - var31) / 2;
                int var17 = var16 + 24;
                int var18 = (var12 - var32 - 4) / 32;
                List var20 = (List)getValue(fCMRecipes, getCManager());
                Iterator var21 = var20.iterator();
                IRecipe var22;
                int var25;
                ItemStack[] var24;
                int var27;
                int var26;
                ItemStack var35;
                List var36;
                int var37;

                while (var21.hasNext())
                {
                    var22 = (IRecipe)var21.next();
                    int var8 = var7;

                    for (int var23 = 0; var23 < var7; ++var23)
                    {
                        var6[var23] = false;
                    }

                    var35 = null;
                    ItemStack var39;

                    if (var22 instanceof ShapedRecipes)
                    {
                        var24 = (ItemStack[])((ItemStack[])getValue(fRMap, var22));
                        var35 = (ItemStack)getValue(fRResA, var22);

                        for (var25 = 0; var25 < var24.length; ++var25)
                        {
                            if (var24[var25] != null)
                            {
                                for (var26 = 0; var26 < var7; ++var26)
                                {
                                    if (!var6[var26] && isItemsMatch(var2[var26], var24[var25]))
                                    {
                                        var6[var26] = true;
                                        --var8;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        if (!(var22 instanceof ShapelessRecipes))
                        {
                            continue;
                        }

                        var36 = (List)getValue(fRList, var22);
                        var35 = (ItemStack)getValue(fRResB, var22);
                        Iterator var34 = var36.iterator();

                        while (var34.hasNext())
                        {
                            var39 = (ItemStack)var34.next();

                            for (var27 = 0; var27 < var7; ++var27)
                            {
                                if (!var6[var27] && isItemsMatch(var2[var27], var39))
                                {
                                    var6[var27] = true;
                                    --var8;
                                    break;
                                }
                            }
                        }
                    }

                    if (var8 == 0)
                    {
                        var0.add(var22);
                    }

                    for (var37 = 0; var37 < var9; ++var37)
                    {
                        var25 = getItemsId(var3[var37]);
                        var39 = getItemHasSubTypes(getItem(var25)) ? var3[var37] : newItems(var25, 1);

                        if (isItemsMatch(var39, var35))
                        {
                            var1.add(var22);
                        }
                    }
                }

                if (var0.size() > 0)
                {
                    if (var0.size() == 1)
                    {
                        showText("1 recipe needs", var14, var16, 15658734);
                        showText("" + (var7 > 1 ? "those items" : "that item") + " :D", var14, var16 + 10, 15658734);
                    }
                    else
                    {
                        showText("" + var0.size() + " recipes need", var14, var16, 14540253);
                        showText("" + (var7 > 1 ? "those items" : "that item") + " :)", var14, var16 + 10, 14540253);
                    }
                }
                else
                {
                    showText("Can not craft anything", var14, var16, 8921634);
                    showText("with " + (var7 > 1 ? "those items :/" : "that item :("), var14, var16 + 10, 8921634);
                }

                var17 = 40 + var16 + (var0.size() + var18 - 1) / var18 * 16;

                if (var1.size() > 0)
                {
                    showText("Recipes for:", var14, var17 - 10, 15658734);
                }

                GL11.glEnable(GL11.GL_LIGHTING);
                GL11.glPushMatrix();
                GL11.glRotatef(120.0F, 1.0F, 0.0F, 0.0F);
                setXItemLighting();
                GL11.glPopMatrix();
                GL11.glEnable(GL12.GL_RESCALE_NORMAL);
                GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
                int var19;

                if (var0.size() > 0)
                {
                    var21 = var0.iterator();
                    var19 = 0;

                    while (var21.hasNext())
                    {
                        var22 = (IRecipe)var21.next();

                        if (var5 == null)
                        {
                            var5 = var22;
                        }

                        var35 = null;

                        if (var22 instanceof ShapedRecipes)
                        {
                            var35 = (ItemStack)getValue(fRResA, var22);
                        }
                        else
                        {
                            if (!(var22 instanceof ShapelessRecipes))
                            {
                                continue;
                            }

                            var35 = (ItemStack)getValue(fRResB, var22);
                        }

                        var37 = var14 + var19 % var18 * 16;
                        var25 = 20 + var16 + var19 / var18 * 16;

                        if (mouseX >= var37 && mouseY >= var25 && mouseX < var37 + 16 && mouseY < var25 + 16)
                        {
                            var4 = var22;

                            if (Mouse.isButtonDown(0))
                            {
                                selRecipe = var22;
                            }
                        }

                        drawItem(var35, var37, var25);
                        ++var19;
                    }
                }

                if (var1.size() > 0)
                {
                    var21 = var1.iterator();
                    var19 = 0;

                    while (var21.hasNext())
                    {
                        var22 = (IRecipe)var21.next();

                        if (var5 == null)
                        {
                            var5 = var22;
                        }

                        var35 = null;

                        if (var22 instanceof ShapedRecipes)
                        {
                            var35 = (ItemStack)getValue(fRResA, var22);
                        }
                        else
                        {
                            if (!(var22 instanceof ShapelessRecipes))
                            {
                                continue;
                            }

                            var35 = (ItemStack)getValue(fRResB, var22);
                        }

                        var37 = var14 + var19 % var18 * 16;
                        var25 = var17 + var19 / var18 * 16;

                        if (mouseX >= var37 && mouseY >= var25 && mouseX < var37 + 16 && mouseY < var25 + 16)
                        {
                            var4 = var22;

                            if (Mouse.isButtonDown(0))
                            {
                                selRecipe = var22;
                            }
                        }

                        drawItem(var35, var37, var25);
                        ++var19;
                    }
                }

                String var33 = null;
                String var38 = null;

                if (var4 == null)
                {
                    var4 = selRecipe;
                }

                if (var4 == null)
                {
                    var4 = var5;
                }

                if (var4 != null)
                {
                    ItemStack var40;

                    if (var4 instanceof ShapedRecipes)
                    {
                        var24 = (ItemStack[])((ItemStack[])getValue(fRMap, var4));
                        var40 = (ItemStack)getValue(fRResA, var4);
                        var26 = ((Integer)getValue(fRWidth, var4)).intValue();
                        var27 = ((Integer)getValue(fRHeight, var4)).intValue();

                        for (int var28 = 0; var28 < var27; ++var28)
                        {
                            for (int var29 = 0; var29 < var26; ++var29)
                            {
                                int var30 = var28 * var26 + var29;

                                if (var30 < var24.length && var24[var30] != null)
                                {
                                    drawItem(var24[var30], var15 + var29 * 16, 28 + var16 + var28 * 16);
                                }
                            }
                        }

                        drawItem(var40, var15, var16);
                        var33 = "     x " + getItemsCount(var40);
                        var38 = "Shaped recipe:";
                    }
                    else if (var4 instanceof ShapelessRecipes)
                    {
                        var36 = (List)getValue(fRList, var4);
                        var40 = (ItemStack)getValue(fRResB, var4);
                        var21 = var36.iterator();
                        var26 = 0;
                        var27 = 0;

                        while (var21.hasNext())
                        {
                            drawItem((ItemStack)var21.next(), var15 + var26 * 16, 28 + var16 + var27 * 16);
                            ++var26;

                            if (var26 > 3)
                            {
                                var26 = 0;
                                ++var27;
                            }
                        }

                        drawItem(var40, var15, var16);
                        var33 = "     x " + getItemsCount(var40);
                        var38 = "Shapeless recipe:";
                    }
                }

                GL11.glDisable(GL11.GL_LIGHTING);
                GL11.glDisable(GL12.GL_RESCALE_NORMAL);

                if (var33 != null)
                {
                    showText(var33, var15, var16 + 6, 15658734);
                    showText(var38, var15, var16 + 18, 15658734);
                }
            }
        }
        else
        {
            selRecipe = null;
        }
    }

    private static String textModRecipe(String var0)
    {
        if (modRecipeEnabled && optRecipeShowId)
        {
            ItemStack var1 = invItemsArr[getInvCur()];

            if (var1 != null)
            {
                int var2 = getItemsId(var1);
                var0 = var0 + "id:" + (getItemHasSubTypes(getItem(var2)) ? var2 + "/" + getItemsInfo(var1) : Integer.valueOf(var2)) + " ";
            }

            return var0;
        }
        else
        {
            return var0;
        }
    }

    private static boolean initModSafe()
    {
        safeMark = new ZMod$Mark[2048];
        log("info: loading config for \"safe\"");
        optSafeDangerColor = getColor("optSafeDangerColor", 16711680);
        optSafeDangerColorSun = getColor("optSafeDangerColorSun", 14540032);
        tagSafe = getString("tagSafe", "safe");
        optionsModSafe();
        return true;
    }

    private static void optionsModSafe()
    {
        keySafeShow = getSetBind(keySafeShow, "keySafeShow", 38, "Show / hide un-safe markers");
        optSafeShowWithSun = getSetBool(optSafeShowWithSun, "optSafeShowWithSun", true, "Mark \'safe at midday\' differently");
    }

    private static void updateModSafe()
    {
        if (modSafeEnabled && !isMenu && keyPress(keySafeShow))
        {
            safeShow = !safeShow;
        }
    }

    public static void drawModSafe(float var0, float var1, float var2)
    {
        if (modSafeEnabled && safeShow)
        {
            if (--safeUpdate < 0)
            {
                safeUpdate = 16;
                reCheckSafe(fix(posX), fix(posY), fix(posZ));
            }

            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glBegin(GL11.GL_LINES);

            for (int var6 = 0; var6 < safeCur; ++var6)
            {
                ZMod$Mark var7 = safeMark[var6];

                if (var7.r == 1)
                {
                    GL11.glColor3ub(optSafeDangerColorSun.r, optSafeDangerColorSun.g, optSafeDangerColorSun.b);
                }
                else
                {
                    GL11.glColor3ub(optSafeDangerColor.r, optSafeDangerColor.g, optSafeDangerColor.b);
                }

                float var3 = var7.x - var0;
                float var4 = var7.y - var1;
                float var5 = var7.z - var2;
                GL11.glVertex3f(var3 + 0.5F, var4, var5 + 0.5F);
                GL11.glVertex3f(var3 - 0.5F, var4, var5 - 0.5F);
                GL11.glVertex3f(var3 + 0.5F, var4, var5 - 0.5F);
                GL11.glVertex3f(var3 - 0.5F, var4, var5 + 0.5F);
            }

            GL11.glEnd();
            GL11.glEnable(GL11.GL_TEXTURE_2D);
        }
    }

    private static String textModSafe(String var0)
    {
        return modSafeEnabled && safeShow && tagSafe.length() != 0 ? var0 + tagSafe + " " : var0;
    }

    private static void reCheckSafe(int var0, int var1, int var2)
    {
        safeCur = 0;
        short var4 = 16384;
        int var5 = 16390;
        short var6 = 16384;
        int var7 = 0;

        if (modSpawnEnabled && !isMultiplayer)
        {
            if (!optSpawnAllowInNonAir)
            {
                var5 |= 512;
            }

            if (!optSpawnAllowOnNonNatural)
            {
                var7 |= 8;
            }

            if (!optSpawnAllowOnGrass)
            {
                var7 |= 128;
            }

            if (!optSpawnAllowOnCobble)
            {
                var7 |= 256;
            }

            if (!optSpawnAllowOnSand)
            {
                var7 |= 1024;
            }

            if (!optSpawnAllowOnGravel)
            {
                var7 |= 2048;
            }

            if (!optSpawnAllowOnTree)
            {
                var7 |= 64;
            }

            if (!optSpawnAllowOnSandstone)
            {
                var7 |= 65536;
            }
        }

        for (int var8 = var0 - 16; var8 < var0 + 16; ++var8)
        {
            for (int var9 = var1 - 16; var9 < var1 + 16; ++var9)
            {
                for (int var10 = var2 - 16; var10 < var2 + 16; ++var10)
                {
                    int var11;

                    if (((var11 = block[mapXGetId(var8, var9, var10)]) & var4) != 0 && (var11 & var7) == 0 && (block[mapXGetId(var8, var9 + 1, var10)] & var5) == 0 && (block[mapXGetId(var8, var9 + 2, var10)] & var6) == 0 && getLightLevel(var8, var9 + 1, var10, 16) <= 7)
                    {
                        safeMark[safeCur++] = new ZMod$Mark(var8, var9 + 1, var10, optSafeShowWithSun && getLightLevel(var8, var9 + 1, var10, 0) > 7);

                        if (safeCur == 2048)
                        {
                            return;
                        }
                    }
                }
            }
        }
    }

    private static boolean initModBoom()
    {
        log("info: loading config for \"boom\"");
        optionsModBoom();
        return checkClass(Explosion.class, "boom");
    }

    private static void optionsModBoom()
    {
        optBoomDropOreChance = (float)getSetInt((int)(optBoomDropOreChance * 100.0F), "optBoomDropOreChance", 100, 0, 100, "Drop ore chance") / 100.0F;
        optBoomDropChance = (float)getSetInt((int)(optBoomDropChance * 100.0F), "optBoomDropChance", 30, 0, 100, "Drop non-ore chance") / 100.0F;
        optBoomScaleTNT = getSetFloat(optBoomScaleTNT, "optBoomScaleTNT", 1.0F, 0.1F, 10.0F, "TNT explosion multiplier");
        optBoomScaleCreeper = getSetFloat(optBoomScaleCreeper, "optBoomScaleCreeper", 1.0F, 0.1F, 10.0F, "Creeper explosion multiplier");
        optBoomScaleFireball = getSetFloat(optBoomScaleFireball, "optBoomScaleFireball", 1.0F, 0.1F, 10.0F, "Fireball explosion multiplier");
        optBoomSafeRange = getSetInt(optBoomSafeRange, "optBoomSafeRange", 16, -1, 32, "Damage prevention range (-1=inf, 0=off)");
    }

    public static float boomDropHandle(int var0)
    {
        return modBoomEnabled && !isMultiplayer ? ((block[var0] & 4096) != 0 ? optBoomDropOreChance : optBoomDropChance) : 0.3F;
    }

    public static boolean boomDamageHandle(int var0, int var1, int var2, int var3)
    {
        boolean var4 = true;

        if (var3 == 1 || var3 == 2)
        {
            if (optBoomSafeRange == -1)
            {
                var4 = false;
            }
            else if (optBoomSafeRange > 0)
            {
                int var5 = var0 - optBoomSafeRange;
                int var6 = var0 + optBoomSafeRange;
                int var7 = var1 - optBoomSafeRange;
                int var8 = var1 + optBoomSafeRange;
                int var9 = var2 - optBoomSafeRange;
                int var10 = var2 + optBoomSafeRange;

                for (int var11 = var5; var11 <= var6; ++var11)
                {
                    for (int var12 = var7; var12 <= var8; ++var12)
                    {
                        for (int var13 = var9; var13 <= var10; ++var13)
                        {
                            if ((block[mapXGetId(var11, var12, var13)] & 8) != 0)
                            {
                                var4 = false;
                                return var4;
                            }
                        }
                    }
                }
            }
        }

        return var4;
    }

    public static float boomScaleHandle(float var0, int var1)
    {
        if (modBoomEnabled && !isMultiplayer)
        {
            switch (var1)
            {
                case 1:
                    var0 *= optBoomScaleCreeper;
                    break;

                case 2:
                    var0 *= optBoomScaleFireball;
                    break;

                case 3:
                    var0 *= optBoomScaleTNT;
            }

            return var0;
        }
        else
        {
            return var0;
        }
    }

    private static boolean initModSpawn()
    {
        log("info: loading config for \"spawn\"");
        optSpawnSupportMods = getBool("optSpawnSupportMods", true);
        optSpawnPigReduction = getInt("optSpawnPigReduction", 75, 0, 100);
        optSpawnChickenReduction = getInt("optSpawnChickenReduction", 0, 0, 100);
        optSpawnCowReduction = getInt("optSpawnCowReduction", 0, 0, 100);
        optSpawnSheepReduction = getInt("optSpawnSheepReduction", 0, 0, 100);
        optSpawnSquidReduction = getInt("optSpawnSquidReduction", 0, 0, 100);
        optSpawnWolfReduction = getInt("optSpawnWolfReduction", 0, 0, 100);
        optSpawnSpiderReduction = getInt("optSpawnSpiderReduction", 0, 0, 100);
        optSpawnSkeletonReduction = getInt("optSpawnSkeletonReduction", 0, 0, 100);
        optSpawnCreeperReduction = getInt("optSpawnCreeperReduction", 0, 0, 100);
        optSpawnZombieReduction = getInt("optSpawnZombieReduction", 0, 0, 100);
        optSpawnSlimeReduction = getInt("optSpawnSlimeReduction", 0, 0, 100);
        optSpawnGhastReduction = getInt("optSpawnGhastReduction", 0, 0, 100);
        optSpawnPigZombieReduction = getInt("optSpawnPigZombieReduction", 0, 0, 100);
        optSpawnCaveSpiderReduction = getInt("optSpawnCaveSpiderReduction", 0, 0, 100);
        optSpawnEndermanReduction = getInt("optSpawnEndermanReduction", 0, 0, 100);
        optSpawnSilverfishReduction = getInt("optSpawnSilverfishReduction", 0, 0, 100);
        optionsModSpawn();
        return true;
    }

    private static void optionsModSpawn()
    {
        optSpawnAllowInNonAir = getSetBool(optSpawnAllowInNonAir, "optSpawnAllowInNonAir", false, "Allow in non-air (reeds, wheat etc)");
        optSpawnAllowOnNonNatural = getSetBool(optSpawnAllowOnNonNatural, "optSpawnAllowOnNonNatural", false, "Allow on non-natural");
        optSpawnAllowOnGrass = getSetBool(optSpawnAllowOnGrass, "optSpawnAllowOnGrass", true, "Allow on grass");
        optSpawnAllowOnCobble = getSetBool(optSpawnAllowOnCobble, "optSpawnAllowOnCobble", false, "Allow on cobble");
        optSpawnAllowOnSand = getSetBool(optSpawnAllowOnSand, "optSpawnAllowOnSand", true, "Allow on sand");
        optSpawnAllowOnGravel = getSetBool(optSpawnAllowOnGravel, "optSpawnAllowOnGravel", true, "Allow on gravel");
        optSpawnAllowOnTree = getSetBool(optSpawnAllowOnTree, "optSpawnAllowOnTree", false, "Allow on tree (leaves, trunk)");
        optSpawnAllowOnSandstone = getSetBool(optSpawnAllowOnSandstone, "optSpawnAllowOnSandstone", false, "Allow on sandstone");
    }

    private static void updateModSpawn(List var0)
    {
        if (modSpawnEnabled && !isMultiplayer)
        {
            Iterator var1 = var0.iterator();
            int var2 = 0;

            if (!optSpawnAllowOnGrass)
            {
                var2 |= 128;
            }

            if (!optSpawnAllowOnCobble)
            {
                var2 |= 256;
            }

            if (!optSpawnAllowOnSand)
            {
                var2 |= 1024;
            }

            if (!optSpawnAllowOnGravel)
            {
                var2 |= 2048;
            }

            if (!optSpawnAllowOnTree)
            {
                var2 |= 64;
            }

            if (!optSpawnAllowOnNonNatural)
            {
                var2 |= 8;
            }

            if (!optSpawnAllowOnSandstone)
            {
                var2 |= 65536;
            }

            while (var1.hasNext())
            {
                Entity var3 = (Entity)var1.next();

                if (getEntityAge(var3) == 1)
                {
                    boolean var4 = false;

                    switch (getEntityType(var3))
                    {
                        case 1:
                            if (optSpawnGhastReduction != 0 && rnd.nextInt(100) < optSpawnGhastReduction)
                            {
                                var4 = true;
                            }

                            break;

                        case 2:
                            if (optSpawnCowReduction != 0 && rnd.nextInt(100) < optSpawnCowReduction)
                            {
                                var4 = true;
                            }

                            break;

                        case 3:
                            if (optSpawnSpiderReduction != 0 && rnd.nextInt(100) < optSpawnSpiderReduction)
                            {
                                var4 = true;
                            }

                            break;

                        case 4:
                            if (optSpawnSheepReduction != 0 && rnd.nextInt(100) < optSpawnSheepReduction)
                            {
                                var4 = true;
                            }

                            break;

                        case 5:
                            if (optSpawnSkeletonReduction != 0 && rnd.nextInt(100) < optSpawnSkeletonReduction)
                            {
                                var4 = true;
                            }

                            break;

                        case 6:
                            if (optSpawnCreeperReduction != 0 && rnd.nextInt(100) < optSpawnCreeperReduction)
                            {
                                var4 = true;
                            }

                            break;

                        case 7:
                            if (optSpawnZombieReduction != 0 && rnd.nextInt(100) < optSpawnZombieReduction)
                            {
                                var4 = true;
                            }

                            break;

                        case 8:
                            if (optSpawnSlimeReduction != 0 && rnd.nextInt(100) < optSpawnSlimeReduction)
                            {
                                var4 = true;
                            }

                            break;

                        case 9:
                            if (optSpawnPigReduction != 0 && rnd.nextInt(100) < optSpawnPigReduction)
                            {
                                var4 = true;
                            }

                            break;

                        case 10:
                            if (optSpawnChickenReduction != 0 && rnd.nextInt(100) < optSpawnChickenReduction)
                            {
                                var4 = true;
                            }

                            break;

                        case 11:
                            if (optSpawnSquidReduction != 0 && rnd.nextInt(100) < optSpawnSquidReduction)
                            {
                                var4 = true;
                            }

                            break;

                        case 12:
                            if (optSpawnPigZombieReduction != 0 && rnd.nextInt(100) < optSpawnPigZombieReduction)
                            {
                                var4 = true;
                            }

                            break;

                        case 13:
                        default:
                            continue;

                        case 14:
                            if (!optSpawnSupportMods)
                            {
                                continue;
                            }

                            break;

                        case 15:
                            if (optSpawnWolfReduction != 0 && rnd.nextInt(100) < optSpawnWolfReduction)
                            {
                                var4 = true;
                            }

                            break;

                        case 16:
                            if (optSpawnCaveSpiderReduction != 0 && rnd.nextInt(100) < optSpawnCaveSpiderReduction)
                            {
                                var4 = true;
                            }

                            break;

                        case 17:
                            if (optSpawnEndermanReduction != 0 && rnd.nextInt(100) < optSpawnEndermanReduction)
                            {
                                var4 = true;
                            }

                            break;

                        case 18:
                            if (optSpawnSilverfishReduction != 0 && rnd.nextInt(100) < optSpawnSilverfishReduction)
                            {
                                var4 = true;
                            }
                    }

                    if (!var4)
                    {
                        int var5 = fix(getEntityPosX(var3));
                        int var6 = fix(getEntityPosY(var3));
                        int var7 = fix(getEntityPosZ(var3));

                        if (!optSpawnAllowInNonAir && (block[mapXGetId(var5, var6, var7)] & 512) != 0)
                        {
                            var4 = true;
                        }

                        if (var2 != 0 && (block[mapXGetId(var5, var6 - 1, var7)] & var2) != 0)
                        {
                            var4 = true;
                        }
                    }

                    if (var4)
                    {
                        dieEntity(var3);
                    }
                }
            }
        }
    }

    private static boolean initModOre()
    {
        log("info: loading config for \"ore\"");
        optOreLavaFloor = getBool("optOreLavaFloor", true);

        if ((optOreCoalRule = parseRule(getString("optOreCoalRule", "75/80/48/8/16/1  10/120/32/128/4/1 5/120/64/1/128/1"))) == null)
        {
            return false;
        }
        else if ((optOreIronRule = parseRule(getString("optOreIronRule", "100/80/16/8/16/1 100/96/8/16/8/1   5/120/64/128/1/1"))) == null)
        {
            return false;
        }
        else if ((optOreGoldRule = parseRule(getString("optOreGoldRule", "50/32/4/4/16/1   5/96/8/8/64/1"))) == null)
        {
            return false;
        }
        else if ((optOreBlueRule = parseRule(getString("optOreBlueRule", "100/32/8/2/8/1   5/56/48/64/2/1    5/96/48/1/32/1/1"))) == null)
        {
            return false;
        }
        else if ((optOreRedRule = parseRule(getString("optOreRedRule", "100/32/8/2/8/1   10/120/96/64/1/1"))) == null)
        {
            return false;
        }
        else if ((optOreDiamondRule = parseRule(getString("optOreDiamondRule", "75/16/4/2/8/1    100/32/2/128/2/11 10/120/16/2/8/1"))) == null)
        {
            return false;
        }
        else
        {
            optionsModOre();
            return true;
        }
    }

    private static void optionsModOre() {}

    private static void updateModOre()
    {
        if (modOreEnabled && !isMultiplayer && !isHell)
        {
            int var0 = fix(posX) >> 4;
            int var1 = fix(posZ) >> 4;

            for (int var6 = var0 - 3; var6 <= var0 + 3; ++var6)
            {
                for (int var7 = var1 - 3; var7 <= var1 + 3; ++var7)
                {
                    if (mapXGetChunkExists(var6, var7))
                    {
                        Chunk var8 = map.getChunkFromChunkCoords(var6, var7);

                        if (var8.getBlockID(0, 0, 8) == 7)
                        {
                            var8.setBlockID(0, 0, 8, 0);
                            var8.setBlockID(0, 1, 8, 7);

                            for (int var9 = 0; var9 < 16; ++var9)
                            {
                                for (int var10 = 0; var10 < 16; ++var10)
                                {
                                    int var11 = var8.getHeightValue(var9, var10);

                                    for (int var12 = 0; var12 <= var11; ++var12)
                                    {
                                        int var5 = var8.getBlockID(var9, var12, var10);

                                        if (var5 <= 255)
                                        {
                                            if ((block[var5] & 4096) != 0)
                                            {
                                                var8.setBlockID(var9, var12, var10, 1);
                                            }
                                            else if (var5 == 7 && var12 > 1)
                                            {
                                                var8.setBlockID(var9, var12, var10, optOreLavaFloor ? 11 : 1);
                                            }
                                            else if (var12 == 1)
                                            {
                                                var8.setBlockID(var9, var12, var10, 7);
                                            }
                                        }
                                    }
                                }
                            }

                            oreDistribute(var8, optOreCoalRule, 16);
                            oreDistribute(var8, optOreIronRule, 15);
                            oreDistribute(var8, optOreGoldRule, 14);
                            oreDistribute(var8, optOreBlueRule, 21);
                            oreDistribute(var8, optOreRedRule, 73);
                            oreDistribute(var8, optOreDiamondRule, 56);
                            chunkNeedsUpdate(var6, var7);
                        }
                    }
                }
            }
        }
    }

    private static void oreDistribute(Chunk var0, int[] var1, int var2)
    {
        for (int var3 = 0; var3 < var1.length; var3 += 6)
        {
            int var4 = var1[var3 + 0];
            int var5 = var1[var3 + 1];
            int var6 = var1[var3 + 2];
            int var7 = var1[var3 + 3];
            int var8 = var1[var3 + 4];
            int var9 = var1[var3 + 5];

            if (var4 >= 100 || rnd.nextInt(100) < var4)
            {
                while (var7-- > 0)
                {
                    int var10 = rnd.nextInt(14) + 1;
                    int var11 = rnd.nextInt(1 + var5 - var6) + var6;
                    int var12 = rnd.nextInt(14) + 1;
                    int var13 = var10 << 11 | var12 << 7 | var11;

                    if (var0.getBlockID(var10, var11, var12) == 1 && var0.getBlockID(var10, var11 - 1, var12) == 1 && var0.getBlockID(var10, var11 + 1, var12) == var9 && var0.getBlockID(var10 + 1, var11, var12) == 1 && var0.getBlockID(var10 - 1, var11, var12) == 1 && var0.getBlockID(var10, var11, var12 + 1) == 1 && var0.getBlockID(var10, var11, var12 - 1) == 1)
                    {
                        int var14 = var8 - 1;
                        var0.setBlockID(var10, var11, var12, var2);

                        while (var14-- > 0)
                        {
                            switch (rnd.nextInt(7))
                            {
                                case 0:
                                    continue;

                                case 1:
                                    ++var10;
                                    break;

                                case 2:
                                    --var10;
                                    break;

                                case 3:
                                    ++var11;
                                    break;

                                case 4:
                                    --var11;
                                    break;

                                case 5:
                                    ++var12;
                                    break;

                                case 6:
                                    --var12;
                            }

                            var10 &= 15;
                            var12 &= 15;
                            var11 &= 255;

                            if (var0.getBlockID(var10, var11, var12) == 1)
                            {
                                var0.setBlockID(var10, var11, var12, var2);
                            }
                        }
                    }
                }
            }
        }
    }

    private static boolean initModTeleport()
    {
        log("info: loading config for \"teleport\"");
        optTeleportItem = getBlockId("optTeleportItem", 42);
        optTeleportPlayer = getBlockId("optTeleportPlayer", 41);
        optTeleportCritter = getBlockId("optTeleportCritter", 57);
        optTeleportUseItem = getItemId("optTeleportUseItem", 331);
        optionsModTeleport();
        return true;
    }

    private static void optionsModTeleport()
    {
        keyTeleportUp = getSetBind(keyTeleportUp, "keyTeleportUp", 201, "Teleport up");
        keyTeleportDown = getSetBind(keyTeleportDown, "keyTeleportDown", 209, "Teleport down");
        keyTeleportCursor = getSetBind(keyTeleportCursor, "keyTeleportCursor", 205, "Teleport at cursor");
        optTeleportIsSelected = getSetBool(optTeleportIsSelected, "optTeleportIsSelected", true, "Teleport item must be selected");
    }

    private static void updateModTeleport(List var0)
    {
        if (modTeleportEnabled && !isMultiplayer)
        {
            Iterator var1 = var0.iterator();
            Object var8 = null;
            int var3;
            int var4;
            int var5;
            int var6;
            boolean var11;
            int var13;

            while (var1.hasNext())
            {
                Entity var9 = (Entity)var1.next();
                int var2 = getEntityType(var9);

                if (!isMultiplayer || var9 == player)
                {
                    var3 = fix(getEntityPosX(var9));
                    var4 = fix(getEntityPosY(var9)) - 1;
                    var5 = fix(getEntityPosZ(var9));
                    int var7 = 0;
                    var6 = mapXGetId(var3, var4, var5);

                    if ((block[var6] & 2) == 0)
                    {
                        --var4;
                        var6 = mapXGetId(var3, var4, var5);
                        ++var7;
                    }

                    if ((var2 != 0 || var6 == optTeleportItem && var9 instanceof EntityItem) && (var2 == 0 || var2 == 13 || var6 == optTeleportCritter) && (var2 != 13 || var6 == optTeleportPlayer))
                    {
                        String[] var10 = null;
                        var6 = mapXGetId(var3, var4 + 1, var5);

                        if (var6 == 63 || var6 == 68)
                        {
                            var10 = getSignText(var3, var4 + 1, var5);
                        }

                        var6 = mapXGetId(var3, var4 + 2, var5);

                        if (var6 == 63 || var6 == 68)
                        {
                            var10 = getSignText(var3, var4 + 2, var5);
                        }

                        var6 = mapXGetId(var3, var4 - 1, var5);

                        if (var6 == 63 || var6 == 68)
                        {
                            var10 = getSignText(var3, var4 - 1, var5);
                        }

                        if (var10 != null)
                        {
                            try
                            {
                                var3 = 0;
                                var4 = -1;
                                var5 = 0;
                                var11 = false;
                                boolean var12 = false;

                                for (var13 = 0; var13 < var10.length; ++var13)
                                {
                                    if (var10[var13] != null && var10[var13].length() > 1)
                                    {
                                        if (var10[var13].charAt(0) == 33)
                                        {
                                            String[] var14 = var10[var13].substring(1).split(",");

                                            if (var14.length != 3)
                                            {
                                                break;
                                            }

                                            var3 = (new Integer(var14[0])).intValue();
                                            var4 = (new Integer(var14[1])).intValue();
                                            var5 = (new Integer(var14[2])).intValue();
                                        }
                                        else if (var10[var13].charAt(0) == 63)
                                        {
                                            String var24;

                                            if (var10[var13].charAt(1) == 33)
                                            {
                                                var24 = var10[var13].substring(2);
                                                var6 = (names.containsKey(var24) ? ((Integer)names.get(var24)).intValue() : parseIdInfo(var24)) & 65535;

                                                if (var2 != 0 && var2 != 13 && var6 == var2)
                                                {
                                                    var4 = -1;
                                                    break;
                                                }

                                                if (var2 == 0 && var9 instanceof EntityItem && getItemsId(getEntityItemStack((EntityItem)var9)) == var6)
                                                {
                                                    var4 = -1;
                                                    break;
                                                }
                                            }
                                            else
                                            {
                                                var12 = true;
                                                var24 = var10[var13].substring(1);
                                                var6 = (names.containsKey(var24) ? ((Integer)names.get(var24)).intValue() : parseIdInfo(var24)) & 65535;

                                                if (var2 != 0 && var2 != 13 && var6 == var2)
                                                {
                                                    var11 = true;
                                                }
                                                else if (var2 == 0 && var9 instanceof EntityItem && getItemsId(getEntityItemStack((EntityItem)var9)) == var6)
                                                {
                                                    var11 = true;
                                                }
                                            }
                                        }
                                    }
                                }

                                if (var4 != -1 && (!var12 || var11))
                                {
                                    Entity var20 = getOnEntity(var9);

                                    if (var20 != null)
                                    {
                                        setEntityPos(var20, 0.5D + (double)var3, 0.0D + (double)(var4 + var7), 0.5D + (double)var5);
                                        setEntityPos(var9, 0.5D + (double)var3, getMountOffset(var20) + (double)(var4 + var7), 0.5D + (double)var5);
                                    }
                                    else
                                    {
                                        setEntityPos(var9, 0.5D + (double)var3, 0.5D + (double)(var4 + var7), 0.5D + (double)var5);
                                    }

                                    if (var2 == 13)
                                    {
                                        var8 = var9;
                                    }
                                }
                            }
                            catch (Exception var16)
                            {
                                ;
                            }
                        }
                    }
                }
            }

            if (!isMenu && inWhat == null)
            {
                byte var17 = 0;
                var11 = false;

                if (keyPress(keyTeleportUp))
                {
                    var17 = 1;
                }
                else if (keyPress(keyTeleportDown))
                {
                    var17 = -1;
                }

                var3 = fix(getEntityPosX(player));
                var4 = fix(getEntityPosY(player));
                var5 = fix(getEntityPosZ(player));
                int var23;
                int var22;

                if (var17 != 0)
                {
                    boolean[] var18 = new boolean[131];
                    boolean var21;

                    for (var21 = false; var4 > 1 && (block[mapXGetId(var3, var4 - 1, var5)] & 2) == 0; --var4)
                    {
                        ;
                    }

                    for (var23 = 0; var23 < 131; ++var23)
                    {
                        var6 = mapXGetId(var3, var23, var5);

                        if ((block[var6] & 2) != 0 && var6 != 81)
                        {
                            var21 = true;
                        }
                        else if (var6 == 10 || var6 == 11 || var6 == 51 || var6 == 81 || var23 == var4)
                        {
                            var21 = false;
                        }

                        var18[var23] = var21 && (block[var6] & 32) != 0;

                        if (var23 > 2 && !var18[var23] && var18[var23 - 1] && !var18[var23 - 3])
                        {
                            var18[var23 - 1] = var18[var23 - 2] = false;
                        }
                    }

                    for (var23 = 130; var23 > 0; --var23)
                    {
                        if (var18[var23] && var18[var23 - 1])
                        {
                            var18[var23] = false;
                        }
                    }

                    while (var4 > 0 && var4 < 129)
                    {
                        if (var18[var4 += var17])
                        {
                            if (var4 >= 1 && (!isHell || var4 <= 127))
                            {
                                var11 = true;
                                ++var4;
                            }

                            break;
                        }
                    }
                }
                else if (keyPress(keyTeleportCursor) && rayTrace(256.0D, 0.0F))
                {
                    var3 = rayHitX();
                    var4 = rayHitY();
                    var5 = rayHitZ();
                    int var19 = rayHitSide();

                    if (var19 == 0)
                    {
                        --var4;
                    }

                    if (var19 == 1)
                    {
                        ++var4;
                    }

                    if (var19 == 2)
                    {
                        --var5;
                    }

                    if (var19 == 3)
                    {
                        ++var5;
                    }

                    if (var19 == 4)
                    {
                        --var3;
                    }

                    if (var19 == 5)
                    {
                        ++var3;
                    }

                    var22 = var4;
                    var6 = 0;

                    if (!fly)
                    {
                        while (var22 > 0 && (block[var6 = mapXGetId(var3, var22 - 1, var5)] & 2) == 0)
                        {
                            --var22;
                        }
                    }

                    if (mapXGetId(var3, var22 - 1, var5) != 81 && var6 != 10 && var6 != 11 && var6 != 51)
                    {
                        if ((block[mapXGetId(var3, var4 + 1, var5)] & 2) != 0)
                        {
                            --var4;
                        }
                        else if ((block[mapXGetId(var3, var4 - 1, var5)] & 2) != 0)
                        {
                            ++var4;
                        }

                        if (var4 - var22 < 4 && (block[mapXGetId(var3, var4 - 1, var5)] & 32) != 0 && (block[mapXGetId(var3, var4, var5)] & 32) != 0 && (block[mapXGetId(var3, var4 + 1, var5)] & 32) != 0)
                        {
                            var11 = true;
                        }
                    }
                }

                if (var11 && optTeleportUseItem != 0)
                {
                    var22 = getInvCur();
                    var13 = -1;

                    for (int var15 = 0; var15 < 36; ++var15)
                    {
                        if (invItemsArr[var15] != null && isItemsMatch(invItemsArr[var15], optTeleportUseItem) && (!optTeleportIsSelected || var15 == var22))
                        {
                            var13 = var15;
                            break;
                        }
                    }

                    if (var13 == -1)
                    {
                        var11 = false;
                    }
                    else
                    {
                        var23 = getItemsCount(invItemsArr[var13]) - 1;

                        if (var23 == 0)
                        {
                            invItemsArr[var13] = null;
                        }
                        else
                        {
                            setItemsCount(invItemsArr[var13], var23);
                        }
                    }
                }

                if (var11)
                {
                    setEntityPos(player, 0.5D + (double)var3, 0.75D + (double)var4, 0.5D + (double)var5);
                    var8 = player;
                }
            }

            if (var8 != null)
            {
                noiseTP((Entity)var8);
            }
        }
    }

    private static boolean initModCheat()
    {
        cheatMobs = new ZMod$Mark[27];
        cheatOres = new ZMod$Mark[256];
        cheatMark = new ZMod$Mark[16384];
        cheatDamage = new boolean[400];
        cheatAmbItems = makeBuffer(new float[] {4.0F, 4.0F, 4.0F, 1.0F});
        cheatAmbGeom = makeBuffer(new float[] {0.0F, 0.0F, 0.0F, 1.0F});
        log("info: loading config for \"cheat\"");
        getDeprecated("optCheatHighlightMode");
        optionsModCheat();

        if (!optCheatFallDamage)
        {
            checkClass(EntityPlayer.class, "cheat", "fall damage is not disabled in MP");
        }

        String[] var0 = getString("optCheatShowOres", "15/0x008888, 82/0x00ffff, 14/0xffee00, 56/0xeeffff, 48/0x00ff00, 21/0x0000ff, 73/0xff0000, 52/0xff00ff, 16/0x444444").split("[\\t ]*,[\\t ]*");
        int var1;
        String[] var2;
        ZMod$Mark var3;
        int var4;

        for (var1 = 0; var1 < var0.length; ++var1)
        {
            var2 = var0[var1].split("/");

            if (var2.length == 2)
            {
                var3 = new ZMod$Mark();
                var4 = names.containsKey(var2[0]) ? ((Integer)((Integer)names.get(var2[0]))).intValue() : parseUnsigned(var2[0]);

                if (var4 > 0 && var4 < 256 && var3.loadColor(var2[1]))
                {
                    cheatOres[var4] = var3;
                    continue;
                }
            }

            err("error: config.txt @ optCheatOres - invalid ore/color pair \"" + var0[var1] + "\"");
        }

        var0 = getString("optCheatShowMobs", "1/0x000088, 3/0x880000, 5/0x888888, 6/0x008800, 7/0x888800, 8/0x880088, 12/0x008888, 11/0x000044, 2/0x444400, 4/0x444444, 9/0x440000, 10/0x004444, 14/0x004400, 15/0xffffff").split("[\\t ]*,[\\t ]*");

        for (var1 = 0; var1 < var0.length; ++var1)
        {
            var2 = var0[var1].split("/");

            if (var2.length == 2)
            {
                var3 = new ZMod$Mark();
                var4 = names.containsKey(var2[0]) ? ((Integer)((Integer)names.get(var2[0]))).intValue() : parseUnsigned(var2[0]);

                if (var4 >= 0 && var4 < 27 && var3.loadColor(var2[1]))
                {
                    cheatMobs[var4] = var3;
                    continue;
                }
            }

            err("error: config.txt @ optCheatMobs - invalid mob/color pair \"" + var0[var1] + "\"");
        }

        tagCheater = getString("tagCheater", "cheater");
        return true;
    }

    private static void optionsModCheat()
    {
        keyCheat = getSetBind(keyCheat, "keyCheat", 21, "Toggle cheat mode");
        optCheatShowHealth = getSetBool(optCheatShowHealth, "optCheatShowHealth", true, "Show critter health");
        keyCheatHighlight = getSetBind(keyCheatHighlight, "keyCheatHighlight", 35, "Toggle light level");
        keyCheatRemoveFire = getSetBind(keyCheatRemoveFire, "keyCheatRemoveFire", 49, "Remove fire nearby");
        keyCheatView = getSetBind(keyCheatView, "keyCheatView", 76, "Get player view");
        keyCheatHealth = getSetBind(keyCheatHealth, "keyCheatHealth", 0, "Toggle invulnerability");
        keyCheatShowMobs = getSetBind(keyCheatShowMobs, "keyCheatShowMobs", 50, "Show / hide critters");
        optCheatShowMobsRange = getSetInt(optCheatShowMobsRange, "optCheatShowMobsRange", 0, 0, 256, "Show critters max range");
        optCheatShowMobsSize = getSetBool(optCheatShowMobsSize, "optCheatShowMobsSize", false, "Use critter height for markers");
        keyCheatShowOres = getSetBind(keyCheatShowOres, "keyCheatShowOres", 24, "Show / hide ores");
        optCheatShowOresRangeH = getSetInt(optCheatShowOresRangeH, "optCheatShowOresRangeH", 16, 4, 128, "Show ores horisontal range");
        optCheatShowOresRangeV = getSetInt(optCheatShowOresRangeV, "optCheatShowOresRangeV", 64, 4, 128, "Show ores vertical range");
        keyCheatSee = getSetBind(keyCheatSee, "keyCheatSee", 23, "See through solid objects");
        optCheatSeeIsToggle = getSetBool(optCheatSeeIsToggle, "optCheatSeeIsToggle", false, "See through is a toggle");
        optCheatSeeDist = getSetFloat(optCheatSeeDist, "optCheatSeeDist", 4.0F, 1.0F, 32.0F, "See through cut distance");
        optCheatRestoreHealth = getSetBool(optCheatRestoreHealth, "optCheatRestoreHealth", false, "Invulnerable");
        optCheatFallDamage = getSetBool(optCheatFallDamage, "optCheatFallDamage", true, "Fall damage");
        optCheatFireImmune = getSetBool(optCheatFireImmune, "optCheatFireImmune", false, "Immune to fire");
        optCheatNerfEnderman = getSetBool(optCheatNerfEnderman, "optCheatNerfEnderman", false, "Enderman is allowed to pick up blocks.");
        optCheatNoAir = getSetBool(optCheatNoAir, "optCheatNoAir", false, "Infinite air supply");
        boolean var0 = optCheatInfArmor;
        optCheatInfArmor = getSetBool(optCheatInfArmor, "optCheatInfArmor", false, "Indestructible armor");

        if (var0 != optCheatInfArmor)
        {
            for (int var1 = 298; var1 <= 317; ++var1)
            {
                cheatDamage[var1] = optCheatInfArmor;
            }
        }

        var0 = optCheatInfSword;
        optCheatInfSword = getSetBool(optCheatInfSword, "optCheatInfSword", false, "Indestructible sword/bow");

        if (var0 != optCheatInfSword)
        {
            cheatDamage[267] = cheatDamage[268] = cheatDamage[272] = cheatDamage[276] = cheatDamage[283] = cheatDamage[261] = optCheatInfSword;
        }

        var0 = optCheatInfTools;
        optCheatInfTools = getSetBool(optCheatInfTools, "optCheatInfTools", false, "Indestructible tools");

        if (var0 != optCheatInfTools)
        {
            cheatDamage[256] = cheatDamage[257] = cheatDamage[258] = cheatDamage[259] = cheatDamage[269] = cheatDamage[270] = cheatDamage[271] = cheatDamage[273] = cheatDamage[274] = cheatDamage[275] = cheatDamage[277] = cheatDamage[278] = cheatDamage[279] = cheatDamage[284] = cheatDamage[285] = cheatDamage[286] = cheatDamage[290] = cheatDamage[291] = cheatDamage[292] = cheatDamage[293] = cheatDamage[294] = cheatDamage[346] = cheatDamage[359] = optCheatInfTools;
        }
    }

    private static void updateModCheat(List var0)
    {
        if (minecraft.gameSettings.gammaSetting < 100.0F)
        {
            cheatGamma = minecraft.gameSettings.gammaSetting;
        }

        minecraft.gameSettings.gammaSetting = cheating && cheatHighlight && !isMenu ? 1000.0F : cheatGamma;

        if (modCheatEnabled)
        {
            boolean var1 = optCheatNerfEnderman && !isMultiplayer;
            int var3;

            if (var1 != cheatCarryOverride)
            {
                cheatCarryOverride = var1;
                Object var2 = getValue(fCarryBlocks, (Object)null);

                if (cheatCarryBlocks == null)
                {
                    cheatCarryBlocks = new boolean[256];

                    for (var3 = 0; var3 < 256; ++var3)
                    {
                        cheatCarryBlocks[var3] = Array.getBoolean(var2, var3);
                    }
                }

                for (var3 = 0; var3 < 256; ++var3)
                {
                    Array.setBoolean(var2, var3, var1 ? false : cheatCarryBlocks[var3]);
                }
            }

            if (!isMenu && keyPress(keyCheat))
            {
                cheating = !cheating;

                if (!modCheatAllowed && cheating)
                {
                    cheating = false;
                    chatClient("\u00a74zombe\'s \u00a72cheat\u00a74-mod is not allowed on this server.");
                }
            }

            if (!isMultiplayer)
            {
                if ((!cheating || !optCheatRestoreHealth) && getHealth(player) > 200)
                {
                    setHealth(player, 20);
                }

                setEntityFireImmune(player, cheating && optCheatFireImmune);
            }

            if (cheatView != null)
            {
                if (isWorldChange || !cheating || !var0.contains(cheatView) || getView() == player)
                {
                    cheatView = null;
                }

                if (cheatView == null)
                {
                    setView(player);
                }
            }

            if (cheatView != null)
            {
                setMsg(1, "View: \u00a79" + getEntityName(cheatView));
            }

            if (cheating)
            {
                int var28;
                int var31;
                int var30;

                if (!isMenu)
                {
                    if (keyPress(keyCheatView))
                    {
                        if (cheatView != null)
                        {
                            cheatView = null;
                            setView(player);
                        }
                        else
                        {
                            float var24 = (float)posX;
                            float var6 = (float)posY;
                            float var10 = (float)posZ;
                            float var14 = getEntityYaw(player) * 0.017453292F;
                            float var15 = getEntityPitch(player) * 0.017453292F;
                            float var27 = var24 + 100.0F * -((float)Math.sin((double)var14)) * (float)Math.abs(Math.cos((double)var15));
                            float var7 = var6 + 100.0F * -((float)Math.sin((double)var15));
                            float var11 = var10 + 100.0F * (float)Math.cos((double)var14) * (float)Math.abs(Math.cos((double)var15));
                            EntityLiving var19 = null;
                            float var20 = 1.0E9F;
                            Iterator var21 = var0.iterator();

                            while (var21.hasNext())
                            {
                                Object var22 = var21.next();

                                if (var22 instanceof EntityLiving && var22 != player)
                                {
                                    EntityLiving var23 = (EntityLiving)var22;

                                    if (var23 instanceof EntityPlayer)
                                    {
                                        float var4 = (float)getEntityPosX(var23);
                                        float var8 = (float)getEntityPosY(var23);
                                        float var12 = (float)getEntityPosZ(var23);

                                        if ((var27 - var24) * (var4 - var24) + (var7 - var6) * (var8 - var6) + (var11 - var10) * (var12 - var10) >= 0.0F)
                                        {
                                            float var18 = 1.0F / ((var24 - var4) * (var24 - var4) + (var6 - var8) * (var6 - var8) + (var10 - var12) * (var10 - var12));
                                            float var5 = var27 - var24;
                                            float var9 = var7 - var6;
                                            float var13 = var11 - var10;
                                            float var16 = var5 * var5 + var9 * var9 + var13 * var13;
                                            var16 = ((var4 - var24) * (var27 - var24) + (var8 - var6) * (var7 - var6) + (var12 - var10) * (var11 - var10)) / var16;
                                            var5 = var24 + var16 * (var27 - var24) - var4;
                                            var9 = var6 + var16 * (var7 - var6) - var8;
                                            var13 = var10 + var16 * (var11 - var10) - var12;
                                            float var17 = (var5 * var5 + var9 * var9 + var13 * var13) * var18;

                                            if (var17 < var20)
                                            {
                                                var19 = var23;
                                                var20 = var17;
                                            }
                                        }
                                    }
                                }
                            }

                            if (var19 != null)
                            {
                                cheatView = var19;
                                setView(var19);
                            }
                        }
                    }

                    if (keyPress(keyCheatShowMobs))
                    {
                        cheatShowMobs = !cheatShowMobs;
                    }

                    if (keyPress(keyCheatShowOres))
                    {
                        cheatShowOres = !cheatShowOres;
                    }

                    if (keyPress(keyCheatHighlight))
                    {
                        cheatHighlight = !cheatHighlight;
                    }

                    if (keyPress(keyCheatHealth))
                    {
                        optCheatRestoreHealth = !optCheatRestoreHealth;
                    }

                    if (optCheatSeeIsToggle)
                    {
                        if (keyPress(keyCheatSee))
                        {
                            cheatSee = !cheatSee;
                        }
                    }
                    else
                    {
                        cheatSee = keyDown(keyCheatSee);
                    }

                    if (!isMultiplayer && keyPress(keyCheatRemoveFire))
                    {
                        int var25 = fix(posX);
                        var3 = fix(posY);
                        var28 = fix(posZ);

                        for (var30 = -16; var30 <= 16; ++var30)
                        {
                            for (var31 = -16; var31 <= 16; ++var31)
                            {
                                for (int var32 = -16; var32 <= 16; ++var32)
                                {
                                    if (mapXGetId(var25 + var30, var3 + var31, var28 + var32) == 51)
                                    {
                                        mapXSetIdMeta(var25 + var30, var3 + var31, var28 + var32, 0, 0);
                                    }
                                }
                            }
                        }
                    }
                }

                if (!isMultiplayer)
                {
                    if (!optCheatFallDamage)
                    {
                        setFall(player, 0.0F);
                    }

                    if (optCheatRestoreHealth)
                    {
                        setHealth(player, 2000);
                        setFire0(player);
                        setAir(player, 300);
                    }
                    else if (optCheatNoAir)
                    {
                        setAir(player, 300);
                    }

                    boolean var26 = true;

                    if (optCheatInfArrows || optCheatInfArmor || optCheatInfSword || optCheatInfTools)
                    {
                        for (var3 = 0; var3 < invItemsArr.length; ++var3)
                        {
                            if (invItemsArr[var3] != null)
                            {
                                ItemStack var29 = invItemsArr[var3];
                                var30 = getItemsId(var29);

                                if (var30 >= 256 && var30 < 400)
                                {
                                    if (optCheatInfArrows && var30 == 262 && var26)
                                    {
                                        var26 = false;
                                        var31 = getItemsCount(var29);

                                        if (cheatArrowCount - 1 == var31)
                                        {
                                            ++var31;
                                            setItemsCount(var29, var31);
                                        }

                                        cheatArrowCount = var31;
                                    }
                                    else if (cheatDamage[var30])
                                    {
                                        setItemsInfo(var29, 0);
                                    }
                                }
                            }
                        }
                    }

                    if (optCheatInfArmor)
                    {
                        for (var3 = 0; var3 < invArmorsArr.length; ++var3)
                        {
                            if (invArmorsArr[var3] != null)
                            {
                                var28 = getItemsId(invArmorsArr[var3]);

                                if (var28 >= 256 && var28 < 400 && cheatDamage[var28])
                                {
                                    setItemsInfo(invArmorsArr[var3], 0);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private static void startModCheat()
    {
        if (modCheatAllowed && cheating && cheatSee)
        {
            obliqueNearPlaneClip(0.0F, 0.0F, -1.0F, -optCheatSeeDist);
        }
    }

    public static void drawModCheat(float var0, float var1, float var2, List var3)
    {
        if (cheatShowMobs || cheatShowOres || optCheatShowHealth || optInfoShowHealth)
        {
            float var4 = (float)posX;
            float var5 = (float)posY;
            float var6 = (float)posZ;
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            float var7;
            float var8;
            float var9;
            Iterator var10;
            int var13;

            if (!isMultiplayer && (cheating && optCheatShowHealth || optInfoShowHealth))
            {
                GL11.glColor3ub((byte)0, (byte) - 128, (byte)0);
                GL11.glBegin(GL11.GL_QUADS);
                var10 = var3.iterator();

                while (var10.hasNext())
                {
                    Object var11 = var10.next();

                    if (var11 instanceof EntityLiving && var11 != player)
                    {
                        EntityLiving var12 = (EntityLiving)var11;
                        var13 = getHealth(var12);
                        var7 = (float)getEntityPrevPosX(var12);
                        var8 = (float)getEntityPrevPosY(var12) + 0.4F;
                        var9 = (float)getEntityPrevPosZ(var12);
                        var8 += getEntityHeight(var12);
                        float var14 = var9 - var6;
                        float var15 = -(var7 - var4);
                        float var16 = (float)Math.sqrt((double)(var14 * var14 + var15 * var15));
                        float var17 = 0.25F * (float)var13;
                        var7 -= var0;
                        var8 -= var1;
                        var9 -= var2;

                        if (var16 >= 0.1F && var16 <= 64.0F)
                        {
                            var14 /= var16;

                            for (var15 /= var16; var13 > 0; var13 -= 2)
                            {
                                var17 -= 0.3F;
                                float var18 = var17 * var14 * 0.1F;
                                float var20 = var17 * var15 * 0.1F;
                                var17 -= 0.7F;
                                float var19 = var17 * var14 * 0.1F;
                                float var21 = var17 * var15 * 0.1F;
                                GL11.glVertex3f(var7 + var18, var8 - 0.1F, var9 + var20);
                                GL11.glVertex3f(var7 + var19, var8 - 0.1F, var9 + var21);
                                GL11.glVertex3f(var7 + var19, var8 + (var13 == 1 ? 0.0F : 0.1F), var9 + var21);
                                GL11.glVertex3f(var7 + var18, var8 + (var13 == 1 ? 0.0F : 0.1F), var9 + var20);
                            }
                        }
                    }
                }

                GL11.glEnd();
            }

            GL11.glDisable(GL11.GL_DEPTH_TEST);
            GL11.glDisable(GL11.GL_FOG);

            if (modCheatAllowed && cheating && cheatShowMobs)
            {
                var10 = var3.iterator();
                float var22 = (float)(optCheatShowMobsRange * optCheatShowMobsRange);
                GL11.glBegin(GL11.GL_LINES);

                while (var10.hasNext())
                {
                    Entity var24 = (Entity)var10.next();
                    var13 = getEntityType(var24);

                    if (cheatMobs[var13] != null && var24 != player)
                    {
                        var7 = (float)getEntityPosX(var24) - var0;
                        var8 = (float)getEntityPosY(var24) - var1;
                        var9 = (float)getEntityPosZ(var24) - var2;

                        if (optCheatShowMobsRange <= 0 || var7 * var7 + var8 * var8 + var9 * var9 <= var22)
                        {
                            GL11.glColor3ub(cheatMobs[var13].r, cheatMobs[var13].g, cheatMobs[var13].b);
                            GL11.glVertex3f(var7, var8, var9);
                            GL11.glVertex3f(var7, var8 + (!optCheatShowMobsSize && var24 instanceof EntityLiving ? 2.0F : getEntityHeight(var24)), var9);
                        }
                    }
                }

                GL11.glEnd();
            }

            GL11.glBegin(GL11.GL_LINES);

            if (modCheatAllowed && cheating && cheatShowOres)
            {
                cheatRefresh += seconds;

                if (cheatRefresh > 0.3F)
                {
                    cheatReCheck(fix(posX), fix(posY), fix(posZ));
                    cheatRefresh -= 0.3F;
                }

                for (int var23 = 0; var23 < cheatCur; ++var23)
                {
                    ZMod$Mark var25 = cheatMark[var23];
                    GL11.glColor3ub(var25.r, var25.g, var25.b);
                    var7 = var25.x - var0;
                    var8 = var25.y - var1;
                    var9 = var25.z - var2;
                    GL11.glVertex3f(var7 + 0.25F, var8 + 0.25F, var9 + 0.25F);
                    GL11.glVertex3f(var7 - 0.25F, var8 - 0.25F, var9 - 0.25F);
                    GL11.glVertex3f(var7 + 0.25F, var8 + 0.25F, var9 - 0.25F);
                    GL11.glVertex3f(var7 - 0.25F, var8 - 0.25F, var9 + 0.25F);
                    GL11.glVertex3f(var7 + 0.25F, var8 - 0.25F, var9 + 0.25F);
                    GL11.glVertex3f(var7 - 0.25F, var8 + 0.25F, var9 - 0.25F);
                    GL11.glVertex3f(var7 + 0.25F, var8 - 0.25F, var9 - 0.25F);
                    GL11.glVertex3f(var7 - 0.25F, var8 + 0.25F, var9 + 0.25F);
                }
            }

            GL11.glEnd();
            GL11.glEnable(GL11.GL_FOG);
            GL11.glEnable(GL11.GL_DEPTH_TEST);
            GL11.glEnable(GL11.GL_TEXTURE_2D);
        }
    }

    private static String textModCheat(String var0)
    {
        return modCheatAllowed && modCheatEnabled && cheating && tagCheater.length() != 0 ? var0 + tagCheater + " " : var0;
    }

    private static void cheatReCheck(int var0, int var1, int var2)
    {
        cheatCur = 0;

        for (int var3 = var0 - optCheatShowOresRangeH; var3 < var0 + optCheatShowOresRangeH; ++var3)
        {
            for (int var4 = var1 - optCheatShowOresRangeV; var4 < var1 + optCheatShowOresRangeV; ++var4)
            {
                for (int var5 = var2 - optCheatShowOresRangeH; var5 < var2 + optCheatShowOresRangeH; ++var5)
                {
                    ZMod$Mark var6 = cheatOres[mapXGetId(var3, var4, var5)];

                    if (var6 != null)
                    {
                        cheatMark[cheatCur++] = new ZMod$Mark(var3, var4, var5, var6);

                        if (cheatCur == 16384)
                        {
                            return;
                        }
                    }
                }
            }
        }
    }

    private static boolean initModResize()
    {
        resizeChanceBig = new int[27];
        resizeChanceSmall = new int[27];
        resizeSize = new float[27];
        log("info: loading config for \"resize\"");

        for (int var0 = 0; var0 < 27; ++var0)
        {
            resizeChanceBig[var0] = 100;
        }

        resizeChanceBig[2] = 100 - getInt("optResizeCowBig", 10, 0, 100);
        resizeChanceBig[3] = 100 - getInt("optResizeSpiderBig", 10, 0, 100);
        resizeChanceBig[4] = 100 - getInt("optResizeSheepBig", 10, 0, 100);
        resizeChanceBig[5] = 100 - getInt("optResizeSkellyBig", 20, 0, 100);
        resizeChanceBig[7] = 100 - getInt("optResizeZombieBig", 20, 0, 100);
        resizeChanceBig[9] = 100 - getInt("optResizePigBig", 10, 0, 100);
        resizeChanceSmall[2] = getInt("optResizeCowSmall", 30, 0, 100);
        resizeChanceSmall[3] = getInt("optResizeSpiderSmall", 50, 0, 100);
        resizeChanceSmall[4] = getInt("optResizeSheepSmall", 30, 0, 100);
        resizeChanceSmall[5] = getInt("optResizeSkellySmall", 10, 0, 100);
        resizeChanceSmall[7] = getInt("optResizeZombieSmall", 30, 0, 100);
        resizeChanceSmall[9] = getInt("optResizePigSmall", 50, 0, 100);
        optionsModResize();
        return checkClass(RenderLiving.class, "resize");
    }

    private static void optionsModResize() {}

    private static void updateResizeMod(List var0)
    {
        if (modResizeEnabled && !isMultiplayer)
        {
            Iterator var1 = var0.iterator();

            while (var1.hasNext())
            {
                Entity var3 = (Entity)var1.next();

                if (getEntityAge(var3) == 1)
                {
                    int var4 = getEntityType(var3);

                    if (var4 != 0 && var4 != 14)
                    {
                        EntityLiving var5 = (EntityLiving)var3;
                        int var6 = var5.getMaxHealth();
                        int var7 = getHealth(var5);
                        float var8 = var5.height;

                        if (resizeSize[var4] < 0.01F)
                        {
                            resizeSize[var4] = getEntityHeight(var5);
                        }

                        if (var6 == var7)
                        {
                            int var2 = rnd.nextInt(100);

                            if (resizeChanceSmall[var4] > var2)
                            {
                                var7 >>= 1;
                                var8 = resizeSize[var4] * 0.5F;
                            }
                            else if (resizeChanceBig[var4] < var2)
                            {
                                var7 <<= 1;
                                var8 = resizeSize[var4] * 1.5F;
                            }
                        }
                        else if (var6 << 1 == var7)
                        {
                            var8 = resizeSize[var4] * 0.5F;
                        }
                        else
                        {
                            if (var6 >> 1 != var7)
                            {
                                continue;
                            }

                            var8 = resizeSize[var4] * 1.5F;
                        }

                        setEntitySize(var5, var8, var7);
                    }
                }
            }
        }
    }

    public static void resizeHandle(EntityLiving var0)
    {
        if (modResizeEnabled && !isMultiplayer && resizeSize != null)
        {
            float var1 = resizeSize[getEntityType(var0)];

            if (var1 > 1.0E-6F)
            {
                float var2 = getEntityHeight(var0) / var1;
                GL11.glScalef(var2, var2, var2);
            }
        }
    }

    private static boolean initModFurnace()
    {
        pFuel = furnaceFuel = new HashMap();
        pSmelt = furnaceSmelting = new HashMap();
        log("info: loading config for \"furnace\"");
        optFurnaceWoodFuel = getInt("optFurnaceWoodFuel", 300, 1, 32767);
        optFurnaceInfiniteFuel = getInt("optFurnaceInfiniteFuel", 32767, 1, 32767);
        optionsModFurnace();
        parse((List)null, "fuel.txt", 3);
        parse((List)null, "smelting.txt", 4);
        return checkClass(TileEntityFurnace.class, "furnace");
    }

    private static void optionsModFurnace()
    {
        optFurnaceSmeltingTime = getSetInt(optFurnaceSmeltingTime, "optFurnaceSmeltingTime", 200, 1, 1000, "Smelting time (20 = 1second)") & 65534;

        if (optFurnaceSmeltingTime == 0)
        {
            optFurnaceSmeltingTime = 1;
        }

        optFurnaceFuelWaste = getSetBool(optFurnaceFuelWaste, "optFurnaceFuelWaste", true, "Fuel waste");
        optFurnaceReturnBucket = getSetBool(optFurnaceReturnBucket, "optFurnaceReturnBucket", false, "Return bucket from lava bucket");
    }

    public static boolean furnaceWasteHandle()
    {
        return isMultiplayer || !modFurnaceEnabled || optFurnaceFuelWaste;
    }

    public static int furnaceSmeltTimeHandle()
    {
        return !isMultiplayer && modFurnaceEnabled ? optFurnaceSmeltingTime : 200;
    }

    public static boolean furnaceUseFuelHandle(int var0, boolean var1)
    {
        return isMultiplayer || !modFurnaceEnabled || optFurnaceInfiniteFuel > var0 && (optFurnaceFuelWaste || var1);
    }

    public static ItemStack furnaceSmeltingHandle(Integer var0)
    {
        return modFurnaceEnabled && !isMultiplayer && furnaceSmelting != null ? (ItemStack)furnaceSmelting.get(var0) : null;
    }

    public static int furnaceWoodFuelHandle()
    {
        return !isMultiplayer && modFurnaceEnabled ? optFurnaceWoodFuel : 300;
    }

    public static int furnaceFuelHandle(Integer var0)
    {
        return !isMultiplayer && modFurnaceEnabled && furnaceFuel != null && furnaceFuel.containsKey(var0) ? ((Integer)furnaceFuel.get(var0)).intValue() : 0;
    }

    public static boolean furnaceWorldUpdateHandle(boolean var0, int var1, int var2, int var3)
    {
        return var0 != (mapXGetId(var1, var2, var3) == 62);
    }

    public static ItemStack furnaceDecFuelHandle(ItemStack var0)
    {
        int var1 = getItemsCount(var0);

        if (modFurnaceEnabled && !isMultiplayer && optFurnaceReturnBucket && getItemsId(var0) == 327)
        {
            return newItems(325, var1);
        }
        else if (var1 == 1)
        {
            return null;
        }
        else
        {
            setItemsCount(var0, var1 - 1);
            return var0;
        }
    }

    private static boolean initModDig()
    {
        log("info: loading config for \"dig\"");
        optionsModDig();
        return checkClass(PlayerControllerMP.class, "dig");
    }

    private static void optionsModDig()
    {
        optDigHarvestAlways = getSetBool(optDigHarvestAlways, "optDigHarvestAlways", false, "Always harvest, regardless of tool");
        optDigReach = getSetFloat(optDigReach, "optDigReach", 4.0F, 2.0F, 128.0F, "Arm length");
        optDigSpeed = getSetFloat(optDigSpeed, "optDigSpeed", 2.0F, 0.1F, 10.0F, "Digging speed multiplier");
    }

    public static float digReachHandle()
    {
        float var0 = 4.0F;

        if (!isMultiplayer)
        {
            if (modDigEnabled && var0 < optDigReach)
            {
                var0 = optDigReach;
            }

            if (optBuild && modBuildEnabled && var0 < optBuildReach)
            {
                var0 = optBuildReach;
            }
        }

        return var0;
    }

    public static boolean harvestableHandle(boolean var0)
    {
        if (modDigEnabled && optDigHarvestAlways)
        {
            var0 = true;
        }

        if (modBuildEnabled && optBuild)
        {
            if (optBuildHarvestRule == -1)
            {
                var0 = false;
            }
            else if (optBuildHarvestRule == 1)
            {
                var0 = true;
            }
        }

        return var0;
    }

    public static float digProgressHandle(float var0, int var1)
    {
        return modBuildEnabled && optBuild ? ((block[var1] & 32768) != 0 ? 0.1F : optBuildDigSpeed) : (modDigEnabled ? var0 * optDigSpeed : var0);
    }

    private static boolean initModWeather()
    {
        log("info: loading config for \"weather\"");
        optWeatherThunderChance = getInt("optWeatherThunderChance", 100000, 1, 500000);
        optWeatherThunderMayhemChance = getInt("optWeatherThunderMayhemChance", 2000, 1, 10000);
        optWeatherRainTime = getIntRange("optWeatherRainTime", 180, 600, 10, 3600);
        optWeatherRainTime.min *= 20;
        optWeatherRainTime.max *= 20;
        optWeatherRainTime.max -= optWeatherRainTime.min - 1;
        optWeatherNoRainTime = getIntRange("optWeatherNoRainTime", 600, 8400, 10, 14400);
        optWeatherNoRainTime.min *= 20;
        optWeatherNoRainTime.max *= 20;
        optWeatherNoRainTime.max -= optWeatherNoRainTime.min - 1;
        optWeatherThunderTime = getIntRange("optWeatherThunderTime", 180, 600, 10, 3600);
        optWeatherThunderTime.min *= 20;
        optWeatherThunderTime.max *= 20;
        optWeatherThunderTime.max -= optWeatherThunderTime.min - 1;
        optWeatherNoThunderTime = getIntRange("optWeatherNoThunderTime", 600, 8400, 10, 14400);
        optWeatherNoThunderTime.min *= 20;
        optWeatherNoThunderTime.max *= 20;
        optWeatherNoThunderTime.max -= optWeatherNoThunderTime.min - 1;
        tagWeatherRaining = getString("tagWeatherRaining", "raining");
        tagWeatherThundering = getString("tagWeatherThundering", "thunder");
        tagWeatherMayhem = getString("tagWeatherMayhem", "mayhem");
        optionsModWeather();
        return true;
    }

    private static void optionsModWeather()
    {
        keyWeatherRain = getSetBind(keyWeatherRain, "keyWeatherRain", 36, "Toggle rain");
        keyWeatherThunderstorm = getSetBind(keyWeatherThunderstorm, "keyWeatherThunderstorm", 37, "Toggle thunderstorm");
        keyWeatherMayhem = getSetBind(keyWeatherMayhem, "keyWeatherMayhem", 42, "Mayhem modifier");
        keyWeatherLightning = getSetBind(keyWeatherLightning, "keyWeatherLightning", 22, "Spawn lightning at cursor");
        optWeatherLocked = getSetBool(optWeatherLocked, "optWeatherLocked", false, "Lock natural weather changes");
        optWeatherNoDraw = getSetBool(optWeatherNoDraw, "optWeatherNoDraw", false, "Do not draw rain");
    }

    private static void updateModWeather()
    {
        if (modWeatherEnabled && !isMultiplayer)
        {
            int var0;
            int var1;

            if (!isMenu && keyPress(keyWeatherLightning) && rayTrace(256.0D, 0.0F))
            {
                var0 = rayHitX();
                var1 = rayHitY();
                int var2 = rayHitZ();
                int var3 = rayHitSide();

                if (var3 == 2)
                {
                    --var2;
                }

                if (var3 == 3)
                {
                    ++var2;
                }

                if (var3 == 4)
                {
                    --var0;
                }

                if (var3 == 5)
                {
                    ++var0;
                }

                while ((block[mapXGetId(var0, var1, var2)] & 2) == 0)
                {
                    --var1;
                }

                while ((block[mapXGetId(var0, var1, var2)] & 2) != 0)
                {
                    ++var1;
                }

                spawnLightning(var0, var1, var2);
            }

            overloadMapRandom();
            var0 = getRainTime();
            var1 = getThunderTime();
            boolean var8 = getRain();
            boolean var7 = getThunder();

            if (!isMenu && keyPress(keyWeatherRain))
            {
                var0 = 1;
            }
            else if (!isMenu && keyPress(keyWeatherThunderstorm))
            {
                boolean var4 = keyDown(keyWeatherMayhem);

                if (!var8)
                {
                    var0 = 1;
                    var8 = false;
                }

                if (var8 && var7)
                {
                    if (!var4)
                    {
                        var1 = 1;
                        var7 = true;
                    }
                }
                else
                {
                    var1 = 1;
                    var7 = false;
                }

                if (var4)
                {
                    weatherMayhem = !var8 || !var7 || !weatherMayhem;
                }
            }

            if (var0 == 0)
            {
                var8 = true;
            }

            if (var0 <= 1)
            {
                var8 = !var8;

                if (var8)
                {
                    var0 = rnd.nextInt(optWeatherRainTime.max) + optWeatherRainTime.min;
                }
                else
                {
                    var0 = rnd.nextInt(optWeatherNoRainTime.max) + optWeatherNoRainTime.min;
                    weatherMayhem = false;
                }
            }

            if (var1 <= 1)
            {
                var7 = !var7;

                if (var7)
                {
                    var1 = rnd.nextInt(optWeatherThunderTime.max) + optWeatherThunderTime.min;
                }
                else
                {
                    var1 = rnd.nextInt(optWeatherNoThunderTime.max) + optWeatherNoThunderTime.min;
                    weatherMayhem = false;
                }
            }

            if (!isHell && optWeatherLocked)
            {
                ++var0;
                ++var1;
            }

            setRain(var8);
            setThunder(var7);
            setRainTime(var0);
            setThunderTime(var1);
        }
    }

    private static String textModWeather(String var0)
    {
        return modWeatherEnabled && !isMultiplayer && getRain() ? var0 + (getThunder() ? (weatherMayhem ? tagWeatherMayhem : tagWeatherThundering) : tagWeatherRaining) + " " : var0;
    }

    public static boolean drawRainHandle()
    {
        return !optWeatherNoDraw;
    }

    public static int mapRandomHandle(int var0, int var1)
    {
        return var0 == 100000 && modWeatherEnabled && !isMultiplayer ? (weatherMayhem ? rnd.nextInt(optWeatherThunderMayhemChance) : rnd.nextInt(optWeatherThunderChance)) : var1;
    }

    private static boolean initModGrowth()
    {
        log("info: loading config for \"growth\"");
        optGrowthPlanting = getBool("optGrowthPlanting", true);
        optGrowthFlower = getInt("optGrowthFlower", 25, 1, 1000);
        optGrowthShroom = getInt("optGrowthShroom", 100, 1, 1000);
        optGrowthPumpkin = getInt("optGrowthPumpkin", 50, 1, 1000);
        optGrowthSappling = getInt("optGrowthSappling", 25, 1, 1000);
        optGrowthReed = getInt("optGrowthReed", 10, 1, 1000);
        optGrowthRootingSpace = getInt("optGrowthRootingSpace", 3, 1, 5);
        optGrowthRootingTime = getInt("optGrowthRootingTime", 10, 1, 300) * 20;
        growthSqrRadius = (0.5F + (float)optGrowthRootingSpace) * (0.5F + (float)optGrowthRootingSpace);
        optionsModGrowth();
        return true;
    }

    private static void optionsModGrowth()
    {
        optGrowthRooting = getSetBool(optGrowthRooting, "optGrowthRooting", true, "Auto root sapplings");
    }

    private static void updateModGrowth(List var0)
    {
        if (modGrowthEnabled && !isMultiplayer)
        {
            int var1 = fix(posX) >> 4;
            int var2 = fix(posZ) >> 4;
            int var7;
            int var9;
            int var10;
            int var11;
            int var12;
            int var13;
            int var14;
            int var15;
            int var16;

            for (int var3 = -15; var3 <= 15; ++var3)
            {
                for (int var4 = -15; var4 <= 15; ++var4)
                {
                    if (mapXGetChunkExists(var1 + var3, var2 + var4))
                    {
                        Chunk var5 = map.getChunkFromChunkCoords(var1 + var3, var2 + var4);
                        int var8 = rnd.nextInt(256);
                        var9 = var8 & 15;
                        var10 = var8 >> 4;
                        var11 = var5.getHeightValue(var9, var10) + 1;

                        for (var12 = 1; var12 <= var11; ++var12)
                        {
                            int var6;

                            if ((block[var6 = var5.getBlockID(var9, var12, var10)] & 131072) != 0 && var5.getBlockID(var9, var12 - 1, var10) == 3)
                            {
                                var13 = Integer.MAX_VALUE;

                                switch (var6)
                                {
                                    case 6:
                                        var13 = optGrowthSappling;
                                        break;

                                    case 37:
                                    case 38:
                                        var13 = optGrowthFlower;
                                        break;

                                    case 39:
                                    case 40:
                                        var13 = optGrowthShroom;
                                        break;

                                    case 83:
                                        var13 = optGrowthReed;
                                        break;

                                    case 86:
                                        var13 = optGrowthPumpkin;
                                }

                                if (var13 < 1000 && rnd.nextInt(var13) == 0)
                                {
                                    var14 = var9 + rnd.nextInt(3) - 1 + (var1 + var3 << 4);
                                    var15 = var10 + rnd.nextInt(3) - 1 + (var2 + var4 << 4);

                                    if (mapXGetId(var14, var12 - 1, var15) == 3 && mapXGetId(var14, var12, var15) == 0)
                                    {
                                        var16 = getLightLevel(var14, var12, var15, 0);

                                        if (var6 != 39 && var6 != 40)
                                        {
                                            if (var16 < 8)
                                            {
                                                continue;
                                            }
                                        }
                                        else if (var16 > 13)
                                        {
                                            continue;
                                        }

                                        var7 = var5.getBlockMetadata(var9, var12, var10);
                                        mapXSetIdMeta(var14, var12, var15, var6, var7);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (optGrowthRooting || optGrowthPlanting)
            {
                ArrayList var17 = new ArrayList();
                Iterator var18 = var0.iterator();
                label145:

                while (var18.hasNext())
                {
                    Object var19 = var18.next();

                    if (var19 instanceof EntityItem)
                    {
                        EntityItem var21 = (EntityItem)var19;
                        var7 = getEntityAge(var21);

                        if (var7 == optGrowthRootingTime || var7 == 5980)
                        {
                            ItemStack var22 = getEntityItemStack(var21);
                            var9 = getItemsId(var22);

                            if (getItemsCount(var22) == 1 && (var9 == 6 && optGrowthRooting || var9 == 295 && optGrowthPlanting))
                            {
                                var10 = fix(getEntityPosX(var21));
                                var11 = fix(getEntityPosY(var21));
                                var12 = fix(getEntityPosZ(var21));

                                if (var11 >= 0 && mapXGetId(var10, var11, var12) == 0 && getLightLevel(var10, var11, var12, 0) >= 8)
                                {
                                    var13 = mapXGetId(var10, var11 - 1, var12);

                                    if (var9 == 295)
                                    {
                                        if (var13 != 60)
                                        {
                                            continue;
                                        }

                                        mapXSetIdMeta(var10, var11, var12, 59, 0);
                                    }
                                    else
                                    {
                                        if (var13 != 2 && var13 != 3)
                                        {
                                            continue;
                                        }

                                        for (var14 = -optGrowthRootingSpace; var14 <= optGrowthRootingSpace; ++var14)
                                        {
                                            for (var15 = -optGrowthRootingSpace; var15 <= optGrowthRootingSpace; ++var15)
                                            {
                                                if ((float)(var14 * var14 + var15 * var15) <= growthSqrRadius)
                                                {
                                                    for (var16 = -optGrowthRootingSpace; var16 <= optGrowthRootingSpace; ++var16)
                                                    {
                                                        var13 = mapXGetId(var10 + var14, var11 + var16, var12 + var15);

                                                        if (var13 == 17 || var13 == 6)
                                                        {
                                                            continue label145;
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        mapXSetIdMeta(var10, var11, var12, 6, getItemsInfo(var22));
                                    }

                                    var17.add(var21);
                                }
                            }
                        }
                    }
                }

                for (int var20 = 0; var20 < var17.size(); ++var20)
                {
                    dieEntity((Entity)var17.get(var20));
                }
            }
        }
    }

    private static boolean drawBtn(int var0, int var1, int var2, String var3, String var4, boolean var5, boolean var6, boolean var7, boolean var8)
    {
        var0 *= 5;
        var1 *= 11;
        var2 *= 5;
        int var9 = -10044570;
        int var10 = -4495770;
        boolean var11 = mouseX >= var0 && mouseY >= var1 && mouseX < var0 + var2 && mouseY < var1 + 11;

        if (!optionsModEnabled)
        {
            var3 = "???";
            var8 = true;
            var7 = true;
        }

        if (var11)
        {
            var9 = -7807608;
            var10 = -2258808;
        }

        ZMod$Options var10000;

        if (var5)
        {
            var10000 = opt;
            ZMod$Options.drawRect(var0 - 2, var1 - 1, var0 + var2 + 2, var1 + 11, -16776961);
        }

        if (var8)
        {
            opt.drawGradientRect(var0, var1, var0 + var2, var1 + 10, var9, var10);
        }
        else
        {
            var10000 = opt;
            ZMod$Options.drawRect(var0, var1, var0 + var2, var1 + 10, var6 ? var9 : var10);
        }

        ++var0;
        ++var1;

        if (var4 != null)
        {
            showText(var4, var0 + var2 + 8, var1, 13421772);
        }

        if (var7)
        {
            var0 += var2 - showTextLength(var3) >> 1;
        }

        showText(var3, var0, var1, 16777215);
        return optionsModEnabled && var11 && mousePress(0);
    }

    private static float drawBar(int var0, int var1, int var2, float var3, float var4, float var5, String var6, boolean var7)
    {
        var0 *= 5;
        var1 *= 11;
        var2 *= 5;
        float var8 = (var3 - var4) / (var5 - var4);
        int var9 = var0 + (int)((float)var2 * var8);
        boolean var10 = mouseX >= var0 && mouseY >= var1 && mouseX < var0 + var2 + 1 && mouseY < var1 + 11;

        if (!optionsModEnabled)
        {
            var9 = -10;
        }

        ZMod$Options var10000 = opt;
        ZMod$Options.drawRect(var0, var1 + 4, var0 + var2, var1 + 5, -10044570);
        var10000 = opt;
        ZMod$Options.drawRect(var9 - 1, var1 + 2, var9 + 1, var1 + 8, -1);
        showText(var6, var0 + var2 + 8, var1 + 1, 13421772);

        if (optionsModEnabled && var10)
        {
            float var11 = (float)(mouseX - var0) / (float)var2 * (var5 - var4) + var4;
            showText(String.format(var7 ? "%.0f (%.0f)" : "%.2f (%.2f)", new Object[] {Float.valueOf(var11), Float.valueOf(var3)}), mouseX, mouseY - 9, 16777164);

            if (Mouse.isButtonDown(0))
            {
                var3 = var11;
            }
        }

        return var3;
    }

    private static void updateConfigFile(String var0, String var1)
    {
        try
        {
            String var2 = path + "config.txt";
            BufferedReader var3 = new BufferedReader(new FileReader(var2));
            StringBuilder var4 = new StringBuilder();
            String var5;

            while ((var5 = var3.readLine()) != null)
            {
                var4.append(var5).append("\r\n");
            }

            var3.close();
            FileWriter var6 = new FileWriter(var2);
            var6.write(var4.toString().replaceAll(var0, var1));
            var6.close();
        }
        catch (Exception var7)
        {
            err("damn", var7);
        }
    }

    private static int getSetInt(int var0, String var1, int var2, int var3, int var4, String var5)
    {
        if (!initialized)
        {
            return getInt(var1, var2, var3, var4);
        }
        else
        {
            ++optionNr;
            int var6 = optionOfs != 0 ? optionOfs + 1 : 0;

            if (optionNr > var6 && optionOfs + optionsPage >= optionNr)
            {
                int var7 = (int)drawBar(22, optionNr - optionOfs, 20, (float)var0, (float)var3, (float)var4, var5, true);

                if (var7 != var0)
                {
                    updateConfigFile("(?m)^" + var1 + "\\W.*$", String.format(Locale.ENGLISH, "%-22s= %d", new Object[] {var1, Integer.valueOf(var7)}));
                    return var7;
                }
                else
                {
                    return var0;
                }
            }
            else
            {
                return var0;
            }
        }
    }

    private static float getSetFloat(float var0, String var1, float var2, float var3, float var4, String var5)
    {
        if (!initialized)
        {
            return getFloat(var1, var2, var3, var4);
        }
        else
        {
            ++optionNr;
            int var6 = optionOfs != 0 ? optionOfs + 1 : 0;

            if (optionNr > var6 && optionOfs + optionsPage >= optionNr)
            {
                float var7 = drawBar(22, optionNr - optionOfs, 20, var0, var3, var4, var5, false);

                if (var7 != var0)
                {
                    updateConfigFile("(?m)^" + var1 + "\\W.*$", String.format(Locale.ENGLISH, "%-22s= %6.2f", new Object[] {var1, Float.valueOf(var7)}));
                    return var7;
                }
                else
                {
                    return var0;
                }
            }
            else
            {
                return var0;
            }
        }
    }

    private static int getSetBind(int var0, String var1, int var2, String var3)
    {
        if (!initialized)
        {
            return getBind(var1, var2);
        }
        else
        {
            ++optionNr;
            int var4 = optionOfs != 0 ? optionOfs + 1 : 0;

            if (optionNr > var4 && optionOfs + optionsPage >= optionNr)
            {
                if (drawBtn(22, optionNr - optionOfs, 20, optionSel == optionNr ? "..." : keyName(var0), var3, optionSel == optionNr, true, true, false))
                {
                    optionSel = optionNr;
                }
                else if (optionSel != optionNr)
                {
                    return var0;
                }

                for (int var5 = 1; var5 < 255; ++var5)
                {
                    if (keyDown(var5))
                    {
                        optionSel = -1;

                        if (var5 == 1)
                        {
                            var5 = 0;
                        }

                        updateConfigFile("(?m)^" + var1 + "\\W.*$", String.format(Locale.ENGLISH, "%-22s= %s", new Object[] {var1, keyName(var5)}));
                        return var5;
                    }
                }

                return var0;
            }
            else
            {
                return var0;
            }
        }
    }

    private static boolean getSetBool(boolean var0, String var1, boolean var2, String var3)
    {
        if (!initialized)
        {
            return getBool(var1, var2);
        }
        else
        {
            ++optionNr;
            int var4 = optionOfs != 0 ? optionOfs + 1 : 0;

            if (optionNr > var4 && optionOfs + optionsPage >= optionNr)
            {
                if (drawBtn(22, optionNr - optionOfs, 20, var0 ? "yes" : "no", var3, false, var0, true, false))
                {
                    updateConfigFile("(?m)^" + var1 + "\\W.*$", String.format(Locale.ENGLISH, "%-22s= %s", new Object[] {var1, var0 ? "no" : "yes"}));
                    return !var0;
                }
                else
                {
                    return var0;
                }
            }
            else
            {
                return var0;
            }
        }
    }

    private static void drawItem(ItemStack var0, int var1, int var2)
    {
        int var3 = getItemsId(var0);
        int var4 = getItemsInfo(var0);
        int var5 = var4;
        boolean var6 = false;

        if (var4 == -1)
        {
            var5 = 0;
            var6 = true;
        }

        setItemsInfo(var0, var5);
        renderItemGUI(var1, var2, var0);
        setItemsInfo(var0, var4);
    }

    private static String getTime(long var0)
    {
        var0 += (long)optInfoTimeOffset;
        int var2 = (int)(var0 % 24000L);
        int var3 = var2 / 1000;
        int var4 = (int)((float)(var2 % 1000) * 0.06F);
        return (var3 < 10 ? "0" : "") + var3 + (var4 < 10 ? " : 0" : " : ") + var4;
    }

    private static String getRealTime(long var0)
    {
        long var2 = var0 / 1728000L;
        var0 %= 1728000L;
        long var4 = var0 / 72000L;
        var0 %= 72000L;
        long var6 = var0 / 1200L;
        var0 %= 1200L;
        long var8 = var0 / 20L;
        var0 %= 20L;
        long var10 = var0 / 2L;
        return "" + var2 + (var4 < 10L ? "\u00a7f : \u00a790" : "\u00a7f : \u00a79") + var4 + (var6 < 10L ? "\u00a7f : \u00a790" : "\u00a7f : \u00a79") + var6 + (var8 < 10L ? "\u00a7f : \u00a790" : "\u00a7f : \u00a79") + var8 + "\u00a7f . \u00a79" + var10;
    }

    private static String getEntityName(Entity var0)
    {
        return !(var0 instanceof EntityLiving) ? "inanimate object" : (var0 instanceof EntityPlayer ? getPlayerName((EntityPlayer)var0) : typeName[getEntityType(var0)]);
    }

    private static String getNameForId(int var0, int var1)
    {
        return getNameForId(var0 | (var1 == -1 ? 9999 : var1) << 16);
    }

    private static String getNameForId(int var0)
    {
        Set var1 = names.entrySet();
        Iterator var2 = var1.iterator();
        String var3 = null;

        while (var2.hasNext())
        {
            Entry var5 = (Entry)var2.next();

            if (((Integer)var5.getValue()).intValue() == var0)
            {
                String var4 = (String)var5.getKey();

                if (!var4.equals("Ghast") && !var4.equals("Cow") && !var4.equals("Spider") && !var4.equals("Sheep") && !var4.equals("Skelly") && !var4.equals("Creeper") && !var4.equals("Zombie") && !var4.equals("Slimes") && !var4.equals("Pig") && !var4.equals("Chicken") && !var4.equals("Squid") && !var4.equals("Pigzombie") && !var4.equals("Player") && !var4.equals("Other") && !var4.equals("Wolf") && !var4.equals("Cavespider") && !var4.equals("Enderman") && !var4.equals("Silverfish") && !var4.equals("LavaSlime") && !var4.equals("MushroomCow") && !var4.equals("Villager") && !var4.equals("SnowMan") && !var4.equals("Blaze") && !var4.equals("EnderDragon") && !var4.equals("Golem") && !var4.equals("Ocelot") && !var4.equals("adminium") && (var3 == null || var3.length() < var4.length()))
                {
                    var3 = var4;
                }
            }
        }

        if (var3 == null && var0 < 65536)
        {
            var3 = getNameForId(var0, -1);

            if (var3.charAt(0) == 54 && var3.length() > 6)
            {
                var3 = null;
            }
        }

        return var3 == null ? "" + var0 : var3;
    }

    private static boolean isTMIEnabled()
    {
        if (!TMI_initialized)
        {
            TMI_initialized = true;

            try
            {
                Class var0 = Class.forName("TMIConfig");
                mTMI_isEnabled = var0.getMethod("isEnabled", new Class[0]);
                mTMI_getInstance = var0.getMethod("getInstance", new Class[0]);
            }
            catch (Exception var3)
            {
                mTMI_isEnabled = null;
            }
        }

        if (mTMI_isEnabled == null)
        {
            return false;
        }
        else
        {
            boolean var4 = false;

            try
            {
                Object var1 = mTMI_getInstance.invoke((Object)null, new Object[0]);
                var4 = ((Boolean)mTMI_isEnabled.invoke(var1, new Object[0])).booleanValue();
                return var4;
            }
            catch (Exception var2)
            {
                return false;
            }
        }
    }

    private static void updateMousePos()
    {
        ScaledResolution var0 = new ScaledResolution(minecraft.gameSettings, minecraft.displayWidth, minecraft.displayHeight);
        int var1 = var0.getScaledWidth();
        int var2 = var0.getScaledHeight();
        mouseX = Mouse.getX() * var1 / minecraft.displayWidth;
        mouseY = var2 - Mouse.getY() * var2 / minecraft.displayHeight - 1;
    }

    private static String getPath()
    {
        String var0 = "";

        try
        {
            var0 = Minecraft.getMinecraftDir().getCanonicalPath();
        }
        catch (Exception var2)
        {
            var0 = "";
        }

        return var0;
    }

    private static int getTexture(String var0)
    {
        return minecraft.renderEngine.getTexture(var0);
    }

    private static List getChat()
    {
        return (List)getValue(fChat, minecraft.ingameGUI.getChatGUI());
    }

    private static boolean getIsMenu()
    {
        return minecraft.currentScreen != null;
    }

    private static boolean getIsOptions()
    {
        return minecraft.currentScreen instanceof ZMod$Options;
    }

    private static boolean getIsMultiplayer()
    {
        return !minecraft.isSingleplayer();
    }

    private static Object getPlayerController()
    {
        return minecraft.playerController;
    }

    private static boolean rayTrace(double var0, float var2)
    {
        return (rayHit = minecraft.renderViewEntity.rayTrace(var0, var2)) != null;
    }

    private static void overloadRenderGlobal()
    {
        minecraft.renderGlobal = render = new ZRG(minecraft, minecraft.renderEngine);
    }

    private static void overloadEntityRender()
    {
        minecraft.entityRenderer = new ZER(minecraft, minecraft.entityRenderer);
    }

    private static void killAchievement()
    {
        setValue(fAchivement, minecraft.guiAchievement, (Object)null);
    }

    private static EntityPlayerSP getPlayer()
    {
        return minecraft.thePlayer;
    }

    private static Object getRenderer()
    {
        return minecraft.entityRenderer;
    }

    private static void setNoClip(boolean var0)
    {
        if (player.noClip != var0)
        {
            if (isMultiplayer)
            {
                if (modNoClipAllowed)
                {
                    sendChat(var0 ? "/noclip enabled" : "/noclip disabled");
                }
                else
                {
                    chatClient("\u00a74zombe\'s \u00a72noclip\u00a74-mod is not enabled on this server.");
                    var0 = false;
                }
            }

            player.noClip = var0;
        }
    }

    private static float getEntityWidth(Entity var0)
    {
        return var0.width;
    }

    private static float getEntityHeight(Entity var0)
    {
        return var0.height;
    }

    private static float getEntityYaw(Entity var0)
    {
        return var0.rotationYaw;
    }

    private static float getEntityPitch(Entity var0)
    {
        return var0.rotationPitch;
    }

    private static Entity getOnEntity(Entity var0)
    {
        return var0.ridingEntity;
    }

    private static double getMountOffset(Entity var0)
    {
        return var0.getMountedYOffset();
    }

    private static float getEntitySteps(Entity var0)
    {
        return var0.distanceWalkedModified;
    }

    private static void setEntitySteps(Entity var0, float var1)
    {
        var0.distanceWalkedModified = var1;
    }

    private static void dieEntity(Entity var0)
    {
        var0.setDead();
    }

    private static boolean getEntityOnGround(Entity var0)
    {
        return var0.onGround;
    }

    private static void setEntityOnGround(Entity var0, boolean var1)
    {
        var0.onGround = var1;
    }

    private static double getEntityMotionX(Entity var0)
    {
        return var0.motionX;
    }

    private static void setEntityMotionX(Entity var0, double var1)
    {
        var0.motionX = var1;
    }

    private static double getEntityMotionY(Entity var0)
    {
        return var0.motionY;
    }

    private static void setEntityMotionY(Entity var0, double var1)
    {
        var0.motionY = var1;
    }

    private static double getEntityMotionZ(Entity var0)
    {
        return var0.motionZ;
    }

    private static void setEntityMotionZ(Entity var0, double var1)
    {
        var0.motionZ = var1;
    }

    private static double getEntityPrevPosX(Entity var0)
    {
        return var0.lastTickPosX;
    }

    private static double getEntityPrevPosY(Entity var0)
    {
        return var0.lastTickPosY;
    }

    private static void setEntityPrevPosY(Entity var0, double var1)
    {
        var0.lastTickPosY = var1;
    }

    private static double getEntityPrevPosZ(Entity var0)
    {
        return var0.lastTickPosZ;
    }

    private static double getEntityPosX(Entity var0)
    {
        return var0.posX;
    }

    private static double getEntityPosY(Entity var0)
    {
        return var0.posY;
    }

    private static double getEntityPosZ(Entity var0)
    {
        return var0.posZ;
    }

    private static void setFire0(Entity var0)
    {
        var0.extinguish();
    }

    private static void setAir(Entity var0, int var1)
    {
        var0.setAir(var1);
    }

    private static void setFall(Entity var0, float var1)
    {
        var0.fallDistance = var1;
    }

    private static int getEntityAge(Entity var0)
    {
        return var0.ticksExisted;
    }

    private static void setEntityAge(Entity var0, int var1)
    {
        var0.ticksExisted = var1;
    }

    private static void setEntityFireImmune(Entity var0, boolean var1)
    {
        setValue(fFireImmune, var0, Boolean.valueOf(var1));
    }

    private static int getEntityType(Entity var0)
    {
        return !(var0 instanceof EntityLiving) ? 0 : (var0 instanceof EntityMagmaCube ? 19 : (var0 instanceof EntityPigZombie ? 12 : (var0 instanceof EntityCaveSpider ? 16 : (var0 instanceof EntityMooshroom ? 20 : (var0 instanceof EntityZombie ? 7 : (var0 instanceof EntityEnderman ? 17 : (var0 instanceof EntitySkeleton ? 5 : (var0 instanceof EntityCreeper ? 6 : (var0 instanceof EntitySlime ? 8 : (var0 instanceof EntitySquid ? 11 : (var0 instanceof EntitySpider ? 3 : (var0 instanceof EntitySheep ? 4 : (var0 instanceof EntityVillager ? 21 : (var0 instanceof EntitySnowman ? 22 : (var0 instanceof EntityChicken ? 10 : (var0 instanceof EntityPig ? 9 : (var0 instanceof EntityCow ? 2 : (var0 instanceof EntityWolf ? 15 : (var0 instanceof EntityBlaze ? 23 : (var0 instanceof EntityIronGolem ? 25 : (var0 instanceof EntityOcelot ? 26 : (var0 instanceof EntityGhast ? 1 : (var0 instanceof EntityPlayer ? 13 : (var0 instanceof EntitySilverfish ? 18 : (var0 instanceof EntityGiantZombie ? 7 : (var0 instanceof EntityDragon ? 24 : 14))))))))))))))))))))))))));
    }

    private static void setEntityPos(Entity var0, double var1, double var3, double var5)
    {
        var0.setPosition(0.0D, 0.0D, 0.0D);
        var0.prevPosX = var0.lastTickPosX = var0.posX = var1;
        var0.prevPosY = var0.lastTickPosY = var0.posY = var3;
        var0.prevPosZ = var0.lastTickPosZ = var0.posZ = var5;
        var0.setPosition(var1, var3, var5);
    }

    private static EntityLiving getView()
    {
        return minecraft.renderViewEntity;
    }

    private static void setView(EntityLiving var0)
    {
        minecraft.renderViewEntity = var0;
    }

    private static void setHealth(EntityLiving var0, int var1)
    {
        setValue(fHealth, var0, Integer.valueOf(var1));
    }

    private static int getHealth(EntityLiving var0)
    {
        return ((Integer)getValue(fHealth, var0)).intValue();
    }

    private static void setEntitySize(EntityLiving var0, float var1, int var2)
    {
        var0.width *= var1 / var0.height;
        var0.height = var1;
        setHealth(var0, var2);
        var0.setPosition(var0.posX, var0.posY, var0.posZ);
    }

    private static void flyCallSuper(EntityPlayer var0, double var1, double var3, double var5)
    {
        var0.callSuper(var1, var3, var5);
    }

    private static boolean getIsSleeping(EntityPlayer var0)
    {
        return player.isPlayerSleeping();
    }

    private static String getPlayerName(EntityPlayer var0)
    {
        return var0.username;
    }

    private static ChunkCoordinates getSpawn(EntityPlayer var0)
    {
        return var0.getSpawnChunk();
    }

    private static ChunkCoordinates getBed(EntityPlayer var0)
    {
        return var0.playerLocation;
    }

    private static void sendChat(String var0)
    {
        ((EntityClientPlayerMP)player).sendChatMessage(var0);
    }

    private static int getCartType(EntityMinecart var0)
    {
        return var0.minecartType;
    }

    private static int getCartFuel(EntityMinecart var0)
    {
        return ((Integer)getValue(fCartFuel, var0)).intValue();
    }

    private static void setCartFuel(EntityMinecart var0, int var1)
    {
        setValue(fCartFuel, var0, Integer.valueOf(var1));
    }

    private static ItemStack getEntityItemStack(EntityItem var0)
    {
        return var0.item;
    }

    private static void setChanged(TileEntity var0)
    {
        var0.onInventoryChanged();
    }

    private static NBTTagCompound mapGetTileCopy(int var0, int var1, int var2)
    {
        TileEntity var3 = getTileEntity(var0, var1, var2);

        if (var3 == null)
        {
            return null;
        }
        else
        {
            NBTTagCompound var4 = new NBTTagCompound();
            var3.writeToNBT(var4);
            return var4;
        }
    }

    private static void mapSetTileCopy(NBTTagCompound var0, int var1, int var2, int var3)
    {
        var0.setInteger("x", var1);
        var0.setInteger("y", var2);
        var0.setInteger("z", var3);
        getTileEntity(var1, var2, var3).readFromNBT(var0);
    }

    private static void loadTileEntityFromNBT(ZP250 var0)
    {
        try
        {
            NBTTagCompound var1 = var0.nbtData;
            NBTTagCompound.writeNamedTag(var1, new DataOutputStream(new ByteArrayOutputStream()));
            TileEntity var2 = TileEntity.createAndLoadEntity(var1);

            if (map != getMap())
            {
                return;
            }

            map.setBlockTileEntity(var2.xCoord, var2.yCoord, var2.zCoord, var2);
        }
        catch (Exception var3)
        {
            ;
        }
    }

    private static ItemStack[] getFurnaceItems(Object var0)
    {
        return (ItemStack[])((ItemStack[])getValue(fFurnaceItems, var0));
    }

    private static ItemStack[] getChestItems(Object var0)
    {
        return (ItemStack[])((ItemStack[])getValue(fChestItems, var0));
    }

    private static ItemStack[] getDispItems(Object var0)
    {
        return (ItemStack[])((ItemStack[])getValue(fDispItems, var0));
    }

    private static String[] getSignText(int var0, int var1, int var2)
    {
        return ((TileEntitySign)getTileEntity(var0, var1, var2)).signText;
    }

    private static int getItemsIcon(ItemStack var0)
    {
        return var0.getIconIndex();
    }

    private static ItemStack newItemsE(int var0, int var1)
    {
        return newItems(var0 & 65535, var1, var0 >> 16);
    }

    private static ItemStack newItems(int var0, int var1, int var2)
    {
        return new ItemStack(var0, var1, var2 == 9999 ? -1 : var2);
    }

    private static ItemStack newItems(int var0, int var1)
    {
        return newItems(var0, var1, 0);
    }

    private static int getItemsId(ItemStack var0)
    {
        return var0.itemID;
    }

    private static int getItemsCount(ItemStack var0)
    {
        return var0.stackSize;
    }

    private static void setItemsCount(ItemStack var0, int var1)
    {
        var0.stackSize = var1;
    }

    private static int getItemsInfo(ItemStack var0)
    {
        return var0.getItemDamage();
    }

    private static void setItemsInfo(ItemStack var0, int var1)
    {
        var0.setItemDamage(var1);
    }

    private static boolean isItemsMatch(ItemStack var0, int var1)
    {
        return (getItemsId(var0) | (var1 >> 16 == 9999 ? 655294464 : getItemsInfo(var0) << 16)) == var1;
    }

    private static boolean isItemsMatch(ItemStack var0, ItemStack var1)
    {
        return getItemsId(var0) == getItemsId(var1) && (getItemsInfo(var1) < 0 || getItemsInfo(var1) == getItemsInfo(var0));
    }

    private static CraftingManager getCManager()
    {
        return CraftingManager.getInstance();
    }

    private static ShapedRecipes newRecipeNormal(int var0, int var1, int var2, int var3, ItemStack[] var4)
    {
        return new ShapedRecipes(var2, var3, var4, newItemsE(var0, var1));
    }

    private static ShapelessRecipes newRecipeShapeless(int var0, int var1, List var2)
    {
        return new ShapelessRecipes(newItemsE(var0, var1), var2);
    }

    private static void sortRecipes(List var0)
    {
        Collections.sort(var0, new RecipeSorter(getCManager()));
    }

    private static InventoryCrafting newCraftingGrid(int var0, int var1, ItemStack[] var2)
    {
        InventoryCrafting var3 = new InventoryCrafting((Container)null, var0, var1);
        setValue(fCBTable, var3, var2);
        return var3;
    }

    private static boolean isRecipeMatch(int var0, InventoryCrafting var1)
    {
        return ((IRecipe)pList.get(var0)).matches(var1);
    }

    private static WorldInfo getWorld()
    {
        return getMap().getWorldInfo();
    }

    private static boolean getRain()
    {
        return world.isRaining();
    }

    private static boolean getThunder()
    {
        return world.isThundering();
    }

    private static void setRain(boolean var0)
    {
        world.setRaining(var0);
    }

    private static void setThunder(boolean var0)
    {
        world.setThundering(var0);
    }

    private static int getRainTime()
    {
        return world.getRainTime();
    }

    private static int getThunderTime()
    {
        return world.getThunderTime();
    }

    private static void setRainTime(int var0)
    {
        world.setRainTime(var0);
    }

    private static void setThunderTime(int var0)
    {
        world.setThunderTime(var0);
    }

    private static long getTime()
    {
        return world.getWorldTime();
    }

    private static void setTime(long var0)
    {
        world.setWorldTime(var0);
    }

    private static long getSeed()
    {
        return world.getSeed();
    }

    private static String getName()
    {
        return world.getWorldName();
    }

    private static World getMap()
    {
        return minecraft.theWorld;
    }

    private static void spawnLightning(int var0, int var1, int var2)
    {
        map.spawnEntityInWorld(new EntityLightningBolt(map, (double)var0, (double)var1, (double)var2));
    }

    private static int getLightLevel(int var0, int var1, int var2, int var3)
    {
        return map.getChunkFromChunkCoords(var0 >> 4, var2 >> 4).getBlockLightValue(var0 & 15, var1, var2 & 15, var3);
    }

    private static float getLight(int var0, int var1, int var2)
    {
        return map.getLightBrightness(var0, var1, var2);
    }

    private static int getLightLevel(int var0, int var1, int var2)
    {
        return map.getFullBlockLightValue(var0, var1, var2);
    }

    private static int mapXGetId(int var0, int var1, int var2)
    {
        return map.getBlockId(var0, var1, var2);
    }

    private static int mapXGetMeta(int var0, int var1, int var2)
    {
        return map.getBlockMetadata(var0, var1, var2);
    }

    private static void mapXSetIdMetaNoUpdate(int var0, int var1, int var2, int var3, int var4)
    {
        map.setBlockAndMetadata(var0, var1, var2, var3, var4);
    }

    private static void mapXSetIdMeta(int var0, int var1, int var2, int var3, int var4)
    {
        map.setBlockAndMetadataWithNotify(var0, var1, var2, var3, var4);
    }

    private static void mapXSetId(int var0, int var1, int var2, int var3)
    {
        map.setBlockWithNotify(var0, var1, var2, var3);
    }

    private static boolean mapXGetChunkExists(int var0, int var1)
    {
        return map.getChunkProvider().chunkExists(var0, var1);
    }

    private static void chunkNeedsUpdate(int var0, int var1)
    {
        var0 <<= 4;
        var1 <<= 4;
        map.markBlocksDirty(var0, 0, var1, var0 + 15, 127, var1 + 15);
    }

    private static void mapXNeedsUpdate(int var0, int var1, int var2, int var3, int var4, int var5)
    {
        map.markBlocksDirty(var0, var1, var2, var3, var4, var5);
    }

    private static List getEntities()
    {
        return (List)((ArrayList)map.loadedEntityList).clone();
    }

    private static void noiseTP(Entity var0)
    {
        map.playSoundAtEntity(var0, "mob.slimeattack", 0.4F, ((rnd.nextFloat() - rnd.nextFloat()) * 0.2F + 1.0F) * 0.8F);
    }

    private static void overloadMapRandom()
    {
        if (map.rand != null && !(map.rand instanceof ZRND))
        {
            map.rand = new ZRND(map.rand);
        }
    }

    private static TileEntity getTileEntity(int var0, int var1, int var2)
    {
        return map.getBlockTileEntity(var0, var1, var2);
    }

    private static String getBiomeName(int var0, int var1)
    {
        return map.getChunkFromBlockCoords(var0, var1).getBiomeGenForWorldCoords(var0 & 15, var1 & 15, map.getWorldChunkManager()).biomeName;
    }

    private static String getChatLine(List var0, int var1)
    {
        return ((ChatLine)var0.get(var1)).getChatLineString();
    }

    private static void chatClient(String var0)
    {
        player.addChatMessage(var0);
    }

    private static int rayHitX()
    {
        return rayHit.blockX;
    }

    private static int rayHitY()
    {
        return rayHit.blockY;
    }

    private static int rayHitZ()
    {
        return rayHit.blockZ;
    }

    private static int rayHitSide()
    {
        return rayHit.sideHit;
    }

    private static InventoryPlayer getInventory(EntityPlayer var0)
    {
        return var0.inventory;
    }

    private static ItemStack[] getInvItems(InventoryPlayer var0)
    {
        return var0.mainInventory;
    }

    private static ItemStack[] getInvArmors(InventoryPlayer var0)
    {
        return var0.armorInventory;
    }

    private static void setInvItems(int var0, ItemStack var1)
    {
        invItemsArr[var0] = var1;
    }

    private static int getInvCur()
    {
        return inv.currentItem;
    }

    private static void setInvCur(int var0)
    {
        inv.currentItem = var0;
    }

    private static int getX(ChunkCoordinates var0)
    {
        return var0.posX;
    }

    private static int getY(ChunkCoordinates var0)
    {
        return var0.posY;
    }

    private static int getZ(ChunkCoordinates var0)
    {
        return var0.posZ;
    }

    private static Block getBlock(int var0)
    {
        return Block.blocksList[var0];
    }

    private static void setBlock(int var0, Block var1)
    {
        Block.blocksList[var0] = var1;
    }

    private static boolean getBlockIsSpawn(int var0)
    {
        return Block.blocksList[var0] != null && Block.blocksList[var0].blockMaterial.isOpaque() && Block.blocksList[var0].renderAsNormalBlock();
    }

    private static void setBlockGraphicsLevel(Block var0, boolean var1)
    {
        ((BlockLeaves)var0).setGraphicsLevel(var1);
    }

    private static float getBlockStrength(Block var0)
    {
        return ((Float)getValue(fBlockStrength, var0)).floatValue();
    }

    private static void setBlockStrength(Block var0, float var1)
    {
        setValue(fBlockStrength, var0, Float.valueOf(var1));
    }

    private static float getBlockResist(Block var0)
    {
        return ((Float)getValue(fBlockResist, var0)).floatValue();
    }

    private static void setBlockResist(Block var0, float var1)
    {
        setValue(fBlockResist, var0, Float.valueOf(var1));
    }

    private static float getBlockSlip(Block var0)
    {
        return var0.slipperiness;
    }

    private static void setBlockSlip(Block var0, float var1)
    {
        var0.slipperiness = var1;
    }

    private static Material getBlockMaterial(Block var0)
    {
        return var0.blockMaterial;
    }

    private static boolean getBlockIsOpaque(int var0)
    {
        return Block.opaqueCubeLookup[var0];
    }

    private static int getBlockOpacity(int var0)
    {
        return Block.lightOpacity[var0];
    }

    private static void setBlockOpacity(int var0, int var1)
    {
        Block.lightOpacity[var0] = var1;
    }

    private static int getBlockLight(int var0)
    {
        return Block.lightValue[var0];
    }

    private static void setBlockLight(int var0, int var1)
    {
        Block.lightValue[var0] = var1;
    }

    private static boolean getIsLiquid(Material var0)
    {
        return var0.isLiquid();
    }

    private static boolean getIsCover(Material var0)
    {
        return var0.getCanBlockGrass();
    }

    private static boolean getIsSolid(Material var0)
    {
        return var0.isSolid();
    }

    private static boolean getIsBurnable(Material var0)
    {
        return var0.getCanBurn();
    }

    private static boolean getIsReplaceable(Material var0)
    {
        return var0.isGroundCover();
    }

    private static Item getItem(int var0)
    {
        return Item.itemsList[var0];
    }

    private static int getItemMax(Item var0)
    {
        return var0 == null ? 0 : var0.getItemStackLimit();
    }

    private static void setItemMax(Item var0, int var1)
    {
        if (var0 != null)
        {
            var0.setMaxStackSize(var1);
        }
    }

    private static int getItemDmgCap(Item var0)
    {
        return var0.getMaxDamage();
    }

    private static void setItemDmgCap(Item var0, int var1)
    {
        var0.setMaxDamage(var1);
    }

    private static String getItemName(Item var0)
    {
        return var0.getItemName();
    }

    private static boolean getItemHasSubTypes(Item var0)
    {
        return var0.getHasSubtypes();
    }

    private static void setOrtho()
    {
        ScaledResolution var0 = new ScaledResolution(minecraft.gameSettings, minecraft.displayWidth, minecraft.displayHeight);
        GL11.glOrtho(0.0D, var0.getScaledWidth_double(), var0.getScaledHeight_double(), 0.0D, 1000.0D, 3000.0D);
    }

    private static int getScrWidthS()
    {
        return (new ScaledResolution(minecraft.gameSettings, minecraft.displayWidth, minecraft.displayHeight)).getScaledWidth();
    }

    private static int getScrHeightS()
    {
        return (new ScaledResolution(minecraft.gameSettings, minecraft.displayWidth, minecraft.displayHeight)).getScaledHeight();
    }

    private static boolean isHideGUI()
    {
        return minecraft.gameSettings.hideGUI;
    }

    private static boolean isShowDebug()
    {
        return minecraft.gameSettings.showDebugInfo;
    }

    private static int getKeyJump()
    {
        return minecraft.gameSettings.keyBindJump.keyCode;
    }

    private static int getKeyGo()
    {
        return minecraft.gameSettings.keyBindForward.keyCode;
    }

    private static int getKeyBack()
    {
        return minecraft.gameSettings.keyBindLeft.keyCode;
    }

    private static int getViewDistance()
    {
        return minecraft.gameSettings.renderDistance;
    }

    private static int getFireSpread(int var0)
    {
        return Array.getInt(getValue(fBlockFireSpread, getBlock(51)), var0);
    }

    private static void setFireSpread(int var0, int var1)
    {
        Array.setInt(getValue(fBlockFireSpread, getBlock(51)), var0, var1);
    }

    private static int getFireBurn(int var0)
    {
        return Array.getInt(getValue(fBlockFireBurn, getBlock(51)), var0);
    }

    private static void setFireBurn(int var0, int var1)
    {
        Array.setInt(getValue(fBlockFireBurn, getBlock(51)), var0, var1);
    }

    private static ItemStack getGridItem(int var0)
    {
        return minecraft.currentScreen instanceof GuiCrafting ? ((ContainerWorkbench)((ContainerWorkbench)((GuiContainer)((GuiContainer)minecraft.currentScreen)).inventorySlots)).craftMatrix.getStackInSlot(var0) : (minecraft.currentScreen instanceof GuiInventory ? ((ContainerPlayer)((ContainerPlayer)((GuiContainer)((GuiContainer)minecraft.currentScreen)).inventorySlots)).craftMatrix.getStackInSlot(var0) : null);
    }

    private static void renderItemGUI(int var0, int var1, ItemStack var2)
    {
        if (itemRenderer == null)
        {
            itemRenderer = new RenderItem();
        }

        itemRenderer.renderItemIntoGUI(minecraft.fontRenderer, minecraft.renderEngine, var2, var0, var1);
    }

    private static void setXItemLighting()
    {
        RenderHelper.enableStandardItemLighting();
    }

    private static boolean getIsHell()
    {
        return mapXGetId(fix(posX), 127, fix(posZ)) == 7;
    }

    private static void showText(String var0, int var1, int var2, int var3)
    {
        minecraft.fontRenderer.drawStringWithShadow(var0, var1, var2, var3);
    }

    private static int showTextLength(String var0)
    {
        return minecraft.fontRenderer.getStringWidth(var0);
    }

    private static void initLogAndPath()
    {
        path = getPath();
        path = path + File.separatorChar + "mods" + File.separatorChar + "zombe" + File.separatorChar;
        File var0;

        try
        {
            var0 = new File(path);
            var0.mkdirs();
        }
        catch (Exception var2)
        {
            path = "";
        }

        try
        {
            var0 = new File(path + "log.txt");
            out = new PrintStream(var0);
            logPath = var0.getCanonicalPath();
        }
        catch (Exception var1)
        {
            logPath = "failed to create one :(";
            out = System.out;
        }

        log("=========== logging ===========");
        log("ZModPack: version 6.3");
        log("Log started at: " + new Timestamp((new Date()).getTime()));
    }

    public static void log(String var0)
    {
        if (out == null)
        {
            initLogAndPath();
        }

        out.println(var0);
    }

    private static void err(String var0)
    {
        if (logErrors > 0)
        {
            log(var0);

            if (showError == null)
            {
                showError = var0;
                setMsg(3, "ZMod: errors detected - one or more mods affected\n" + (logErrors == 8 ? "First " : "Next ") + showError + "\nLog: " + logPath, 16746632);
            }

            if (logErrors-- == 0)
            {
                log("info: stopping error logging.");
            }
        }
    }

    private static void err(String var0, Exception var1)
    {
        err(var0);

        if (logErrors > 0)
        {
            log("### Exception: " + var1.toString());
            var1.printStackTrace(out);
        }
    }

    public static void logc(String var0)
    {
        log(var0);
        chatClient(var0);
    }

    private static int getBind(String var0, int var1)
    {
        String var2 = conf.getProperty(var0);

        if (var2 == null)
        {
            return var1;
        }
        else
        {
            var2 = var2.replaceAll("[\t\r\n]+", " ").trim();

            if (var2.equals(""))
            {
                return 0;
            }
            else
            {
                int var3 = Keyboard.getKeyIndex(var2.toUpperCase());

                if (var3 == 0)
                {
                    err("error: config.txt @ " + var0 + " - invalid key name \"" + var2 + "\"");
                    return var1;
                }
                else
                {
                    return var3;
                }
            }
        }
    }

    private static float getFloat(String var0, float var1, float var2, float var3)
    {
        String var4 = conf.getProperty(var0);

        if (var4 == null)
        {
            return var1;
        }
        else
        {
            var4 = var4.replaceAll("[\t\r\n]+", " ").trim();
            float var5 = parseFloat(var4, Float.NaN);

            if (Float.isNaN(var5))
            {
                err("error: config.txt @ " + var0 + " - float expected but garbage found \"" + var4 + "\"");
                return var1;
            }
            else if (var5 >= var2 && var5 <= var3)
            {
                return var5;
            }
            else
            {
                err("error: config.txt @ " + var0 + " - must be between " + var2 + " and " + var3 + " \"" + var4 + "\"");
                return var1;
            }
        }
    }

    private static int getInt(String var0, int var1, int var2, int var3)
    {
        String var4 = conf.getProperty(var0);

        if (var4 == null)
        {
            return var1;
        }
        else
        {
            var4 = var4.replaceAll("[\t\r\n]+", " ").trim();
            int var5 = parseInteger(var4, Integer.MIN_VALUE);

            if (var5 == Integer.MIN_VALUE)
            {
                err("error: config.txt @ " + var0 + " - integer expected but garbage found \"" + var4 + "\"");
                return var1;
            }
            else if (var5 >= var2 && var5 <= var3)
            {
                return var5;
            }
            else
            {
                err("error: config.txt @ " + var0 + " - must be between " + var2 + " and " + var3 + " \"" + var4 + "\"");
                return var1;
            }
        }
    }

    private static String getString(String var0, String var1)
    {
        String var2 = conf.getProperty(var0);

        if (var2 == null)
        {
            return var1;
        }
        else
        {
            var2 = var2.replaceAll("[\t\r\n]+", " ").trim();
            return var2;
        }
    }

    private static boolean getBool(String var0, boolean var1)
    {
        String var2 = conf.getProperty(var0);

        if (var2 == null)
        {
            return var1;
        }
        else
        {
            var2 = var2.replaceAll("[\t\r\n]+", " ").trim();

            if (!var2.equals("1") && !var2.equals("yes") && !var2.equals("true") && !var2.equals("on"))
            {
                if (!var2.equals("0") && !var2.equals("no") && !var2.equals("false") && !var2.equals("off"))
                {
                    err("error: config.txt @ " + var0 + " - must be one of (1, yes, true, on, 0, no, false, off) \"" + var2 + "\"");
                    return var1;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }
    }

    private static ZMod$Mark getColor(String var0, int var1)
    {
        ZMod$Mark var2 = new ZMod$Mark(var1);
        String var3 = conf.getProperty(var0);

        if (var3 == null)
        {
            return var2;
        }
        else
        {
            var3 = var3.replaceAll("[\t\r\n]+", " ").trim();

            if (!var2.loadColor(var3))
            {
                err("error: config.txt @ " + var0 + " - undefined or invalid color \"" + var3 + "\"");
            }

            return var2;
        }
    }

    private static ZMod$Mark getIntRange(String var0, int var1, int var2, int var3, int var4)
    {
        ZMod$Mark var5 = new ZMod$Mark(var3, var4);
        String var6 = conf.getProperty(var0);

        if (var6 == null)
        {
            return var5;
        }
        else
        {
            var6 = var6.replaceAll("[\t\r\n]+", " ").trim();
            String[] var7 = var6.split(" *\\.\\. *");
            int var8 = var1;
            int var9 = var2;

            if (var7.length == 2)
            {
                var8 = parseInteger(var7[0], Integer.MIN_VALUE);
                var9 = parseInteger(var7[1], Integer.MIN_VALUE);
            }

            if (var7.length != 2)
            {
                err("error: config.txt @ " + var0 + " - invalid range specification \"" + var6 + "\"");
            }
            else if (var8 == Integer.MIN_VALUE)
            {
                err("error: config.txt @ " + var0 + " - integer expected but garbage found \"" + var7[0] + "\" in \"" + var6 + "\"");
            }
            else if (var9 == Integer.MIN_VALUE)
            {
                err("error: config.txt @ " + var0 + " - integer expected but garbage found \"" + var7[1] + "\" in \"" + var6 + "\"");
            }
            else if (var8 > var9)
            {
                err("error: config.txt @ " + var0 + " - range begins after end \"" + var6 + "\"");
            }
            else if (var8 >= var3 && var9 <= var4)
            {
                var5.min = var8;
                var5.max = var9;
            }
            else
            {
                err("error: config.txt @ " + var0 + " - range \"" + var6 + "\" is out of bounds (" + var3 + " .. " + var4 + ")");
            }

            return var5;
        }
    }

    private static int getBlockId(String var0, int var1)
    {
        String var2 = conf.getProperty(var0);

        if (var2 == null)
        {
            return var1;
        }
        else
        {
            var2 = var2.replaceAll("[\t\r\n]+", " ").trim();
            int var3 = parseUnsigned(var2);

            if (names.containsKey(var2))
            {
                var3 = ((Integer)names.get(var2)).intValue();
            }

            if ((var3 & 65535) > 255)
            {
                err("error: config.txt @ " + var0 + " - non-block name or id out of block id range \"" + var2 + "\"");
            }
            else
            {
                if (var3 >> 16 == 9999 || var3 >> 16 == 0)
                {
                    return var3 & 255;
                }

                err("error: config.txt @ " + var0 + " - block has metadata (ex: colored wool) \"" + var2 + "\".");
            }

            return var1;
        }
    }

    private static int getItemId(String var0, int var1)
    {
        String var2 = conf.getProperty(var0);

        if (var2 == null)
        {
            return var1;
        }
        else
        {
            var2 = var2.replaceAll("[\t\r\n]+", " ").trim();
            int var3 = parseIdInfo(var2);

            if (names.containsKey(var2))
            {
                var3 = ((Integer)names.get(var2)).intValue();
            }

            if (var3 == -1)
            {
                err("error: config.txt @ " + var0 + " - invalid name or id \"" + var2 + "\"");
                return var1;
            }
            else
            {
                return var3;
            }
        }
    }

    private static boolean getDeprecated(String var0)
    {
        if (!initialized && conf.getProperty(var0) != null)
        {
            log("notice: config.txt @ " + var0 + " - this option is deprecated");
            return true;
        }
        else
        {
            return false;
        }
    }

    private static boolean getBroken(String var0)
    {
        if (!initialized && conf.getProperty(var0) != null)
        {
            log("notice: config.txt @ " + var0 + " - this option is disabled in this release");
            return true;
        }
        else
        {
            return false;
        }
    }

    private static void reportException(Exception var0)
    {
        if (!exceptionReported)
        {
            exceptionReported = true;
            err("exception in reflection code encountered !", var0);
        }
    }

    private static boolean getClassExists(String var0)
    {
        try
        {
            return Class.forName(var0) != null;
        }
        catch (Exception var2)
        {
            return false;
        }
    }

    private static Field getField(Class var0, String var1)
    {
        int var2 = -1;

        for (int var3 = 0; var3 < MCPnames.length; var3 += 3)
        {
            if (var1.equals(MCPnames[var3]))
            {
                var2 = var3;
                break;
            }
        }

        if (var2 == -1)
        {
            err("getField failed for: " + var1);
            return null;
        }
        else
        {
            try
            {
                Field var7 = var0.getDeclaredField(MCPnames[var2 + 1]);
                var7.setAccessible(true);
                return var7;
            }
            catch (Exception var6)
            {
                try
                {
                    Field var4 = var0.getDeclaredField(MCPnames[var2 + 2]);
                    var4.setAccessible(true);
                    return var4;
                }
                catch (Exception var5)
                {
                    err("exception in reflection code encountered ! (missing field: \'" + MCPnames[var2 + 1] + "\', obfus: \'" + MCPnames[var2 + 2] + "\')", var5);
                    return null;
                }
            }
        }
    }

    private static Object getValue(Field var0, Object var1)
    {
        try
        {
            return var0.get(var1);
        }
        catch (Exception var3)
        {
            reportException(var3);
            return null;
        }
    }

    private static void setValue(Field var0, Object var1, Object var2)
    {
        try
        {
            var0.set(var1, var2);
        }
        catch (Exception var4)
        {
            reportException(var4);
        }
    }

    private static Class getClass(String var0)
    {
        try
        {
            return Class.forName(var0);
        }
        catch (Exception var2)
        {
            reportException(var2);
            return null;
        }
    }

    private static Object getResult(Method var0, Object var1, Object[] var2)
    {
        try
        {
            return var0.invoke(var1, var2);
        }
        catch (Exception var4)
        {
            reportException(var4);
            return null;
        }
    }

    private static Object getResult(Method var0)
    {
        return getResult(var0, (Object)null, new Object[0]);
    }

    private static Object getResult(Method var0, Object var1)
    {
        return getResult(var0, var1, new Object[0]);
    }

    private static Object getResult(Method var0, Object var1, Object var2)
    {
        return getResult(var0, var1, new Object[] {var2});
    }

    private static Object getResult(Method var0, Object var1, Object var2, Object var3)
    {
        return getResult(var0, var1, new Object[] {var2, var3});
    }

    private static Object getResult(Method var0, Object var1, Object var2, Object var3, Object var4)
    {
        return getResult(var0, var1, new Object[] {var2, var3, var4});
    }

    private static Object getResult(Method var0, Object var1, Object var2, Object var3, Object var4, Object var5)
    {
        return getResult(var0, var1, new Object[] {var2, var3, var4, var5});
    }

    private static boolean checkClass(Class var0, String var1)
    {
        return checkClass(var0, var1, (String)null);
    }

    private static boolean checkClass(Class var0, String var1, String var2)
    {
        try
        {
            Field var3 = var0.getDeclaredField("zmodmarker");

            if (var3 != null)
            {
                return true;
            }
        }
        catch (Exception var4)
        {
            ;
        }

        if (var2 == null)
        {
            err("error: " + var0.getName() + ".class has not been installed - " + var1 + " mod disabled");
        }
        else
        {
            log("warning: " + var0.getName() + ".class has not been installed - " + var1 + " mod: " + var2);
        }

        return false;
    }

    private static int fix(double var0)
    {
        return (int)Math.floor(var0);
    }

    private static void delMsg(int var0)
    {
        texts[var0] = null;
    }

    private static void setMsg(String var0)
    {
        setMsg(2, var0);
    }

    private static void setMsg(int var0, String var1)
    {
        setMsg(var0, var1, 16777215, 2 + var0 * 2, 2 + var0 * 12);
    }

    private static void setMsg(int var0, String var1, int var2)
    {
        texts[var0] = new ZMod$Text(var1, 2 + var0 * 2, 2 + var0 * 12, var2);
    }

    private static void setMsg(int var0, String var1, int var2, int var3, int var4)
    {
        texts[var0] = new ZMod$Text(var1, var3, var4, var2);
    }

    private static boolean keyPress(int var0)
    {
        boolean var1 = !keys[var0];
        return (keys[var0] = keyDown(var0)) && var1;
    }

    private static boolean keyDown(int var0)
    {
        return var0 != 0 && Keyboard.isKeyDown(var0);
    }

    private static String keyName(int var0)
    {
        if (var0 == 0)
        {
            return "";
        }
        else
        {
            String var1 = Keyboard.getKeyName(var0);
            return var1 != null ? var1 : "" + var0;
        }
    }

    private static boolean mousePress(int var0)
    {
        boolean var1 = !keysM[var0];
        return (keysM[var0] = Mouse.isButtonDown(var0)) && var1;
    }

    private static float sgn(float var0)
    {
        return var0 < 0.0F ? -1.0F : (var0 > 0.0F ? 1.0F : 0.0F);
    }

    private static FloatBuffer makeBuffer(int var0)
    {
        return ByteBuffer.allocateDirect(var0 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
    }

    private static FloatBuffer makeBuffer(float[] var0)
    {
        return (FloatBuffer)ByteBuffer.allocateDirect(var0.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(var0).flip();
    }

    private static void obliqueNearPlaneClip(float var0, float var1, float var2, float var3)
    {
        float[] var4 = new float[16];
        FloatBuffer var10 = makeBuffer(16);
        GL11.glGetFloat(GL11.GL_PROJECTION_MATRIX, var10);
        var10.get(var4).rewind();
        float var5 = (sgn(var0) + var4[8]) / var4[0];
        float var6 = (sgn(var1) + var4[9]) / var4[5];
        float var7 = -1.0F;
        float var8 = (1.0F + var4[10]) / var4[14];
        float var9 = var0 * var5 + var1 * var6 + var2 * var7 + var3 * var8;
        var4[2] = var0 * (2.0F / var9);
        var4[6] = var1 * (2.0F / var9);
        var4[10] = var2 * (2.0F / var9) + 1.0F;
        var4[14] = var3 * (2.0F / var9);
        var10.put(var4).rewind();
        GL11.glMatrixMode(GL11.GL_PROJECTION);
        GL11.glLoadMatrix(var10);
        GL11.glMatrixMode(GL11.GL_MODELVIEW);
    }

    private static void parse(List var0, String var1, int var2)
    {
        pList = var0;
        pNames = names == null ? new HashMap() : (HashMap)((HashMap)names.clone());
        pFiles = new HashSet();
        parseFile(var1, var2);
    }

    private static void parseFile(String var0, int var1)
    {
        if (!pFiles.add(var0))
        {
            err("error: recursion detected - \"" + var0 + "\" is already included");
        }
        else
        {
            String var2 = "";
            String var3 = path + var0;

            try
            {
                byte[] var4 = new byte[(int)(new File(var3)).length()];
                BufferedInputStream var5 = new BufferedInputStream(new FileInputStream(var3));
                var5.read(var4);
                var5.close();
                var2 = new String(var4);
                log("info: parsing \"" + var0 + "\"");
            }
            catch (Exception var7)
            {
                err("error: failed to load \"" + var0 + "\"", var7);
                var2 = "";
            }

            String[] var8 = var2.split("\\r?\\n");

            for (int var6 = 0; var6 < var8.length; ++var6)
            {
                if (var8[var6].startsWith("[IGNORE]"))
                {
                    var1 = 0;
                }
                else if (var8[var6].startsWith("[NAMEMAP]"))
                {
                    var1 = 1;
                }
                else if (var8[var6].startsWith("[RECIPES]"))
                {
                    var1 = 2;
                }
                else if (var8[var6].startsWith("[FUEL]"))
                {
                    var1 = 3;
                }
                else if (var8[var6].startsWith("[SMELTING]"))
                {
                    var1 = 4;
                }
                else if (var8[var6].startsWith("[ITEMS]"))
                {
                    var1 = 5;
                }
                else if (var8[var6].startsWith("[NAMEMAP="))
                {
                    parseFile(var8[var6].substring(9).replaceAll("\\].*\\z", ""), 1);
                }
                else if (var8[var6].startsWith("[RECIPES="))
                {
                    parseFile(var8[var6].substring(9).replaceAll("\\].*\\z", ""), 2);
                }
                else if (var8[var6].startsWith("[FUEL="))
                {
                    parseFile(var8[var6].substring(6).replaceAll("\\].*\\z", ""), 3);
                }
                else if (var8[var6].startsWith("[SMELTING="))
                {
                    parseFile(var8[var6].substring(10).replaceAll("\\].*\\z", ""), 4);
                }
                else if (var8[var6].startsWith("[ITEMS="))
                {
                    parseFile(var8[var6].substring(7).replaceAll("\\].*\\z", ""), 5);
                }
                else if (var1 == 1)
                {
                    parseNames(var8[var6], var0, var6 + 1);
                }
                else if (var1 == 2)
                {
                    parseRecipe(var8[var6], var0, var6 + 1);
                }
                else if (var1 == 3)
                {
                    parseFuel(var8[var6], var0, var6 + 1);
                }
                else if (var1 == 4)
                {
                    parseSmelting(var8[var6], var0, var6 + 1);
                }
                else if (var1 == 5)
                {
                    parseItems(var8[var6], var0, var6 + 1);
                }
            }
        }
    }

    private static int parseUnsigned(String var0)
    {
        return parseInteger(var0, -1);
    }

    private static int parseInteger(String var0, int var1)
    {
        try
        {
            return Integer.decode(var0).intValue();
        }
        catch (Exception var3)
        {
            return var1;
        }
    }

    private static float parseFloat(String var0, float var1)
    {
        try
        {
            return Float.parseFloat(var0);
        }
        catch (Exception var3)
        {
            return var1;
        }
    }

    private static int parseIdInfo(String var0)
    {
        try
        {
            String[] var1 = var0.split("/");

            if (var1.length > 2)
            {
                return -1;
            }
            else
            {
                int var2 = Integer.decode(var1[0]).intValue();

                if (var1.length == 2)
                {
                    int var3 = Integer.decode(var1[1]).intValue();

                    if (var3 < 0)
                    {
                        var3 = 9999;
                    }

                    var2 += var3 << 16;
                }

                return var2;
            }
        }
        catch (Exception var4)
        {
            return -1;
        }
    }

    private static void parseFuel(String var0, String var1, int var2)
    {
        String[] var3 = var0.replaceAll("\\A[\\t ]*", "").replaceAll("[\\t ]*(|//.*)\\z", "").split("[ \\t]+");

        if (var3.length != 2)
        {
            if (var3.length == 1 && !var3[0].equals(""))
            {
                err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid fuel definition");
            }
        }
        else
        {
            int var4 = pNames.containsKey(var3[0]) ? ((Integer)pNames.get(var3[0])).intValue() : parseUnsigned(var3[0]);

            if (var4 > 0)
            {
                var4 &= 65535;
            }

            int var5 = parseUnsigned(var3[1]);

            if (var4 <= 0)
            {
                err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid fuel definition (\"" + var3[0] + "\" is unknown or invalid)");
            }
            else if (var5 <= 0)
            {
                err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid fuel definition (\"" + var3[1] + "\" is invalid time)");
            }
            else
            {
                pFuel.put(Integer.valueOf(var4), Integer.valueOf(var5));
            }
        }
    }

    private static void parseSmelting(String var0, String var1, int var2)
    {
        String[] var3 = var0.replaceAll("\\A[\\t ]*", "").replaceAll("[\\t ]*(|//.*)\\z", "").split("[ \\t]+");

        if (var3.length != 2)
        {
            if (var3.length == 1 && !var3[0].equals(""))
            {
                err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid smelt definition");
            }
        }
        else
        {
            int var4 = pNames.containsKey(var3[0]) ? ((Integer)pNames.get(var3[0])).intValue() : parseIdInfo(var3[0]);
            int var5 = pNames.containsKey(var3[1]) ? ((Integer)pNames.get(var3[1])).intValue() : parseUnsigned(var3[1]);

            if (var5 > 0)
            {
                var5 &= 65535;
            }

            ItemStack var6 = var4 > 0 ? newItemsE(var4, 1) : null;

            if (var5 <= 0)
            {
                err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid smelting definition (\"" + var3[1] + "\" is unknown or invalid)");
            }
            else if (var6 == null)
            {
                err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid smelting definition (\"" + var3[0] + "\" is unknown or invalid)");
            }
            else
            {
                pSmelt.put(Integer.valueOf(var5), var6);
            }
        }
    }

    private static void parseNames(String var0, String var1, int var2)
    {
        String[] var3 = var0.replaceAll("\\A[\\t ]*", "").replaceAll("[\\t ]*(|//.*)\\z", "").split("[ \\t]+");

        if ((var3.length & 1) != 0)
        {
            if (var3.length != 1 && !var3[0].equals(""))
            {
                err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - incomplete name definition");
            }
        }
        else
        {
            for (int var4 = 0; var4 < var3.length; var4 += 2)
            {
                int var5 = parseIdInfo(var3[var4 + 1]);

                if (var5 == -1)
                {
                    err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - non numbers in name definition");
                }
                else
                {
                    pNames.put(var3[var4], Integer.valueOf(var5));
                }
            }
        }
    }

    private static void addRecipe(int var0, int var1, ItemStack[] var2, int var3, int var4)
    {
        boolean var5 = var1 > 0;
        ItemStack[] var6 = var2;
        ArrayList var7 = null;

        if (!var5)
        {
            var6 = new ItemStack[9];
            var7 = new ArrayList();

            for (int var8 = 0; var8 < var2.length; ++var8)
            {
                var7.add(var6[var8] = var2[var8]);
            }

            var1 = 3;
            var0 = 3;
        }

        InventoryCrafting var10 = newCraftingGrid(var0, var1, var6);

        for (int var9 = 0; var9 < pList.size(); ++var9)
        {
            if (isRecipeMatch(var9, var10))
            {
                pList.remove(var9);
                break;
            }
        }

        if (var3 != 0)
        {
            pList.add(var5 ? newRecipeNormal(var3, var4, var0, var1, var2) : newRecipeShapeless(var3, var4, var7));
        }
    }

    private static void parseRecipe(String var0, String var1, int var2)
    {
        String var3 = "";
        String[] var4 = var0.replaceAll("\\A[\\t ]*", "").replaceAll("[\\t ]*(|//.*)\\z", "").split("[ \\t]+");

        if (var4.length < 5)
        {
            if (var4.length != 1 && !var4[0].equals(""))
            {
                log("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - incomplete recipe definition");
            }
        }
        else
        {
            try
            {
                var3 = var4[0];
                int var5 = Integer.decode(var4[2]).intValue();
                int var6 = Integer.decode(var4[3]).intValue();
                int var7 = Integer.decode(var4[1]).intValue();
                int var8 = pNames.containsKey(var4[0]) ? ((Integer)pNames.get(var4[0])).intValue() : parseIdInfo(var4[0]);

                if (var8 < 0 || var7 < 0 || var8 > 0 && var7 <= 0)
                {
                    err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - bad recipe result");
                    return;
                }

                if (var8 != 0 && getItem(var8 & 65535) == null)
                {
                    log("warning: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - resulting item does not exist, recipe ignored");
                    return;
                }

                if (var6 != 0 && (var5 * var6 + 4 != var4.length || var5 <= 0 || var6 <= 0 || var5 > 3 || var6 > 3))
                {
                    err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid recipe size (" + var5 + "," + var6 + ")");
                    return;
                }

                if (var6 == 0 && (var5 + 4 != var4.length || var5 <= 0))
                {
                    err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid recipe size (" + var5 + ")");
                    return;
                }

                ItemStack[] var9 = new ItemStack[var5 * (var6 == 0 ? 1 : var6)];

                for (int var10 = 4; var10 < var4.length; ++var10)
                {
                    String var10000 = var4[var10];
                    int var11 = pNames.containsKey(var4[var10]) ? ((Integer)pNames.get(var4[var10])).intValue() : parseIdInfo(var4[var10]);

                    if (var11 == -1 || var6 == 0 && var11 == 0)
                    {
                        throw new Exception("(" + var11 + " " + var4[var10] + " " + (pNames.containsKey(var4[var10]) ? "+" : "-") + ")");
                    }

                    var9[var10 - 4] = var11 <= 0 ? null : newItemsE(var11, 1);
                }

                addRecipe(var5, var6, var9, var8, var7);
            }
            catch (Exception var12)
            {
                err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - \"" + var3 + "\" is unknown or malformed");
                err("???", var12);
            }
        }
    }

    private static void parseItems(String var0, String var1, int var2)
    {
        String[] var3 = var0.replaceAll("\\A[\\t ]*", "").replaceAll("[\\t ]*(|//.*)\\z", "").split("[ \\t]+");

        if (var3.length < 2)
        {
            if (var3.length == 1 && !var3[0].equals(""))
            {
                err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid items definition");
            }
        }
        else
        {
            int var5 = 0;
            int var6 = 0;
            int var7 = 0;
            int var8 = 0;
            int var9 = 0;
            int var10 = 0;
            int var11 = 0;
            float var12 = 0.0F;
            float var13 = 0.0F;
            float var14 = 0.0F;
            int var4 = (pNames.containsKey(var3[0]) ? ((Integer)pNames.get(var3[0])).intValue() : parseUnsigned(var3[0])) & 65535;
            Item var15;

            if (var4 <= 32000 && (var15 = getItem(var4)) != null)
            {
                if (!var3[1].equals("?"))
                {
                    var9 |= 1;
                    var5 = parseUnsigned(var3[1]);
                }

                if (var4 >= 256)
                {
                    if (var3.length > 2 && !var3[2].equals("?") && !getItemHasSubTypes(var15) && getItemDmgCap(var15) > 0)
                    {
                        var9 |= 2;
                        var6 = parseUnsigned(var3[2]);
                    }
                }
                else
                {
                    if (var3.length > 2 && !var3[2].equals("?"))
                    {
                        var9 |= 4;
                        var7 = parseUnsigned(var3[2]);
                    }

                    if (var3.length > 3 && !var3[3].equals("?"))
                    {
                        var9 |= 8;
                        var8 = parseUnsigned(var3[3]);
                    }

                    if (var3.length > 4 && !var3[4].equals("?"))
                    {
                        var9 |= 16;
                        var12 = parseFloat(var3[4], Float.NaN);
                    }

                    if (var3.length > 5 && !var3[5].equals("?"))
                    {
                        var9 |= 32;
                        var13 = parseFloat(var3[5], Float.NaN);
                    }

                    if (var3.length > 6 && !var3[6].equals("?"))
                    {
                        var9 |= 64;
                        var14 = parseFloat(var3[6], Float.NaN);
                    }

                    if (var3.length > 7 && !var3[7].equals("?"))
                    {
                        var9 |= 128;
                        var10 = parseUnsigned(var3[7]);
                    }

                    if (var3.length > 8 && !var3[8].equals("?"))
                    {
                        var9 |= 256;
                        var11 = parseUnsigned(var3[8]);
                    }
                }

                if ((var9 & 1) != 0 && (var5 < 1 || var5 > 64))
                {
                    err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid max stack size (\"" + var3[1] + "\")");
                }
                else if ((var9 & 2) != 0 && var6 < 1)
                {
                    err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid max damage (\"" + var3[2] + "\")");
                }
                else if ((var9 & 4) != 0 && (var7 < 0 || var7 > 15))
                {
                    err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid light emission (\"" + var3[2] + "\")");
                }
                else if ((var9 & 8) != 0 && (var8 < 0 || var8 > 255))
                {
                    err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid light reduction (\"" + var3[3] + "\")");
                }
                else if ((var9 & 16) != 0 && (Float.isNaN(var12) || var12 < -1.0F || var12 > 100.0F))
                {
                    err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid strength (\"" + var3[4] + "\")");
                }
                else if ((var9 & 32) != 0 && (Float.isNaN(var13) || var13 < 0.0F || var13 > 1.8E7F))
                {
                    err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid resistance (\"" + var3[5] + "\")");
                }
                else if ((var9 & 64) != 0 && (Float.isNaN(var14) || var14 < 0.5F || var14 > 1.0F))
                {
                    err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid slipperiness (\"" + var3[6] + "\")");
                }
                else if ((var9 & 128) != 0 && (var10 < 0 || var10 > 100))
                {
                    err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid fire spread value (\"" + var3[7] + "\")");
                }
                else if ((var9 & 256) != 0 && (var11 < 0 || var11 > 100))
                {
                    err("error: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - invalid burn speed value (\"" + var3[8] + "\")");
                }
                else
                {
                    ZMod$Mark var16 = itemMine[var4];

                    if ((var9 & 1) != 0)
                    {
                        var16.setMaxStack(var5);
                    }

                    if ((var9 & 2) != 0)
                    {
                        var16.setMaxDamage(var6);
                    }

                    if ((var9 & 4) != 0)
                    {
                        var16.setLightEmission(var7);
                    }

                    if ((var9 & 8) != 0)
                    {
                        var16.setLightReduction(var8);
                    }

                    if ((var9 & 16) != 0)
                    {
                        var16.setStrength(var12);
                    }

                    if ((var9 & 32) != 0)
                    {
                        var16.setResistance(var13);
                    }

                    if ((var9 & 64) != 0)
                    {
                        var16.setSlipperiness(var14);
                    }

                    if ((var9 & 128) != 0)
                    {
                        var16.setFireSpread(var10);
                    }

                    if ((var9 & 256) != 0)
                    {
                        var16.setFireBurn(var11);
                    }
                }
            }
            else
            {
                log("warning: " + var1 + " @ line#" + var2 + " \"" + var0 + "\" - item/block does not exist, definition ignored");
            }
        }
    }

    private static int[] parseRule(String var0)
    {
        String[] var1 = var0.split("[\t ]+");
        int[] var3 = new int[var1.length * 6];

        for (int var4 = 0; var4 < var1.length; ++var4)
        {
            String[] var2 = var1[var4].split("/");

            if (var2.length != 6)
            {
                modOreEnabled = false;
                err("error : ore-mod disabled - invalid ore rule found \"" + var0 + "\"");
                return null;
            }

            var3[var4 * 6 + 0] = (new Integer(var2[0])).intValue();
            var3[var4 * 6 + 1] = (new Integer(var2[1])).intValue();
            var3[var4 * 6 + 2] = (new Integer(var2[2])).intValue();
            var3[var4 * 6 + 3] = (new Integer(var2[3])).intValue();
            var3[var4 * 6 + 4] = (new Integer(var2[4])).intValue();
            var3[var4 * 6 + 5] = (new Integer(var2[5])).intValue();
        }

        return var3;
    }

    static HashMap access$000()
    {
        return names;
    }

    static int access$100(String var0)
    {
        return parseUnsigned(var0);
    }

    static Item access$200(int var0)
    {
        return getItem(var0);
    }

    static int access$300(Item var0)
    {
        return getItemMax(var0);
    }

    static int access$400(Item var0)
    {
        return getItemDmgCap(var0);
    }

    static int access$500(int var0)
    {
        return getBlockLight(var0);
    }

    static int access$600(int var0)
    {
        return getBlockOpacity(var0);
    }

    static Block access$700(int var0)
    {
        return getBlock(var0);
    }

    static float access$800(Block var0)
    {
        return getBlockStrength(var0);
    }

    static float access$900(Block var0)
    {
        return getBlockResist(var0);
    }

    static float access$1000(Block var0)
    {
        return getBlockSlip(var0);
    }

    static int access$1100(int var0)
    {
        return getFireBurn(var0);
    }

    static int access$1200(int var0)
    {
        return getFireSpread(var0);
    }

    static void access$1300(Item var0, int var1)
    {
        setItemMax(var0, var1);
    }

    static void access$1400(Item var0, int var1)
    {
        setItemDmgCap(var0, var1);
    }

    static void access$1500(int var0, int var1)
    {
        setBlockLight(var0, var1);
    }

    static void access$1600(int var0, int var1)
    {
        setBlockOpacity(var0, var1);
    }

    static void access$1700(Block var0, float var1)
    {
        setBlockStrength(var0, var1);
    }

    static void access$1800(Block var0, float var1)
    {
        setBlockResist(var0, var1);
    }

    static void access$1900(Block var0, float var1)
    {
        setBlockSlip(var0, var1);
    }

    static void access$2000(int var0, int var1)
    {
        setFireSpread(var0, var1);
    }

    static void access$2100(int var0, int var1)
    {
        setFireBurn(var0, var1);
    }

    static int access$2202(int var0)
    {
        optionSel = var0;
        return var0;
    }

    static void access$2300(ZMod$Options var0)
    {
        optionsMods(var0);
    }
}
