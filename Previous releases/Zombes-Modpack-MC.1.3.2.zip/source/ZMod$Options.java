package net.minecraft.src;

final class ZMod$Options extends GuiScreen
{
    public ZMod$Options()
    {
        ZMod.access$2202(-1);
    }

    /**
     * Draws the screen and all the components in it.
     */
    public void drawScreen(int var1, int var2, float var3)
    {
        ZMod.access$2300(this);
    }

    /**
     * Fired when a key is typed. This is the equivalent of KeyListener.keyTyped(KeyEvent e).
     */
    protected void keyTyped(char var1, int var2) {}
}
